# app/libs — Firefox Go core .aar

The file `core.aar` is NOT committed in this tree. At build time it is
placed here from the build server's gomobile trial bind:

    ~/armanlife-trial/core-trial.aar  ->  app/libs/core.aar

This app has no second Go runtime (no sing-box/libbox), so the full
trial .aar is used as-is — no class stripping is needed. The binding
class is `mobile.Mobile` and the native library is `libgojni.so`,
loaded by `GoCoreBinding` before any Mobile call.
