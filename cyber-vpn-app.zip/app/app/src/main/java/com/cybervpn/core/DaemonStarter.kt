package com.cybervpn.core

import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// Starts the core daemon (dashboard only, proxy off) and hands its
// local-API token to the dashboard client. The dashboard API refuses
// calls without the X-Local-Token header, and the token file appears
// only after the daemon is up, so callers must await it.
object DaemonStarter {
    suspend fun ensureDaemon(filesDir: File, api: DashboardApiClient): Boolean {
        return withContext(Dispatchers.IO) {
            val dir = GoCoreBinding.dataDir(filesDir)
            if (!GoCoreBinding.isRunning()) {
                runCatching { GoCoreBinding.startDaemon(dir) }
            }
            repeat(20) {
                val token = GoCoreBinding.readToken(dir)
                if (token != null) {
                    api.localToken = token
                    return@withContext true
                }
                delay(500)
            }
            false
        }
    }
}
