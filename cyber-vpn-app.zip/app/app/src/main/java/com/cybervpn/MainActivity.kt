package com.cybervpn

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.cybervpn.core.DaemonStarter
import com.cybervpn.core.DashboardApiClient
import com.cybervpn.core.SignInMachine
import com.cybervpn.core.SignInUiState
import com.cybervpn.service.LocalVpnService
import com.cybervpn.store.VpnStore
import com.cybervpn.ui.screens.AccountsScreen
import com.cybervpn.ui.screens.DashboardScreen
import com.cybervpn.ui.screens.ServerListScreen
import com.cybervpn.ui.screens.SignInScreen
import com.cybervpn.ui.screens.SmartRoutingScreen
import com.cybervpn.ui.theme.CyberVpnTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

enum class Tab(val title: String, val icon: String) {
    DASHBOARD("داشبورد", "🏠"),
    SERVERS("سرورها", "🌍"),
    ACCOUNTS("اکانت‌ها", "👤"),
    ROUTING("مسیریابی", "🛤️")
}

class MainActivity : ComponentActivity() {
    private val store = VpnStore()
    private val api = DashboardApiClient()
    private val machineScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val signInState = MutableStateFlow<SignInUiState>(SignInUiState.Idle)
    private lateinit var machine: SignInMachine

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            startTunnelService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        machine = SignInMachine(api, machineScope) { signInState.value = it }
        lifecycleScope.launch {
            DaemonStarter.ensureDaemon(filesDir, api)
        }
        setContent {
            CyberVpnTheme {
                val state by store.state.collectAsStateWithLifecycle()
                val signIn by signInState.collectAsStateWithLifecycle()
                var tab by remember { mutableStateOf(Tab.DASHBOARD) }
                if (signIn is SignInUiState.Done) {
                    LaunchedEffect(signIn) {
                        store.setSignedIn(true)
                    }
                }
                if (!state.signedIn) {
                    SignInScreen(
                        uiState = signIn,
                        onSignIn = { email, password -> machine.start(email, password) },
                        onAnswer = { code -> machine.answer(code) },
                        onCancel = { machine.cancel() }
                    )
                } else {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Box(modifier = Modifier.weight(1f)) {
                            when (tab) {
                                Tab.DASHBOARD -> DashboardScreen(
                                    state = state,
                                    onToggleConnection = { toggleTunnel() },
                                    onOpenServers = { tab = Tab.SERVERS }
                                )
                                Tab.SERVERS -> ServerListScreen(
                                    state = state,
                                    onSelectServer = { store.selectServer(it) }
                                )
                                Tab.ACCOUNTS -> AccountsScreen(
                                    state = state,
                                    onToggleAutoSwitch = { store.toggleAutoSwitch() }
                                )
                                Tab.ROUTING -> SmartRoutingScreen(
                                    state = state,
                                    onSetProtocol = { store.setProtocol(it) },
                                    onToggleBypassLocal = { store.toggleBypassLocal() },
                                    onToggleKillSwitch = { store.toggleKillSwitch() }
                                )
                            }
                        }
                        BottomNav(tab = tab, onTab = { tab = it })
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        machineScope.cancel()
        super.onDestroy()
    }

    private fun toggleTunnel() {
        if (store.state.value.isConnected) {
            val stop = Intent(this, LocalVpnService::class.java).apply {
                action = LocalVpnService.ACTION_STOP
            }
            startService(stop)
            store.toggleConnection()
            return
        }
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            vpnPermissionLauncher.launch(prepareIntent)
        } else {
            startTunnelService()
        }
    }

    private fun startTunnelService() {
        val start = Intent(this, LocalVpnService::class.java).apply {
            action = LocalVpnService.ACTION_START
        }
        startService(start)
        store.toggleConnection()
    }
}

@Composable
private fun BottomNav(tab: Tab, onTab: (Tab) -> Unit) {
    NavigationBar {
        for (item in Tab.values()) {
            NavigationBarItem(
                selected = tab == item,
                onClick = { onTab(item) },
                icon = { Text(text = item.icon) },
                label = { Text(text = item.title) }
            )
        }
    }
}
