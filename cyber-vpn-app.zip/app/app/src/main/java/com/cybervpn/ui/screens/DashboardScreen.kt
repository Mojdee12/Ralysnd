package com.cybervpn.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybervpn.store.VpnState
import com.cybervpn.ui.components.PowerButton
import com.cybervpn.ui.theme.CyberColors

@Composable
fun CyberCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberColors.BorderSubtle, RoundedCornerShape(24.dp)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CyberColors.Surface2)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            content()
        }
    }
}

fun formatDuration(totalSec: Long): String {
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return "%02d:%02d:%02d".format(h, m, s)
}

@Composable
fun DashboardScreen(
    state: VpnState,
    onToggleConnection: () -> Unit,
    onOpenServers: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        CyberCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .background(
                                if (state.isConnected) CyberColors.Emerald else CyberColors.TextMuted,
                                RoundedCornerShape(5.dp)
                            )
                    )
                    Text(
                        text = "  ms ${state.activeServer.ping}",
                        fontSize = 12.sp,
                        color = CyberColors.Emerald
                    )
                }
                Box(
                    modifier = Modifier.border(
                        1.dp,
                        CyberColors.Cyan.copy(alpha = 0.3f),
                        RoundedCornerShape(8.dp)
                    )
                ) {
                    Text(
                        text = state.protocol.label,
                        fontSize = 12.sp,
                        color = CyberColors.Cyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        CyberCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "وضعیت اتصال امن", fontSize = 12.sp, color = CyberColors.TextSecondary)
                    Text(
                        text = if (state.isConnected) "متصل به شبکه ابر موزیلا" else "تونل غیرفعال است",
                        fontSize = 14.sp,
                        color = if (state.isConnected) CyberColors.Emerald else CyberColors.TextSecondary
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "مدت زمان", fontSize = 12.sp, color = CyberColors.TextSecondary)
                    Text(
                        text = formatDuration(state.activeTimeSec),
                        fontSize = 14.sp,
                        color = CyberColors.TextPrimary
                    )
                }
            }
        }

        Box(
            modifier = Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            PowerButton(
                isConnected = state.isConnected,
                durationText = formatDuration(state.activeTimeSec),
                onToggle = onToggleConnection
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, CyberColors.BorderSubtle, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CyberColors.Surface2),
                onClick = onOpenServers
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "لوکیشن فعال", fontSize = 12.sp, color = CyberColors.TextSecondary)
                    Text(
                        text = "${state.activeServer.flag} ${state.activeServer.name}",
                        fontSize = 14.sp,
                        color = CyberColors.TextPrimary
                    )
                    Text(text = "تغییر سرور ←", fontSize = 10.sp, color = CyberColors.Cyan)
                }
            }
            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, CyberColors.BorderSubtle, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = CyberColors.Surface2)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "آی‌پی ماسک‌شده", fontSize = 12.sp, color = CyberColors.TextSecondary)
                    Text(
                        text = state.maskedIp,
                        fontSize = 14.sp,
                        color = CyberColors.TextPrimary
                    )
                    Text(text = "● محافظت نشت DNS", fontSize = 10.sp, color = CyberColors.Emerald)
                }
            }
        }

        CyberCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "تله‌متری زنده پهنای باند", fontSize = 12.sp, color = CyberColors.TextSecondary)
                Text(text = "Fastly Edge Network", fontSize = 12.sp, color = CyberColors.Cyan)
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberColors.Surface1)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "دانلود", fontSize = 12.sp, color = CyberColors.TextSecondary)
                        Text(
                            text = "${state.downloadSpeed} MB/s",
                            fontSize = 18.sp,
                            color = CyberColors.Cyan
                        )
                    }
                }
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberColors.Surface1)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = "آپلود", fontSize = 12.sp, color = CyberColors.TextSecondary)
                        Text(
                            text = "${state.uploadSpeed} MB/s",
                            fontSize = 18.sp,
                            color = CyberColors.Violet
                        )
                    }
                }
            }
        }
    }
}
