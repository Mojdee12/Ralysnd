package com.cybervpn.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp

// Cyber Dark & Neon Telemetry tokens, copied exactly from DESIGN.md.
// Font files (Space Grotesk / Inter / JetBrains Mono) are not bundled yet,
// so system sans/mono fallbacks stand in until the font files land.
object CyberColors {
    val Canvas = Color(0xFF07090E)
    val Surface1 = Color(0xFF0B0F17)
    val Surface2 = Color(0xFF111827)
    val Surface3 = Color(0xFF1E293B)
    val Cyan = Color(0xFF00F0FF)
    val Emerald = Color(0xFF05DF72)
    val Emerald2 = Color(0xFF44FB8A)
    val Violet = Color(0xFF8B5CF6)
    val Red = Color(0xFFEF4444)
    val Amber = Color(0xFFF59E0B)
    val TextPrimary = Color(0xFFF8FAFC)
    val TextSecondary = Color(0xFF94A3B8)
    val TextMuted = Color(0xFF475569)
    val BorderSubtle = Color(0xFF1E293B)
    val BorderHighlight = Color(0xFF334155)
}

private val CyberTypography = Typography(
    headlineLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 32.sp),
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 26.sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 20.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 12.sp),
    labelLarge = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 14.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 10.sp)
)

@Composable
fun CyberVpnTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = CyberColors.Canvas,
            surface = CyberColors.Surface2,
            surfaceVariant = CyberColors.Surface3,
            primary = CyberColors.Cyan,
            secondary = CyberColors.Emerald,
            tertiary = CyberColors.Violet,
            error = CyberColors.Red,
            onBackground = CyberColors.TextPrimary,
            onSurface = CyberColors.TextPrimary
        ),
        typography = CyberTypography,
        content = content
    )
}
