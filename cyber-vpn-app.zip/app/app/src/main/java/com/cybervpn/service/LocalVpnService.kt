package com.cybervpn.service

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import com.cybervpn.core.GoCoreBinding

class LocalVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTunnel()
            stopSelf()
            return START_NOT_STICKY
        }
        val builder = Builder()
        builder.setSession("CyberVPN")
            .addAddress("10.0.0.2", 24)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .setMtu(1500)
        val pfd = builder.establish() ?: return START_NOT_STICKY
        vpnInterface = pfd
        try {
            GoCoreBinding.startTunnel(pfd.detachFd())
        } catch (e: Exception) {
            pfd.close()
            vpnInterface = null
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    private fun stopTunnel() {
        runCatching { GoCoreBinding.stopTunnel() }
        vpnInterface?.close()
        vpnInterface = null
    }

    companion object {
        const val ACTION_START = "com.cybervpn.START"
        const val ACTION_STOP = "com.cybervpn.STOP"
    }
}
