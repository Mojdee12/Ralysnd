package com.cybervpn.model

enum class Protocol(val label: String) {
    HTTP3_QUIC("HTTP/3 QUIC"),
    HTTP2("HTTP/2"),
    SOCKS5("SOCKS5")
}

data class ServerItem(
    val id: String,
    val name: String,
    val country: String,
    val flag: String,
    val ping: Int,
    val load: Int,
    val recommended: Boolean = false
)

enum class AccountStatus {
    ACTIVE,
    STANDBY,
    EXHAUSTED
}

data class AccountItem(
    val id: String,
    val email: String,
    val usedGB: Double,
    val totalGB: Double,
    val status: AccountStatus,
    val renewDate: String
)
