package com.cybervpn.core

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

// Loopback client for the Firefox core daemon dashboard.
// All calls are blocking OkHttp: callers MUST run them on Dispatchers.IO,
// never on a Main-dispatcher scope (a main-thread network call throws
// NetworkOnMainThreadException instantly, before any packet is sent).
// The daemon requires the X-Local-Token header (its token file content);
// without it the dashboard refuses every call.
data class SigninView(
    val id: String,
    val status: String,
    val step: String,
    val errorCode: String,
    val error: String
)

class DashboardApiClient(
    private val baseUrl: String = "http://127.0.0.1:10820"
) {
    @Volatile
    var localToken: String? = null

    private val client = OkHttpClient()
    private val jsonType = "application/json".toMediaType()

    private fun builder(path: String): Request.Builder {
        val builder = Request.Builder().url(baseUrl + path)
        val token = localToken
        if (token != null) {
            builder.addHeader("X-Local-Token", token)
        }
        return builder
    }

    private fun get(path: String): String? {
        val request = builder(path).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            return response.body?.string()
        }
    }

    private fun post(path: String, json: String? = null): String? {
        val body = (json ?: "").toRequestBody(if (json == null) null else jsonType)
        val request = builder(path).post(body).build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            return response.body?.string()
        }
    }

    private fun delete(path: String): Boolean {
        val request = builder(path).delete().build()
        client.newCall(request).execute().use { response ->
            return response.isSuccessful
        }
    }

    fun startSignIn(email: String, password: String): String? {
        val json = JSONObject()
            .put("email", email)
            .put("password", password)
            .toString()
        val raw = post("/api/signin", json) ?: return null
        val id = JSONObject(raw).optString("id")
        return id.ifBlank { null }
    }

    fun getSignin(id: String): SigninView? {
        val raw = get("/api/signin/$id") ?: return null
        val obj = JSONObject(raw)
        return SigninView(
            id = id,
            status = obj.optString("status"),
            step = obj.optString("step"),
            errorCode = obj.optString("error_code"),
            error = obj.optString("error")
        )
    }

    fun answerSignin(id: String, value: String): Boolean {
        val json = JSONObject().put("value", value).toString()
        return post("/api/signin/$id", json) != null
    }

    fun cancelSignin(id: String): Boolean {
        return runCatching { delete("/api/signin/$id") }.getOrDefault(false)
    }

    fun getStatus(): String? {
        return get("/api/status")
    }

    fun getLocations(): String? {
        return get("/api/locations")
    }
}
