package com.cybervpn.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed interface SignInUiState {
    data object Idle : SignInUiState
    data object Starting : SignInUiState
    data class Waiting(val step: String, val prompt: String) : SignInUiState
    data class Failed(val message: String) : SignInUiState
    data object Done : SignInUiState
}

// One dashboard sign-in: start -> poll -> answer steps -> done/failed.
// Every network call runs on Dispatchers.IO, explicitly, even though the
// owning scope may be Main: a blocking OkHttp call on Main throws
// NetworkOnMainThreadException before any packet leaves the device.
class SignInMachine(
    private val api: DashboardApiClient,
    private val scope: CoroutineScope,
    private val onState: (SignInUiState) -> Unit
) {
    private var job: Job? = null
    private var currentId: String? = null

    fun start(email: String, password: String) {
        job?.cancel()
        onState(SignInUiState.Starting)
        job = scope.launch(Dispatchers.IO) {
            try {
                val id = api.startSignIn(email, password)
                    ?: throw IllegalStateException("Core did not return a sign-in id")
                currentId = id
                poll(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onState(SignInUiState.Failed(e.message ?: e.javaClass.simpleName))
            }
        }
    }

    fun answer(value: String) {
        val id = currentId ?: return
        job?.cancel()
        job = scope.launch(Dispatchers.IO) {
            try {
                api.answerSignin(id, value)
                poll(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onState(SignInUiState.Failed(e.message ?: e.javaClass.simpleName))
            }
        }
    }

    fun cancel() {
        val id = currentId
        currentId = null
        job?.cancel()
        job = null
        if (id != null) {
            scope.launch(Dispatchers.IO) {
                runCatching { api.cancelSignin(id) }
            }
        }
        onState(SignInUiState.Idle)
    }

    private suspend fun poll(id: String) {
        val deadline = System.currentTimeMillis() + 5 * 60 * 1000L
        while (currentId == id) {
            if (System.currentTimeMillis() > deadline) {
                onState(SignInUiState.Failed("Sign-in timed out"))
                return
            }
            val view = api.getSignin(id)
            if (view == null) {
                delay(1500)
                continue
            }
            when {
                view.status == "done" -> {
                    onState(SignInUiState.Done)
                    return
                }
                view.status == "failed" -> {
                    val detail = listOf(view.errorCode, view.error)
                        .filter { it.isNotBlank() }
                        .joinToString(": ")
                    onState(SignInUiState.Failed(detail.ifBlank { "Sign-in failed" }))
                    return
                }
                view.step.isNotBlank() -> {
                    onState(SignInUiState.Waiting(view.step, promptFor(view.step)))
                    return
                }
                else -> delay(1500)
            }
        }
    }

    private fun promptFor(step: String): String {
        return when (step) {
            "need_email_code" -> "کد ارسال‌شده به ایمیل را وارد کنید"
            "need_totp" -> "کد احراز هویت را وارد کنید"
            "need_captcha" -> "کد امنیتی را وارد کنید"
            "need_unblock_code" -> "کد رفع مسدودی را وارد کنید"
            "need_email_link" -> "لینک ارسال‌شده به ایمیل را تایید کنید"
            else -> step
        }
    }
}
