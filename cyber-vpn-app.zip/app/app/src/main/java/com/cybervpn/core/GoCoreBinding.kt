package com.cybervpn.core

import java.io.File
import mobile.Mobile

// Thin binding over the Firefox Go core (gomobile .aar).
// The binding class is mobile.Mobile; its exact statics were verified
// against the trial bind: start(dataDir, on), stop, running, setOn,
// connect, proxyAddress, startTun(fd), stopTun. The library is loaded
// before any Mobile call, so a missing native library fails here
// instead of crashing later inside Mobile's static init.
object GoCoreBinding {
    init {
        runCatching { System.loadLibrary("gojni") }
    }

    fun dataDir(filesDir: File): File {
        return File(filesDir, "gocore").apply { mkdirs() }
    }

    fun startDaemon(dataDir: File) {
        Mobile.start(dataDir.absolutePath, false)
    }

    fun stopDaemon() {
        runCatching { Mobile.stop() }
    }

    fun isRunning(): Boolean {
        return runCatching { Mobile.running() }.getOrDefault(false)
    }

    fun readToken(dataDir: File): String? {
        val file = File(dataDir, "local-api.token")
        if (!file.exists()) return null
        return file.readText().trim().ifBlank { null }
    }

    fun startTunnel(fd: Int) {
        Mobile.startTun(fd)
    }

    fun stopTunnel() {
        runCatching { Mobile.stopTun() }
    }

    fun setOn(on: Boolean) {
        Mobile.setOn(on)
    }

    fun connect() {
        Mobile.connect()
    }

    fun proxyAddress(): String {
        return runCatching { Mobile.proxyAddress() }.getOrDefault("")
    }
}
