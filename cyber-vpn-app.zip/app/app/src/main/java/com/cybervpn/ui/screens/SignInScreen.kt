package com.cybervpn.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybervpn.core.SignInUiState
import com.cybervpn.ui.theme.CyberColors

// Sign-in UI only. Passwords are never logged, never stored, and never
// placed in state — they travel only to the sign-in call and are dropped.
@Composable
fun SignInScreen(
    uiState: SignInUiState,
    onSignIn: (String, String) -> Unit,
    onAnswer: (String) -> Unit,
    onCancel: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(text = "ورود با حساب فایرفاکس", fontSize = 20.sp, color = CyberColors.TextPrimary)
        Text(
            text = "برای اتصال به شبکه موزیلا وارد شوید",
            fontSize = 14.sp,
            color = CyberColors.TextSecondary
        )
        when (uiState) {
            is SignInUiState.Waiting -> {
                Text(text = uiState.prompt, fontSize = 14.sp, color = CyberColors.TextPrimary)
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text(text = "کد") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { onAnswer(code) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "تایید")
                }
                OutlinedButton(
                    onClick = onCancel,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "لغو")
                }
            }
            is SignInUiState.Failed -> {
                Text(text = uiState.message, fontSize = 14.sp, color = CyberColors.Red)
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text(text = "ایمیل") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(text = "رمز") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { onSignIn(email, password) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "تلاش دوباره")
                }
            }
            is SignInUiState.Starting -> {
                Text(text = "در حال ورود...", fontSize = 14.sp, color = CyberColors.TextSecondary)
            }
            else -> {
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text(text = "ایمیل") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(text = "رمز") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = { onSignIn(email, password) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "ورود")
                }
            }
        }
    }
}
