package com.cybervpn.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybervpn.model.Protocol
import com.cybervpn.store.VpnState
import com.cybervpn.ui.theme.CyberColors

@Composable
fun SmartRoutingScreen(
    state: VpnState,
    onSetProtocol: (Protocol) -> Unit,
    onToggleBypassLocal: () -> Unit,
    onToggleKillSwitch: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(text = "TUNNEL & ROUTING PROTOCOL", fontSize = 16.sp, color = CyberColors.Cyan)

        CyberCard {
            Text(
                text = "پروتکل انتقال ترافیک هسته",
                fontSize = 12.sp,
                color = CyberColors.TextSecondary
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (proto in Protocol.values()) {
                    val selected = state.protocol == proto
                    Button(
                        onClick = { onSetProtocol(proto) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selected) {
                                CyberColors.Cyan.copy(alpha = 0.15f)
                            } else {
                                CyberColors.Surface1
                            },
                            contentColor = if (selected) {
                                CyberColors.Cyan
                            } else {
                                CyberColors.TextSecondary
                            }
                        )
                    ) {
                        Text(text = proto.label, fontSize = 12.sp)
                    }
                }
            }
        }

        CyberCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "دور زدن سایت‌های داخلی و بانکی",
                        fontSize = 14.sp,
                        color = CyberColors.TextPrimary
                    )
                    Text(
                        text = "عدم کسر ترافیک از سهمیه ۵۰ گیگ و حفظ سرعت لود بالا",
                        fontSize = 12.sp,
                        color = CyberColors.TextSecondary
                    )
                }
                Switch(checked = state.bypassLocalSites, onCheckedChange = { onToggleBypassLocal() })
            }
        }

        CyberCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "کلید اضطراری Kill Switch",
                        fontSize = 14.sp,
                        color = CyberColors.Red
                    )
                    Text(
                        text = "قطع کامل اینترنت در صورت افت ناگهانی تانل موزیلا",
                        fontSize = 12.sp,
                        color = CyberColors.TextSecondary
                    )
                }
                Switch(checked = state.killSwitch, onCheckedChange = { onToggleKillSwitch() })
            }
        }
    }
}
