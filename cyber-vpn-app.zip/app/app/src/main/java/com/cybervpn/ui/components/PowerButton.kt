package com.cybervpn.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybervpn.ui.theme.CyberColors

@Composable
fun PowerButton(
    isConnected: Boolean,
    durationText: String,
    onToggle: () -> Unit
) {
    val ringColor = if (isConnected) CyberColors.Emerald else CyberColors.BorderHighlight
    val centerBg = if (isConnected) Color(0xFF0E1F1B) else CyberColors.Surface1
    val centerText = if (isConnected) CyberColors.Emerald else CyberColors.TextSecondary
    Box(
        modifier = Modifier.size(264.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(264.dp)
                .border(1.dp, ringColor.copy(alpha = 0.3f), CircleShape)
        )
        Box(
            modifier = Modifier
                .size(208.dp)
                .border(1.dp, ringColor.copy(alpha = 0.5f), CircleShape)
        )
        Box(
            modifier = Modifier
                .size(176.dp)
                .clip(CircleShape)
                .background(centerBg)
                .border(2.dp, ringColor, CircleShape)
                .clickable { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "⏻", fontSize = 56.sp, color = centerText)
                Text(
                    text = if (isConnected) "CONNECTED" else "DISCONNECTED",
                    fontSize = 14.sp,
                    color = centerText
                )
                Text(
                    text = if (isConnected) durationText else "ضربه جهت اتصال",
                    fontSize = 12.sp,
                    color = CyberColors.TextSecondary
                )
            }
        }
    }
}
