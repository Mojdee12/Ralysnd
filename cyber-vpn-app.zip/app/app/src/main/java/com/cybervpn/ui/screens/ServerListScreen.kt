package com.cybervpn.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybervpn.model.ServerItem
import com.cybervpn.store.VpnState
import com.cybervpn.ui.theme.CyberColors

@Composable
fun ServerListScreen(
    state: VpnState,
    onSelectServer: (ServerItem) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val visible = state.servers.filter {
        query.isBlank() ||
            it.name.contains(query, ignoreCase = true) ||
            it.country.contains(query, ignoreCase = true)
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "NODE LOCATIONS (MOZILLA EDGES)",
            fontSize = 16.sp,
            color = CyberColors.Cyan
        )
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text(text = "جستجوی کشور یا شهر سرور...", fontSize = 12.sp) },
            modifier = Modifier.fillMaxWidth()
        )
        for (srv in visible) {
            val isSelected = state.activeServer.id == srv.id
            val pingColor = when {
                srv.ping < 30 -> CyberColors.Emerald
                srv.ping > 80 -> CyberColors.Amber
                else -> CyberColors.TextSecondary
            }
            CyberCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectServer(srv) },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = srv.flag, fontSize = 24.sp)
                        Column(modifier = Modifier.padding(start = 12.dp)) {
                            Text(text = srv.name, fontSize = 14.sp, color = CyberColors.TextPrimary)
                            Text(
                                text = "Load: ${srv.load}%",
                                fontSize = 12.sp,
                                color = CyberColors.TextSecondary
                            )
                        }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "${srv.ping} ms", fontSize = 12.sp, color = pingColor)
                        if (isSelected) {
                            Text(text = "متصل", fontSize = 10.sp, color = CyberColors.Cyan)
                        }
                    }
                }
            }
        }
    }
}
