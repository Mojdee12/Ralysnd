package com.cybervpn.store

import com.cybervpn.model.AccountItem
import com.cybervpn.model.AccountStatus
import com.cybervpn.model.Protocol
import com.cybervpn.model.ServerItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

// PLACEHOLDER data, copied from the spec for layout purposes only.
// These numbers are NOT real: real servers, accounts, speeds and IPs
// arrive from the Firefox core after sign-in. Never present them as real.
val placeholderServers = listOf(
    ServerItem("auto", "اتصال هوشمند (کمترین پینگ)", "Anycast", "⚡", 28, 30, true),
    ServerItem("de-fra", "فرانکفورت (آلمان #1)", "Germany", "🇩🇪", 34, 42),
    ServerItem("nl-ams", "آمستردام (هلند #2)", "Netherlands", "🇳🇱", 41, 56),
    ServerItem("fi-hel", "هلسینکی (فنلاند)", "Finland", "🇫🇮", 49, 24),
    ServerItem("fr-par", "پاریس (فرانسه)", "France", "🇫🇷", 52, 68),
    ServerItem("us-ash", "ویرجینیا (آمریکا)", "USA", "🇺🇸", 112, 74)
)

val placeholderAccounts = listOf(
    AccountItem("1", "user.node01@firefox.auth", 11.5, 50.0, AccountStatus.ACTIVE, "۱۴ روز مانده"),
    AccountItem("2", "alpha.relay@firefox.auth", 0.0, 50.0, AccountStatus.STANDBY, "آماده رزرو"),
    AccountItem("3", "cloud.tunnel@firefox.auth", 0.0, 50.0, AccountStatus.STANDBY, "آماده رزرو")
)

data class VpnState(
    val isConnected: Boolean = false,
    val connecting: Boolean = false,
    val signedIn: Boolean = false,
    val activeTimeSec: Long = 0,
    val activeServer: ServerItem = placeholderServers[1],
    val maskedIp: String = "—",
    val protocol: Protocol = Protocol.HTTP3_QUIC,
    val downloadSpeed: Double = 0.0,
    val uploadSpeed: Double = 0.0,
    val servers: List<ServerItem> = placeholderServers,
    val accounts: List<AccountItem> = placeholderAccounts,
    val autoSwitch: Boolean = true,
    val bypassLocalSites: Boolean = true,
    val killSwitch: Boolean = true
)

class VpnStore {
    private val _state = MutableStateFlow(VpnState())
    val state: StateFlow<VpnState> = _state.asStateFlow()

    fun toggleConnection() {
        _state.update { it.copy(isConnected = !it.isConnected) }
    }

    fun setSignedIn(value: Boolean) {
        _state.update { it.copy(signedIn = value) }
    }

    fun selectServer(server: ServerItem) {
        _state.update { it.copy(activeServer = server) }
    }

    fun setProtocol(protocol: Protocol) {
        _state.update { it.copy(protocol = protocol) }
    }

    fun toggleAutoSwitch() {
        _state.update { it.copy(autoSwitch = !it.autoSwitch) }
    }

    fun toggleBypassLocal() {
        _state.update { it.copy(bypassLocalSites = !it.bypassLocalSites) }
    }

    fun toggleKillSwitch() {
        _state.update { it.copy(killSwitch = !it.killSwitch) }
    }
}
