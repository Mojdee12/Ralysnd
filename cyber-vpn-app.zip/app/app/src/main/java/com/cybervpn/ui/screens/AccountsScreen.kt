package com.cybervpn.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybervpn.model.AccountStatus
import com.cybervpn.store.VpnState
import com.cybervpn.ui.theme.CyberColors

@Composable
fun AccountsScreen(
    state: VpnState,
    onToggleAutoSwitch: () -> Unit
) {
    val totalGB = state.accounts.sumOf { it.totalGB }
    val usedGB = state.accounts.sumOf { it.usedGB }
    val remainingGB = totalGB - usedGB
    val fraction = if (totalGB > 0) (remainingGB / totalGB).toFloat() else 0f
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "FIREFOX ACCOUNTS POOL", fontSize = 16.sp, color = CyberColors.Cyan)
            Text(text = "50GB / ACCOUNT", fontSize = 12.sp, color = CyberColors.Emerald)
        }

        CyberCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "مخزن تجمیعی فعال", fontSize = 12.sp, color = CyberColors.TextSecondary)
                Text(
                    text = "$remainingGB GB باقی‌مانده از $totalGB GB",
                    fontSize = 12.sp,
                    color = CyberColors.Cyan
                )
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(CyberColors.Surface1)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(fraction)
                        .height(10.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(CyberColors.Cyan, CyberColors.Emerald)
                            )
                        )
                )
            }
        }

        CyberCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "چرخش خودکار حساب‌ها (Auto-Switch)",
                        fontSize = 14.sp,
                        color = CyberColors.TextPrimary
                    )
                    Text(
                        text = "سوییچ خودکار به اکانت بعدی بعد از پایان ۵۰ گیگابایت",
                        fontSize = 12.sp,
                        color = CyberColors.TextSecondary
                    )
                }
                Switch(checked = state.autoSwitch, onCheckedChange = { onToggleAutoSwitch() })
            }
        }

        for (acc in state.accounts) {
            CyberCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = acc.email, fontSize = 12.sp, color = CyberColors.TextPrimary)
                    Text(
                        text = acc.status.name,
                        fontSize = 10.sp,
                        color = if (acc.status == AccountStatus.ACTIVE) {
                            CyberColors.Emerald
                        } else {
                            CyberColors.TextSecondary
                        }
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "مصرف: ${acc.usedGB} / ${acc.totalGB} GB",
                        fontSize = 12.sp,
                        color = CyberColors.TextSecondary
                    )
                    Text(text = acc.renewDate, fontSize = 12.sp, color = CyberColors.TextSecondary)
                }
            }
        }
    }
}
