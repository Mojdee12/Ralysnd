// New code written for the Ralysnd FENIX rebuild (Go-core integration).
// Package: com.kunk.singbox.gocore (new; the old FENIX
// package is deleted).
//
// This machine drives ONE dashboard sign-in: start → poll → answer steps
// → done/failed. The Go core owns the whole FxA flow; Kotlin only drives
// its waiting steps. No direct FxA HTTP call exists in Kotlin anymore.
// Step names and error codes below are the daemon's published vocabulary
// (signInView.step / error_code) — factual API surface, not copied code.
//
// VISIBLE LOG (fixes the empty-log bug): every diagnostic line goes
// through [onLog], which the ViewModel wires to BOTH the file-backed
// LogRepository (so Settings > Tools > Logs shows it) AND the FENIX tab's
// always-visible event strip. Never: bodies, tokens, emails, passwords,
// codes, challenge payloads, account ids.

package com.kunk.singbox.gocore

import com.kunk.singbox.repository.LogRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** UI states for one sign-in attempt. Carries no secrets. */
sealed interface GoSignInUiState {
    data object Idle : GoSignInUiState
    data object Starting : GoSignInUiState

    /** Waiting for the user to answer a daemon step. */
    data class WaitingStep(val signInId: String, val step: GoSignInView) : GoSignInUiState

    /** Waiting with no user action needed (daemon working / email-link wait). */
    data class Waiting(val signInId: String, val hint: String) : GoSignInUiState

    data object Answering : GoSignInUiState
    data class Done(val accountId: String) : GoSignInUiState
    data class Failed(val category: SignInFailureCategory, val detail: String = "") : GoSignInUiState
    data object Cancelled : GoSignInUiState
}

enum class SignInFailureCategory {
    WRONG_CREDENTIALS, NO_ACCOUNT, NO_PASSWORD, CODE_INVALID, TOO_MANY_ATTEMPTS,
    BLOCKED, NETWORK, TIMEOUT, UNKNOWN,
}

/**
 * Drives one dashboard sign-in: start → poll → answer steps → done/failed.
 * Owns the poll Job; callers cancel via [cancel] (which also DELETEs server-side).
 * The password is used only for the start request object, then dropped —
 * it is never put in state, logs, or saved state.
 */
class SignInStateMachine(
    private val api: DashboardApiClient,
    private val scope: CoroutineScope,
    private val onEvent: (GoSignInUiState) -> Unit = {},
    private val onLog: (level: String, message: String) -> Unit = { level, message ->
        // Default bridge: the store the Logs screen reads (addAlwaysLog
        // persists even when debug logging is off).
        LogRepository.getInstance().addAlwaysLog("$level [FENIX] $message")
    },
) {
    private val _state = MutableStateFlow<GoSignInUiState>(GoSignInUiState.Idle)
    val state: StateFlow<GoSignInUiState> = _state.asStateFlow()

    private var pollJob: Job? = null
    private var currentSignInId: String? = null

    private fun emit(next: GoSignInUiState) {
        _state.value = next
        onEvent(next)
    }

    private fun log(level: String, message: String) = onLog(level, message)

    /** Start a sign-in. Any in-flight attempt is cancelled first. */
    fun start(email: String, password: String) {
        cancel()
        emit(GoSignInUiState.Starting)
        log("INFO", "signin started")
        pollJob = scope.launch {
            try {
                val started = api.startSignIn(email, password)
                val id = started.id.ifBlank {
                    throw IllegalStateException("Dashboard returned no sign-in id")
                }
                currentSignInId = id
                pollLoop(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val category = classify(e)
                val detail = detailForException(e)
                log("ERROR", "signin failed category=$category" + detailSuffix(detail))
                emit(GoSignInUiState.Failed(category, detail))
            }
        }
    }

    private suspend fun pollLoop(id: String) {
        val deadlineMs = 5 * 60 * 1000L
        val startedAt = System.currentTimeMillis()
        var intervalMs = 1500L
        var pollCount = 0
        var consecutiveNetworkErrors = 0
        var lastPollError: String? = null
        while (scope.isActive) {
            if (System.currentTimeMillis() - startedAt > deadlineMs) {
                log("ERROR", "signin failed category=TIMEOUT")
                runCatching { api.cancelSignIn(id) }
                emit(GoSignInUiState.Failed(SignInFailureCategory.TIMEOUT))
                return
            }
            try {
                val view = api.getSignIn(id)
                consecutiveNetworkErrors = 0
                log("INFO", "poll step=${view.step}")
                when {
                    view.step == GoSignInStep.DONE -> {
                        val accountId = view.accountId.orEmpty()
                        log("INFO", "signin done")
                        emit(GoSignInUiState.Done(accountId))
                        return
                    }
                    view.step == GoSignInStep.FAILED -> {
                        val category = classifyErrorCode(view.errorCode, view.error)
                        val detail = daemonDetail(view.errorCode, view.error)
                        log("ERROR", "signin failed category=$category" + detailSuffix(detail))
                        emit(GoSignInUiState.Failed(category, detail))
                        return
                    }
                    view.step == GoSignInStep.CANCELLED -> {
                        log("INFO", "signin cancelled")
                        emit(GoSignInUiState.Cancelled)
                        emit(GoSignInUiState.Idle)
                        return
                    }
                    GoSignInStep.NEEDS_TYPED_ANSWER.contains(view.step) -> {
                        emit(GoSignInUiState.WaitingStep(id, view))
                        // No parking gate: answer() cancels this poll job
                        // and starts a fresh loop after posting the answer,
                        // so the loop simply re-polls (same state value,
                        // deduped by StateFlow) until answered/cancelled.
                    }
                    else -> {
                        emit(GoSignInUiState.Waiting(id, view.step.ifBlank { "working" }))
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Token-missing is a daemon/token state problem, NOT a
                // network strike: the daemon may have gone down mid
                // sign-in. Do not burn a strike on it; the loop keeps
                // polling until the 5-minute timeout ends it cleanly.
                if (e is IllegalStateException &&
                    e.message?.contains("Dashboard local token") == true
                ) {
                    log("ERROR", "poll token unavailable; daemon may be down")
                } else {
                    lastPollError = detailForException(e)
                    consecutiveNetworkErrors++
                    log("ERROR", "poll network error count=$consecutiveNetworkErrors")
                    if (consecutiveNetworkErrors >= 3) {
                        val detail = lastPollError?.let { "Poll failed 3 times: $it" }
                            ?: "Poll failed 3 times"
                        log("ERROR", "signin failed category=NETWORK detail=$detail")
                        emit(GoSignInUiState.Failed(SignInFailureCategory.NETWORK, detail))
                        return
                    }
                }
            }
            pollCount++
            if (pollCount > 40) intervalMs = 3000L
            delay(intervalMs)
        }
    }

    /** Answer the currently waiting step, then resume polling. */
    fun answer(value: String) {
        val id = currentSignInId ?: return
        val waiting = _state.value as? GoSignInUiState.WaitingStep ?: return
        emit(GoSignInUiState.Answering)
        log("INFO", "step=${waiting.step.step} answered")
        // The parked poll loop is cancelled here; a fresh loop starts below.
        pollJob?.cancel()
        pollJob = scope.launch {
            try {
                api.answerSignIn(id, value)
                pollLoop(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val category = classify(e)
                val detail = detailForException(e)
                log("ERROR", "answer failed category=$category" + detailSuffix(detail))
                emit(GoSignInUiState.Failed(category, detail))
            }
        }
    }

    /** Fail the current attempt immediately (e.g. core not ready, M3). */
    fun failNow(category: SignInFailureCategory, detail: String = "") {
        cancel()
        emit(GoSignInUiState.Failed(category, detail))
    }

    /** User cancel: DELETE server-side, stop polling, return to idle. */
    fun cancel() {
        pollJob?.cancel()
        pollJob = null
        val id = currentSignInId
        currentSignInId = null
        if (id != null) {
            log("INFO", "signin cancelled")
            scope.launch {
                runCatching { api.cancelSignIn(id) }
            }
        }
        if (_state.value !is GoSignInUiState.Idle) {
            emit(GoSignInUiState.Cancelled)
            emit(GoSignInUiState.Idle)
        }
    }

    /**
     * Short, safe failure detail for the dialog and logs: first line only,
     * truncated, with email addresses and long token-like runs redacted.
     * Never contains passwords, codes, or tokens.
     */
    private fun sanitizeDetail(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        var line = raw.lineSequence().firstOrNull()?.trim().orEmpty()
        line = EMAIL_PATTERN.replace(line, "[email]")
        line = TOKEN_PATTERN.replace(line, "[token]")
        if (line.length > MAX_DETAIL_CHARS) line = line.take(MAX_DETAIL_CHARS).trimEnd() + "…"
        return line
    }

    /** Raw detail for an exception: HTTP status for dashboard errors, else the message. */
    private fun detailForException(e: Exception): String {
        val api = e as? GoApiException
        if (api != null) {
            val inner = e.message
                ?.substringAfter("(", "")
                ?.removeSuffix(")")
                ?.trim()
                .orEmpty()
            val innerDetail = sanitizeDetail(inner)
            return if (innerDetail.isNotBlank()) "HTTP ${api.statusCode}: $innerDetail"
            else "HTTP ${api.statusCode}"
        }
        return sanitizeDetail(e.message).ifBlank { e.javaClass.simpleName }
    }

    /** Raw detail for a daemon FAILED step: error_code plus the daemon message. */
    private fun daemonDetail(errorCode: String?, error: String?): String {
        val code = errorCode?.trim().orEmpty()
        val msg = sanitizeDetail(error)
        return when {
            code.isNotBlank() && msg.isNotBlank() -> "$code: $msg"
            code.isNotBlank() -> code
            else -> msg
        }
    }

    private fun detailSuffix(detail: String): String =
        if (detail.isNotBlank()) " detail=$detail" else ""

    private fun classify(e: Exception): SignInFailureCategory {
        val msg = (e.message ?: "").lowercase()
        return when {
            "401" in msg || "403" in msg -> SignInFailureCategory.WRONG_CREDENTIALS
            "406" in msg -> SignInFailureCategory.BLOCKED
            "429" in msg -> SignInFailureCategory.TOO_MANY_ATTEMPTS
            "500" in msg || "502" in msg || "503" in msg || "504" in msg ->
                SignInFailureCategory.NETWORK
            "timeout" in msg || "timed out" in msg || "deadline" in msg ->
                SignInFailureCategory.TIMEOUT
            "certificate" in msg || "handshake" in msg || "tls" in msg || "ssl" in msg ->
                SignInFailureCategory.NETWORK
            "unreachable" in msg || "unable to resolve" in msg || "connection" in msg ||
                "failed to connect" in msg || "connect failed" in msg ||
                "no route to host" in msg || "socket" in msg || "reset" in msg ||
                "broken pipe" in msg || "dns" in msg || "resolve" in msg ||
                "unknownhost" in msg || "unknown host" in msg ->
                SignInFailureCategory.NETWORK
            else -> SignInFailureCategory.UNKNOWN
        }
    }

    private fun classifyErrorCode(code: String?, message: String?): SignInFailureCategory {
        return when (code) {
            GoSignInErrorCode.NO_ACCOUNT -> SignInFailureCategory.NO_ACCOUNT
            GoSignInErrorCode.WRONG_PASSWORD -> SignInFailureCategory.WRONG_CREDENTIALS
            GoSignInErrorCode.NO_PASSWORD -> SignInFailureCategory.NO_PASSWORD
            GoSignInErrorCode.WRONG_CODE, GoSignInErrorCode.WRONG_TOTP ->
                SignInFailureCategory.CODE_INVALID
            GoSignInErrorCode.TOO_MANY_ATTEMPTS, GoSignInErrorCode.TOO_MANY_CODES ->
                SignInFailureCategory.TOO_MANY_ATTEMPTS
            GoSignInErrorCode.UNBLOCK_REJECTED -> SignInFailureCategory.BLOCKED
            GoSignInErrorCode.TIMED_OUT -> SignInFailureCategory.TIMEOUT
            GoSignInErrorCode.NETWORK -> SignInFailureCategory.NETWORK
            else -> classifyMessageFallback(message)
        }
    }

    private fun classifyMessageFallback(message: String?): SignInFailureCategory {
        val msg = (message ?: "").lowercase()
        return when {
            "password" in msg || "credential" in msg -> SignInFailureCategory.WRONG_CREDENTIALS
            "code" in msg || "expired" in msg || "otp" in msg || "totp" in msg ->
                SignInFailureCategory.CODE_INVALID
            "block" in msg || "406" in msg || "not acceptable" in msg ||
                "forbidden" in msg || "denied" in msg -> SignInFailureCategory.BLOCKED
            "too many" in msg || "rate limit" in msg || "429" in msg ->
                SignInFailureCategory.TOO_MANY_ATTEMPTS
            "timeout" in msg || "timed out" in msg || "deadline" in msg ->
                SignInFailureCategory.TIMEOUT
            "no account" in msg || "no user" in msg || "unknown user" in msg ->
                SignInFailureCategory.NO_ACCOUNT
            "network" in msg || "unreachable" in msg || "connection" in msg ||
                "dns" in msg || "resolve" in msg || "tls" in msg || "ssl" in msg ||
                "certificate" in msg || "handshake" in msg ||
                "500" in msg || "502" in msg || "503" in msg ->
                SignInFailureCategory.NETWORK
            else -> SignInFailureCategory.UNKNOWN
        }
    }
}

private val EMAIL_PATTERN = Regex("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}")
private val TOKEN_PATTERN = Regex("[A-Za-z0-9_\\-]{32,}")
private const val MAX_DETAIL_CHARS = 120
