// New code written for the Ralysnd FENIX rebuild (Go-core integration).
// Package: com.kunk.singbox.gocore (new; the old FENIX
// package is deleted). The old FENIX ViewModel surface (signIn, connect,
// disconnect, ping all, fastest, select, refresh, signOut, remove, switch)
// is re-implemented here against the dashboard API with NEW names
// (GoCoreUiState / GoCoreViewModel) so a stale reference is a compile
// error, not a silent old-code path.
//
// No tokens, passwords, or codes are stored here. The password is passed
// straight to the sign-in machine's start call and dropped. Account
// emails are display data only (see GoCoreAccountStore); they are never
// logged.
//
// SEPARATE PROCESS (:gocore): this ViewModel runs in the main process,
// which already runs sing-box's Go runtime at startup. It MUST NEVER call
// GoCoreBinding (or any mobile.Mobile method): that would load libgojni.so
// — a second Go runtime — into the main process and kill it silently on
// tab open. Instead it drives the core ONLY through:
//  - startService intents to GoCoreDaemonService (:gocore) for daemon
//    start/stop and to GoCoreVpnService (:gocore) for tunnel start/stop;
//  - the daemon's loopback dashboard HTTP API (127.0.0.1:10820) for
//    accounts, locations, status, speeds, and exit country;
//  - VpnStateStore (MMKV multi-process) for tunnel mode/active/pending.
// The old GoCoreVpnService.transportState StateFlow is gone on purpose:
// a static StateFlow is per-process and would read stale (always
// default) in the main process. Connection state below is DERIVED from
// the cross-process store + dashboard on every poll tick.

package com.kunk.singbox.gocore

import android.app.Application
import android.content.Intent
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kunk.singbox.ipc.VpnStateStore
import com.kunk.singbox.manager.VpnServiceManager
import com.kunk.singbox.repository.LogRepository
import com.kunk.singbox.service.manager.VpnStopInitiator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Connection state shown on the FENIX tab. */
enum class GoConnectionState {
    DISCONNECTED, CONNECTING, CONNECTED, RECONNECTING, ERROR,
}

/** Full UI state for the new FENIX tab. */
data class GoCoreUiState(
    val accounts: List<GoAccount> = emptyList(),
    val activeAccountId: String? = null,
    val activeAccountEmail: String = "",
    val locations: List<GoLocation> = emptyList(),
    val selectedCountry: String = "",
    val connectionState: GoConnectionState = GoConnectionState.DISCONNECTED,
    val exitCountry: String? = null,
    val speedDownBps: Long = 0L,
    val speedUpBps: Long = 0L,
    val signIn: GoSignInUiState = GoSignInUiState.Idle,
    /**
     * Latest sign-in failure, kept on the tab even after the dialog is
     * dismissed (dismiss cancels the machine, which would otherwise erase
     * the reason). Cleared on the next attempt and on success.
     */
    val lastSignInFailure: GoSignInUiState.Failed? = null,
    val errorMessage: String? = null,
    val coreError: String? = null,
    val isRefreshing: Boolean = false,
    val isPinging: Boolean = false,
)

class GoCoreViewModel(application: Application) : AndroidViewModel(application) {

    private val app: Application = application
    private val endpoint = GoCoreEndpoint(goCoreDataDir(app))
    private val api = DashboardApiClient(endpoint)
    private val accountStore = GoCoreAccountStore.getInstance(app)

    val eventStore = FenixEventStore(app)

    private val _uiState = MutableStateFlow(GoCoreUiState())
    val uiState: StateFlow<GoCoreUiState> = _uiState.asStateFlow()

    private val signInMachine = SignInStateMachine(
        api = api,
        scope = viewModelScope,
        onEvent = { signInState ->
            _uiState.value = _uiState.value.copy(
                signIn = signInState,
                lastSignInFailure = when (signInState) {
                    is GoSignInUiState.Failed -> signInState
                    is GoSignInUiState.Starting,
                    is GoSignInUiState.Done -> null
                    else -> _uiState.value.lastSignInFailure
                },
            )
            if (signInState is GoSignInUiState.Done) {
                refreshAll()
            }
        },
        onLog = { level, message ->
            eventStore.append(level, message)
            LogRepository.getInstance().addAlwaysLog("$level [FENIX] $message")
        },
    )

    /** Sign-in state, for the sheet. */
    val signInState: StateFlow<GoSignInUiState> = signInMachine.state

    private var ensureJob: Job? = null
    private var statePollJob: Job? = null

    /**
     * Local connect intent: true from the moment the user taps connect
     * until the poll observes the tunnel up (CONNECTED), failed (ERROR),
     * or gone (DISCONNECTED). The poll needs this because the
     * cross-process store alone cannot tell "connect requested, service
     * not up yet" apart from "start failed, service never came up" —
     * [connectDeadlineMs] bounds the first case.
     */
    private var connecting: Boolean = false
    private var connectDeadlineMs: Long = 0L

    init {
        eventStore.load()
        startStatePolling()
        ensureCore()
    }

    private fun logEvent(level: String, message: String) {
        eventStore.append(level, message)
        LogRepository.getInstance().addAlwaysLog("$level [FENIX] $message")
    }

    /**
     * Make sure the daemon answers the dashboard API. Idempotent.
     *
     * SEPARATE PROCESS: the daemon is started in :gocore by
     * GoCoreDaemonService (proxy off, dashboard only) — this function
     * NEVER calls GoCoreBinding itself, because that would load
     * libgojni.so into the main process. The fast path is a live probe
     * (a dashboard call), never a flag: a stale flag would leave the API
     * dead until the app process is recreated (the old C2 lesson).
     */
    fun ensureCore() {
        if (ensureJob?.isActive == true) return
        ensureJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                // Fast path: the :gocore daemon already answers.
                if (runCatching { api.getStatus() }.isSuccess) {
                    refreshAll()
                    return@launch
                }
                ensureCoreNow()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        coreError = "FENIX core could not start",
                    )
                }
                logEvent("ERROR", "core start failed")
            }
        }
    }

    /**
     * Synchronous ensure, for callers that must not proceed until the
     * daemon + token are ready (see [startSignIn], M3). If a background
     * ensure is already in flight (e.g. from init), wait for it instead
     * of starting a second daemon. Throws on failure; callers surface it.
     * The daemon itself is started in :gocore via an intent; this process
     * only waits for the token file the daemon writes once bound.
     */
    private suspend fun ensureCoreNow() {
        // Never join our own job: ensureCore() itself runs this function
        // inside ensureJob, and joining self would suspend forever.
        val currentJob = currentCoroutineContext()[Job]
        ensureJob?.let { job ->
            if (job.isActive && job !== currentJob) {
                runCatching { job.join() }
            }
        }
        app.startService(
            Intent(app, GoCoreDaemonService::class.java).apply {
                action = GoCoreDaemonActions.ACTION_ENSURE_DAEMON
            },
        )
        // Start removes the old token file and writes a fresh one
        // once bound; wait briefly for it before the first call.
        endpoint.awaitToken(10_000L)
            ?: throw IllegalStateException("Dashboard local token unavailable")
        refreshAll()
    }

    /** Refresh accounts, locations, and status from the daemon. */
    fun refreshAll() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val accountsResp = api.getAccounts()
                val accounts = accountsResp.accounts.sortedBy { it.position }
                val active = accounts.firstOrNull { it.active }
                if (active != null) {
                    accountStore.saveActive(active.email, active.id)
                } else if (accounts.isEmpty()) {
                    accountStore.clear()
                }
                val locationsResp = runCatching { api.getLocations() }.getOrNull()
                val statusResp = runCatching { api.getStatus() }.getOrNull()
                withContext(Dispatchers.Main) {
                    val current = _uiState.value
                    val mergedLocations = mergePings(
                        locationsResp?.locations ?: current.locations,
                        current.locations,
                    )
                    _uiState.value = current.copy(
                        accounts = accounts,
                        activeAccountId = active?.id,
                        activeAccountEmail = active?.email.orEmpty(),
                        locations = mergedLocations,
                        selectedCountry = statusResp?.proxy?.countryCode
                            ?.takeIf { it.isNotBlank() }
                            ?: current.selectedCountry,
                        exitCountry = statusResp?.exit?.countryCode
                            ?.takeIf { it.isNotBlank() }
                            ?: statusResp?.proxy?.countryCode
                                ?.takeIf { it.isNotBlank() }
                            ?: current.exitCountry,
                        speedDownBps = statusResp?.traffic?.downRate ?: 0L,
                        speedUpBps = statusResp?.traffic?.upRate ?: 0L,
                        isRefreshing = false,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                logEvent("ERROR", "refresh failed")
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(isRefreshing = false)
                }
            }
        }
    }

    /** Keep old ping measurements when a locations refresh has none. */
    private fun mergePings(
        fresh: List<GoLocation>,
        previous: List<GoLocation>,
    ): List<GoLocation> {
        if (fresh.isEmpty()) return previous
        val oldByCode = previous.associateBy { it.code }
        return fresh.map { loc ->
            val old = oldByCode[loc.code]
            if (loc.pingMs == null && old?.pingMs != null) loc.copy(pingMs = old.pingMs) else loc
        }
    }

    /**
     * Poll tunnel state from cross-process sources every 3 s while this
     * ViewModel lives (tab open). Cross-process state cannot push, so it
     * must be polled; a 3 s tick bounds stale UI after connect/disconnect
     * (the old same-process flow was instant — this lag is the honest
     * price of the separate process). The loop never throws: a failed
     * tick just keeps the previous UI state.
     */
    private fun startStatePolling() {
        if (statePollJob?.isActive == true) return
        statePollJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                runCatching { refreshTunnelState() }
                delay(3_000L)
            }
        }
    }

    private fun stopStatePolling() {
        statePollJob?.cancel()
        statePollJob = null
    }

    /**
     * Derive connection state from the cross-process store
     * (VpnStateStore, MMKV multi-process) plus the dashboard API.
     * Never reads service statics — they are :gocore-local.
     *
     * Rules:
     * - mode GO_CORE + active → CONNECTED (tunnel up).
     * - mode GO_CORE + pending "starting" → CONNECTING.
     * - mode GO_CORE otherwise → CONNECTING while a connect is in flight,
     *   else DISCONNECTED (transient; the service always sets pending or
     *   clears the mode on every transition).
     * - mode != GO_CORE → ERROR while a connect is in flight past its
     *   deadline (the service never came up), else DISCONNECTED.
     * - A shown ERROR persists: only a new connect attempt (which sets
     *   CONNECTING) or an explicit disconnect clears it. Without this,
     *   the next tick would overwrite the error with DISCONNECTED.
     * - Stale-mode self-heal: mode GO_CORE with no dashboard answer and
     *   no system VPN transport (and not mid-start) means the :gocore
     *   process died without clearing the store — clear it and report
     *   DISCONNECTED instead of a stuck CONNECTED.
     */
    private suspend fun refreshTunnelState() {
        val mode = VpnStateStore.getMode()
        val active = VpnStateStore.getActive()
        val pending = VpnStateStore.getPending()
        val status = runCatching { api.getStatus() }.getOrNull()
        val current = _uiState.value

        if (mode == VpnStateStore.CoreMode.GO_CORE &&
            status == null &&
            pending != "starting"
        ) {
            if (!hasVpnTransport()) {
                // Provably dead tunnel with a stale store record: the
                // :gocore process died without clearing the store.
                VpnStateStore.setMode(VpnStateStore.CoreMode.NONE)
                VpnStateStore.setActive(false)
                VpnStateStore.setPending("")
                connecting = false
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        connectionState = GoConnectionState.DISCONNECTED,
                        speedDownBps = 0L,
                        speedUpBps = 0L,
                    )
                }
                return
            }
            // A VPN transport exists but the dashboard cannot confirm it
            // is ours (transient dashboard failure, or a foreign VPN):
            // hold the current state this tick rather than guessing.
            return
        }

        var derived = when {
            mode == VpnStateStore.CoreMode.GO_CORE && active ->
                GoConnectionState.CONNECTED
            mode == VpnStateStore.CoreMode.GO_CORE && pending == "starting" ->
                GoConnectionState.CONNECTING
            mode == VpnStateStore.CoreMode.GO_CORE ->
                if (connecting) GoConnectionState.CONNECTING
                else GoConnectionState.DISCONNECTED
            connecting && System.currentTimeMillis() <= connectDeadlineMs ->
                GoConnectionState.CONNECTING
            connecting -> GoConnectionState.ERROR
            else -> GoConnectionState.DISCONNECTED
        }
        if (derived == GoConnectionState.ERROR) {
            connecting = false
        } else if (derived == GoConnectionState.CONNECTED ||
            derived == GoConnectionState.DISCONNECTED
        ) {
            connecting = false
        }
        if (current.connectionState == GoConnectionState.ERROR &&
            derived == GoConnectionState.DISCONNECTED &&
            !connecting
        ) {
            // Keep a shown error until the user retries or disconnects.
            derived = GoConnectionState.ERROR
        }

        withContext(Dispatchers.Main) {
            val latest = _uiState.value
            _uiState.value = latest.copy(
                connectionState = derived,
                exitCountry = status?.exit?.countryCode
                    ?.takeIf { it.isNotBlank() }
                    ?: status?.proxy?.countryCode
                        ?.takeIf { it.isNotBlank() }
                    ?: latest.exitCountry,
                speedDownBps = status?.traffic?.downRate ?: latest.speedDownBps,
                speedUpBps = status?.traffic?.upRate ?: latest.speedUpBps,
                activeAccountEmail = status?.activeAccount?.email
                    ?: latest.activeAccountEmail,
                errorMessage = if (derived == GoConnectionState.ERROR &&
                    latest.connectionState != GoConnectionState.ERROR
                ) {
                    "Could not connect. Try again."
                } else {
                    latest.errorMessage
                },
            )
        }
    }

    /** True when Android reports a live VPN transport (any VPN, incl. ours). */
    private fun hasVpnTransport(): Boolean {
        val cm = app.getSystemService(ConnectivityManager::class.java) ?: return false
        return runCatching {
            cm.allNetworks.any { network ->
                cm.getNetworkCapabilities(network)
                    ?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
            }
        }.getOrDefault(false)
    }

    // ---- Sign-in (sheet) ----

    /**
     * M3: await daemon start + token BEFORE starting the state machine,
     * so the first sign-in cannot fail spuriously on a not-yet-written
     * token file. On core failure the dialog gets a clean failure instead
     * of a generic UNKNOWN from a dead loopback port.
     */
    fun startSignIn(email: String, password: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                ensureCoreNow()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                logEvent("ERROR", "signin failed: core not ready")
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        coreError = "FENIX core could not start",
                    )
                }
                signInMachine.failNow(SignInFailureCategory.NETWORK, "Core not ready")
                return@launch
            }
            signInMachine.start(email, password)
        }
    }

    fun answerSignInStep(value: String) {
        signInMachine.answer(value)
    }

    fun cancelSignIn() {
        signInMachine.cancel()
    }

    // ---- Accounts ----

    fun switchAccount(accountId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { api.activateAccount(accountId) }
            refreshAll()
        }
    }

    fun refreshAccount() {
        val id = _uiState.value.activeAccountId ?: return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { api.refreshAccount(id) }
            refreshAll()
        }
    }

    fun removeAccount(accountId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val isActive = accountId == _uiState.value.activeAccountId
            if (isActive && _uiState.value.connectionState == GoConnectionState.CONNECTED) {
                disconnectFenix()
            }
            runCatching { api.deleteAccount(accountId) }
            refreshAll()
        }
    }

    /** Sign out of the active account: stop the tunnel first, then remove it. */
    fun signOut() {
        val id = _uiState.value.activeAccountId ?: return
        removeAccount(id)
    }

    // ---- Locations ----

    fun selectCountry(countryCode: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { api.setLocation(countryCode) }
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(selectedCountry = countryCode)
            }
            refreshAll()
        }
    }

    /** User-visible notice line (connect errors, ping hints, permission). */
    fun showNotice(message: String) {
        _uiState.value = _uiState.value.copy(errorMessage = message)
    }

    /**
     * M2/M9: ping requires the proxy running (the daemon answers 409
     * otherwise), so gate on connected state with a visible message
     * instead of a silent log-only failure.
     */
    fun pingAllCountries() {
        if (_uiState.value.connectionState != GoConnectionState.CONNECTED) {
            showNotice("Connect FENIX first, then ping countries.")
            logEvent("ERROR", "ping all blocked: not connected")
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(isPinging = true, errorMessage = null)
            }
            try {
                val codes = _uiState.value.locations.map { it.code }
                val resp = api.pingLocations(codes)
                val pingByCode = resp.locations.associateBy { it.code }
                withContext(Dispatchers.Main) {
                    val current = _uiState.value
                    _uiState.value = current.copy(
                        locations = current.locations.map { loc ->
                            val ping = pingByCode[loc.code]
                            if (ping?.pingMs != null) loc.copy(pingMs = ping.pingMs) else loc
                        },
                        isPinging = false,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                logEvent("ERROR", "ping all failed")
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        isPinging = false,
                        errorMessage = "Ping failed. Try again.",
                    )
                }
            }
        }
    }

    /** Lowest measured ping; ties broken by list order (documented). */
    fun fastestCountry(): GoLocation? {
        return _uiState.value.locations
            .filter { it.pingMs != null && it.pingMs > 0 }
            .minByOrNull { it.pingMs ?: Long.MAX_VALUE }
    }

    // ---- Connect / disconnect (mutual exclusion, both directions) ----

    /**
     * Connect FENIX. The caller (screen) must have obtained VPN permission
     * via VpnService.prepare first. Stops sing-box first (bounded 10 s),
     * then starts the Go-core service. Never starts over a live sing-box.
     */
    fun connectSelected() {
        viewModelScope.launch(Dispatchers.IO) {
            connecting = true
            connectDeadlineMs = System.currentTimeMillis() + 15_000L
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(
                    connectionState = GoConnectionState.CONNECTING,
                    errorMessage = null,
                )
            }
            try {
                ensureCore()
                if (VpnStateStore.getMode() == VpnStateStore.CoreMode.VPN) {
                    VpnServiceManager.stopVpn(app, VpnStopInitiator.MODE_SWITCH)
                    val stopped = VpnServiceManager.awaitModeStopped(
                        VpnStateStore.CoreMode.VPN,
                        10_000L,
                    )
                    if (!stopped) {
                        throw IllegalStateException("sing-box did not stop in time")
                    }
                }
                VpnStateStore.setMode(VpnStateStore.CoreMode.GO_CORE)
                VpnStateStore.setPending("starting")
                app.startForegroundService(
                    Intent(app, GoCoreVpnService::class.java).apply {
                        action = GoCoreServiceActions.ACTION_START
                    },
                )
                logEvent("INFO", "connect requested")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                connecting = false
                VpnStateStore.setMode(VpnStateStore.CoreMode.NONE)
                VpnStateStore.setPending("")
                logEvent("ERROR", "connect failed")
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        connectionState = GoConnectionState.ERROR,
                        errorMessage = "Could not connect. Try again.",
                    )
                }
            }
        }
    }

    /** Disconnect FENIX (prompt stop; the service clears the owner record). */
    fun disconnectFenix() {
        viewModelScope.launch(Dispatchers.IO) {
            connecting = false
            runCatching {
                app.startService(
                    Intent(app, GoCoreVpnService::class.java).apply {
                        action = GoCoreServiceActions.ACTION_STOP
                    },
                )
            }
            logEvent("INFO", "disconnect requested")
            // If the tab was showing a start error, the service is (per the
            // store) already down, so clearing the error immediately cannot
            // flicker back; otherwise the poll drives DISCONNECTED once the
            // service clears the mode (within one 3 s tick).
            if (_uiState.value.connectionState == GoConnectionState.ERROR) {
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        connectionState = GoConnectionState.DISCONNECTED,
                        errorMessage = null,
                    )
                }
            }
        }
    }

    override fun onCleared() {
        signInMachine.cancel()
        stopStatePolling()
        // M8: the service owns the daemon while a tunnel runs, so a live
        // tunnel is never killed from here — but when the FENIX
        // destination is destroyed with NO tunnel active, ask the :gocore
        // daemon host to stop the daemon instead of leaving it listening
        // on loopback until the app process dies. (If the app's tab
        // navigation retains this ViewModel across tab switches, the
        // daemon stays up for an instant return to the tab; that path
        // is the navigation's retention behavior, not a leak here.)
        // The host re-checks the mode itself before stopping, so a tunnel
        // that started in the meantime is safe.
        if (VpnStateStore.getMode() != VpnStateStore.CoreMode.GO_CORE) {
            runCatching {
                app.startService(
                    Intent(app, GoCoreDaemonService::class.java).apply {
                        action = GoCoreDaemonActions.ACTION_STOP_DAEMON
                    },
                )
            }
        }
        super.onCleared()
    }
}
