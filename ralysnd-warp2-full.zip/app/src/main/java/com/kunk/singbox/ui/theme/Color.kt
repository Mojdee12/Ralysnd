package com.kunk.singbox.ui.theme

import androidx.compose.ui.graphics.Color

// Monochromatic OLED Palette
val OLEDBlack = Color(0xFF000000)
val Neutral950 = Color(0xFF0A0A0A)
val Neutral900 = Color(0xFF121212)
val Neutral800 = Color(0xFF262626)
val Neutral700 = Color(0xFF404040)
val Neutral600 = Color(0xFF525252)
val Neutral500 = Color(0xFF737373)
val Neutral400 = Color(0xFFA3A3A3)
val Neutral200 = Color(0xFFE5E5E5)
val PureWhite = Color(0xFFFFFFFF)

// Light Palette
val LightBackground = Color(0xFFF7F4EE)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEFF2F7)
val LightDivider = Color(0xFFE4E8EE)
val LightTextPrimary = Color(0xFF0F1E33)
val LightTextSecondary = Color(0xFF5B6B82)

val Red500 = Color(0xFFEF4444) // Destructive

// Semantic Colors (Deprecated, use MaterialTheme.colorScheme instead)
val AppBackground = OLEDBlack
val SurfaceCard = Neutral900
val SurfaceCardAlt = Neutral950
val Divider = Neutral800
val TextPrimary = PureWhite
val TextSecondary = Neutral500
val TextTertiary = Neutral700
val AccentWhite = PureWhite
val Destructive = Red500

// RALYSND DARK THEME 2026 — approved dark mockup: deep charcoal, emerald primary, violet secondary
val RalysndBackground = Color(0xFF0A0E14)
val RalysndSurface = Color(0xFF111827)
val RalysndSurfaceAlt = Color(0xFF182233)
val RalysndOutline = Color(0xFF1F2937)
val RalysndEmerald = Color(0xFF10B981)
val RalysndEmeraldBright = Color(0xFF34D399)
val RalysndViolet = Color(0xFF8B5CF6)
val RalysndVioletLight = Color(0xFFA78BFA)
