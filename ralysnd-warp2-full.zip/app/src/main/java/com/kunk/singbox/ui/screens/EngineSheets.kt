package com.kunk.singbox.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kunk.singbox.engines.ENGINE_GRID
import com.kunk.singbox.engines.EngineId
import com.kunk.singbox.engines.EnginesViewModel
import com.kunk.singbox.ui.navigation.Screen
import com.kunk.singbox.ui.theme.L4EngineTile
import com.kunk.singbox.ui.theme.L4Green
import com.kunk.singbox.ui.theme.L4PastelAmber
import com.kunk.singbox.ui.theme.L4PastelCyan
import com.kunk.singbox.ui.theme.L4PastelRose
import com.kunk.singbox.ui.theme.L4PastelSlate
import com.kunk.singbox.ui.theme.L4PastelViolet
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim

/**
 * Home engine grid (mlm-style, sample-4 light tiles) + per-engine
 * sheets. Only wanted engines appear here — no rejected engine has
 * a tile, placeholder, or reserved space. Plain WARP is NOT a
 * user-facing engine anymore: the grid is MASQUE, WARP², Psiphon,
 * WireGuard, FENIX, in that order. The WARP identity and
 * registration code still exist underneath because WARP² needs
 * them as its outer layer — but the user never sees a plain-WARP
 * tile, sheet, or label.
 *
 * Wiring (honest):
 * - WireGuard -> Nodes screen (existing nodes).
 * - FENIX -> FENIX tab (existing Foxy tunnel).
 * - WARP² -> ONE TAP, fully automatic: registers a WARP identity
 *   if none is stored, builds the two-outbound chain (outer WARP
 *   + inner WireGuard with detour, MTU 1220) in the profile store,
 *   selects the inner node, and starts it through the normal
 *   Dashboard path. Connected status is the real sing-box state.
 *   Disconnect is the normal Dashboard stop. No JSON copy step.
 * - MASQUE -> gateway discovery + cached winner (live connect
 *   needs a QUIC core — stated in the sheet, no connect button).
 * - Psiphon -> public server list + regions + sample probes
 *   (live connect needs the official Go core — stated, no button).
 */
@Composable
fun EngineGridSection(
    onNavigate: (String) -> Unit,
    onAddNode: (String) -> Unit,
    onOpenScanner: () -> Unit,
    enginesViewModel: EnginesViewModel = viewModel(),
    /** Called with the inner node id when a WARP² chain is ready; the caller selects it and starts the service. */
    onConnectNode: (String) -> Unit = {},
) {
    var sheet by remember { mutableStateOf<EngineId?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Engines", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = L4Text)
            TextButton(onClick = onOpenScanner) { Text("Scanner", color = L4Green) }
        }
        for (row in ENGINE_GRID.chunked(2)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (engine in row) {
                    L4EngineTile(
                        title = engine.title,
                        subtitle = engine.statusNote,
                        pastel = when (engine.id) {
                            EngineId.MASQUE -> L4PastelCyan
                            EngineId.WARP2 -> L4PastelAmber
                            EngineId.PSIPHON -> L4PastelRose
                            EngineId.WIREGUARD -> L4PastelSlate
                            EngineId.FENIX -> L4PastelViolet
                        },
                        badge = engine.badge,
                        enabled = true,
                        onClick = {
                            when (engine.id) {
                                EngineId.WIREGUARD -> onNavigate(Screen.Nodes.route)
                                EngineId.FENIX -> onNavigate(Screen.Fenix.route)
                                else -> sheet = engine.id
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (row.size == 1) Spacer(modifier = Modifier.weight(1f))
            }
        }
    }

    when (sheet) {
        EngineId.WARP2 -> Warp2Sheet(enginesViewModel = enginesViewModel, onConnectNode = onConnectNode, onDismiss = { sheet = null })
        EngineId.MASQUE -> MasqueSheet(enginesViewModel = enginesViewModel, onDismiss = { sheet = null })
        EngineId.PSIPHON -> PsiphonSheet(enginesViewModel = enginesViewModel, onDismiss = { sheet = null })
        else -> Unit
    }
}

@Composable
private fun Warp2Sheet(
    enginesViewModel: EnginesViewModel,
    onConnectNode: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val identity by enginesViewModel.warpIdentity.collectAsStateWithLifecycle()
    val busy by enginesViewModel.warp2Busy.collectAsStateWithLifecycle()
    val error by enginesViewModel.warp2Error.collectAsStateWithLifecycle()
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("51820") }
    var serverKey by remember { mutableStateOf("") }
    var privateKey by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("WARP²", color = L4Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "One tap: WireGuard inside WARP (MTU 1220). Enter YOUR inner server's details and tap Connect — a WARP identity is registered automatically if you do not have one yet, the chain is built, and the tunnel starts. Disconnect from the Dashboard like any other connection.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                if (identity == null) {
                    Text(
                        text = "No WARP identity stored yet — one will be registered automatically when you connect.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                }
                if (error != null) Text(text = error ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = host, onValueChange = { host = it }, label = { Text("Inner server host") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = port, onValueChange = { port = it }, label = { Text("Inner server port") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = serverKey, onValueChange = { serverKey = it }, label = { Text("Inner server public key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                OutlinedTextField(value = privateKey, onValueChange = { privateKey = it }, label = { Text("Your inner private key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(
                    onClick = {
                        val p = port.toIntOrNull() ?: 51820
                        if (host.isNotBlank() && serverKey.isNotBlank() && privateKey.isNotBlank()) {
                            enginesViewModel.connectWarp2(host, p, serverKey, privateKey) { nodeId ->
                                onConnectNode(nodeId)
                                onDismiss()
                            }
                        }
                    },
                    enabled = !busy && host.isNotBlank() && serverKey.isNotBlank() && privateKey.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text(if (busy) "Connecting…" else "Connect WARP²") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun MasqueSheet(
    enginesViewModel: EnginesViewModel,
    onDismiss: () -> Unit,
) {
    val results by enginesViewModel.masqueResults.collectAsStateWithLifecycle()
    val scanning by enginesViewModel.masqueScanning.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    var manual by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("MASQUE", color = L4Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "HTTP/3 with HTTP/2 fallback, MTU 1304, TLS chrome/compat. Discovery below is real (measured TCP probes, fastest cached). A live MASQUE connect still needs a QUIC core — this sheet does not fake one.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                OutlinedTextField(value = input, onValueChange = { input = it }, label = { Text("Gateways, comma-separated") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(
                    onClick = { enginesViewModel.scanMasque(input) },
                    enabled = !scanning && input.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text(if (scanning) "Scanning…" else "Discover gateways") }
                for (result in results) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = result.target.label, style = MaterialTheme.typography.bodySmall, color = L4Text, modifier = Modifier.weight(1f, fill = false))
                        Text(text = if (result.reachable) "${result.rttMs} ms" else "unreachable", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = L4Text)
                    }
                }
                enginesViewModel.masqueWinner?.let { winner ->
                    Text(text = "Cached winner: $winner", style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                }
                OutlinedTextField(value = manual, onValueChange = { manual = it }, label = { Text("Manual endpoint override") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                TextButton(onClick = { if (manual.isNotBlank()) enginesViewModel.setMasqueManualEndpoint(manual) }) { Text("Use manual endpoint") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun PsiphonSheet(
    enginesViewModel: EnginesViewModel,
    onDismiss: () -> Unit,
) {
    val summary by enginesViewModel.psiphonSummary.collectAsStateWithLifecycle()
    val busy by enginesViewModel.psiphonBusy.collectAsStateWithLifecycle()
    val error by enginesViewModel.psiphonError.collectAsStateWithLifecycle()
    val probes by enginesViewModel.psiphonProbeResults.collectAsStateWithLifecycle()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Psiphon", color = L4Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Public server list, regions, and sample probes. A live Psiphon tunnel needs the official Go core — this sheet does not fake a connection.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                if (error != null) Text(text = error ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Button(
                    onClick = { enginesViewModel.fetchPsiphonList() },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text(if (busy) "Downloading…" else "Fetch server list") }
                summary?.let { s ->
                    Text(
                        text = "List: ${s.bytesDownloaded} bytes" +
                            (s.entryCount?.let { ", ~$it sampled IPs" } ?: "") +
                            (s.regions.takeIf { it.isNotEmpty() }?.let { ", regions: ${it.joinToString(", ")}" } ?: ""),
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                    Button(
                        onClick = { enginesViewModel.probePsiphonSample() },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                    ) { Text("Probe sampled servers") }
                }
                for (result in probes) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = result.target.label, style = MaterialTheme.typography.bodySmall, color = L4Text, modifier = Modifier.weight(1f, fill = false))
                        Text(text = if (result.reachable) "${result.rttMs} ms" else "unreachable", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = L4Text)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
