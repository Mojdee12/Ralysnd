package com.kunk.singbox.engines

import android.content.Context
import com.tencent.mmkv.MMKV

/**
 * Local persistence for the user's own Cloudflare WARP identity.
 *
 * NOTE (same caveat as the Foxy TokenStore): MMKV storage is NOT
 * encrypted. The WARP private key lives here so the identity can be
 * reused across connects (deleting it would force re-registration and
 * lose the Cloudflare-side identity). Do not log these values.
 */
data class WarpIdentity(
    val accountId: String,
    val token: String,
    val privateKeyBase64: String,
    val publicKeyBase64: String,
    val reserved: List<Int>,
    val registeredAtMs: Long,
)

class WarpIdentityStore(context: Context) {
    private val kv = MMKV.mmkvWithID("ralysnd_warp", MMKV.SINGLE_PROCESS_MODE)

    fun load(): WarpIdentity? {
        val id = kv.decodeString("account_id", "")?.takeIf { it.isNotBlank() } ?: return null
        val token = kv.decodeString("token", "") ?: ""
        val priv = kv.decodeString("private_key", "")?.takeIf { it.isNotBlank() } ?: return null
        val pub = kv.decodeString("public_key", "")?.takeIf { it.isNotBlank() } ?: return null
        val reserved = kv.decodeString("reserved", "")
            ?.split(",")
            ?.mapNotNull { it.trim().toIntOrNull() }
            .orEmpty()
        return WarpIdentity(
            accountId = id,
            token = token,
            privateKeyBase64 = priv,
            publicKeyBase64 = pub,
            reserved = reserved,
            registeredAtMs = kv.decodeLong("registered_at", 0L),
        )
    }

    fun save(identity: WarpIdentity) {
        kv.encode("account_id", identity.accountId)
        kv.encode("token", identity.token)
        kv.encode("private_key", identity.privateKeyBase64)
        kv.encode("public_key", identity.publicKeyBase64)
        kv.encode("reserved", identity.reserved.joinToString(","))
        kv.encode("registered_at", identity.registeredAtMs)
    }

    fun clear() {
        kv.clearAll()
    }
}
