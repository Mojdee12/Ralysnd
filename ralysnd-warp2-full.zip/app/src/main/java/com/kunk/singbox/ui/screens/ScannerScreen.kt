package com.kunk.singbox.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.kunk.singbox.engines.EnginesViewModel
import com.kunk.singbox.engines.ScanResult
import com.kunk.singbox.ui.theme.L4Background
import com.kunk.singbox.ui.theme.L4GlassCard
import com.kunk.singbox.ui.theme.L4Green
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim

/**
 * Scanner tab (sample-4 bottom nav: Scanner).
 *
 * One scanner per wanted engine — MASQUE, WARP², Psiphon — each
 * probing candidates on the REAL line (TCP connect timing via
 * EngineScanner), streaming results live as they arrive, ordering
 * fastest-first, and caching the winner for the next connect
 * (manual override = tapping / typing a different endpoint).
 * No value here is invented: unreachable targets show as
 * unreachable, never as a made-up latency.
 *
 * WARP² note shown in its section: a TCP probe measures
 * reachability only, not a WireGuard handshake.
 */
@Composable
fun ScannerScreen(
    navController: NavController,
    viewModel: EnginesViewModel = viewModel(),
    bottomContentPadding: Dp = 0.dp,
) {
    val context = LocalContext.current
    val masqueResults by viewModel.masqueResults.collectAsStateWithLifecycle()
    val masqueScanning by viewModel.masqueScanning.collectAsStateWithLifecycle()
    val warp2Results by viewModel.warp2Results.collectAsStateWithLifecycle()
    val warp2Scanning by viewModel.warp2Scanning.collectAsStateWithLifecycle()
    val psiphonSummary by viewModel.psiphonSummary.collectAsStateWithLifecycle()
    val psiphonBusy by viewModel.psiphonBusy.collectAsStateWithLifecycle()
    val psiphonError by viewModel.psiphonError.collectAsStateWithLifecycle()
    val psiphonProbes by viewModel.psiphonProbeResults.collectAsStateWithLifecycle()

    var masqueInput by remember { mutableStateOf("") }
    var warp2Input by remember { mutableStateOf("") }
    var manualMasque by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(L4Background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
            .padding(bottom = bottomContentPadding),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(
            text = "RALYSND",
            style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.ExtraBold),
            color = L4Text,
        )
        Text(
            text = "Scanner — measure before you connect. Fastest first, nothing invented.",
            style = MaterialTheme.typography.bodyMedium,
            color = L4TextDim,
        )

        // ---- MASQUE ----
        L4GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "MASQUE scanner", fontWeight = FontWeight.Bold, color = L4Text)
                Text(
                    text = "Enter gateways (host or host:port, comma-separated). The fastest reachable one is cached as the winner.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                OutlinedTextField(
                    value = masqueInput,
                    onValueChange = { masqueInput = it },
                    label = { Text("Gateways, e.g. gateway.example.com:443") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                Button(
                    onClick = { viewModel.scanMasque(masqueInput) },
                    enabled = !masqueScanning && masqueInput.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green, contentColor = L4Background),
                ) { Text(if (masqueScanning) "Scanning…" else "Scan MASQUE", fontWeight = FontWeight.Bold) }
                if (masqueScanning) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = L4Green)
                ScanResultList(results = masqueResults)
                viewModel.masqueWinner?.let { winner ->
                    Text(text = "Cached winner: $winner", style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                }
                OutlinedTextField(
                    value = manualMasque,
                    onValueChange = { manualMasque = it },
                    label = { Text("Manual override endpoint") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                TextButton(onClick = {
                    if (manualMasque.isNotBlank()) viewModel.setMasqueManualEndpoint(manualMasque)
                }) { Text("Use manual endpoint") }
            }
        }

        // ---- WARP² ----
        L4GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "WARP² scanner", fontWeight = FontWeight.Bold, color = L4Text)
                Text(
                    text = "Enter inner WireGuard servers (host:port) for the WARP² path — inner server reached through WARP. TCP reachability only — it does not prove a WireGuard handshake. Fastest reachable first.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                OutlinedTextField(
                    value = warp2Input,
                    onValueChange = { warp2Input = it },
                    label = { Text("Inner servers, e.g. 203.0.113.10:51820") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                )
                Button(
                    onClick = { viewModel.scanWarp2(warp2Input) },
                    enabled = !warp2Scanning && warp2Input.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green, contentColor = L4Background),
                ) { Text(if (warp2Scanning) "Scanning…" else "Scan WARP²", fontWeight = FontWeight.Bold) }
                if (warp2Scanning) LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = L4Green)
                ScanResultList(results = warp2Results)
            }
        }

        // ---- Psiphon ----
        L4GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "Psiphon scanner", fontWeight = FontWeight.Bold, color = L4Text)
                Text(
                    text = "Downloads the public Psiphon server list, extracts regions, and probes a sample of its servers (TCP 443). Live connect needs the official Go core — not claimed here.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                Button(
                    onClick = { viewModel.fetchPsiphonList() },
                    enabled = !psiphonBusy,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green, contentColor = L4Background),
                ) { Text(if (psiphonBusy) "Downloading…" else "Fetch server list", fontWeight = FontWeight.Bold) }
                if (psiphonError != null) {
                    Text(text = psiphonError ?: "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
                psiphonSummary?.let { summary ->
                    Text(
                        text = "List: ${summary.bytesDownloaded} bytes" +
                            (summary.entryCount?.let { ", ~$it sampled IPs" } ?: "") +
                            (summary.regions.takeIf { it.isNotEmpty() }?.let { ", regions: ${it.joinToString(", ")}" } ?: ""),
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                    Button(
                        onClick = { viewModel.probePsiphonSample() },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = L4Green, contentColor = L4Background),
                    ) { Text("Probe sampled servers") }
                }
                ScanResultList(results = psiphonProbes)
                Spacer(modifier = Modifier.height(4.dp))
                TextButton(onClick = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Ralysnd", "Scanner results are measured on-device; see the app."))
                }) { Text("Copy note") }
            }
        }
    }
}

@Composable
private fun ScanResultList(results: List<ScanResult>) {
    if (results.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (result in results) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(
                    text = result.target.label,
                    style = MaterialTheme.typography.bodySmall,
                    color = L4Text,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Text(
                    text = if (result.reachable) "${result.rttMs} ms" else "unreachable",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    color = if (result.reachable) L4Text else MaterialTheme.colorScheme.error,
                )
            }
        }
    }
}
