package com.kunk.singbox.engines

import android.content.Context
import com.tencent.mmkv.MMKV
import java.io.ByteArrayInputStream
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * Psiphon engine — server-list fetch, region extraction, and bench
 * scaffolding. Fresh code, no other app's Psiphon code vendored.
 *
 * What is real here: downloading the PUBLIC Psiphon server list
 * (the same public compressed list Psiphon's own clients use),
 * counting entries and extracting regions from it, caching the
 * summary, and probing a small sample of extracted servers so the
 * user sees measured values only.
 *
 * What is NOT here, stated plainly: a live Psiphon tunnel. That
 * needs the official Psiphon client library (Go, via its Android
 * PsiphonTunnel JNI wrapper) built into this app — a gomobile/JNI
 * integration that cannot be verified without a real Gradle build
 * and would be irresponsible to half-wire statically. Until that
 * binding lands, this screen shows the list + regions + measured
 * probes and refuses to claim a connection.
 */
data class PsiphonListSummary(
    val bytesDownloaded: Int,
    /** Entry count when the list could be parsed, else null. */
    val entryCount: Int?,
    val regions: List<String>,
    val fetchedAtMs: Long,
    /** Sampled server IPs extracted from the list (at most 20). */
    val sampleIps: List<String>,
)

class PsiphonEngine(context: Context) {
    private val kv = MMKV.mmkvWithID("ralysnd_psiphon", MMKV.SINGLE_PROCESS_MODE)

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    companion object {
        /** Public Psiphon server list (public URL, no key material). */
        const val PUBLIC_SERVER_LIST_URL =
            "https://s3.amazonaws.com/psiphon/web/iohq-waa4-q4dt/server_list_compressed"
        private val IP_REGEX = Regex("\"ipAddress\"\\s*:\\s*\"([0-9.]+)\"")
        private val REGION_REGEX = Regex("\"region\"\\s*:\\s*\"([A-Z]{2})\"")
    }

    fun cachedSummary(): PsiphonListSummary? {
        val bytes = kv.decodeInt("bytes", 0)
        if (bytes <= 0) return null
        val regions = kv.decodeString("regions", "")
            ?.split(",")
            ?.filter { it.isNotBlank() }
            .orEmpty()
        return PsiphonListSummary(
            bytesDownloaded = bytes,
            entryCount = kv.decodeInt("entries", -1).takeIf { it >= 0 },
            regions = regions,
            fetchedAtMs = kv.decodeLong("fetched_at", 0L),
            sampleIps = kv.decodeString("sample_ips", "")
                ?.split(",")
                ?.filter { it.isNotBlank() }
                .orEmpty(),
        )
    }

    /** Downloads the public list and returns a parsed summary. */
    suspend fun fetchServerList(): PsiphonListSummary = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(PUBLIC_SERVER_LIST_URL).build()
        val raw = http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Psiphon server list failed: HTTP ${response.code}")
            }
            response.body?.bytes() ?: ByteArray(0)
        }
        val text = decompressIfNeeded(raw)
        val ips = IP_REGEX.findAll(text).map { it.groupValues[1] }.distinct().take(20).toList()
        val regions = REGION_REGEX.findAll(text).map { it.groupValues[1] }.distinct().sorted().toList()
        val entries = if (ips.isNotEmpty()) ips.size else null
        kv.encode("bytes", raw.size)
        kv.encode("entries", entries ?: -1)
        kv.encode("regions", regions.joinToString(","))
        kv.encode("sample_ips", ips.joinToString(","))
        kv.encode("fetched_at", System.currentTimeMillis())
        PsiphonListSummary(
            bytesDownloaded = raw.size,
            entryCount = entries,
            regions = regions,
            fetchedAtMs = System.currentTimeMillis(),
            sampleIps = ips,
        )
    }

    private fun decompressIfNeeded(raw: ByteArray): String {
        return try {
            if (raw.size >= 2 && raw[0] == 0x1f.toByte() && raw[1] == 0x8b.toByte()) {
                GZIPInputStream(ByteArrayInputStream(raw)).readBytes().toString(Charsets.UTF_8)
            } else {
                raw.toString(Charsets.UTF_8)
            }
        } catch (_: Exception) {
            raw.toString(Charsets.UTF_8)
        }
    }
}
