package com.kunk.singbox.engines

import android.content.Context
import com.tencent.mmkv.MMKV
import com.kunk.singbox.utils.TcpPing

/**
 * MASQUE engine — configuration, gateway discovery, and winner cache.
 *
 * What is real here: the config model (transport, TLS profile,
 * fragmentation, MTU 1304 from the mlm extraction), live TCP
 * reachability probing of candidate gateways the user supplies (or
 * that were previously cached), fastest-first ordering, and a cached
 * winner reused on the next connect attempt.
 *
 * What is NOT here, stated plainly: a live MASQUE data plane. A real
 * MASQUE connect needs a QUIC stack speaking HTTP/3 CONNECT-UDP with
 * an HTTP/2 fallback (e.g. a quic-go / quiche-based native core, or
 * Xray's MASQUE support wired as a separate process core). This
 * codebase has Netty (no QUIC) and sing-box (no MASQUE outbound), so
 * adding a fake "connected" state would be dishonest. The discovery
 * flow below is the part that can be verified today, and it is what
 * a future QUIC core will consume: [MasqueConfig.endpoint].
 *
 * No gateway list is invented: candidates come only from the user's
 * manual endpoint, from a previously cached winner, or from endpoints
 * the user pastes in. Cloudflare's own MASQUE endpoint is not
 * hard-coded because mlm's own finding was that gateways must be
 * discovered by scanning, not assumed.
 */
enum class MasqueTransport { AUTO_H3_THEN_H2, HTTP3, HTTP2, SPLIT_HTTP2 }
enum class MasqueTlsProfile { CHROME, COMPAT }

data class MasqueConfig(
    val transport: MasqueTransport = MasqueTransport.AUTO_H3_THEN_H2,
    val tlsProfile: MasqueTlsProfile = MasqueTlsProfile.CHROME,
    val fragmentH2: Boolean = true,
    val mtu: Int = 1304,
    /** host:port of the discovered gateway, null until discovery runs. */
    val endpoint: String? = null,
)

data class GatewayProbe(
    val endpoint: String,
    /** TCP connect RTT in ms, or -1 when unreachable. Never invented. */
    val rttMs: Long,
    val reachable: Boolean,
)

class MasqueEngine(context: Context) {
    private val kv = MMKV.mmkvWithID("ralysnd_masque", MMKV.SINGLE_PROCESS_MODE)

    var config: MasqueConfig
        get() {
            val endpoint = kv.decodeString("winner_endpoint", "")?.takeIf { it.isNotBlank() }
            return MasqueConfig(endpoint = endpoint)
        }
        private set(value) {
            if (value.endpoint != null) kv.encode("winner_endpoint", value.endpoint)
        }

    /** Cached discovery winner, if any. */
    val cachedWinner: String?
        get() = kv.decodeString("winner_endpoint", "")?.takeIf { it.isNotBlank() }

    val cachedWinnerRttMs: Long
        get() = kv.decodeLong("winner_rtt", -1L)

    /**
     * Probes each candidate (host or host:port, default port 443)
     * with a real TCP connect and returns results fastest-first
     * (unreachable last). The winner is cached for the next attempt.
     * Emits live: callers should collect [EngineScanner.scan] instead
     * for streaming; this is the one-shot variant.
     */
    suspend fun probeCandidates(candidates: List<String>): List<GatewayProbe> {
        val results = candidates.map { raw ->
            val (host, port) = parseHostPort(raw)
            val rtt = if (host.isBlank()) -1L else TcpPing.connect(host, port, timeout = 3000)
            GatewayProbe(endpoint = raw, rttMs = rtt, reachable = rtt >= 0)
        }
        val sorted = results.sortedWith(
            compareBy<GatewayProbe> { !it.reachable }.thenBy { if (it.rttMs < 0) Long.MAX_VALUE else it.rttMs },
        )
        sorted.firstOrNull { it.reachable }?.let { winner ->
            kv.encode("winner_endpoint", winner.endpoint)
            kv.encode("winner_rtt", winner.rttMs)
            config = config.copy(endpoint = winner.endpoint)
        }
        return sorted
    }

    fun setManualEndpoint(endpoint: String) {
        val trimmed = endpoint.trim()
        if (trimmed.isNotBlank()) {
            kv.encode("winner_endpoint", trimmed)
            kv.encode("winner_rtt", -1L)
            config = config.copy(endpoint = trimmed)
        }
    }

    companion object {
        fun parseHostPort(raw: String): Pair<String, Int> {
            val trimmed = raw.trim()
            val lastColon = trimmed.lastIndexOf(':')
            if (lastColon > 0) {
                val port = trimmed.substring(lastColon + 1).toIntOrNull()
                if (port != null) return trimmed.substring(0, lastColon) to port
            }
            return trimmed to 443
        }
    }
}
