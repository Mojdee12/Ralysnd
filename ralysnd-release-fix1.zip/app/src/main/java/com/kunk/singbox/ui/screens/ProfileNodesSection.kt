package com.kunk.singbox.ui.screens

// Nodes section of the single configs tab (Profiles). This is the whole
// Nodes tab's content, moved here when the Nodes tab was removed
// (2026-10-30): browsing/managing nodes, fastest node, connect tile,
// search/sort/filter, test-all, clear latency, add-node flows. It renders
// as full-span items inside ProfilesScreen's 2-column grid, below the
// approved profile tiles, so the grid itself is untouched.
//
// What did NOT move here (see the coordinator report):
// - The FAB menu: replaced by the actions row below (same six actions).
// - "Locate current node": it needs a LazyColumn item index; the grid
//   has no equivalent scroll math, so it is an open decision, not a
//   silent drop.
// - The per-row entrance fade: cosmetic only, not re-implemented.
// - The search bar's scroll-collapse: the grid has no list state to
//   collapse on; the search item stays visible with its own toggle.

import android.content.Context
import com.kunk.singbox.R
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FilterAlt
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.kunk.singbox.ipc.SingBoxRemote
import com.kunk.singbox.model.AppSettings
import com.kunk.singbox.model.ConnectionState
import com.kunk.singbox.model.FilterMode
import com.kunk.singbox.model.NodeFilter
import com.kunk.singbox.model.NodeSortType
import com.kunk.singbox.model.NodeUi
import com.kunk.singbox.model.ProfileUi
import com.kunk.singbox.ui.components.AppNotificationManager
import com.kunk.singbox.ui.components.ConfirmDialog
import com.kunk.singbox.ui.components.ExpandableSearchBar
import com.kunk.singbox.ui.components.InputDialog
import com.kunk.singbox.ui.components.NodeCard
import com.kunk.singbox.ui.components.NodeFilterDialog
import com.kunk.singbox.ui.components.SingleSelectDialog
import com.kunk.singbox.ui.components.flagEmojiForNodeName
import com.kunk.singbox.ui.components.rememberLocalNetworkPermissionRequest
import com.kunk.singbox.ui.navigation.Screen
import com.kunk.singbox.ui.theme.BentoAmber
import com.kunk.singbox.ui.theme.BentoBlue
import com.kunk.singbox.ui.theme.BentoCoral
import com.kunk.singbox.ui.theme.BentoInk
import com.kunk.singbox.ui.theme.BentoMint
import com.kunk.singbox.ui.theme.BentoSurface
import com.kunk.singbox.ui.theme.BentoTintBlue
import com.kunk.singbox.ui.theme.BentoViolet
import com.kunk.singbox.ui.theme.L4GlassCard
import com.kunk.singbox.ui.theme.L4Outline
import com.kunk.singbox.ui.theme.L4Surface
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim
import com.kunk.singbox.ui.theme.Neutral500
import com.kunk.singbox.ui.theme.PureWhite
import com.kunk.singbox.ui.theme.isLiquidGlassTheme
import com.kunk.singbox.ui.theme.liquidGlassMutedContentColor
import com.kunk.singbox.ui.theme.liquidGlassPanel
import com.kunk.singbox.ui.theme.liquidGlassProgressColor
import com.kunk.singbox.ui.theme.liquidGlassProgressTrackColor
import com.kunk.singbox.utils.LocalNetworkPermission
import com.kunk.singbox.viewmodel.DashboardViewModel
import com.kunk.singbox.viewmodel.NodesViewModel
import com.kunk.singbox.viewmodel.SettingsViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@Composable
private fun Modifier.nodesSectionProgressPanel(): Modifier {
    return if (isLiquidGlassTheme()) {
        liquidGlassPanel(shape = RoundedCornerShape(16.dp), shadowElevation = 8.dp)
            .padding(12.dp)
    } else {
        background(L4Surface, RoundedCornerShape(24.dp))
            .border(1.dp, L4Outline, RoundedCornerShape(24.dp))
            .padding(12.dp)
    }
}

@Composable
private fun Modifier.nodesSectionActiveIndicatorPanel(): Modifier {
    return if (isLiquidGlassTheme()) {
        size(10.dp)
            .liquidGlassPanel(shape = RoundedCornerShape(5.dp), selected = true, shadowElevation = 3.dp)
    } else {
        size(6.dp)
            .background(
                color = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(3.dp)
            )
    }
}

// Nodes-section state, shared by the grid items below and by
// ProfileNodesDialogs. It is created in @Composable context (see
// rememberProfileNodesState) and read from the grid's LazyGridScope
// content lambda, which is NOT a @Composable context — so the scope
// function below is deliberately NOT @Composable and only emits
// item{} blocks. (2026-10-30 fix for
// "@Composable invocations can only happen from the context of a
// @Composable function" at ProfilesScreen.kt:915.)
class ProfileNodesState(
    val navController: NavController,
    val nodesViewModel: NodesViewModel,
    val dashboardViewModel: DashboardViewModel,
    val settingsViewModel: SettingsViewModel,
    val scope: CoroutineScope,
    val context: Context,
    val clipboardManager: ClipboardManager,
    val requestLocalNetworkPermission: ((() -> Unit) -> Unit),
    val nodesState: State<List<NodeUi>>,
    val nodeProfilesState: State<List<ProfileUi>>,
    val activeNodeIdState: State<String?>,
    val isAutoSelectionEnabledState: State<Boolean>,
    val switchingNodeIdState: State<String?>,
    val runtimeNodeLabelState: State<String>,
    val testingNodeIdsState: State<Set<String>>,
    val nodeFilterState: State<NodeFilter>,
    val sortTypeState: State<NodeSortType>,
    val testProgressState: State<Pair<Int, Int>?>,
    val connectionStateState: State<ConnectionState>,
    val dashActiveNodeLatencyState: State<Long?>,
    val settingsState: State<AppSettings>,
    val isTestingState: State<Boolean>,
    val searchQueryState: MutableState<String>,
    val isSearchExpandedState: MutableState<Boolean>,
    val showSortDialogState: MutableState<Boolean>,
    val showFilterDialogState: MutableState<Boolean>,
    val exportLinkState: MutableState<String?>,
    val nodeToDeleteState: MutableState<NodeUi?>,
    val showClearLatencyConfirmState: MutableState<Boolean>,
    val filteredNodesState: State<List<NodeUi>>,
    val nodeRowColors: List<Pair<Color, Color>>,
)

@Suppress("LongMethod")
@Composable
fun rememberProfileNodesState(
    navController: NavController,
    dashboardViewModel: DashboardViewModel,
    nodesViewModel: NodesViewModel = viewModel(),
    settingsViewModel: SettingsViewModel = viewModel(),
): ProfileNodesState {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val nodesState = nodesViewModel.nodes.collectAsStateWithLifecycle()
    // CENTER-CONNECT: profiles supply each config's remaining volume
    // (totalTraffic - usedTraffic, only when totalTraffic > 0).
    val nodeProfilesState = nodesViewModel.profiles.collectAsStateWithLifecycle()
    val activeNodeIdState = nodesViewModel.activeNodeId.collectAsStateWithLifecycle()
    val isAutoSelectionEnabledState = nodesViewModel.isAutoSelectionEnabled.collectAsStateWithLifecycle()
    val switchingNodeIdState = nodesViewModel.switchingNodeId.collectAsStateWithLifecycle()
    val runtimeNodeLabelState = SingBoxRemote.activeLabel.collectAsStateWithLifecycle()
    val testingNodeIdsState = nodesViewModel.testingNodeIds.collectAsStateWithLifecycle()
    val nodeFilterState = nodesViewModel.nodeFilter.collectAsStateWithLifecycle()
    val sortTypeState = nodesViewModel.sortType.collectAsStateWithLifecycle()
    val testProgressState = nodesViewModel.testProgress.collectAsStateWithLifecycle()
    // CONNECT TILE: connection state + active-node latency from
    // DashboardViewModel (the same source Dashboard's own blue tile
    // uses), plus the app settings for the local-network permission
    // gate on the pill. No new tunnel logic anywhere here.
    val connectionStateState = dashboardViewModel.connectionState.collectAsStateWithLifecycle()
    val dashActiveNodeLatencyState = dashboardViewModel.activeNodeLatency.collectAsStateWithLifecycle()
    val settingsState = settingsViewModel.settings.collectAsStateWithLifecycle()
    val requestLocalNetworkPermission = rememberLocalNetworkPermissionRequest()
    val isTestingState = nodesViewModel.isTesting.collectAsStateWithLifecycle()

    LaunchedEffect(nodesViewModel) {
        nodesViewModel.toastEvents.collectLatest { message ->
            AppNotificationManager.showMessage(context, message)
        }
    }

    val searchQueryState = remember { mutableStateOf("") }
    val isSearchExpandedState = remember { mutableStateOf(true) }
    val filteredNodesState = remember {
        derivedStateOf {
            if (searchQueryState.value.isBlank()) {
                nodesState.value
            } else {
                nodesState.value.filter { node ->
                    node.displayName.contains(searchQueryState.value, ignoreCase = true)
                }
            }
        }
    }

    val showSortDialogState = remember { mutableStateOf(false) }
    val showFilterDialogState = remember { mutableStateOf(false) }
    val exportLinkState = remember { mutableStateOf<String?>(null) }
    val nodeToDeleteState = remember { mutableStateOf<NodeUi?>(null) }
    val showClearLatencyConfirmState = remember { mutableStateOf(false) }

    val nodeRowColors = remember {
        listOf(
            BentoCoral to BentoInk,
            BentoMint to BentoInk,
            BentoViolet to PureWhite,
            BentoTintBlue to BentoInk
        )
    }

    return ProfileNodesState(
        navController = navController,
        nodesViewModel = nodesViewModel,
        dashboardViewModel = dashboardViewModel,
        settingsViewModel = settingsViewModel,
        scope = scope,
        context = context,
        clipboardManager = clipboardManager,
        requestLocalNetworkPermission = requestLocalNetworkPermission,
        nodesState = nodesState,
        nodeProfilesState = nodeProfilesState,
        activeNodeIdState = activeNodeIdState,
        isAutoSelectionEnabledState = isAutoSelectionEnabledState,
        switchingNodeIdState = switchingNodeIdState,
        runtimeNodeLabelState = runtimeNodeLabelState,
        testingNodeIdsState = testingNodeIdsState,
        nodeFilterState = nodeFilterState,
        sortTypeState = sortTypeState,
        testProgressState = testProgressState,
        connectionStateState = connectionStateState,
        dashActiveNodeLatencyState = dashActiveNodeLatencyState,
        settingsState = settingsState,
        isTestingState = isTestingState,
        searchQueryState = searchQueryState,
        isSearchExpandedState = isSearchExpandedState,
        showSortDialogState = showSortDialogState,
        showFilterDialogState = showFilterDialogState,
        exportLinkState = exportLinkState,
        nodeToDeleteState = nodeToDeleteState,
        showClearLatencyConfirmState = showClearLatencyConfirmState,
        filteredNodesState = filteredNodesState,
        nodeRowColors = nodeRowColors,
    )
}

// Dialogs for the nodes section. They MUST be emitted from @Composable
// context (ProfilesScreen calls this outside the grid), while the
// grid items below read and write the same state object — so a row
// delete sets the same nodeToDelete this dialog reads.
@Suppress("FunctionNaming")
@Composable
fun ProfileNodesDialogs(state: ProfileNodesState) {
    val nodesViewModel = state.nodesViewModel
    val context = state.context
    val clipboardManager = state.clipboardManager
    val nodeFilter = state.nodeFilterState.value
    val sortType = state.sortTypeState.value
    var nodeToDelete by state.nodeToDeleteState
    var showClearLatencyConfirm by state.showClearLatencyConfirmState
    var showSortDialog by state.showSortDialogState
    var showFilterDialog by state.showFilterDialogState
    var exportLink by state.exportLinkState

    val pendingNodeDelete = nodeToDelete
    if (pendingNodeDelete != null) {
        ConfirmDialog(
            title = stringResource(R.string.common_delete),
            message = stringResource(R.string.common_delete_confirm, pendingNodeDelete.displayName),
            confirmText = stringResource(R.string.common_delete),
            isDestructive = true,
            onConfirm = {
                nodesViewModel.deleteNode(pendingNodeDelete.id)
                nodeToDelete = null
            },
            onDismiss = { nodeToDelete = null }
        )
    }

    if (showClearLatencyConfirm) {
        ConfirmDialog(
            title = stringResource(R.string.nodes_clear_latency),
            message = stringResource(R.string.nodes_clear_latency_confirm),
            confirmText = stringResource(R.string.common_clear),
            isDestructive = true,
            onConfirm = {
                nodesViewModel.clearLatency()
                showClearLatencyConfirm = false
            },
            onDismiss = { showClearLatencyConfirm = false }
        )
    }

    if (showSortDialog) {
        val sortOptions = listOf(
            stringResource(R.string.nodes_sort_default) to NodeSortType.DEFAULT,
            stringResource(R.string.nodes_sort_latency) to NodeSortType.LATENCY,
            stringResource(R.string.nodes_sort_name) to NodeSortType.NAME
        )
        SingleSelectDialog(
            title = stringResource(R.string.nodes_sort),
            options = sortOptions.map { it.first },
            selectedIndex = sortOptions.indexOfFirst { it.second == sortType },
            onSelect = { index ->
                nodesViewModel.setSortType(sortOptions[index].second)
                showSortDialog = false
            },
            onDismiss = { showSortDialog = false }
        )
    }

    if (showFilterDialog) {
        NodeFilterDialog(
            currentFilter = nodeFilter,
            onConfirm = { filter ->
                nodesViewModel.setNodeFilter(filter)
                showFilterDialog = false
            },
            onDismiss = { showFilterDialog = false }
        )
    }

    if (exportLink != null) {
        val exportValue = checkNotNull(exportLink)
        val copiedMsg = stringResource(R.string.nodes_copied_to_clipboard)
        InputDialog(
            title = stringResource(R.string.nodes_export_link),
            initialValue = exportValue,
            confirmText = stringResource(R.string.common_copy),
            onConfirm = {
                clipboardManager.setText(AnnotatedString(it))
                AppNotificationManager.showMessage(context, copiedMsg)
                exportLink = null
            },
            onDismiss = { exportLink = null }
        )
    }
}

// Grid items for the nodes section. NOT @Composable on purpose: the
// LazyGridScope content lambda that calls this is not a @Composable
// context, so this function only emits item{} blocks (whose content
// lambdas ARE @Composable) and reads state values collected above.
// All state mutations below (search text, dialog flags, row delete)
// write the same state object the dialogs read.
@Suppress("FunctionNaming", "LongMethod", "CyclomaticComplexMethod", "CognitiveComplexMethod")
fun LazyGridScope.ProfileNodesSection(state: ProfileNodesState) {
    val navController = state.navController
    val nodesViewModel = state.nodesViewModel
    val dashboardViewModel = state.dashboardViewModel
    val scope = state.scope
    val requestLocalNetworkPermission = state.requestLocalNetworkPermission
    val nodeRowColors = state.nodeRowColors

    val nodes = state.nodesState.value
    val nodeProfiles = state.nodeProfilesState.value
    val activeNodeId = state.activeNodeIdState.value
    val isAutoSelectionEnabled = state.isAutoSelectionEnabledState.value
    val switchingNodeId = state.switchingNodeIdState.value
    val runtimeNodeLabel = state.runtimeNodeLabelState.value
    val testingNodeIds = state.testingNodeIdsState.value
    val nodeFilter = state.nodeFilterState.value
    val testProgress = state.testProgressState.value
    val connectionState = state.connectionStateState.value
    val dashActiveNodeLatency = state.dashActiveNodeLatencyState.value
    val settings = state.settingsState.value
    val isTesting = state.isTestingState.value
    val filteredNodes = state.filteredNodesState.value

    var searchQuery by state.searchQueryState
    var isSearchExpanded by state.isSearchExpandedState
    var showSortDialog by state.showSortDialogState
    var showFilterDialog by state.showFilterDialogState
    var exportLink by state.exportLinkState
    var nodeToDelete by state.nodeToDeleteState
    var showClearLatencyConfirm by state.showClearLatencyConfirmState

    // Section header: "Nodes" + live count (mirrors the old tab's
    // "All Nodes / N available" header).
    item(span = { GridItemSpan(maxLineSpan) }) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Nodes",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold
                ),
                color = L4Text
            )
            Text(
                text = "${filteredNodes.size} available",
                style = MaterialTheme.typography.bodySmall,
                color = L4TextDim
            )
        }
    }

    // Search (same NodeSearchBar as the old tab; no scroll-collapse
    // here — the grid has no list state — but the toggle still works).
    item(span = { GridItemSpan(maxLineSpan) }) {
        NodeSearchBar(
            query = searchQuery,
            onQueryChange = { searchQuery = it },
            isExpanded = isSearchExpanded,
            onToggle = { isSearchExpanded = !isSearchExpanded },
            totalCount = nodes.size,
            filteredCount = filteredNodes.size,
            activeNodeName = nodes.find { it.id == activeNodeId }?.displayName,
            modifier = Modifier.fillMaxWidth()
        )
    }

    // Actions row: the old FAB menu + more menu, minus Locate (open
    // decision). Two rows of three tonal buttons; the Filter button
    // keeps its active-filter highlight.
    item(span = { GridItemSpan(maxLineSpan) }) {
        val hasFilter = nodeFilter.filterMode != FilterMode.NONE
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = { navController.navigate(Screen.NodeAdd.route) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = stringResource(R.string.nodes_add))
                }
                FilledTonalButton(
                    onClick = { navController.navigate(Screen.NodeProtocolSelect.route) },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Edit, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = stringResource(R.string.nodes_manual_create))
                }
                FilledTonalButton(
                    onClick = { nodesViewModel.testAllLatency() },
                    modifier = Modifier.weight(1f)
                ) {
                    if (isTesting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(Icons.Rounded.Bolt, contentDescription = null)
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isTesting) {
                            stringResource(R.string.nodes_stop_test)
                        } else {
                            stringResource(R.string.nodes_test_latency)
                        }
                    )
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = { showClearLatencyConfirm = true },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Delete, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = stringResource(R.string.nodes_clear_latency))
                }
                FilledTonalButton(
                    onClick = { showSortDialog = true },
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Rounded.Sort, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = stringResource(R.string.nodes_sort))
                }
                FilledTonalButton(
                    onClick = { showFilterDialog = true },
                    modifier = Modifier.weight(1f),
                    colors = if (hasFilter) {
                        ButtonDefaults.filledTonalButtonColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer,
                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    } else {
                        ButtonDefaults.filledTonalButtonColors()
                    }
                ) {
                    Icon(Icons.Rounded.FilterAlt, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = stringResource(R.string.nodes_filter))
                }
            }
        }
    }

    // Testing progress (only while a test runs).
    if (testProgress != null) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            testProgress?.let { (completed, total) ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .nodesSectionProgressPanel()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.nodes_testing_progress),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "$completed / $total",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { if (total > 0) completed.toFloat() / total else 0f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp),
                        color = liquidGlassProgressColor(MaterialTheme.colorScheme.primary),
                        trackColor = liquidGlassProgressTrackColor(
                            MaterialTheme.colorScheme.surfaceVariant
                        )
                    )
                }
            }
        }
    }

    // Amber Fastest Node tile (old tab's amber tile, unchanged):
    // lowest measured latency; "Low load • 12% usage" has no
    // counterpart (nodes carry no load field), so the tile shows the
    // name + ping pill + "Recommended" instead. Tap selects the node.
    item(span = { GridItemSpan(maxLineSpan) }) {
        val fastestNode = remember(nodes) {
            nodes.filter { it.latencyMs != null }
                .minByOrNull { it.latencyMs ?: Long.MAX_VALUE }
        }
        L4GlassCard(
            modifier = Modifier.fillMaxWidth(),
            tileColor = BentoAmber,
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Bolt,
                        contentDescription = null,
                        tint = L4Text,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "Fastest Node",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            ),
                            color = L4Text
                        )
                        Text(
                            text = "Optimal for you based on latency & location",
                            style = MaterialTheme.typography.bodySmall,
                            color = L4TextDim
                        )
                    }
                }
                if (fastestNode != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { nodesViewModel.setActiveNode(fastestNode.id) },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f, fill = false)) {
                            Text(
                                text = (flagEmojiForNodeName(fastestNode.displayName)?.let { "$it " } ?: "") + fastestNode.displayName,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.SemiBold
                                ),
                                color = L4Text
                            )
                            Text(
                                text = "Recommended",
                                style = MaterialTheme.typography.bodySmall,
                                color = L4TextDim
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(
                                    PureWhite,
                                    RoundedCornerShape(999.dp)
                                )
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = fastestNode.latencyMs?.let { "${it}ms" } ?: "—",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = BentoInk
                            )
                        }
                    }
                } else {
                    Text(
                        text = "No latency measured yet — use Test all above to test all nodes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim
                    )
                }
            }
        }
    }

    // Auto-selection row (retained: it is the only auto-selection
    // entry point, so it has no other home but cannot be dropped).
    item(span = { GridItemSpan(maxLineSpan) }) {
        val subtitle = when {
            !isAutoSelectionEnabled -> stringResource(R.string.nodes_auto_selection_disabled)
            runtimeNodeLabel.isNotBlank() -> stringResource(
                R.string.nodes_auto_selection_current,
                runtimeNodeLabel
            )
            else -> stringResource(R.string.nodes_auto_selection_selecting)
        }
        NodeCard(
            name = stringResource(R.string.nodes_auto_selection),
            type = subtitle,
            isSelected = isAutoSelectionEnabled,
            onClick = nodesViewModel::enableAutoSelection,
            onEdit = {},
            onExport = {},
            onLatency = {},
            onDelete = {},
            showLatency = false,
            showActions = false
        )
    }

    // Node rows (same NodeCard calls as the old tab, same cycling
    // row colors, same volume-remaining rule). Each row is a
    // full-span grid item; no itemsIndexed import is used (the
    // scope-member rule) — a plain loop over the filtered list.
    for ((index, node) in filteredNodes.withIndex()) {
        item(key = node.id, span = { GridItemSpan(maxLineSpan) }) {
            val isSelected = !isAutoSelectionEnabled && activeNodeId == node.id
            val isTestingNode = testingNodeIds.contains(node.id)
            val isSwitchingNode = switchingNodeId == node.id

            val onNodeClick = remember(node.id) { { nodesViewModel.setActiveNode(node.id) } }
            val onEdit = remember(node.id) {
                { navController.navigate(Screen.NodeDetail.createRoute(node.id)) }
            }
            val onExport = remember(node.id) {
                {
                    scope.launch {
                        val link = nodesViewModel.exportNode(node.id)
                        if (link != null) {
                            exportLink = link
                        }
                    }
                    Unit
                }
            }
            val onLatency = remember(node.id) { { nodesViewModel.testLatency(node.id) } }
            val onDelete = remember(node) { { nodeToDelete = node } }

            val (rowColor, rowContent) = nodeRowColors[index % nodeRowColors.size]
            NodeCard(
                name = node.displayName,
                flag = flagEmojiForNodeName(node.displayName),
                type = node.protocolDisplay,
                latency = node.latencyMs,
                isSelected = isSelected,
                hasDetour = node.hasDetour,
                isSwitching = isSwitchingNode,
                isTesting = isTestingNode,
                // Volume BELOW the row; null = no total reported,
                // so no volume line renders.
                volumeRemaining = nodeProfiles
                    .find { it.id == node.sourceProfileId }
                    ?.let { profile ->
                        if (profile.totalTraffic > 0) {
                            (profile.totalTraffic - profile.usedTraffic).coerceAtLeast(0L)
                        } else {
                            null
                        }
                    },
                onClick = onNodeClick,
                onEdit = onEdit,
                onExport = onExport,
                onLatency = onLatency,
                onDelete = onDelete,
                tileColor = rowColor,
                contentColor = rowContent
            )
        }
    }

    // Blue Connect tile (old tab's bottom Connect tile, unchanged):
    // title + real node line + CONNECT/DISCONNECT pill. The pill
    // calls DashboardViewModel.toggleConnection — the exact
    // Dashboard toggle, including its local-network permission gate.
    // No new tunnel logic.
    item(key = "connect-tile", span = { GridItemSpan(maxLineSpan) }) {
        val isConnected = connectionState == ConnectionState.Connected
        val isRunning = isConnected || connectionState == ConnectionState.Connecting
        val toggleConnection = { dashboardViewModel.toggleConnection() }
        val fastestNode = remember(nodes) {
            nodes.filter { it.latencyMs != null }
                .minByOrNull { it.latencyMs ?: Long.MAX_VALUE }
        }
        val activeNode = nodes.find { it.id == activeNodeId }
        // Real node line only. Running -> the actually running node
        // (runtime label first, else the selected node) with
        // Dashboard's real active latency. Stopped + auto -> the
        // fastest measured node. Stopped + manual -> the selected
        // node. No fake country, city, ping, or load anywhere;
        // "Auto" is claimed only when auto-selection is actually on.
        val connectLine = when {
            isRunning -> {
                val runningName = runtimeNodeLabel.takeIf { it.isNotBlank() }
                    ?: activeNode?.displayName
                when {
                    runningName == null ->
                        if (isConnected) "Connected" else "Connecting"
                    isAutoSelectionEnabled ->
                        "Auto — $runningName" +
                            (dashActiveNodeLatency?.let { " • ${it}ms" } ?: "")
                    else ->
                        runningName +
                            (dashActiveNodeLatency?.let { " • ${it}ms" } ?: "")
                }
            }
            isAutoSelectionEnabled -> fastestNode?.let {
                "Auto — ${it.displayName} • ${it.latencyMs}ms"
            } ?: "Auto — test nodes first to find the fastest"
            activeNode != null -> activeNode.displayName +
                (activeNode.latencyMs?.let { " • ${it}ms" } ?: "")
            else -> "Select a node to connect"
        }
        L4GlassCard(
            modifier = Modifier.fillMaxWidth(),
            tileColor = BentoBlue,
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    BentoSurface,
                                    RoundedCornerShape(12.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Power,
                                contentDescription = null,
                                tint = BentoBlue,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Connect",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold
                            ),
                            color = BentoSurface
                        )
                    }
                    Button(
                        onClick = {
                            if (!isRunning && LocalNetworkPermission.requiresLocalNetworkAccess(settings)) {
                                requestLocalNetworkPermission(toggleConnection)
                            } else {
                                toggleConnection()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BentoSurface,
                            contentColor = BentoInk
                        ),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(
                            horizontal = 16.dp,
                            vertical = 6.dp
                        )
                    ) {
                        Text(
                            text = if (isRunning) "DISCONNECT" else "CONNECT",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
                Text(
                    text = connectLine,
                    style = MaterialTheme.typography.bodyMedium,
                    color = BentoSurface
                )
            }
        }
    }
}

@Suppress("FunctionNaming", "LongMethod", "CognitiveComplexMethod")
@Composable
internal fun NodeSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    totalCount: Int,
    filteredCount: Int,
    activeNodeName: String?,
    modifier: Modifier = Modifier
) {
    ExpandableSearchBar(
        query = query,
        onQueryChange = onQueryChange,
        isExpanded = isExpanded,
        onToggle = onToggle,
        placeholder = stringResource(R.string.common_search),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (filteredCount != totalCount) {
                    "$filteredCount / $totalCount ${stringResource(R.string.nodes_count_suffix)}"
                } else {
                    "$totalCount ${stringResource(R.string.nodes_count_suffix)}"
                },
                style = MaterialTheme.typography.bodyMedium,
                color = liquidGlassMutedContentColor(Neutral500)
            )

            if (activeNodeName != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(start = 8.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.nodesSectionActiveIndicatorPanel()
                    ) {
                        if (isLiquidGlassTheme()) {
                            Box(
                                modifier = Modifier
                                    .size(4.dp)
                                    .background(
                                        color = MaterialTheme.colorScheme.primary,
                                        shape = RoundedCornerShape(2.dp)
                                    )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = activeNodeName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                }
            }
        }
    }
}
