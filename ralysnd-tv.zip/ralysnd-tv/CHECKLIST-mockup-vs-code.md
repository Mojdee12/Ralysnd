# Ralysnd TV — tile-by-tile mockup check (code vs approved mockups)

Checked 2026-11-11 ~03:30 UTC (07:00 +0330), against the local scaffold
`~/workspace/ralysnd-tv/` (zip `~/workspace/ralysnd-tv.zip`, 02:43 UTC).
This is a SOURCE check only — the build-1 APK had not been delivered in
chat at check time, so nothing here verifies the built artifact. Re-run
this list against the real APK on a TV before handover.

Approved mockups (all in `~/workspace/imagine_media/`):
- Home: `media-generation-darktv-sample-green-split-0-b34f4ac9-a107-40a4-b015-4a669313f411.webp` (sample 5, green split)
- Channels: `media-generation-ralysnd-tv-channels-list-0-af37c1d2-8fa2-416f-8a69-4d4e4fb70c96.webp`
- Player: `media-generation-ralysnd-tv-player-screen-0-8a5b8986-bc88-4db1-a468-628e09dfa612.webp`
- Categories home: `media-generation-ralysnd-tv-categories-home-0-d636c76f-660e-4d9e-b4ae-0d4f547b8e06.webp`
- Settings: `media-generation-ralysnd-tv-settings-screen-0-c7d90d69-303b-4320-8519-c0859ce96626.webp`

## Data — verified
- `channels.json` bundled in the app is byte-identical to the recovered
  original (md5 `2f0999bd258c69c7b407701485145536` both files): **214 channels,
  244 stream URLs, 18 categories, 0 channels without a URL, 40 without a logo**
  (logo fallback = green tile with initial letter, in `Common.kt`).
- 5 `.mpd` URLs confirmed; `PlayerFactory.mediaItemFor` sets
  `APPLICATION_MPD` for `.mpd`, `APPLICATION_M3U8` for `.m3u8`.
- Sorting A–Z confirmed in `ChannelRepository.channelsFor`; categories
  ordered All first, then by channel count.

## Home (green split) — MATCH
- Top bar: "Ralysnd TV" wordmark (white + green TV), category pills,
  Settings button. Pills = all 18 categories + All (scrollable LazyRow);
  mockup shows only Live/News/Movies/Music/Sports — extra categories are
  real data, not a deviation.
- Split 62/38: live preview left (muted ExoPlayer, LIVE badge, channel
  name + category, green "▶ Watch" button), "UP NEXT • N CHANNELS" right
  with real count, D-pad hint, "All Channels →" button.
- Palette: `#00C853` green on `#101613`, grey pills `#3A4440` — exact.

## All Channels — MATCH, 2 minor notes
- Left rail CATEGORIES, All highlighted green; right "All Channels /
  N channels • Sorted A–Z"; 5-column grid, logo + name tiles, emerald
  focus border (`FocusableCard`).
- NOTE 1: mockup rail rows have a small icon per category; code rows are
  text-only and add a channel count per category (count is an addition,
  not in the mockup).
- NOTE 2: mockup has a search magnifier top-right and a green divider
  line under the header; code has neither (search deliberately excluded —
  not in the original app; she was told "بدون سرچ").

## Player — MATCH, 3 notes
- Full-bleed video, LIVE badge + channel name top-left overlay, right
  "NEXT CHANNELS" panel (8 next channels, same category), bottom control
  bar: pause, −10s/+10s, progress slider, time, speed, CC, audio, Vol−/Vol+,
  Hide/Next toggle. Controls auto-hide after 5 s; D-pad ↑↓ zaps channels
  when controls + panel are hidden; failure retries the next URL of the
  same channel before showing an error + Retry.
- NOTE 3: mockup shows a programme line under each next channel
  ("News • Now / Daily Bulletin") and a channel watermark top-right;
  code shows name + category only — correct, because no EPG data exists;
  inventing programme text would be fake.
- NOTE 4: mockup control bar has a fullscreen icon; code has the
  Hide/Next panel toggle instead. Volume is Vol−/Vol+ text buttons,
  not speaker icons.

## Categories home — SAME SCREEN as Home, 1 note
- Served by the same `HomeScreen` (pills drive the split); layout matches.
- NOTE 5: mockup shows "Now Live: Evening News — Tehran | 19:30",
  "12.4k watching" and a big centre play button on the preview; code has
  none of these — again no EPG/viewer data exists, and the Watch button
  sits under the preview instead of overlaid.

## Settings — MATCH, 1 trivial note
- Top bar Ralysnd TV + Settings; left nav Playback / Video Quality /
  Subtitles / Audio / About with green selected row; right rows exactly
  as mocked: Video quality, Buffer size, Autoplay next channel (toggle),
  Subtitles, Audio language, App version. Values persist via SettingsStore.
- NOTE 6 (trivial): mockup top-right shows Wi-Fi/Bluetooth + clock
  10:42; code shows "214 channels" there instead.

## Navigation — verified in code
- `RalysndTvApp`: Home ↔ Channels ↔ Player ↔ Settings all wired;
  Back from anywhere returns Home. Single activity, Leanback launcher +
  banner in the manifest, `com.ralysnd.tv`, separate app.

## Open items NOT in build 1 (from README, still true)
- **Font:** Vazirmatn is NOT bundled — `RalysndFontFamily =
  FontFamily.Default`, no `res/font/` directory. Persian channel names
  render in the system default font, not the original's Vazirmatn.
- **Banner:** `res/drawable/banner.xml` is a vector placeholder (emerald
  play mark + wordmark), not a 320×180 PNG. Fine for a debug build,
  replace before any release.
- No search / favourites / EPG / recording anywhere in code (grep clean)
  — matches the original app and what she was told.

## Verdict for the handover gate
Code matches the approved mockups on layout, palette, screens and
navigation. The only things that will visibly differ from the mockups on
the real device are the 6 notes above — of which 3–5 are honest absences
(no EPG/viewer data, no search) and 1–2 are small polish items
(category icons, font, banner). Do NOT hand over the APK as "exactly
like the mockups" without naming the font + banner + no-search points.
