package com.ralysnd.tv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Loads the bundled channels.json (assets/channels.json, 214 channels,
 * copied verbatim from the original app) and groups channels by category.
 *
 * Categories are derived from the data itself, ordered by channel count
 * (largest first). The 36 channels with no category are listed under
 * "general" so no channel is ever unreachable.
 */
class ChannelRepository(private val channels: List<Channel>) {

    val all: List<Channel> get() = channels

    /** Category keys in display order: "all" first, then by channel count. */
    val categories: List<String> by lazy {
        val counts = linkedMapOf<String, Int>()
        for (channel in channels) {
            for (category in channel.categories) {
                counts[category] = (counts[category] ?: 0) + 1
            }
        }
        listOf(CATEGORY_ALL) + counts.entries
            .sortedByDescending { it.value }
            .map { it.key }
    }

    /** Channels for one category key, or every channel for "all". Sorted A–Z. */
    fun channelsFor(category: String): List<Channel> {
        val filtered = if (category == CATEGORY_ALL) {
            channels
        } else {
            channels.filter { it.categories.contains(category) }
        }
        return filtered.sortedBy { it.name.lowercase() }
    }

    fun channelById(id: String): Channel? = channels.firstOrNull { it.id == id }

    /** Next channels in the same category as [channel], for the player side panel. */
    fun nextChannels(channel: Channel, limit: Int = 8): List<Channel> {
        val category = channel.categories.firstOrNull() ?: CATEGORY_ALL
        return channelsFor(category)
            .filter { it.id != channel.id }
            .take(limit)
    }

    companion object {
        const val CATEGORY_ALL = "all"

        /** Loads and parses the bundled channels.json from assets. */
        fun load(context: Context): ChannelRepository {
            val json = context.assets.open("channels.json")
                .bufferedReader()
                .use { it.readText() }
            return ChannelRepository(parseChannels(json))
        }

        /** Pure parse of a channels.json document. Kept separate so unit tests
         * can exercise it without Android assets. */
        fun parseChannels(json: String): List<Channel> {
            val array = JSONArray(json)
            val out = ArrayList<Channel>(array.length())
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val categories = obj.stringList("categories")
                    .ifEmpty { listOf("general") }
                out += Channel(
                    id = obj.optString("id"),
                    name = obj.optString("name"),
                    logo = obj.optString("logo"),
                    categories = categories,
                    urls = obj.stringList("urls"),
                )
            }
            return out
        }

        private fun JSONObject.stringList(key: String): List<String> {
            val arr: JSONArray = optJSONArray(key) ?: return emptyList()
            val out = ArrayList<String>(arr.length())
            for (i in 0 until arr.length()) {
                val value = arr.optString(i)
                if (value.isNotBlank()) out += value
            }
            return out
        }
    }
}
