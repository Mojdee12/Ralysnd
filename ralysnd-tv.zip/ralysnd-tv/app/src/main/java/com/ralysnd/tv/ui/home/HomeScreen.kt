package com.ralysnd.tv.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.data.ChannelRepository
import com.ralysnd.tv.data.SettingsStore
import com.ralysnd.tv.player.PlayerFactory
import com.ralysnd.tv.ui.components.ChannelRow
import com.ralysnd.tv.ui.components.DpadHint
import com.ralysnd.tv.ui.components.LiveBadge
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors

/**
 * Home — the approved green-split layout, exactly as the mockup:
 * top bar (wordmark + category pills + Settings), left live preview card
 * with LIVE badge + channel name, right "UP NEXT" channel list,
 * D-pad hint at the bottom. The same split is reused by the player screen.
 *
 * Deliberately NO lookup field anywhere on this screen: the original
 * app has none and it was not approved for the rebuild.
 */
@Composable
fun HomeScreen(
    repository: ChannelRepository,
    settings: SettingsStore,
    onPlay: (Channel) -> Unit,
    onOpenChannels: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var selectedCategory by remember { mutableStateOf(ChannelRepository.CATEGORY_ALL) }
    val channels = remember(selectedCategory) {
        repository.channelsFor(selectedCategory).filter { it.isPlayable }
    }
    var selectedChannel by remember(channels) {
        mutableStateOf(channels.firstOrNull())
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RalysndTvColors.Background)
            .padding(horizontal = 32.dp, vertical = 20.dp),
    ) {
        // ---- Top bar: wordmark | category pills | Settings ----------------
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(RalysndTvColors.Surface, RoundedCornerShape(20.dp))
                .padding(horizontal = 20.dp, vertical = 12.dp),
        ) {
            Text(
                text = buildAnnotatedString {
                    append("Ralysnd ")
                    withStyle(SpanStyle(color = RalysndTvColors.GreenPrimary)) { append("TV") }
                },
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Spacer(Modifier.width(28.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(repository.categories) { category ->
                    CategoryPill(
                        label = categoryLabel(category),
                        selected = category == selectedCategory,
                        onClick = { selectedCategory = category },
                    )
                }
            }
            Spacer(Modifier.width(16.dp))
            SettingsButton(onClick = onOpenSettings)
        }

        Spacer(Modifier.height(20.dp))

        // ---- Split body: live preview (left) + Up Next list (right) -------
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            // Left: live preview card.
            Box(
                modifier = Modifier
                    .weight(0.62f)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(20.dp))
                    .background(RalysndTvColors.Surface),
            ) {
                Column(Modifier.fillMaxSize().padding(16.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.Black),
                    ) {
                        val preview = selectedChannel
                        if (preview != null) {
                            MutedPreviewPlayer(
                                channel = preview,
                                settings = settings,
                                modifier = Modifier.fillMaxSize(),
                            )
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LiveBadge()
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(
                                text = selectedChannel?.name ?: "",
                                color = Color.White,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = RalysndFontFamily,
                            )
                            Text(
                                text = categoryLabel(
                                    selectedChannel?.categories?.firstOrNull()
                                        ?: ChannelRepository.CATEGORY_ALL,
                                ),
                                color = RalysndTvColors.TextMuted,
                                fontSize = 16.sp,
                                fontFamily = RalysndFontFamily,
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        // OK on the preview opens the full player.
                        OpenPlayerButton(
                            enabled = selectedChannel != null,
                            onClick = { selectedChannel?.let(onPlay) },
                        )
                    }
                }
            }

            // Right: Up Next list.
            Column(
                modifier = Modifier
                    .weight(0.38f)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(20.dp))
                    .background(RalysndTvColors.Surface)
                    .padding(16.dp),
            ) {
                Text(
                    text = "UP NEXT • ${channels.size} CHANNELS",
                    color = RalysndTvColors.TextMuted,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = RalysndFontFamily,
                )
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    items(channels, key = { it.id }) { channel ->
                        ChannelRow(
                            channel = channel,
                            isPlaying = channel.id == selectedChannel?.id,
                            onClick = { selectedChannel = channel },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                DpadHint(
                    text = "Press OK to play • ↑↓ to navigate",
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(6.dp))
                AllChannelsButton(onClick = onOpenChannels)
            }
        }
    }
}

@Composable
private fun CategoryPill(label: String, selected: Boolean, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = Modifier
            .border(
                width = if (focused) 3.dp else 0.dp,
                color = if (focused) Color.White else Color.Transparent,
                RoundedCornerShape(24.dp),
            )
            .background(
                if (selected) RalysndTvColors.GreenPrimary else RalysndTvColors.PillGrey,
                RoundedCornerShape(24.dp),
            )
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 22.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (selected) Color.Black else Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = RalysndFontFamily,
        )
    }
}

@Composable
private fun SettingsButton(onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = Modifier
            .border(
                width = if (focused) 3.dp else 1.dp,
                color = if (focused) RalysndTvColors.GreenPrimary
                else RalysndTvColors.SurfaceElevated,
                RoundedCornerShape(24.dp),
            )
            .background(RalysndTvColors.SurfaceElevated, RoundedCornerShape(24.dp))
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "⚙ Settings",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = RalysndFontFamily,
        )
    }
}

@Composable
private fun OpenPlayerButton(enabled: Boolean, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = Modifier
            .border(
                width = if (focused) 3.dp else 0.dp,
                color = if (focused) Color.White else Color.Transparent,
                RoundedCornerShape(24.dp),
            )
            .background(RalysndTvColors.GreenPrimary, RoundedCornerShape(24.dp))
            .focusable(enabled, interactionSource)
            .clickable(enabled = enabled, interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 24.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "▶ Watch",
            color = Color.Black,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}

@Composable
private fun AllChannelsButton(onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (focused) 3.dp else 1.dp,
                color = if (focused) RalysndTvColors.GreenPrimary
                else RalysndTvColors.SurfaceElevated,
                RoundedCornerShape(14.dp),
            )
            .background(RalysndTvColors.SurfaceElevated, RoundedCornerShape(14.dp))
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "All Channels →",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = RalysndFontFamily,
        )
    }
}

/** Muted live preview of the selected channel. Released when the home screen leaves. */
@Composable
private fun MutedPreviewPlayer(
    channel: Channel,
    settings: SettingsStore,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val player = remember {
        PlayerFactory.create(context, settings).apply { volume = 0f }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    LaunchedEffect(channel) {
        val url = channel.primaryUrl ?: return@LaunchedEffect
        player.setMediaItem(PlayerFactory.mediaItemFor(url))
        player.prepare()
        player.play()
    }
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                useController = false
            }
        },
        modifier = modifier,
    )
}

/** Display label for a category key ("all" -> "All", "general" -> "General", ...). */
fun categoryLabel(category: String): String =
    category.replaceFirstChar { it.uppercase() }
