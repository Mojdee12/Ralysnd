package com.ralysnd.tv.ui.player

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.data.ChannelRepository
import com.ralysnd.tv.data.SettingsStore
import com.ralysnd.tv.player.PlayerFactory
import com.ralysnd.tv.ui.components.ChannelRow
import com.ralysnd.tv.ui.components.LiveBadge
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors
import kotlinx.coroutines.delay

/**
 * Full-screen player — the approved player mockup:
 * video on the left, "NEXT CHANNELS" panel on the right, bottom control bar
 * (pause, progress, time, speed, subtitles, audio, volume), LIVE badge.
 *
 * Behaviour, matching the original app: play/pause, seek when the stream
 * allows it, speed 0.25x–2x, subtitle + audio track pickers, and retry:
 * on failure the next URL of the same channel is tried before an error is
 * shown (channels carry up to 8 alternate streams).
 */
@Composable
fun PlayerScreen(
    channel: Channel,
    repository: ChannelRepository,
    settings: SettingsStore,
    onBack: () -> Unit,
    onChannelSelected: (Channel) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val player = remember { PlayerFactory.create(context, settings) }
    DisposableEffect(player) { onDispose { player.release() } }

    var urlIndex by remember(channel) { mutableIntStateOf(0) }
    var errorMessage by remember(channel) { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(true) }
    var speed by remember { mutableFloatStateOf(1f) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(C.TIME_UNSET) }
    var controlsVisible by remember { mutableStateOf(true) }
    var interactionTick by remember { mutableIntStateOf(0) }
    var showNextPanel by remember { mutableStateOf(true) }
    var showSubtitlePicker by remember { mutableStateOf(false) }
    var showAudioPicker by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(1f) }

    val urls = channel.urls
    val nextChannels = remember(channel) { repository.nextChannels(channel) }

    // Load the current stream URL whenever the channel or the retry index changes.
    LaunchedEffect(channel, urlIndex) {
        errorMessage = null
        if (urls.isEmpty()) {
            errorMessage = "This channel has no stream."
        } else {
            player.setMediaItem(PlayerFactory.mediaItemFor(urls[urlIndex]))
            player.prepare()
            player.play()
        }
    }

    // Player state -> UI state, and failure -> next URL -> error overlay.
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                isPlaying = player.isPlaying
                if (state == Player.STATE_READY) errorMessage = null
                if (state == Player.STATE_ENDED && settings.autoplayNextChannel) {
                    nextChannels.firstOrNull()?.let(onChannelSelected)
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                if (urlIndex + 1 < urls.size) {
                    urlIndex += 1
                } else {
                    errorMessage = "Channel unavailable — trying the next stream…"
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    // Position clock for the progress bar / time label.
    LaunchedEffect(player) {
        while (true) {
            positionMs = player.currentPosition
            durationMs = player.duration
            delay(500)
        }
    }

    // Auto-hide the control bar 5s after the last interaction.
    LaunchedEffect(controlsVisible, interactionTick) {
        if (controlsVisible) {
            delay(5_000)
            controlsVisible = false
        }
    }

    fun poke() {
        controlsVisible = true
        interactionTick += 1
    }

    fun zap(delta: Int) {
        val list = repository.channelsFor(
            channel.categories.firstOrNull() ?: ChannelRepository.CATEGORY_ALL,
        ).filter { it.isPlayable }
        val index = list.indexOfFirst { it.id == channel.id }.takeIf { it >= 0 } ?: return
        val target = list[(index + delta + list.size) % list.size]
        onChannelSelected(target)
    }

    BackHandler { onBack() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .onPreviewKeyEvent { event ->
                if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (event.key) {
                    Key.DirectionCenter, Key.Enter -> {
                        poke()
                        false // let the focused control handle the click
                    }
                    Key.DirectionUp -> {
                        if (!controlsVisible && !showNextPanel) {
                            zap(+1)
                            true
                        } else {
                            poke()
                            false
                        }
                    }
                    Key.DirectionDown -> {
                        if (!controlsVisible && !showNextPanel) {
                            zap(-1)
                            true
                        } else {
                            poke()
                            false
                        }
                    }
                    else -> {
                        poke()
                        false
                    }
                }
            },
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                }
            },
            modifier = Modifier.fillMaxSize(),
        )

        // ---- Top overlay: LIVE badge + channel name --------------------------
        if (controlsVisible) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(28.dp),
            ) {
                LiveBadge()
                Spacer(Modifier.width(14.dp))
                Text(
                    text = channel.name,
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RalysndFontFamily,
                )
            }
        }

        // ---- Right: NEXT CHANNELS panel (same green-split as home) -----------
        if (showNextPanel) {
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(420.dp)
                    .padding(20.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(RalysndTvColors.Background.copy(alpha = 0.92f))
                    .padding(16.dp),
            ) {
                Text(
                    text = "NEXT CHANNELS",
                    color = RalysndTvColors.GreenBright,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RalysndFontFamily,
                )
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    items(nextChannels, key = { it.id }) { next ->
                        ChannelRow(
                            channel = next,
                            isPlaying = false,
                            onClick = { onChannelSelected(next) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "UP / DOWN to navigate • OK to select",
                    color = RalysndTvColors.GreenBright,
                    fontSize = 14.sp,
                    fontFamily = RalysndFontFamily,
                )
            }
        }

        // ---- Error overlay ----------------------------------------------------
        errorMessage?.let { message ->
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(16.dp))
                    .background(RalysndTvColors.Surface)
                    .padding(24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = message,
                        color = Color.White,
                        fontSize = 20.sp,
                        fontFamily = RalysndFontFamily,
                    )
                    Spacer(Modifier.height(14.dp))
                    ControlButton(label = "Retry", onClick = {
                        urlIndex = 0
                        player.setMediaItem(PlayerFactory.mediaItemFor(urls.first()))
                        player.prepare()
                        player.play()
                    })
                }
            }
        }

        // ---- Bottom control bar ----------------------------------------------
        if (controlsVisible) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 28.dp, vertical = 20.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(RalysndTvColors.Background.copy(alpha = 0.92f))
                    .padding(horizontal = 20.dp, vertical = 14.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ControlButton(
                        label = if (isPlaying) "❚❚" else "▶",
                        onClick = {
                            poke()
                            if (player.isPlaying) player.pause() else player.play()
                        },
                    )
                    Spacer(Modifier.width(12.dp))
                    ControlButton(label = "−10s", onClick = {
                        poke()
                        if (player.isCurrentMediaItemSeekable) {
                            player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0))
                        }
                    })
                    ControlButton(label = "+10s", onClick = {
                        poke()
                        if (player.isCurrentMediaItemSeekable) {
                            player.seekTo(player.currentPosition + 10_000)
                        }
                    })
                    Spacer(Modifier.width(12.dp))
                    val seekable = durationMs > 0 && player.isCurrentMediaItemSeekable
                    if (seekable) {
                        Slider(
                            value = (positionMs.toFloat() / durationMs).coerceIn(0f, 1f),
                            onValueChange = { fraction ->
                                player.seekTo((durationMs * fraction).toLong())
                            },
                            colors = SliderDefaults.colors(
                                thumbColor = RalysndTvColors.GreenPrimary,
                                activeTrackColor = RalysndTvColors.GreenPrimary,
                                inactiveTrackColor = RalysndTvColors.PillGrey,
                            ),
                            modifier = Modifier.weight(1f),
                        )
                    } else {
                        Spacer(Modifier.weight(1f))
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = formatTime(positionMs, durationMs),
                        color = Color.White,
                        fontSize = 18.sp,
                        fontFamily = RalysndFontFamily,
                    )
                    Spacer(Modifier.width(12.dp))
                    ControlButton(label = PlayerFactory.formatSpeed(speed), onClick = {
                        poke()
                        speed = PlayerFactory.nextSpeed(speed)
                        player.setPlaybackSpeed(speed)
                    })
                    ControlButton(label = "CC", onClick = {
                        poke()
                        showSubtitlePicker = true
                    })
                    ControlButton(label = "♪", onClick = {
                        poke()
                        showAudioPicker = true
                    })
                    ControlButton(label = "Vol−", onClick = {
                        poke()
                        volume = (volume - 0.1f).coerceIn(0f, 1f)
                        player.volume = volume
                    })
                    ControlButton(label = "Vol+", onClick = {
                        poke()
                        volume = (volume + 0.1f).coerceIn(0f, 1f)
                        player.volume = volume
                    })
                    ControlButton(
                        label = if (showNextPanel) "Hide ◂" else "Next ▸",
                        onClick = {
                            poke()
                            showNextPanel = !showNextPanel
                        },
                    )
                }
            }
        }
    }

    if (showSubtitlePicker) {
        TrackPickerDialog(
            title = "Subtitles",
            options = subtitleOptions(player),
            onDismiss = { showSubtitlePicker = false },
            onPick = { option ->
                showSubtitlePicker = false
                applyTextTrack(player, option)
            },
        )
    }
    if (showAudioPicker) {
        TrackPickerDialog(
            title = "Audio track",
            options = audioOptions(player),
            onDismiss = { showAudioPicker = false },
            onPick = { option ->
                showAudioPicker = false
                applyAudioTrack(player, option)
            },
        )
    }
}

@Composable
private fun ControlButton(label: String, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (focused) RalysndTvColors.GreenPrimary else RalysndTvColors.SurfaceElevated,
                RoundedCornerShape(12.dp),
            )
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (focused) Color.Black else Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = RalysndFontFamily,
        )
    }
}

private data class TrackOption(
    val label: String,
    val group: Tracks.Group?,
    val trackIndex: Int,
)

private fun audioOptions(player: ExoPlayer): List<TrackOption> {
    val out = ArrayList<TrackOption>()
    for (group in player.currentTracks.groups) {
        if (group.type != C.TRACK_TYPE_AUDIO) continue
        for (i in 0 until group.length) {
            val format = group.getTrackFormat(i)
            val label = format.label
                ?: format.language?.uppercase()
                ?: "Audio ${out.size + 1}"
            out += TrackOption(label, group, i)
        }
    }
    return out
}

private fun subtitleOptions(player: ExoPlayer): List<TrackOption> {
    val out = ArrayList<TrackOption>()
    out += TrackOption("Off", null, -1)
    for (group in player.currentTracks.groups) {
        if (group.type != C.TRACK_TYPE_TEXT) continue
        for (i in 0 until group.length) {
            val format = group.getTrackFormat(i)
            val label = format.label
                ?: format.language?.uppercase()
                ?: "Subtitles ${out.size}"
            out += TrackOption(label, group, i)
        }
    }
    return out
}

private fun applyAudioTrack(player: ExoPlayer, option: TrackOption) {
    val group = option.group ?: return
    val override = TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex)
    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
        .setOverrideForType(override)
        .build()
}

private fun applyTextTrack(player: ExoPlayer, option: TrackOption) {
    val builder = player.trackSelectionParameters.buildUpon()
    if (option.group == null) {
        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
    } else {
        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(
                TrackSelectionOverride(option.group.mediaTrackGroup, option.trackIndex),
            )
    }
    player.trackSelectionParameters = builder.build()
}

@Composable
private fun TrackPickerDialog(
    title: String,
    options: List<TrackOption>,
    onDismiss: () -> Unit,
    onPick: (TrackOption) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = title,
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (options.isEmpty()) {
                    Text(
                        text = "No tracks available for this channel.",
                        color = RalysndTvColors.TextMuted,
                        fontSize = 17.sp,
                        fontFamily = RalysndFontFamily,
                    )
                }
                for (option in options) {
                    Text(
                        text = option.label,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontFamily = RalysndFontFamily,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(RalysndTvColors.SurfaceElevated)
                            .clickable { onPick(option) }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = RalysndTvColors.GreenPrimary)
            }
        },
        containerColor = RalysndTvColors.Surface,
    )
}

private fun formatTime(positionMs: Long, durationMs: Long): String {
    fun part(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
    }
    return if (durationMs > 0) "${part(positionMs)} / ${part(durationMs)}"
    else "${part(positionMs)} • LIVE"
}
