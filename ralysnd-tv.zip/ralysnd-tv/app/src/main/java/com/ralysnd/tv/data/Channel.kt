package com.ralysnd.tv.data

/**
 * One channel from the bundled channels.json (recovered verbatim from the
 * original DarkTV APK). Keys: id, name, logo, categories, urls.
 * `urls` holds every HLS stream for the channel; the first is the primary
 * stream and the rest are fallbacks the player tries on failure.
 */
data class Channel(
    val id: String,
    val name: String,
    val logo: String,
    val categories: List<String>,
    val urls: List<String>,
) {
    /** Primary stream URL, or null when the channel has no stream at all. */
    val primaryUrl: String? get() = urls.firstOrNull()
    /** True when this channel is live-streamable right now. */
    val isPlayable: Boolean get() = urls.isNotEmpty()
}
