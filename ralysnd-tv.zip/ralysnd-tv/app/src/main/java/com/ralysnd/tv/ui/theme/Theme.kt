package com.ralysnd.tv.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle

/**
 * Ralysnd TV theme — the approved green-split look on every screen:
 * dark charcoal-green background, emerald green accent, grey pills,
 * white text, muted green-grey secondary text, red LIVE badge.
 *
 * Font: the original app used Vazirmatn. No Vazirmatn TTF was recoverable
 * from the APK, so the typeface is FontFamily.Default until the font files
 * are added under res/font/ (see README "Before the first build").
 */
object RalysndTvColors {
    val GreenPrimary = Color(0xFF00C853)
    val GreenBright = Color(0xFF22C55E)
    val GreenDark = Color(0xFF007A33)
    val GreenGlow = Color(0xFF1DB954)
    val Background = Color(0xFF101613)
    val Surface = Color(0xFF1C231F)
    val SurfaceElevated = Color(0xFF262E29)
    val PillGrey = Color(0xFF3A4440)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextMuted = Color(0xFF9DB3A8)
    val LiveRed = Color(0xFFE53935)
}

private val ColorScheme = darkColorScheme(
    primary = RalysndTvColors.GreenPrimary,
    secondary = RalysndTvColors.GreenBright,
    background = RalysndTvColors.Background,
    surface = RalysndTvColors.Surface,
    onBackground = RalysndTvColors.TextPrimary,
    onSurface = RalysndTvColors.TextPrimary,
    error = RalysndTvColors.LiveRed,
)

private val AppTypography = Typography(
    displayLarge = TextStyle(fontSize = 48.sp, fontWeight = FontWeight.Bold),
    headlineLarge = TextStyle(fontSize = 36.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Normal),
    labelLarge = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun RalysndTvTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ColorScheme,
        typography = AppTypography,
        content = content,
    )
}

/** Vazirmatn placeholder — swap FontFamily.Default for the bundled font once added. */
val RalysndFontFamily: FontFamily = FontFamily.Default
