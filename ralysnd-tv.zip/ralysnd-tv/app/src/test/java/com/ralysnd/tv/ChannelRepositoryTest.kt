package com.ralysnd.tv

import com.ralysnd.tv.data.ChannelRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Unit tests for the bundled-channels parsing. org.json needs Robolectric
 * on the JVM (the android.jar stubs throw), so these run under Robolectric.
 * The bundled asset itself is verified separately: python count = 214.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ChannelRepositoryTest {

    private val sampleJson = """
        [
          {"id": "a.ir", "name": "Alpha", "logo": "https://example.com/a.png",
           "categories": ["news"], "urls": ["https://example.com/a.m3u8"]},
          {"id": "b.ir", "name": "Beta", "logo": "",
           "categories": ["news", "sports"],
           "urls": ["https://example.com/b1.m3u8", "https://example.com/b2.m3u8"]},
          {"id": "c.ir", "name": "Gamma", "logo": "",
           "categories": [], "urls": []}
        ]
    """.trimIndent()

    @Test
    fun parsesAllChannels() {
        val repo = ChannelRepository(ChannelRepository.parseChannels(sampleJson))
        assertEquals(3, repo.all.size)
        assertEquals("Alpha", repo.all[0].name)
        assertEquals("https://example.com/a.m3u8", repo.all[0].primaryUrl)
        assertTrue(repo.all[0].isPlayable)
    }

    @Test
    fun multiUrlChannelKeepsAlternates() {
        val repo = ChannelRepository(ChannelRepository.parseChannels(sampleJson))
        val beta = repo.channelById("b.ir")!!
        assertEquals(2, beta.urls.size)
        assertEquals("https://example.com/b2.m3u8", beta.urls[1])
    }

    @Test
    fun uncategorisedChannelFallsUnderGeneral() {
        val repo = ChannelRepository(ChannelRepository.parseChannels(sampleJson))
        val gamma = repo.channelById("c.ir")!!
        assertEquals(listOf("general"), gamma.categories)
        assertTrue(repo.channelsFor("general").any { it.id == "c.ir" })
    }

    @Test
    fun categoriesAreOrderedByCount() {
        val repo = ChannelRepository(ChannelRepository.parseChannels(sampleJson))
        // news: 2 channels, sports: 1, general: 1 (Gamma). "all" is always first.
        assertEquals("all", repo.categories.first())
        assertEquals("news", repo.categories[1])
    }

    @Test
    fun nextChannelsStayInTheSameCategory() {
        val repo = ChannelRepository(ChannelRepository.parseChannels(sampleJson))
        val alpha = repo.channelById("a.ir")!!
        val next = repo.nextChannels(alpha)
        assertEquals(listOf("b.ir"), next.map { it.id })
    }
}
