# Ralysnd TV

Clean-room rebuild of **Dark TV Live** (original package `com.darktv.player`
v1.0.0) as a true Android TV app, approved 2026-11-11.

- **Project name:** Ralysnd TV
- **Package:** `com.ralysnd.tv` (separate app — the original DarkTV is untouched)
- **Player:** Media3 ExoPlayer (kept, per user order), tuned for live HLS
- **Design:** approved sample #5 **green split** — dark charcoal-green
  background, emerald green accent — on **every** screen (home, channels,
  player, settings), matching the approved mockups tile by tile.
- **Channels:** all **214** from the original app, bundled verbatim in
  `app/src/main/assets/channels.json` (18 categories; mostly HLS `m3u8`,
  BBC Persian also carries DASH `.mpd` alternates — the player sets the
  MIME type explicitly per URL).

## Screens

| Screen | File | Mockup matched |
|---|---|---|
| Home (green split: live preview left, Up Next list right, category pills on top) | `ui/home/HomeScreen.kt` | `media-generation-darktv-sample-green-split-…webp` |
| All Channels (category rail left, channel grid right) | `ui/channels/ChannelsScreen.kt` | `media-generation-ralysnd-tv-channels-list-…webp` |
| Player (video + NEXT CHANNELS panel + control bar) | `ui/player/PlayerScreen.kt` | `media-generation-ralysnd-tv-player-screen-…webp` |
| Categories home (category pills + preview + channel list) | same `HomeScreen` (pills drive the split) | `media-generation-ralysnd-tv-categories-home-…webp` |
| Settings (left nav + playback rows) | `ui/settings/SettingsScreen.kt` | `media-generation-ralysnd-tv-settings-screen-…webp` |

## What is in the app (and what is not)

Kept from the original, as proven by the APK analysis:

- Home with category sections, channel list with logo + name grouped by
  category, tap-to-play full-screen live, ExoPlayer controls (play/pause,
  seek, speed 0.25x–2x, subtitle + audio track pickers).
- Settings screen — a **new** addition, approved via the settings mockup
  (video quality, buffer size, autoplay next channel, subtitles, audio
  language, app version). Values persist and apply to the player.

Deliberately **not** included (not in the original, not approved):

- No text-search UI anywhere (the channels-list mockup shows a search icon;
  it was left out on purpose).
- No favourites, no EPG / programme guide, no recent/history, no sleep
  timer, no recording, no downloads.

## Player behaviour

- Live HLS with a 2 s target offset, short rebuffer, buffer size follows
  the Settings screen (Small / Medium / Large).
- On failure the player tries the next stream URL of the same channel
  (channels carry up to 8 alternates) before showing an error + Retry.
- D-pad: ↑↓ move in lists, ←→ move between panels, OK plays/selects,
  Back returns to Home. In the player with controls hidden, ↑↓ zap to the
  next/previous channel in the same category.
- Home preview plays the selected channel muted; OK opens the full player.

## Before the first build

1. **Vazirmatn font** — the original used it, but no TTF was recoverable
   from the APK. Add `Vazirmatn-Regular.ttf` / `Vazirmatn-Bold.ttf` under
   `app/src/main/res/font/` and point `RalysndFontFamily` in
   `ui/theme/Theme.kt` at them (currently `FontFamily.Default`).
2. **Banner** — `res/drawable/banner.xml` is a vector placeholder; replace
   with a 320×180 PNG banner for the Leanback launcher before release.
3. **Keystore** — no signing config yet; create one before a release build.
4. Build on the build server (same transfer flow as the other apps):
   Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24, compileSdk/targetSdk 34,
   minSdk 21. Then `./gradlew :app:testDebugUnitTest :app:assembleDebug`
   and verify the APK (size/SHA/`aapt dump badging`) before handing over
   the link. No build has been run from this scaffold yet.

## Verification done locally (scaffold only)

- `channels.json` bundled byte-identical to the recovered file, 214 entries.
- `grep` over `app/src`: no text-search UI, no favourites/EPG/recording
  code; package `com.ralysnd.tv`; Leanback launcher + banner in the manifest.
- Unit test: `ChannelRepositoryTest` (Robolectric, 5 tests) — run with
  `:app:testDebugUnitTest` on the build server.
