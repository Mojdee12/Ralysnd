package com.v2ray.ang.ui

import android.content.Intent
import android.os.Bundle
import android.webkit.WebView
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.v2ray.ang.AppConfig
import com.v2ray.ang.BuildConfig
import com.v2ray.ang.R
import com.v2ray.ang.core.CoreNativeManager
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.compose.RalysndCard
import com.v2ray.ang.ui.compose.SettingsMenuItem
import com.v2ray.ang.util.Utils

class AboutActivity : BaseComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() {
        AboutScreen(
            onBackClick = { finish() },
            onTranslatorsClick = {
                startActivity(Intent(this, TranslatorsActivity::class.java))
            }
        )
    }
}

@Composable
fun AboutScreen(
    onBackClick: () -> Unit,
    onTranslatorsClick: () -> Unit
) {
    val context = LocalContext.current
    var showOssDialog by remember { mutableStateOf(false) }

    val libVersion = CoreNativeManager.getLibVersion()
    val versionText = "v${BuildConfig.VERSION_NAME} ($libVersion)"
    val appIdText = BuildConfig.APPLICATION_ID

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            AppTopBar(
                title = stringResource(R.string.title_about),
                onBackClick = onBackClick
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            // Hero card: logo + name + version + the GPL-3.0 credit line
            // (still opens the source page, as the old credit row did).
            // The mockup's "Build 2315 • arm64-v8a" line is not reproduced:
            // the real versionCode is 755 and no ABI string is available.
            RalysndCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painterResource(R.drawable.ic_ralysnd_logo),
                        contentDescription = null,
                        modifier = Modifier.size(96.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = versionText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = stringResource(R.string.about_based_on_pattng),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.clickable { Utils.openUri(context, AppConfig.APP_URL) }
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = appIdText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            // Links card. The mockup's "LINKS" / "LEGAL" section headers
            // and its "Third-party notices" row have no string keys and no
            // data source: the OSS licenses dialog covers third-party
            // notices, and the two cards are left unlabeled rather than
            // inventing labels. The mockup's "© 2025 Ralysnd" footer is
            // likewise omitted (no string key).
            RalysndCard {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_source_code_24dp),
                        title = stringResource(R.string.title_source_code),
                        onClick = { Utils.openUri(context, AppConfig.APP_URL) }
                    )
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_telegram_24dp),
                        title = stringResource(R.string.title_tg_channel),
                        onClick = { Utils.openUri(context, AppConfig.TG_CHANNEL_URL) }
                    )
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_privacy_24dp),
                        title = stringResource(R.string.title_privacy_policy),
                        onClick = { Utils.openUri(context, AppConfig.APP_PRIVACY_POLICY) }
                    )
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_feedback_24dp),
                        title = stringResource(R.string.title_pref_feedback),
                        onClick = { Utils.openUri(context, AppConfig.APP_ISSUES_URL) }
                    )
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.ic_translate_24dp),
                        title = stringResource(R.string.title_translators),
                        onClick = onTranslatorsClick
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            RalysndCard {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.license_24px),
                        title = stringResource(R.string.title_oss_license),
                        onClick = { showOssDialog = true }
                    )
                    // The Aether binary is not a Gradle dependency, so the generated license report
                    // cannot list it; its AGPL-3.0 notice and source link live here instead.
                    SettingsMenuItem(
                        icon = painterResource(R.drawable.license_24px),
                        title = stringResource(R.string.title_aether_core),
                        subtitle = stringResource(R.string.summary_aether_core),
                        onClick = { Utils.openUri(context, AppConfig.AETHER_URL) }
                    )
                }
            }
            NavigationBarsSpacer()
        }
    }

    if (showOssDialog) {
        AlertDialog(
            onDismissRequest = { showOssDialog = false },
            title = { Text(stringResource(R.string.title_oss_license)) },
            text = {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            loadUrl("file:///android_asset/open_source_licenses.html")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 300.dp)
                )
            },
            confirmButton = {
                TextButton(onClick = { showOssDialog = false }) {
                    Text(stringResource(R.string.action_ok))
                }
            },
            containerColor = MaterialTheme.colorScheme.surface,
            modifier = Modifier.padding(bottom = 60.dp)
        )
    }
}
