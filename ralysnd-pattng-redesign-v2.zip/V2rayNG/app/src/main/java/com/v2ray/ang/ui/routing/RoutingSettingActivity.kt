package com.v2ray.ang.ui.routing

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.dto.entities.RulesetItem
import com.v2ray.ang.enums.RoutingType
import com.v2ray.ang.extension.toastError
import com.v2ray.ang.extension.toastSuccess
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.handler.SettingsManager
import com.v2ray.ang.ui.base.HelperBaseComponentActivity
import com.v2ray.ang.ui.compose.AppDropdownMenuItems
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.NavigationBarsBottomPadding
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.compose.RalysndCard
import com.v2ray.ang.ui.compose.RalysndModeCard
import com.v2ray.ang.ui.compose.RalysndPrimaryButton
import com.v2ray.ang.ui.compose.RalysndRuleChip
import com.v2ray.ang.ui.compose.RalysndSectionHeader
import com.v2ray.ang.ui.compose.ReorderableListItem
import com.v2ray.ang.ui.compose.SelectListDialog
import com.v2ray.ang.ui.compose.SettingsListItem
import com.v2ray.ang.ui.compose.colorConfigType
import com.v2ray.ang.ui.compose.verticalScrollbar
import com.v2ray.ang.util.JsonUtil
import com.v2ray.ang.util.LogUtil
import com.v2ray.ang.util.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState

private enum class RoutingMenuAction(@StringRes val labelRes: Int) {
    ImportPredefined(R.string.routing_settings_import_predefined_rulesets),
    ImportClipboard(R.string.routing_settings_import_rulesets_from_clipboard),
    ImportQRCode(R.string.routing_settings_import_rulesets_from_qrcode),
    ExportClipboard(R.string.routing_settings_export_rulesets_to_clipboard)
}

private enum class RoutingPreset(val type: RoutingType, @StringRes val labelRes: Int) {
    ChinaWhitelist(RoutingType.WHITE, R.string.routing_preset_china_whitelist),
    ChinaBlacklist(RoutingType.BLACK, R.string.routing_preset_china_blacklist),
    Global(RoutingType.GLOBAL, R.string.routing_preset_global),
    IranWhitelist(RoutingType.WHITE_IRAN, R.string.routing_preset_iran_whitelist),
    RussiaWhitelist(RoutingType.WHITE_RUSSIA, R.string.routing_preset_russia_whitelist)
}

class RoutingSettingActivity : HelperBaseComponentActivity() {
    private val viewModel: RoutingSettingsViewModel by viewModels {
        viewModelFactory {
            initializer { RoutingSettingsViewModel(application, RoutingEditRepository()) }
        }
    }
    private val domainStrategyState = MutableStateFlow("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        domainStrategyState.value = getDomainStrategy()
    }

    @Composable
    override fun ScreenContent() {
        RoutingSettingScreen(
            viewModel = viewModel,
            domainStrategyState = domainStrategyState,
            onBackClick = { finish() },
            onAddRule = { startActivity(Intent(this, RoutingEditActivity::class.java)) },
            onEditRule = { position, id ->
                // PattNG: with the rule's id, by which the editor finds it, the list's order having maybe changed since.
                startActivity(Intent(this, RoutingEditActivity::class.java).putExtra("position", position).putExtra(EXTRA_RULE_ID, id))
            },
            onDomainStrategySelected = { value ->
                MmkvManager.encodeSettings(AppConfig.PREF_ROUTING_DOMAIN_STRATEGY, value)
                domainStrategyState.value = value
            },
            onImportPredefined = { type -> importPredefined(type) },
            onImportClipboard = { importFromClipboard() },
            onImportQRcode = { importQRcode() },
            onExportClipboard = { export2Clipboard() }
        )
    }

    override fun onResume() {
        super.onResume()
        viewModel.reload()
    }

    private fun getDomainStrategy(): String {
        val strategies = resources.getStringArray(R.array.routing_domain_strategy)
        return MmkvManager.decodeSettingsString(AppConfig.PREF_ROUTING_DOMAIN_STRATEGY) ?: strategies.first()
    }

    private fun importPredefined(type: RoutingType) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val stored = SettingsManager.resetRoutingRulesetsFromPresets(this@RoutingSettingActivity, type)
                launch(Dispatchers.Main) {
                    viewModel.reload()
                    // PattNG: a preset the storage refused is told.
                    if (stored) toastSuccess(R.string.toast_success) else toastError(R.string.toast_failure)
                }
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "Failed to import predefined ruleset", e)
            }
        }
    }

    private fun importFromClipboard() {
        val clipboard = try {
            Utils.getClipboard(this)
        } catch (e: Exception) {
            toastError(R.string.toast_failure)
            return
        }
        lifecycleScope.launch(Dispatchers.IO) {
            val result = SettingsManager.resetRoutingRulesets(clipboard)
            withContext(Dispatchers.Main) {
                if (result) {
                    viewModel.reload()
                    toastSuccess(R.string.toast_success)
                } else {
                    toastError(R.string.toast_failure)
                }
            }
        }
    }

    private fun importQRcode() {
        launchQRCodeScanner { scanResult ->
            if (scanResult != null) {
                lifecycleScope.launch(Dispatchers.IO) {
                    val result = SettingsManager.resetRoutingRulesets(scanResult)
                    withContext(Dispatchers.Main) {
                        if (result) {
                            viewModel.reload()
                            toastSuccess(R.string.toast_success)
                        } else {
                            toastError(R.string.toast_failure)
                        }
                    }
                }
            }
        }
    }

    private fun export2Clipboard() {
        // PattNG: the rules as stored, read off the main thread once the changes the list asked for are stored.
        lifecycleScope.launch {
            val rulesetList = viewModel.storedRules()
            if (rulesetList.isEmpty()) {
                toastError(R.string.toast_failure)
            } else {
                Utils.setClipboard(this@RoutingSettingActivity, JsonUtil.toJson(rulesetList))
                toastSuccess(R.string.toast_success)
            }
        }
    }
}

@Composable
fun RoutingSettingScreen(
    viewModel: RoutingSettingsViewModel,
    domainStrategyState: MutableStateFlow<String>,
    onBackClick: () -> Unit,
    onAddRule: () -> Unit,
    onEditRule: (position: Int, id: String) -> Unit,
    onDomainStrategySelected: (String) -> Unit,
    onImportPredefined: (RoutingType) -> Unit,
    onImportClipboard: () -> Unit,
    onImportQRcode: () -> Unit,
    onExportClipboard: () -> Unit
) {
    val rulesets by viewModel.rulesetsFlow.collectAsStateWithLifecycle()
    val domainStrategy by domainStrategyState.collectAsState()
    var showMenu by remember { mutableStateOf(false) }
    var showPresetDialog by remember { mutableStateOf(false) }

    val domainStrategies = stringArrayResource(R.array.routing_domain_strategy).toList()
    val lazyListState = rememberLazyListState()
    val reorderableState = rememberReorderableLazyListState(lazyListState) { from, to ->
        // Lazy list indices include the preceding non-rule content, so resolve the stable rule keys.
        // PattNG: by the ids, which the view model finds in the list it holds.
        viewModel.move(from.key as? String ?: return@rememberReorderableLazyListState, to.key as? String ?: return@rememberReorderableLazyListState)
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            AppTopBar(
                title = stringResource(R.string.routing_settings_title),
                onBackClick = onBackClick,
                actions = {
                    IconButton(onClick = onAddRule) {
                        Icon(
                            painterResource(R.drawable.ic_add_24dp),
                            contentDescription = stringResource(R.string.acc_add_rule)
                        )
                    }
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(
                                painterResource(R.drawable.ic_more_vert_24dp),
                                contentDescription = stringResource(R.string.acc_more)
                            )
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            AppDropdownMenuItems(RoutingMenuAction.entries, { it.labelRes }) { action ->
                                showMenu = false
                                when (action) {
                                    RoutingMenuAction.ImportPredefined -> showPresetDialog = true
                                    RoutingMenuAction.ImportClipboard -> onImportClipboard()
                                    RoutingMenuAction.ImportQRCode -> onImportQRcode()
                                    RoutingMenuAction.ExportClipboard -> onExportClipboard()
                                }
                            }
                        }
                    }
                }
            )
        },
        // Pinned yellow ADD RULE button (48dp); the top-bar add icon stays.
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surface) {
                Column {
                    RalysndPrimaryButton(
                        text = stringResource(R.string.routing_settings_add_rule),
                        onClick = onAddRule,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                    NavigationBarsSpacer()
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            state = lazyListState,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScrollbar(lazyListState),
            contentPadding = NavigationBarsBottomPadding()
        ) {
            item(key = "domain_strategy") {
                RalysndCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    SettingsListItem(
                        title = stringResource(R.string.routing_settings_domain_strategy),
                        entries = domainStrategies,
                        values = domainStrategies,
                        selectedValue = domainStrategy,
                        onSelected = { onDomainStrategySelected(it) }
                    )
                }
            }
            // Mode shortcuts. No card is shown selected: which preset the
            // current rules match cannot be derived honestly (the preset
            // lookup is private to SettingsManager), so these import a
            // preset (Global / Iran whitelist, the app's default) or open
            // the rule editor — they do not claim a current mode.
            item(key = "routing_modes") {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    RalysndModeCard(
                        title = stringResource(R.string.routing_preset_global),
                        subtitle = "",
                        selected = false,
                        onClick = { onImportPredefined(RoutingType.GLOBAL) },
                        modifier = Modifier.weight(1f)
                    )
                    RalysndModeCard(
                        title = stringResource(R.string.routing_preset_iran_whitelist),
                        subtitle = "",
                        selected = false,
                        onClick = { onImportPredefined(RoutingType.WHITE_IRAN) },
                        modifier = Modifier.weight(1f)
                    )
                    RalysndModeCard(
                        title = stringResource(R.string.routing_settings_add_rule),
                        subtitle = "",
                        selected = false,
                        onClick = onAddRule,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            item {
                RalysndSectionHeader(
                    text = stringResource(R.string.routing_settings_rule_title),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }

            itemsIndexed(
                items = rulesets,
                key = { _, ruleset -> ruleset.id }
            ) { index, ruleset ->
                ReorderableItem(reorderableState, key = ruleset.id) { isDragging ->
                    ReorderableListItem(
                        scope = this,
                        isDragging = isDragging
                    ) {
                        RoutingRulesetItem(
                            ruleset = ruleset,
                            onEdit = { onEditRule(index, ruleset.id) },
                            onEnabledChange = { checked ->
                                viewModel.update(ruleset.copy(enabled = checked))
                            },
                            onUpdate = { updated -> viewModel.update(updated) }
                        )
                    }
                }
            }
        }
    }


    if (showPresetDialog) {
        SelectListDialog(
            title = stringResource(R.string.routing_settings_import_predefined_rulesets),
            options = RoutingPreset.entries,
            optionText = { stringResource(it.labelRes) },
            onSelected = { preset ->
                showPresetDialog = false
                onImportPredefined(preset.type)
            },
            onDismiss = { showPresetDialog = false }
        )
    }
}

/**
 * One routing rule as a card (redesign v2): remarks + lock + edit + enable
 * switch on top, then the rule's entries as small removable chips grouped
 * by Domains / IP Ranges / Apps. Tapping a chip opens the rule editor;
 * the × removes just that entry. The group headers reuse the editor's own
 * field labels (domain / ip / process), uppercased — the mockup's "Apps"
 * header has no string key, so the editor's "process" label stands in.
 */
@Composable
private fun RoutingRulesetItem(
    ruleset: RulesetItem,
    onEdit: () -> Unit,
    onEnabledChange: (Boolean) -> Unit,
    onUpdate: (RulesetItem) -> Unit
) {
    RalysndCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
        // The "port: …" chip's prefix, read once here (composable context)
        // so the remove callback below can tell it apart from an IP entry.
        val portLabel = stringResource(R.string.routing_settings_port)
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = ruleset.remarks ?: "",
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (ruleset.locked == true) {
                    Icon(
                        painter = painterResource(R.drawable.ic_lock_24dp),
                        contentDescription = stringResource(R.string.acc_locked),
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_edit_24dp),
                        contentDescription = stringResource(R.string.acc_edit)
                    )
                }
                Switch(
                    checked = ruleset.enabled ?: false,
                    onCheckedChange = onEnabledChange,
                    modifier = Modifier.scale(0.7f),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.onSecondary,
                        checkedTrackColor = MaterialTheme.colorScheme.secondary
                    )
                )
            }
            if (!ruleset.outboundTag.isNullOrEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = ruleset.outboundTag,
                    style = MaterialTheme.typography.labelMedium,
                    color = colorConfigType
                )
            }
            RuleChipGroup(
                headerRes = R.string.routing_settings_domain,
                entries = ruleset.domain,
                onEdit = onEdit,
                onRemove = { entry ->
                    onUpdate(ruleset.copy(domain = ruleset.domain?.minus(entry)?.takeIf { it.isNotEmpty() }))
                }
            )
            RuleChipGroup(
                headerRes = R.string.routing_settings_ip,
                entries = (ruleset.ip ?: emptyList()) + listOfNotNull(
                    ruleset.port?.takeIf { it.isNotBlank() }?.let { "$portLabel: $it" }
                ),
                onEdit = onEdit,
                onRemove = { entry ->
                    if (entry.startsWith("$portLabel: ")) {
                        onUpdate(ruleset.copy(port = null))
                    } else {
                        onUpdate(ruleset.copy(ip = ruleset.ip?.minus(entry)?.takeIf { it.isNotEmpty() }))
                    }
                }
            )
            RuleChipGroup(
                headerRes = R.string.routing_settings_process,
                entries = ruleset.process,
                onEdit = onEdit,
                onRemove = { entry ->
                    onUpdate(ruleset.copy(process = ruleset.process?.minus(entry)?.takeIf { it.isNotEmpty() }))
                }
            )
        }
    }
}

/** One chip group inside a rule card; hidden entirely when it has no entries. */
@Composable
private fun RuleChipGroup(
    @StringRes headerRes: Int,
    entries: List<String>?,
    onEdit: () -> Unit,
    onRemove: (String) -> Unit
) {
    if (entries.isNullOrEmpty()) return
    Spacer(modifier = Modifier.height(12.dp))
    // The editor's field label, first word only ("process (Package Name …)"
    // would wrap as a header), uppercased like the other section headers.
    Text(
        text = stringResource(headerRes).substringBefore(" ").uppercase(),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(8.dp))
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (entry in entries) {
            RalysndRuleChip(
                label = entry,
                onClick = onEdit,
                onRemove = { onRemove(entry) }
            )
        }
    }
}
