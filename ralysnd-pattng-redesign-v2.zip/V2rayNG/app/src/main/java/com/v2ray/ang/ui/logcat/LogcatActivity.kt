package com.v2ray.ang.ui.logcat

import android.content.ClipData
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.extension.toastError
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.NavigationBarsBottomPadding
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.compose.RalysndCard
import com.v2ray.ang.ui.compose.RalysndFilterChip
import com.v2ray.ang.ui.compose.RalysndLevelTag
import com.v2ray.ang.ui.compose.RalysndPrimaryButton
import com.v2ray.ang.ui.compose.verticalScrollbar
import com.v2ray.ang.util.LogUtil
import com.v2ray.ang.util.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LogcatActivity : BaseComponentActivity() {
    private val viewModel: LogcatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() {
        LogcatScreen(
            viewModel = viewModel,
            onBackClick = { finish() },
            onShareLogcat = { shareLogcat() }
        )
    }

    private fun shareLogcat() {
        lifecycleScope.launch(Dispatchers.IO) {
            val logText = viewModel.filteredLogs.value.joinToString("\n")

            val result = try {
                val shareDir = File(cacheDir, "shared_logs").apply {
                    mkdirs()
                }

                shareDir.listFiles()?.forEach { it.delete() }

                val timestamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
                val logFile = File(shareDir, "Ralysnd_logcat_$timestamp.txt")
                logFile.writeText(logText, Charsets.UTF_8)

                val uri = FileProvider.getUriForFile(
                    this@LogcatActivity,
                    "${packageName}.cache",
                    logFile
                )

                uri to logFile.name
            } catch (e: Exception) {
                LogUtil.e(AppConfig.TAG, "Failed to share Logcat", e)
                withContext(Dispatchers.Main) {
                    toastError(R.string.toast_failure)
                }
                return@launch
            }

            withContext(Dispatchers.Main) {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_STREAM, result.first)
                    putExtra(Intent.EXTRA_SUBJECT, result.second)
                    putExtra(Intent.EXTRA_TITLE, result.second)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    clipData = ClipData.newUri(contentResolver, result.second, result.first)
                }

                startActivity(
                    Intent.createChooser(
                        shareIntent,
                        getString(R.string.logcat_share)
                    )
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun LogcatScreen(
    viewModel: LogcatViewModel,
    onBackClick: () -> Unit,
    onShareLogcat: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val logs by viewModel.logEntries.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()

    var logFilter by remember { mutableStateOf(LogFilter.ALL) }
    // The "error" word comes from the core log-level array (translatable=false),
    // uppercased to match the level tags in the terminal card.
    val errorLabel = stringArrayResource(R.array.core_loglevel)
        .firstOrNull { it.equals("error", ignoreCase = true) }?.uppercase() ?: "ERROR"
    val filteredLogs = remember(logs, logFilter) {
        when (logFilter) {
            LogFilter.ALL -> logs
            LogFilter.ERRORS -> logs.filter { parseLogLine(it.text).level in ERROR_LEVELS }
            LogFilter.CONNECTION -> logs.filter { entry ->
                CONNECTION_KEYWORDS.any { entry.text.lowercase().contains(it) }
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            AppTopBar(
                title = stringResource(R.string.title_logcat),
                onBackClick = onBackClick,
                isLoading = isLoading,
                isSearchActive = showSearch,
                searchQuery = searchQuery,
                onSearchQueryChange = {
                    searchQuery = it
                    viewModel.filter(it)
                },
                onSearchClose = {
                    searchQuery = ""
                    viewModel.filter("")
                    showSearch = false
                },
                searchPlaceholder = stringResource(R.string.menu_item_search),
                actions = {
                    if (!showSearch) {
                        IconButton(onClick = { showSearch = true }) {
                            Icon(
                                painterResource(R.drawable.ic_search_24dp),
                                contentDescription = stringResource(R.string.acc_search)
                            )
                        }
                    }
                    IconButton(onClick = { viewModel.copyLogcat() }) {
                        Icon(
                            painterResource(R.drawable.ic_copy),
                            contentDescription = stringResource(R.string.acc_copy_log)
                        )
                    }
                    IconButton(onClick = { onShareLogcat() }) {
                        Icon(
                            painterResource(R.drawable.ic_share_24dp),
                            contentDescription = stringResource(R.string.acc_share_log)
                        )
                    }
                    IconButton(onClick = {
                        scope.launch(Dispatchers.IO) { viewModel.clearLogcat() }
                    }) {
                        Icon(
                            painterResource(R.drawable.ic_delete_24dp),
                            contentDescription = stringResource(R.string.acc_clear_log)
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.loadLogcat() },
                modifier = Modifier.navigationBarsPadding()
            ) {
                Icon(
                    painterResource(R.drawable.ic_restore_24dp),
                    contentDescription = stringResource(R.string.acc_refresh)
                )
            }
        },
        // Pinned yellow Clear logs button (48dp); the top-bar clear icon stays.
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surface) {
                Column {
                    RalysndPrimaryButton(
                        text = stringResource(R.string.logcat_clear),
                        onClick = { scope.launch(Dispatchers.IO) { viewModel.clearLogcat() } },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                    NavigationBarsSpacer()
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Filter chips. "All" shows the (search-filtered) line count; the
            // "Connection" chip is labeled with the only existing short
            // "Connection…" string ("Connection checks") — no "Connection"
            // string key exists and no new keys may be added.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RalysndFilterChip(
                    label = "${stringResource(R.string.filter_config_all)} (${logs.size})",
                    selected = logFilter == LogFilter.ALL,
                    onClick = { logFilter = LogFilter.ALL }
                )
                RalysndFilterChip(
                    label = errorLabel,
                    selected = logFilter == LogFilter.ERRORS,
                    onClick = { logFilter = LogFilter.ERRORS }
                )
                RalysndFilterChip(
                    label = stringResource(R.string.notification_channel_connection_checks),
                    selected = logFilter == LogFilter.CONNECTION,
                    onClick = { logFilter = LogFilter.CONNECTION }
                )
            }
            RalysndCard(
                modifier = Modifier
                    .padding(horizontal = 16.dp)
                    .weight(1f)
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScrollbar(listState),
                    contentPadding = NavigationBarsBottomPadding()
                ) {
                    items(items = filteredLogs, key = { it.key }) { log ->
                        LogcatItem(
                            log = log.text,
                            onCopy = { Utils.setClipboard(context, log.text) }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

/** The three log filters (redesign v2). */
private enum class LogFilter { ALL, ERRORS, CONNECTION }

private val ERROR_LEVELS = setOf("E", "F")

/** Keywords that mark a log line as connection-related (tunnel, dial, DNS…). */
private val CONNECTION_KEYWORDS = listOf(
    "connect", "tunnel", "handshake", "proxy", "dial", "dns",
    "tcp", "udp", "socket", "wireguard", "vless", "vmess", "trojan", "xray", "core"
)

/** One parsed logcat `-v time` line: `MM-DD HH:MM:SS.mmm  PID  TID L TAG: message`. */
private data class ParsedLogLine(
    val timestamp: String?,
    val level: String?,
    val message: String
)

private val LOG_LINE_REGEX =
    Regex("""^(\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3})\s+\d+\s+\d+\s+([VDIWEF])\s+(.*)$""")

/** Parses a `-v time` line; anything else is shown whole, with no tag. */
private fun parseLogLine(log: String): ParsedLogLine {
    val match = LOG_LINE_REGEX.find(log) ?: return ParsedLogLine(null, null, log)
    return ParsedLogLine(
        timestamp = match.groupValues[1],
        level = match.groupValues[2],
        message = match.groupValues[3]
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun LogcatItem(log: String, onCopy: () -> Unit) {
    val parsed = parseLogLine(log)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onCopy, onLongClick = onCopy)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        if (parsed.timestamp != null) {
            Text(
                text = parsed.timestamp,
                style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1
            )
            Spacer(modifier = Modifier.width(8.dp))
        }
        if (parsed.level != null) {
            RalysndLevelTag(level = parsed.level)
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
            text = parsed.message,
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            modifier = Modifier.weight(1f)
        )
    }
}
