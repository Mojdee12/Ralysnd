package com.v2ray.ang.ui.subscription

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.v2ray.ang.R
import com.v2ray.ang.dto.entities.SubscriptionCache
import com.v2ray.ang.extension.toTrafficString
import com.v2ray.ang.extension.toast
import com.v2ray.ang.extension.toastError
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.DeleteConfirmDialog
import com.v2ray.ang.ui.compose.NavigationBarsBottomPadding
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.compose.QRCodeDialog
import com.v2ray.ang.ui.compose.RalysndCard
import com.v2ray.ang.ui.compose.RalysndPrimaryButton
import com.v2ray.ang.ui.compose.RalysndUsageBar
import com.v2ray.ang.ui.compose.ReorderableListItem
import com.v2ray.ang.ui.compose.SelectListDialog
import com.v2ray.ang.ui.compose.SettingsSwitchItem
import com.v2ray.ang.ui.compose.verticalScrollbar
import com.v2ray.ang.ui.main.buildSubscriptionInfoUiModel
import com.v2ray.ang.util.Utils
import sh.calvin.reorderable.ReorderableItem
import sh.calvin.reorderable.rememberReorderableLazyListState

private enum class SubscriptionRowAction(@StringRes val labelRes: Int) {
    ShareQRCode(R.string.share_subscription_qrcode),
    ShareClipboard(R.string.share_subscription_clipboard),
    Edit(R.string.acc_edit),
    Delete(R.string.acc_delete)
}

private data class SubscriptionDeleteTarget(val guid: String, val name: String)

class SubSettingActivity : BaseComponentActivity() {
    /** PattNG: the list, read and changed off the main thread, see [SubscriptionsViewModel]. */
    private val viewModel: SubscriptionsViewModel by viewModels {
        viewModelFactory {
            initializer { SubscriptionsViewModel(application, SubEditRepository()) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() {
        val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()
        // PattNG: a change the storage refused is told once, each refusal by its number, so that one set again right
        // after the last was told is told too; the list shows the subscriptions as stored.
        val refusal = viewModel.refused.collectAsStateWithLifecycle().value
        val failureText = stringResource(R.string.toast_failure)
        LaunchedEffect(refusal) {
            if (refusal != null) {
                toastError(failureText)
                viewModel.onRefusalShown(refusal)
            }
        }
        SubSettingScreen(
            viewModel = viewModel,
            isLoading = isLoading,
            onBackClick = { finish() },
            onAddClick = { startActivity(Intent(this, SubEditActivity::class.java)) },
            onSubUpdate = { viewModel.updateSubscriptions() },
            onEditSub = { subId ->
                startActivity(Intent(this, SubEditActivity::class.java).putExtra("subId", subId))
            },
            onRemoveSub = { subId -> removeSub(subId) },
            onShareQRCode = viewModel::shareQRCode,
            onShareClipboard = { url ->
                Utils.setClipboard(this, url)
                toast(getString(R.string.toast_success))
            }
        )
    }

    override fun onResume() {
        super.onResume()
        viewModel.onScreenShown()
        viewModel.reload()
    }

    /**
     * PattNG: what the list stores while out of sight is told to the main screen, see
     * [SubscriptionsViewModel.onScreenHidden]: this runs before the main screen gets the list's result, whether the list
     * finishes itself or the system closes it, as when the notification brings the main screen up.
     */
    override fun onPause() {
        viewModel.onScreenHidden()
        super.onPause()
    }

    private fun removeSub(subId: String) {
        viewModel.remove(subId)
    }
}

@Composable
fun SubSettingScreen(
    viewModel: SubscriptionsViewModel,
    isLoading: Boolean,
    onBackClick: () -> Unit,
    onAddClick: () -> Unit,
    onSubUpdate: () -> Unit,
    onEditSub: (String) -> Unit,
    onRemoveSub: (String) -> Unit,
    onShareQRCode: (String) -> Unit,
    onShareClipboard: (String) -> Unit
) {
    val subscriptions by viewModel.subsFlow.collectAsStateWithLifecycle()
    var showUpdateDialog by remember { mutableStateOf(false) }
    // PattNG: read off the main thread when the dialog opens, see SubscriptionsViewModel.loadUpdateOptions.
    val updateOptions by viewModel.updateOptions.collectAsStateWithLifecycle()
    var removeTarget by remember { mutableStateOf<SubscriptionDeleteTarget?>(null) }
    // PattNG: read off the main thread with the subscriptions, see SubscriptionsViewModel.reload.
    val confirmRemove by viewModel.confirmRemove.collectAsStateWithLifecycle()

    var rowMenuTarget by remember { mutableStateOf<SubscriptionCache?>(null) }
    val qrCodeBitmap by viewModel.qrCode.collectAsStateWithLifecycle()

    val lazyListState = rememberLazyListState()
    val reorderableState = rememberReorderableLazyListState(lazyListState) { from, to ->
        // PattNG: by the keys of the subscriptions, which the rows are keyed by, not by their positions.
        viewModel.move(from.key as? String ?: return@rememberReorderableLazyListState, to.key as? String ?: return@rememberReorderableLazyListState)
    }

    // Usage totals across the subscriptions that report a quota, for the
    // summary card; the card is omitted entirely when none reports one.
    val nowMillis = System.currentTimeMillis()
    val reportedUsage = subscriptions.mapNotNull { cache ->
        cache.subscription.usageInfo?.let { buildSubscriptionInfoUiModel(it, nowMillis) }
    }.filter { it.totalBytes > 0L }
    val totalUsedBytes = reportedUsage.sumOf { it.usedBytes }
    val totalQuotaBytes = reportedUsage.sumOf { it.totalBytes }

    Scaffold(
        contentWindowInsets = WindowInsets(0),
        topBar = {
            AppTopBar(
                title = stringResource(R.string.title_sub_setting),
                onBackClick = onBackClick,
                isLoading = isLoading,
                actions = {
                    IconButton(onClick = onAddClick) {
                        Icon(painterResource(R.drawable.ic_add_24dp), contentDescription = stringResource(R.string.acc_add_subscription))
                    }
                    IconButton(onClick = {
                        viewModel.loadUpdateOptions()
                        showUpdateDialog = true
                    }) {
                        Icon(painterResource(R.drawable.ic_restore_24dp), contentDescription = stringResource(R.string.acc_update_subscriptions))
                    }
                }
            )
        },
        // Pinned yellow Add button (48dp); the top-bar add icon stays.
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surface) {
                Column {
                    RalysndPrimaryButton(
                        text = stringResource(R.string.acc_add_subscription),
                        onClick = onAddClick,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                    NavigationBarsSpacer()
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            state = lazyListState,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScrollbar(lazyListState),
            contentPadding = NavigationBarsBottomPadding()
        ) {
            if (reportedUsage.isNotEmpty()) {
                item(key = "usage-summary") {
                    RalysndCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Figures read left to right, also in RTL languages.
                            val figuresStyle = MaterialTheme.typography.bodyLarge.copy(textDirection = TextDirection.Ltr)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stringResource(
                                        R.string.sub_info_traffic,
                                        totalUsedBytes.toTrafficString(),
                                        totalQuotaBytes.toTrafficString()
                                    ),
                                    style = figuresStyle,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${(totalUsedBytes.toDouble() / totalQuotaBytes * 100).toInt()}%",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            RalysndUsageBar(progress = (totalUsedBytes.toDouble() / totalQuotaBytes).toFloat())
                        }
                    }
                }
            }
            itemsIndexed(
                items = subscriptions,
                key = { _, item -> item.guid }
            ) { _, subCache ->
                val usageModel = subCache.subscription.usageInfo?.let {
                    buildSubscriptionInfoUiModel(it, nowMillis)
                }
                ReorderableItem(reorderableState, key = subCache.guid) { isDragging ->
                    ReorderableListItem(
                        scope = this,
                        isDragging = isDragging
                    ) {
                        RalysndCard(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 72.dp)
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = subCache.subscription.remarks,
                                        style = MaterialTheme.typography.bodyLarge,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    // Expiry date when the subscription reports one,
                                    // otherwise the last-update timestamp.
                                    val expiryText = usageModel?.expireMillis?.let {
                                        Utils.formatTimestamp(it, "yyyy-MM-dd")
                                    }.orEmpty()
                                    Text(
                                        text = expiryText.ifEmpty {
                                            Utils.formatTimestamp(subCache.subscription.lastUpdated)
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (usageModel?.expired == true) MaterialTheme.colorScheme.error
                                        else MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    usageModel?.trafficFraction?.let { fraction ->
                                        Spacer(modifier = Modifier.height(6.dp))
                                        RalysndUsageBar(progress = fraction)
                                    }
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Switch(
                                        checked = subCache.subscription.enabled,
                                        onCheckedChange = { checked -> viewModel.setEnabled(subCache.guid, checked) },
                                        modifier = Modifier.scale(0.7f),
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = MaterialTheme.colorScheme.onSecondary,
                                            checkedTrackColor = MaterialTheme.colorScheme.secondary
                                        )
                                    )
                                    IconButton(
                                        onClick = { rowMenuTarget = subCache },
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Icon(
                                            painter = painterResource(R.drawable.ic_more_vert_24dp),
                                            contentDescription = stringResource(R.string.acc_more)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // One "more" menu per row: share (QR / clipboard, only when the
    // subscription has a URL), edit and delete — the actions the row's
    // three inline buttons used to hold.
    if (rowMenuTarget != null) {
        val target = rowMenuTarget!!
        val url = target.subscription.url
        val options = SubscriptionRowAction.entries.filter {
            when (it) {
                SubscriptionRowAction.ShareQRCode, SubscriptionRowAction.ShareClipboard -> url.isNotEmpty()
                SubscriptionRowAction.Edit, SubscriptionRowAction.Delete -> true
            }
        }
        SelectListDialog(
            options = options,
            optionText = { stringResource(it.labelRes) },
            onSelected = { action ->
                rowMenuTarget = null
                when (action) {
                    SubscriptionRowAction.ShareQRCode -> onShareQRCode(url)
                    SubscriptionRowAction.ShareClipboard -> onShareClipboard(url)
                    SubscriptionRowAction.Edit -> onEditSub(target.guid)
                    SubscriptionRowAction.Delete -> {
                        if (confirmRemove) removeTarget = SubscriptionDeleteTarget(target.guid, target.subscription.remarks)
                        else onRemoveSub(target.guid)
                    }
                }
            },
            onDismiss = { rowMenuTarget = null }
        )
    }

    // QR Code Dialog
    if (qrCodeBitmap != null) {
        QRCodeDialog(
            bitmap = qrCodeBitmap,
            onDismiss = viewModel::dismissQRCode
        )
    }

    removeTarget?.let { target ->
        DeleteConfirmDialog(
            message = stringResource(R.string.confirm_delete_subscription_group),
            itemName = target.name,
            onConfirm = {
                removeTarget = null
                onRemoveSub(target.guid)
            },
            onDismiss = { removeTarget = null }
        )
    }

    val options = updateOptions
    if (showUpdateDialog && options != null) {
        AlertDialog(
            onDismissRequest = { showUpdateDialog = false },
            text = {
                Column {
                    SettingsSwitchItem(
                        title = stringResource(R.string.title_sub_update),
                        checked = options[SubscriptionUpdateOption.UPDATE],
                        onCheckedChange = { viewModel.setUpdateOption(SubscriptionUpdateOption.UPDATE, it) }
                    )
                    SettingsSwitchItem(
                        title = stringResource(R.string.title_pref_auto_test_after_update_subscription),
                        summary = stringResource(R.string.summary_pref_auto_test_after_update_subscription),
                        checked = options[SubscriptionUpdateOption.TEST_AFTER],
                        onCheckedChange = { viewModel.setUpdateOption(SubscriptionUpdateOption.TEST_AFTER, it) }
                    )
                    SettingsSwitchItem(
                        title = stringResource(R.string.title_pref_auto_remove_invalid_after_test),
                        summary = stringResource(R.string.summary_pref_auto_remove_invalid_after_test),
                        checked = options[SubscriptionUpdateOption.REMOVE_INVALID_AFTER_TEST],
                        enabled = options[SubscriptionUpdateOption.TEST_AFTER],
                        onCheckedChange = { viewModel.setUpdateOption(SubscriptionUpdateOption.REMOVE_INVALID_AFTER_TEST, it) }
                    )
                    SettingsSwitchItem(
                        title = stringResource(R.string.title_pref_auto_sort_after_test),
                        summary = stringResource(R.string.summary_pref_auto_sort_after_test),
                        checked = options[SubscriptionUpdateOption.SORT_AFTER_TEST],
                        enabled = options[SubscriptionUpdateOption.TEST_AFTER],
                        onCheckedChange = { viewModel.setUpdateOption(SubscriptionUpdateOption.SORT_AFTER_TEST, it) }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showUpdateDialog = false
                    onSubUpdate()
                }) {
                    Text(text = stringResource(R.string.action_ok))
                }
            },
            dismissButton = {
                TextButton(onClick = { showUpdateDialog = false }) {
                    Text(text = stringResource(R.string.action_cancel))
                }
            }
        )
    }
}
