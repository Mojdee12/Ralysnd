package com.ralysnd.tv.ui.channels

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.data.ChannelRepository
import com.ralysnd.tv.data.UserDataStore
import com.ralysnd.tv.ui.components.ChannelLogo
import com.ralysnd.tv.ui.components.DpadHint
import com.ralysnd.tv.ui.components.FocusableCard
import com.ralysnd.tv.ui.components.VpnBadge
import com.ralysnd.tv.ui.home.categoryLabel
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors

/**
 * All Channels — the approved channels-list mockup: left category rail
 * (All highlighted green, then every category with its count) and a right
 * grid of channel tiles (logo + name, focused tile gets the emerald border).
 * OK on a tile plays the channel. D-pad left/right moves between rail and grid.
 */
@Composable
fun ChannelsScreen(
    repository: ChannelRepository,
    userData: UserDataStore,
    onPlay: (Channel) -> Unit,
    modifier: Modifier = Modifier,
) {
    var selectedCategory by remember { mutableStateOf(ChannelRepository.CATEGORY_ALL) }
    val channels = remember(selectedCategory) {
        repository.channelsFor(selectedCategory).filter { it.isPlayable }
    }
    // Favorites, kept in state so each tile's star updates at once.
    var favoriteIds by remember { mutableStateOf(userData.favoriteIds()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RalysndTvColors.Background)
            .padding(horizontal = 32.dp, vertical = 20.dp),
    ) {
        // ---- Top bar: wordmark ------------------------------------------------
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Ralysnd ",
                color = RalysndTvColors.TextPrimary,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Text(
                text = "TV",
                color = RalysndTvColors.GreenPrimary,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
        }
        Spacer(Modifier.height(16.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            // ---- Left: category rail ------------------------------------------
            Column(
                modifier = Modifier
                    .width(300.dp)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(20.dp))
                    .background(RalysndTvColors.Surface)
                    .padding(16.dp),
            ) {
                Text(
                    text = "CATEGORIES",
                    color = RalysndTvColors.TextMuted,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = RalysndFontFamily,
                )
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    items(repository.categories) { category ->
                        val count = repository.channelsFor(category).size
                        CategoryRailRow(
                            label = categoryLabel(category),
                            count = count,
                            selected = category == selectedCategory,
                            onClick = { selectedCategory = category },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                DpadHint(
                    text = "↑↓ category • → channels",
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            // ---- Right: channel grid ------------------------------------------
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize(),
            ) {
                Text(
                    text = "All Channels",
                    color = RalysndTvColors.TextPrimary,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RalysndFontFamily,
                )
                Text(
                    text = "${channels.size} channels • Sorted A–Z",
                    color = RalysndTvColors.TextMuted,
                    fontSize = 16.sp,
                    fontFamily = RalysndFontFamily,
                )
                Spacer(Modifier.height(14.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    items(channels, key = { it.id }) { channel ->
                        ChannelTile(
                            channel = channel,
                            isFavorite = channel.id in favoriteIds,
                            onClick = { onPlay(channel) },
                            onToggleFavorite = {
                                favoriteIds = userData.toggleFavorite(channel.id)
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryRailRow(
    label: String,
    count: Int,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FocusableCard(
        onClick = onClick,
        modifier = modifier,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (selected) RalysndTvColors.GreenPrimary
                    else RalysndTvColors.Surface,
                    RoundedCornerShape(16.dp),
                )
                .padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            Text(
                text = label,
                color = if (selected) RalysndTvColors.Background
                else RalysndTvColors.TextPrimary,
                fontSize = 19.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = RalysndFontFamily,
                modifier = Modifier.weight(1f),
            )
            Text(
                text = "$count",
                color = if (selected) RalysndTvColors.Background
                else RalysndTvColors.TextMuted,
                fontSize = 15.sp,
                fontFamily = RalysndFontFamily,
            )
        }
    }
}

@Composable
private fun ChannelTile(
    channel: Channel,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
) {
    FocusableCard(onClick = onClick) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(14.dp),
        ) {
            Box {
                ChannelLogo(channel, Modifier.size(84.dp))
                // Star toggle on the tile corner (Stitch model): its own
                // focus target, so D-pad users can star without playing.
                TileHeartButton(
                    isFavorite = isFavorite,
                    onClick = onToggleFavorite,
                    modifier = Modifier.align(Alignment.TopEnd),
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = channel.name,
                color = RalysndTvColors.TextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = RalysndFontFamily,
                maxLines = 1,
            )
            if (channel.needsVpn) {
                Spacer(Modifier.height(6.dp))
                VpnBadge()
            }
        }
    }
}

/** Small round star toggle for a tile corner. */
@Composable
private fun TileHeartButton(
    isFavorite: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = modifier
            .size(36.dp)
            .border(
                width = if (focused) 2.dp else 0.dp,
                color = if (focused) RalysndTvColors.GreenPrimary else Color.Transparent,
                CircleShape,
            )
            .clip(CircleShape)
            .background(RalysndTvColors.Background.copy(alpha = 0.85f))
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = if (isFavorite) "★" else "☆",
            color = if (isFavorite) RalysndTvColors.GreenPrimary
            else RalysndTvColors.TextMuted,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}
