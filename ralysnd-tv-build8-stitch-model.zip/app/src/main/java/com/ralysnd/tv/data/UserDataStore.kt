package com.ralysnd.tv.data

import android.content.Context

/**
 * User-owned lists, persisted in SharedPreferences (same pattern as
 * [SettingsStore]): favorite channels and recently watched channels.
 *
 * Both lists hold channel ids only — the channel data itself always comes
 * from the bundled channels.json, so a stored id that no longer exists
 * simply resolves to nothing and is never shown. Nothing here is a
 * number without a real source: no viewer counts, no program data, no
 * subscription — just the user's own picks and watch history.
 */
class UserDataStore(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    /** Favorite channel ids, in the order they were added. */
    fun favoriteIds(): List<String> = readList(KEY_FAVORITES)

    fun isFavorite(channelId: String): Boolean = channelId in favoriteIds()

    /** Toggles one channel in the favorites; returns the updated list. */
    fun toggleFavorite(channelId: String): List<String> {
        val updated = toggleInList(favoriteIds(), channelId)
        writeList(KEY_FAVORITES, updated)
        return updated
    }

    /** Recently watched channel ids, most recent first. */
    fun recentlyWatchedIds(): List<String> = readList(KEY_RECENT)

    /** Records a watch: moves the channel to the front, deduped, capped. */
    fun recordWatched(channelId: String) {
        writeList(KEY_RECENT, addRecent(recentlyWatchedIds(), channelId, MAX_RECENT))
    }

    private fun readList(key: String): List<String> {
        val raw = prefs.getString(key, "") ?: ""
        return raw.split(DELIMITER).filter { it.isNotBlank() }
    }

    private fun writeList(key: String, ids: List<String>) {
        prefs.edit().putString(key, ids.joinToString(DELIMITER)).apply()
    }

    companion object {
        const val MAX_RECENT = 12
        private const val PREFS_NAME = "ralysnd_tv_user_data"
        private const val KEY_FAVORITES = "favorite_channel_ids"
        private const val KEY_RECENT = "recently_watched_ids"
        /** Channel ids never contain "|", so it is a safe separator. */
        private const val DELIMITER = "|"

        /** Pure list op, unit-tested: adds when absent, removes when present. */
        fun toggleInList(ids: List<String>, id: String): List<String> =
            if (id in ids) ids - id else ids + id

        /** Pure list op, unit-tested: most-recent-first, deduped, capped. */
        fun addRecent(ids: List<String>, id: String, max: Int = MAX_RECENT): List<String> =
            (listOf(id) + (ids - id)).take(max)
    }
}
