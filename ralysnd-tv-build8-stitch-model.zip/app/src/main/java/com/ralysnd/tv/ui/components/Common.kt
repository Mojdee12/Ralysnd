package com.ralysnd.tv.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.data.SettingsStore
import com.ralysnd.tv.player.PlayerFactory
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors

/**
 * Shared building blocks for the green-split style. Every screen uses these
 * so the look is identical everywhere: dark surface cards, emerald focus
 * border, red LIVE badge, logo + name channel rows.
 */

/**
 * One shared Coil loader for channel logos: disk cache (100 MB under the
 * app cache dir) + memory cache (25% of available memory), so a logo is
 * downloaded once and every later row/tile/rail reuses it instead of
 * re-fetching over a slow connection. Built lazily and cached per process.
 */
object LogoImageLoader {
    @Volatile
    private var instance: ImageLoader? = null

    fun get(context: android.content.Context): ImageLoader =
        instance ?: synchronized(this) {
            instance ?: ImageLoader.Builder(context)
                .memoryCache {
                    MemoryCache.Builder(context)
                        .maxSizePercent(0.25)
                        .build()
                }
                .diskCache {
                    DiskCache.Builder()
                        .directory(context.cacheDir.resolve("coil_logos"))
                        .maxSizeBytes(100L * 1024L * 1024L)
                        .build()
                }
                .respectCacheHeaders(false)
                .build()
                .also { instance = it }
        }
}

/** Red LIVE pill, as on the home preview and the focused channel row. */
@Composable
fun LiveBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(RalysndTvColors.LiveRed, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "● LIVE",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}

/** Small VPN pill: marks channels the source app flags as needing a VPN
 *  to play. Only the 11 explicitly flagged channels carry it — nothing
 *  is inferred. Shown on rows, tiles and in the player. */
@Composable
fun VpnBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .border(
                width = 1.dp,
                color = RalysndTvColors.GreenPrimary,
                RoundedCornerShape(8.dp),
            )
            .background(RalysndTvColors.SurfaceElevated, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "VPN",
            color = RalysndTvColors.GreenPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}

/** Channel logo: remote image when present, initial letter on a green tile when not.
 * 209 of the 383 channels ship without a logo, so the fallback is part of the design.
 * Logos that fail to load (e.g. blocked hosts) fall back to the letter tile too —
 * never a blank white box. Logos go through the shared cached loader, requested
 * at 192px (covers the largest 84dp tile) so a logo is fetched once, downsampled
 * once, and reused from cache everywhere it appears. */
@Composable
fun ChannelLogo(channel: Channel, modifier: Modifier = Modifier) {
    var loadFailed by remember(channel.logo) { mutableStateOf(false) }
    if (channel.logo.isNotBlank() && !loadFailed) {
        val context = LocalContext.current
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(channel.logo)
                .size(192)
                .memoryCachePolicy(CachePolicy.ENABLED)
                .diskCachePolicy(CachePolicy.ENABLED)
                .build(),
            imageLoader = LogoImageLoader.get(context),
            contentDescription = channel.name,
            contentScale = ContentScale.Fit,
            onError = { loadFailed = true },
            modifier = modifier
                .clip(RoundedCornerShape(8.dp))
                .background(RalysndTvColors.SurfaceElevated),
        )
    } else {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(8.dp))
                .background(RalysndTvColors.GreenDark),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = channel.name.firstOrNull()?.uppercase() ?: "•",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
        }
    }
}

/**
 * A D-pad focusable card. Focused state gets the emerald border + slight
 * surface lift used across all mockups; unfocused state is the plain dark card.
 * Focused cards also pop slightly (1.04x), as in the Stitch model — a small
 * scale so the focused card reads at 10 feet without moving its neighbours.
 */
@Composable
fun FocusableCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.04f else 1f,
        label = "focusPop",
    )
    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .border(
                BorderStroke(
                    width = if (focused) 3.dp else 1.dp,
                    color = if (focused) RalysndTvColors.GreenPrimary
                    else RalysndTvColors.SurfaceElevated,
                ),
                RoundedCornerShape(16.dp),
            )
            .background(
                if (focused) RalysndTvColors.SurfaceElevated
                else RalysndTvColors.Surface,
                RoundedCornerShape(16.dp),
            )
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

/** One channel row: logo + name (+ LIVE badge when it is the playing channel). */
@Composable
fun ChannelRow(
    channel: Channel,
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FocusableCard(
        onClick = onClick,
        modifier = modifier,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            ChannelLogo(channel, Modifier.size(48.dp))
            Spacer(Modifier.width(14.dp))
            Text(
                text = channel.name,
                color = RalysndTvColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = RalysndFontFamily,
                modifier = Modifier.weight(1f),
            )
            if (channel.needsVpn) {
                VpnBadge()
                Spacer(Modifier.width(8.dp))
            }
            if (isPlaying) LiveBadge()
        }
    }
}

/** Bottom D-pad hint bar, as on the home mockup. */
@Composable
fun DpadHint(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = RalysndTvColors.TextMuted,
        fontSize = 16.sp,
        fontFamily = RalysndFontFamily,
        textAlign = TextAlign.Center,
        modifier = modifier,
    )
}

/**
 * Muted live preview of a channel. A SINGLE player instance per screen:
 * switching the channel only swaps its media item, the player is never
 * recreated per selection. Released when the hosting screen leaves.
 * Shared by Home and Favorites (both show a live hero preview).
 * The hero is a wide banner, so the video zooms to fill it instead of
 * letterboxing.
 */
@Composable
fun MutedPreviewPlayer(
    channel: Channel?,
    settings: SettingsStore,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val player = remember {
        PlayerFactory.create(context, settings).apply { volume = 0f }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    LaunchedEffect(channel) {
        val url = channel?.primaryUrl ?: return@LaunchedEffect
        player.setMediaItem(PlayerFactory.mediaItemFor(url))
        player.prepare()
        player.play()
    }
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            }
        },
        modifier = modifier,
    )
}

/**
 * 16:9 poster card from the Stitch model: a wide logo area on top (the
 * channel logo, or the green letter tile when the channel has none) and
 * the channel name below. No poster art exists for real channels, so the
 * logo area is the logo itself — never an invented image. The selected
 * card (the hero's channel) also shows LIVE.
 */
@Composable
fun ChannelPosterCard(
    channel: Channel,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FocusableCard(
        onClick = onClick,
        modifier = modifier,
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(RalysndTvColors.SurfaceElevated),
                contentAlignment = Alignment.Center,
            ) {
                ChannelLogo(channel, Modifier.fillMaxSize())
                if (selected) {
                    LiveBadge(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp),
                    )
                }
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
            ) {
                Text(
                    text = channel.name,
                    color = RalysndTvColors.TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = RalysndFontFamily,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                if (channel.needsVpn) {
                    Spacer(Modifier.width(8.dp))
                    VpnBadge()
                }
            }
        }
    }
}

/**
 * Pill toggle for favorites (hero and player): filled green with a solid
 * star when the channel is a favorite, dark with an outline star when not.
 */
@Composable
fun FavoriteToggleButton(
    isFavorite: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = modifier
            .border(
                width = if (focused) 3.dp else 0.dp,
                color = if (focused) Color.White else Color.Transparent,
                RoundedCornerShape(24.dp),
            )
            .background(
                if (isFavorite) RalysndTvColors.GreenPrimary
                else RalysndTvColors.SurfaceElevated,
                RoundedCornerShape(24.dp),
            )
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = if (isFavorite) "★ Favorite" else "☆ Favorite",
            color = if (isFavorite) Color.Black else Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}
