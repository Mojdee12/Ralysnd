package com.ralysnd.tv.ui.favorites

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.data.ChannelRepository
import com.ralysnd.tv.data.SettingsStore
import com.ralysnd.tv.data.UserDataStore
import com.ralysnd.tv.ui.components.ChannelPosterCard
import com.ralysnd.tv.ui.components.DpadHint
import com.ralysnd.tv.ui.components.FavoriteToggleButton
import com.ralysnd.tv.ui.components.LiveBadge
import com.ralysnd.tv.ui.components.MutedPreviewPlayer
import com.ralysnd.tv.ui.components.VpnBadge
import com.ralysnd.tv.ui.home.categoryLabel
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors

/**
 * Favorites — the Stitch-model favorites screen in the green split:
 * a top hero = the live muted preview of the selected favorite (name +
 * category + LIVE badge + Watch + remove-from-favorites), and below it a
 * grid of 16:9 poster cards of every favorite channel. OK on a card
 * selects it into the hero; OK on Watch plays it.
 *
 * Only the user's own picks, stored locally in [UserDataStore]. No
 * invented data: no program titles, no viewer counts, no "most watched"
 * ordering — the grid shows the favorites in the order they were added.
 */
@Composable
fun FavoritesScreen(
    repository: ChannelRepository,
    settings: SettingsStore,
    userData: UserDataStore,
    onPlay: (Channel) -> Unit,
    modifier: Modifier = Modifier,
) {
    var favoriteIds by remember { mutableStateOf(userData.favoriteIds()) }
    val favorites = remember(favoriteIds) {
        favoriteIds.mapNotNull { repository.channelById(it) }.filter { it.isPlayable }
    }
    var selectedChannel by remember(favorites) {
        mutableStateOf(favorites.firstOrNull())
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RalysndTvColors.Background)
            .padding(horizontal = 32.dp, vertical = 20.dp),
    ) {
        // ---- Top bar: wordmark + title + real count -------------------------
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Ralysnd ",
                color = Color.White,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Text(
                text = "TV",
                color = RalysndTvColors.GreenPrimary,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Spacer(Modifier.width(48.dp))
            Text(
                text = "♥ Favorites",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = "${favorites.size} favorites",
                color = RalysndTvColors.TextMuted,
                fontSize = 16.sp,
                fontFamily = RalysndFontFamily,
            )
        }
        Spacer(Modifier.height(16.dp))

        if (favorites.isEmpty()) {
            // Empty state: nothing invented, just how to add one.
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(RalysndTvColors.Surface),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No favorites yet",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = RalysndFontFamily,
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "Open any channel and press ☆ Favorite to add it here.",
                        color = RalysndTvColors.TextMuted,
                        fontSize = 18.sp,
                        fontFamily = RalysndFontFamily,
                        textAlign = TextAlign.Center,
                    )
                }
            }
            return@Column
        }

        // ---- Hero: live muted preview of the selected favorite --------------
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.42f)
                .clip(RoundedCornerShape(20.dp))
                .background(Color.Black),
        ) {
            MutedPreviewPlayer(
                channel = selectedChannel,
                settings = settings,
                modifier = Modifier.fillMaxSize(),
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(RalysndTvColors.Background.copy(alpha = 0.78f))
                    .padding(horizontal = 20.dp, vertical = 14.dp),
            ) {
                LiveBadge()
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = selectedChannel?.name ?: "",
                            color = Color.White,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = RalysndFontFamily,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        if (selectedChannel?.needsVpn == true) {
                            Spacer(Modifier.width(12.dp))
                            VpnBadge()
                        }
                    }
                    Text(
                        text = categoryLabel(
                            selectedChannel?.categories?.firstOrNull()
                                ?: ChannelRepository.CATEGORY_ALL,
                        ),
                        color = RalysndTvColors.TextMuted,
                        fontSize = 16.sp,
                        fontFamily = RalysndFontFamily,
                    )
                }
                Spacer(Modifier.width(16.dp))
                val heroChannel = selectedChannel
                FavoriteToggleButton(
                    isFavorite = heroChannel != null,
                    onClick = {
                        heroChannel?.let {
                            favoriteIds = userData.toggleFavorite(it.id)
                        }
                    },
                )
                Spacer(Modifier.width(12.dp))
                WatchButton(
                    enabled = selectedChannel != null,
                    onClick = { selectedChannel?.let(onPlay) },
                )
            }
        }

        Spacer(Modifier.height(18.dp))

        // ---- Grid: every favorite as a 16:9 poster card ---------------------
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.weight(0.58f),
        ) {
            items(favorites, key = { it.id }) { channel ->
                ChannelPosterCard(
                    channel = channel,
                    selected = channel.id == selectedChannel?.id,
                    onClick = { selectedChannel = channel },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        DpadHint(
            text = "OK select • Watch plays • ★ removes from favorites",
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

/** Green Watch pill, as on the home hero. */
@Composable
private fun WatchButton(enabled: Boolean, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = Modifier
            .border(
                width = if (focused) 3.dp else 0.dp,
                color = if (focused) Color.White else Color.Transparent,
                RoundedCornerShape(24.dp),
            )
            .background(RalysndTvColors.GreenPrimary, RoundedCornerShape(24.dp))
            .focusable(enabled, interactionSource)
            .clickable(enabled = enabled, interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 24.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "▶ Watch",
            color = Color.Black,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}
