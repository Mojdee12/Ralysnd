package com.ralysnd.tv

import com.ralysnd.tv.data.UserDataStore
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Unit tests for the favorites / recently-watched list rules.
 * The persistence itself is SharedPreferences (same pattern as
 * SettingsStore); the list operations are pure and tested here.
 */
class UserDataStoreTest {

    @Test
    fun toggleAddsWhenAbsent() {
        assertEquals(listOf("a"), UserDataStore.toggleInList(emptyList(), "a"))
        assertEquals(listOf("a", "b"), UserDataStore.toggleInList(listOf("a"), "b"))
    }

    @Test
    fun toggleRemovesWhenPresentAndKeepsOrder() {
        assertEquals(listOf("a", "c"), UserDataStore.toggleInList(listOf("a", "b", "c"), "b"))
        assertEquals(emptyList<String>(), UserDataStore.toggleInList(listOf("a"), "a"))
    }

    @Test
    fun addRecentMovesToFrontAndDedupes() {
        assertEquals(listOf("b", "a"), UserDataStore.addRecent(listOf("a"), "b"))
        assertEquals(listOf("a", "b"), UserDataStore.addRecent(listOf("b", "a"), "a"))
        assertEquals(listOf("a"), UserDataStore.addRecent(listOf("a"), "a"))
    }

    @Test
    fun addRecentCapsAtMax() {
        val ids = (1..12).map { "ch$it" }
        val result = UserDataStore.addRecent(ids, "new")
        assertEquals(12, result.size)
        assertEquals("new", result.first())
        assertEquals("ch11", result.last())
    }

    @Test
    fun maxRecentIsTwelve() {
        assertEquals(12, UserDataStore.MAX_RECENT)
    }
}
