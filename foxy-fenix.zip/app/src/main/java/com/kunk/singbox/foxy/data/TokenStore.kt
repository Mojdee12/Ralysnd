package com.kunk.singbox.foxy.data

import android.content.Context
import com.kunk.singbox.foxy.data.model.RuntimeAuth
import com.tencent.mmkv.MMKV

/**
 * FoxyVPN TokenStore, adapted for Ralysnd.
 *
 * Original FoxyVPN used EncryptedSharedPreferences (androidx.security:security-crypto),
 * which KunBox does not depend on. This version uses the app's existing MMKV store
 * (already initialised in SingBoxApplication, same store family as the rest of the app)
 * with the same public API Foxy's FxaAuthRepository expects.
 *
 * CAVEAT: MMKV here is not encrypted. Before a public release, move this store to
 * an encrypted store (androidx.security:security-crypto) — tokens must not ship
 * in plaintext storage in a production build.
 */
class TokenStore(context: Context) {

    private val mmkv: MMKV by lazy {
        MMKV.mmkvWithID("foxyvpn_tokens", MMKV.MULTI_PROCESS_MODE)
    }

    fun saveAuth(auth: RuntimeAuth) {
        mmkv.encode(KEY_ACCESS_TOKEN, auth.accessToken)
        if (auth.refreshToken != null) {
            mmkv.encode(KEY_REFRESH_TOKEN, auth.refreshToken)
        } else {
            mmkv.remove(KEY_REFRESH_TOKEN)
        }
        mmkv.encode(KEY_EXPIRES_AT, auth.expiresAtEpochSeconds)
    }

    fun loadAuth(): RuntimeAuth? = runCatching {
        val access = mmkv.decodeString(KEY_ACCESS_TOKEN, null)?.takeIf { it.isNotBlank() }
            ?: return@runCatching null
        val refresh = mmkv.decodeString(KEY_REFRESH_TOKEN, null)?.takeIf { it.isNotBlank() }
        val expiresAt = mmkv.decodeLong(KEY_EXPIRES_AT, 0L)
        RuntimeAuth(access, refresh, expiresAt)
    }.getOrNull()

    fun hasValidAccessToken(): Boolean {
        val auth = loadAuth() ?: return false
        if (auth.expiresAtEpochSeconds <= 0L) return false
        val nowSeconds = System.currentTimeMillis() / 1000
        return auth.expiresAtEpochSeconds - nowSeconds > CLOCK_SKEW_TOLERANCE_SECONDS
    }

    fun hasStoredSession(): Boolean = loadAuth() != null

    fun hasRefreshToken(): Boolean = loadAuth()?.refreshToken != null

    var pendingSessionToken: String?
        get() = mmkv.decodeString(KEY_PENDING_SESSION_TOKEN, null)?.takeIf { it.isNotBlank() }
        set(value) {
            if (value != null) {
                mmkv.encode(KEY_PENDING_SESSION_TOKEN, value)
            } else {
                mmkv.remove(KEY_PENDING_SESSION_TOKEN)
            }
        }

    fun clear() {
        mmkv.clear()
    }

    companion object {
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_EXPIRES_AT = "expires_at"
        private const val KEY_PENDING_SESSION_TOKEN = "pending_session_token"
        private const val CLOCK_SKEW_TOLERANCE_SECONDS = 60L
    }
}
