package com.kunk.singbox.foxy

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kunk.singbox.foxy.data.FxaAuthRepository
import com.kunk.singbox.foxy.data.GuardianClient
import com.kunk.singbox.foxy.data.ServerListClient
import com.kunk.singbox.foxy.data.TokenStore
import com.kunk.singbox.foxy.data.ProxyStateStore
import com.kunk.singbox.foxy.vpn.FoxyVpnService
import com.kunk.singbox.foxy.data.model.Entitlement
import com.kunk.singbox.foxy.data.model.ProxyCandidate
import com.kunk.singbox.foxy.data.model.VpnCountry
import com.kunk.singbox.foxy.vpn.PingUtil
import com.kunk.singbox.viewmodel.DashboardViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * FENIX (Foxy) ViewModel for Ralysnd.
 *
 * Auth + server list + quota + ping are FoxyVPN's actual flow (MIT, Vauth):
 * Firefox-account email+password sign-in via FxaAuthRepository (PBKDF2 authPW,
 * FxA OAuth, client_id 5882386c6d801776 from FoxyVPN), Guardian proxy pass +
 * account status via GuardianClient, country list via Mozilla Remote Settings
 * via ServerListClient, TCP ping via PingUtil.
 *
 * CONNECTION PATH — FULL FOXY TUNNEL (no HTTP-outbound fallback):
 * connectSelected() saves the chosen country candidate into ProxyStateStore
 * (the store FoxyVpnService.connect() reads), stops KunBox's sing-box VPN
 * if it is running (Android allows only one active VpnService), then starts
 * FoxyVpnService, which mints its own Guardian proxy pass and opens a Netty
 * HTTP/2 CONNECT to the Fastly edge with `proxy-authorization: Bearer <pass>`,
 * forwarding device traffic through a local SOCKS5 proxy + hev-socks5-tunnel
 * native TUN forwarder. The old sing-box HTTP node path is deleted: it sent
 * Basic auth, which is NOT Foxy's authentication, and must never be used
 * as a substitute for the tunnel.
 */
data class FoxyUiState(
    val signedIn: Boolean = false,
    val needsTwoFactor: Boolean = false,
    val isLoading: Boolean = false,
    val isPinging: Boolean = false,
    val isConnecting: Boolean = false,
    val entitlement: Entitlement? = null,
    val countries: List<VpnCountry> = emptyList(),
    val selected: ProxyCandidate? = null,
    val pingMs: Map<String, Int> = emptyMap(),
    val message: String? = null,
)

class FoxyViewModel(application: Application) : AndroidViewModel(application) {

    private val tokenStore = TokenStore(application)
    private val authRepo = FxaAuthRepository(tokenStore)
    private val guardian = GuardianClient()
    private val serverClient = ServerListClient(application)
    /** Live state of the Foxy tunnel service (for the FENIX tab's toggle). */
    val foxyState = FoxyVpnService.state

    private val _uiState = MutableStateFlow(FoxyUiState())
    val uiState: StateFlow<FoxyUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val status = runCatching { authRepo.restoreSession() }.getOrNull()
            if (status == com.kunk.singbox.foxy.data.SessionStatus.ACTIVE) {
                _uiState.update { it.copy(signedIn = true) }
                refreshAccountAndCountries()
            }
        }
    }

    fun signIn(email: String, password: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, message = null) }
            val result = authRepo.startLogin(email, password)
            result.onSuccess { needsCode ->
                if (needsCode) {
                    _uiState.update { it.copy(isLoading = false, needsTwoFactor = true) }
                } else {
                    _uiState.update { it.copy(isLoading = false, signedIn = true, needsTwoFactor = false) }
                    refreshAccountAndCountries()
                }
            }.onFailure { e ->
                _uiState.update { it.copy(isLoading = false, message = e.message ?: "Sign-in failed") }
            }
        }
    }

    fun submitTwoFactorCode(code: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, message = null) }
            val result = authRepo.submitTwoFactorCode(code)
            result.onSuccess {
                _uiState.update { it.copy(isLoading = false, signedIn = true, needsTwoFactor = false) }
                refreshAccountAndCountries()
            }.onFailure { e ->
                _uiState.update { it.copy(isLoading = false, message = e.message ?: "Verification failed") }
            }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            runCatching { FoxyVpnService.stop(getApplication()) }
            runCatching { tokenStore.clear() }
            _uiState.update { FoxyUiState() }
        }
    }

    fun refreshAccountAndCountries() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, message = null) }
            try {
                val token = authRepo.currentAccessToken()
                if (token == null) {
                    _uiState.update { it.copy(isLoading = false, signedIn = false, message = "Session expired — sign in again") }
                    return@launch
                }
                val entitlement = runCatching {
                    guardian.fetchUserInfo(com.kunk.singbox.foxy.data.GUARDIAN_ENDPOINT_DEFAULT, token)
                }.getOrNull()
                val countries = runCatching { serverClient.fetchCountries() }
                    .getOrElse { serverClient.loadCachedCountries() }
                _uiState.update {
                    it.copy(isLoading = false, entitlement = entitlement, countries = countries)
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, message = e.message ?: "Failed to load FENIX data") }
            }
        }
    }

    fun selectCountry(countryCode: String) {
        val candidates = ServerListClient.candidatesForCountry(_uiState.value.countries, countryCode)
        val first = candidates.firstOrNull()
        if (first != null) {
            _uiState.update { it.copy(selected = first, message = null) }
        } else {
            _uiState.update { it.copy(message = "No available servers for that country") }
        }
    }

    fun pingAllCountries() {
        viewModelScope.launch {
            _uiState.update { it.copy(isPinging = true) }
            try {
                val results = mutableMapOf<String, Int>()
                withContext(Dispatchers.IO) {
                    for (country in _uiState.value.countries) {
                        val candidate = ServerListClient.candidatesForCountry(
                            _uiState.value.countries, country.code,
                        ).firstOrNull() ?: continue
                        val ms = PingUtil.measureTcpLatencyMs(candidate.host, candidate.port)
                        if (ms != null) results[country.code] = ms
                    }
                }
                _uiState.update { it.copy(pingMs = results) }
            } finally {
                _uiState.update { it.copy(isPinging = false) }
            }
        }
    }

    fun fastestCountry(): VpnCountry? {
        val pings = _uiState.value.pingMs
        if (pings.isEmpty()) return null
        val code = pings.minByOrNull { it.value }?.key ?: return null
        return _uiState.value.countries.firstOrNull { it.code.equals(code, ignoreCase = true) }
    }

    /**
     * Connect via the FULL Foxy tunnel. Caller (FenixScreen) must have
     * already ensured VpnService.prepare() is granted for this app (the
     * Dashboard permission flow grants it app-wide); this function only
     * starts the service. Steps: save the selected candidate where
     * FoxyVpnService.connect() reads it, stop sing-box if running, then
     * start FoxyVpnService. The service mints its own Guardian proxy pass
     * and dials the Fastly edge with Bearer auth on an H2 CONNECT.
     */
    fun connectSelected(context: android.content.Context, dashboardViewModel: DashboardViewModel) {
        val selected = _uiState.value.selected
        if (selected == null) {
            _uiState.update { it.copy(message = "Pick a country first") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isConnecting = true, message = null) }
            try {
                // Single-VpnService rule: stop sing-box first if it is up.
                val dashState = dashboardViewModel.connectionState.value
                if (dashState == com.kunk.singbox.model.ConnectionState.Connected ||
                    dashState == com.kunk.singbox.model.ConnectionState.Connecting
                ) {
                    dashboardViewModel.toggleConnection()
                    // Settle time for sing-box to release the VPN slot; the
                    // system also revokes the old VpnService when the new
                    // one starts, so this is a belt-and-braces delay.
                    delay(700)
                }
                ProxyStateStore(context).save(selected)
                FoxyVpnService.start(context)
                _uiState.update {
                    it.copy(
                        isConnecting = false,
                        message = "FENIX connecting via the Foxy tunnel to ${selected.countryName}",
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isConnecting = false, message = e.message ?: "Connect failed") }
            }
        }
    }

    /** Disconnect the Foxy tunnel (does not touch sing-box). */
    fun disconnectFenix(context: android.content.Context) {
        FoxyVpnService.stop(context)
    }
}
