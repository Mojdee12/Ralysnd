package com.kunk.singbox.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.kunk.singbox.foxy.FoxyViewModel
import com.kunk.singbox.foxy.data.model.ConnectionState as FoxyConnectionState
import com.kunk.singbox.foxy.data.formatBytes
import com.kunk.singbox.foxy.data.model.emojiFlag
import com.kunk.singbox.model.ConnectionState
import com.kunk.singbox.ui.components.BigToggle
import com.kunk.singbox.ui.theme.RalysndGlassCard
import com.kunk.singbox.viewmodel.DashboardViewModel

/**
 * FENIX bottom-tab screen — FoxyVPN's flow, ported (MIT, Vauth).
 *
 * Order, exactly as in FoxyVPN:
 * 1) Login: Firefox-account email + password (FxaAuthRepository: PBKDF2
 *    authPW + FxA OAuth). "Create a Firefox account" opens
 *    https://accounts.firefox.com/signup in the browser. If the account
 *    needs a code, a 2FA field appears. No credential is stored in source
 *    or logs; tokens live in the app's MMKV Foxy store.
 * 2) Account + quota: from Guardian /api/v1/fpn/status. If the API gives
 *    no quota, the card says "Quota unavailable" — never a fake number.
 * 3) Countries: from Mozilla Remote Settings via ServerListClient, with
 *    TCP ping per country (PingUtil) and fastest-first ordering.
 * 4) Connect: the professional BigToggle (CONNECT/DISCONNECT). The full
 *    Foxy tunnel is ported (FoxyVpnService: Netty H2 CONNECT with Bearer
 *    proxy pass to the Fastly edge, local SOCKS5 proxy, hev-socks5-tunnel
 *    native TUN forwarder). A real-account connect test on a device is
 *    still required before claiming FENIX connects end to end.
 *
 * Footer credit (FoxyVPN MIT attribution): "FENIX engine based on
 * FoxyVPN (MIT) by Vauth".
 */
@Composable
fun FenixScreen(
    navController: NavController,
    viewModel: FoxyViewModel = viewModel(),
    dashboardViewModel: DashboardViewModel = viewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val connectionState by dashboardViewModel.connectionState.collectAsStateWithLifecycle()
    val foxyState by viewModel.foxyState.collectAsStateWithLifecycle()
    var pendingFenixConnect by remember { mutableStateOf(false) }
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingFenixConnect) {
            pendingFenixConnect = false
            viewModel.connectSelected(context, dashboardViewModel)
        } else {
            pendingFenixConnect = false
        }
    }
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var twoFactorCode by remember { mutableStateOf("") }
    val foxyRunning = foxyState == FoxyConnectionState.CONNECTED ||
        foxyState == FoxyConnectionState.CONNECTING
    val isRunning = foxyRunning ||
        connectionState == ConnectionState.Connected ||
        connectionState == ConnectionState.Connecting

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(
            text = "FENIX",
            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
        )
        Text(
            text = "Firefox VPN on your own Firefox account",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        if (!state.signedIn) {
            RalysndGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "Sign in with your Firefox account", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Firefox account email") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                    )
                    if (state.needsTwoFactor) {
                        OutlinedTextField(
                            value = twoFactorCode,
                            onValueChange = { twoFactorCode = it },
                            label = { Text("Confirmation code sent to your email") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                        )
                        Button(
                            onClick = { viewModel.submitTwoFactorCode(twoFactorCode) },
                            enabled = !state.isLoading && twoFactorCode.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Verify code") }
                    } else {
                        Button(
                            onClick = { viewModel.signIn(email, password) },
                            enabled = !state.isLoading && email.isNotBlank() && password.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Sign in") }
                    }
                    TextButton(
                        onClick = {
                            context.startActivity(
                                Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse("https://accounts.firefox.com/signup"),
                                ),
                            )
                        },
                    ) { Text("Create a Firefox account") }
                }
            }
        } else {
            val entitlement = state.entitlement
            RalysndGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(text = "Firefox account connected", fontWeight = FontWeight.SemiBold)
                    if (entitlement != null) {
                        Text(
                            text = if (entitlement.subscribed) "Subscription: active" else "Subscription: free account",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        val quotaText = when {
                            entitlement.quotaRemaining != null ->
                                "Quota remaining: ${formatBytes(entitlement.quotaRemaining)}"
                            entitlement.maxBytes != null ->
                                "Allowance: ${formatBytes(entitlement.maxBytes)}"
                            else -> "Quota unavailable"
                        }
                        Text(text = quotaText, style = MaterialTheme.typography.bodyMedium)
                    } else {
                        Text(text = "Quota unavailable", style = MaterialTheme.typography.bodyMedium)
                    }
                    TextButton(onClick = { viewModel.signOut() }) { Text("Sign out") }
                }
            }

            BigToggle(
                isRunning = isRunning,
                onClick = {
                    if (isRunning) {
                        if (foxyRunning) {
                            viewModel.disconnectFenix(context)
                        } else {
                            dashboardViewModel.toggleConnection()
                        }
                    } else {
                        // VpnService.prepare() is app-wide: once granted (e.g.
                        // via the Dashboard flow) it returns null. If it
                        // returns an intent, launch it and connect on grant.
                        val prepareIntent = VpnService.prepare(context)
                        if (prepareIntent != null) {
                            pendingFenixConnect = true
                            vpnPermissionLauncher.launch(prepareIntent)
                        } else {
                            viewModel.connectSelected(context, dashboardViewModel)
                        }
                    }
                },
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { viewModel.refreshAccountAndCountries() }) { Text("Refresh") }
                Button(onClick = { viewModel.pingAllCountries() }) { Text("Ping all") }
                Button(
                    onClick = {
                        val fastest = viewModel.fastestCountry()
                        if (fastest != null) viewModel.selectCountry(fastest.code)
                    },
                ) { Text("Fastest") }
            }
            if (state.isLoading || state.isPinging || state.isConnecting) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            state.selected?.let { selected ->
                Text(
                    text = "Selected: ${selected.countryName} (${selected.host}:${selected.port})",
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }

        state.message?.let { Text(text = it, color = MaterialTheme.colorScheme.error) }

        if (state.signedIn) {
            Text(text = "Countries", fontWeight = FontWeight.SemiBold)
            val sorted = state.countries.sortedBy { country ->
                state.pingMs[country.code] ?: Int.MAX_VALUE
            }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                for (country in sorted) {
                    val ping = state.pingMs[country.code]
                    val isSelected = state.selected?.countryCode.equals(country.code, ignoreCase = true)
                    RalysndGlassCard(
                        modifier = Modifier.fillMaxWidth(),
                        selected = isSelected,
                        onClick = { viewModel.selectCountry(country.code) },
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(text = "${country.emojiFlag} ${country.name}", fontWeight = FontWeight.SemiBold)
                            Text(
                                text = when {
                                    ping != null -> "$ping ms"
                                    state.isPinging -> "pinging…"
                                    else -> "—"
                                },
                                style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        Text(
            text = "FENIX engine based on FoxyVPN (MIT) by Vauth",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
