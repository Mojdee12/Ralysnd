package com.kunk.singbox.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
// Note: Modifier.animateItem() needs no import here — it resolves via
// the LazyItemScope receiver inside items { }, same as NodesScreen.
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.kunk.singbox.foxy.FoxyViewModel
import com.kunk.singbox.foxy.data.formatBytes
import com.kunk.singbox.foxy.data.model.ConnectionState as FoxyConnectionState
import com.kunk.singbox.foxy.data.model.emojiFlag
import com.kunk.singbox.model.ConnectionState
import com.kunk.singbox.ui.theme.L4Amber
import com.kunk.singbox.ui.theme.L4Background
import com.kunk.singbox.ui.theme.L4CenterConnectButton
import com.kunk.singbox.ui.theme.L4CountryCard
import com.kunk.singbox.ui.theme.L4Green
import com.kunk.singbox.ui.theme.L4GlassCard
import com.kunk.singbox.ui.theme.L4Surface
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim
import com.kunk.singbox.viewmodel.DashboardViewModel

/**
 * FENIX bottom-tab screen — v2 approved style, FoxyVPN's flow (MIT, Vauth).
 *
 * v2 layout, exactly: big bold RALYSND headline at top (the app wordmark,
 * with this tab titled FENIX beneath it), a simple volume tab (a
 * rounded pill showing ONLY the AGGREGATE volume text across all added
 * Firefox accounts — no circle, no ring, no arc, no percentage circle;
 * real Guardian data only; "Quota unavailable" when no account reports
 * one), a FENIX Accounts strip (EMAIL TEXT ONLY — never a profile
 * photo/avatar — with a + button to add another account, tap an account
 * to switch, remove only when not connected), and a HORIZONTAL carousel
 * of country cards. Each country card shows its flag (emoji text) +
 * country-code text badge, the country name, and its PING BELOW the
 * country name in large text, live-updating as ping results arrive
 * (not only as a small corner badge). Ping all is a prominent primary
 * action; Fastest picks the lowest measured ping.
 *
 * Connect is the LARGE CENTER button in the middle of the screen
 * (approved center-connect mockups) — the old bottom-right floating
 * button has been removed. The tunnel itself is untouched:
 * FoxyVpnService (Netty H2 CONNECT with Bearer proxy pass to the Fastly
 * edge, local SOCKS5 proxy, hev-socks5-tunnel) using the ACTIVE
 * account's tokens. No credential is stored in source or logs.
 *
 * Footer credit (FoxyVPN MIT attribution): "FENIX engine based on
 * FoxyVPN (MIT) by Vauth".
 */
@Composable
fun FenixScreen(
    navController: NavController,
    viewModel: FoxyViewModel = viewModel(),
    dashboardViewModel: DashboardViewModel = viewModel(),
    // m4: shared bottom padding from AppNavigation (same value the
    // other top-level screens get) — replaces the hardcoded 96dp.
    bottomContentPadding: Dp = 0.dp,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    // Auto-load countries on first open when signed in. Previously the
    // list loaded ONLY via the manual Refresh button, so a fresh install
    // (server-list cache wiped by uninstalling the previous build) showed
    // a permanently blank country panel until the button was found.
    LaunchedEffect(state.signedIn) {
        if (state.signedIn && state.countries.isEmpty() && !state.isLoading) {
            viewModel.refreshAccountAndCountries()
        }
    }
    val connectionState by dashboardViewModel.connectionState.collectAsStateWithLifecycle()
    val foxyState by viewModel.foxyState.collectAsStateWithLifecycle()
    val foxyLastError by viewModel.foxyLastError.collectAsStateWithLifecycle()
    var pendingFenixConnect by remember { mutableStateOf(false) }
    // M5: a denied VPN-permission dialog must say so, like MASQUE /
    // OpenVPN do — never silently clear the pending connect.
    var vpnPermissionDenied by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingFenixConnect) {
            pendingFenixConnect = false
            vpnPermissionDenied = false
            viewModel.connectSelected(context, dashboardViewModel)
        } else {
            pendingFenixConnect = false
            vpnPermissionDenied = true
        }
    }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var twoFactorCode by remember { mutableStateOf("") }
    val foxyRunning = foxyState == FoxyConnectionState.CONNECTED ||
        foxyState == FoxyConnectionState.CONNECTING
    val isRunning = foxyRunning ||
        connectionState == ConnectionState.Connected ||
        connectionState == ConnectionState.Connecting

    val onPowerClick: () -> Unit = {
        if (isRunning) {
            if (foxyRunning) {
                viewModel.disconnectFenix(context)
            } else {
                dashboardViewModel.toggleConnection()
            }
        } else {
            vpnPermissionDenied = false
            val prepareIntent = VpnService.prepare(context)
            if (prepareIntent != null) {
                pendingFenixConnect = true
                vpnPermissionLauncher.launch(prepareIntent)
            } else {
                viewModel.connectSelected(context, dashboardViewModel)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(L4Background),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
                .padding(bottom = bottomContentPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Headline: big bold wordmark + tab title (text only).
            Text(
                text = "RALYSND",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp,
                ),
                color = L4Text,
            )
            Text(
                text = "FENIX — Firefox VPN on your own Firefox accounts",
                style = MaterialTheme.typography.bodyMedium,
                color = L4TextDim,
            )

            // CENTER connect button (approved mockups): in the middle of
            // the screen, in the normal flow — never a bottom-corner
            // overlay. Same VpnService.prepare flow and toggle logic.
            // M21: also rendered while signed out when sing-box (or
            // FENIX itself) is running, so the running tunnel can be
            // stopped from here — the handler already covered that
            // branch, it was just unreachable.
            if (state.signedIn ||
                connectionState == ConnectionState.Connected ||
                connectionState == ConnectionState.Connecting ||
                foxyRunning
            ) {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    L4CenterConnectButton(isRunning = isRunning, onClick = onPowerClick)
                }
            }
            if (vpnPermissionDenied) {
                Text(
                    text = "VPN permission was not granted — tap the center button again to retry.",
                    color = MaterialTheme.colorScheme.error,
                )
            }
            // M37: the local Foxy proxy has no authentication, so a
            // 0.0.0.0 bind must carry this warning wherever it applies.
            // (There is no dedicated bind-host picker UI in the app;
            // the bind value is read from FoxySettingsStore here.)
            if (runCatching {
                    com.kunk.singbox.foxy.data.FoxySettingsStore(context).isLanBind
                }.getOrDefault(false)
            ) {
                Text(
                    text = com.kunk.singbox.foxy.data.FoxySettingsStore.LAN_BIND_WARNING,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            // Aggregate volume tab: total volume across all accounts, as
            // plain text only — no circle, no ring, no arc, no progress
            // percentage. Same real Guardian sourcing as the old ring
            // (totalQuotaRemaining / totalMaxBytes); never a fake number.
            val totalRemaining = state.totalQuotaRemaining
            val totalMax = state.totalMaxBytes
            val volumeTabText = when {
                totalRemaining != null && totalMax != null ->
                    "${formatBytes(totalRemaining)} left"
                totalMax != null -> "of ${formatBytes(totalMax)}"
                else -> "Quota unavailable"
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(L4Surface, RoundedCornerShape(24.dp))
                    .border(1.dp, L4Green.copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                    .padding(vertical = 14.dp, horizontal = 16.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = volumeTabText,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                    color = L4Text,
                )
            }

            // Accounts strip: email text only, + to add, tap to switch.
            if (state.signedIn) {
                Text(text = "FENIX Accounts", fontWeight = FontWeight.Bold, color = L4Text)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (account in state.accounts) {
                        val accountLabel = account.displayEmail.ifBlank { "Firefox account" }
                        L4GlassCard(
                            selected = account.isActive,
                            onClick = { viewModel.switchAccount(account.id) },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = accountLabel, fontWeight = FontWeight.SemiBold, color = L4Text)
                                    val accountRemaining = account.entitlement?.quotaRemaining
                                    val accountMax = account.entitlement?.maxBytes
                                    Text(
                                        text = when {
                                            accountRemaining != null ->
                                                "Quota remaining: ${formatBytes(accountRemaining)}"
                                            accountMax != null ->
                                                "Allowance: ${formatBytes(accountMax)}"
                                            else -> "Quota unavailable"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = L4TextDim,
                                    )
                                    if (account.isActive) {
                                        Text(text = "Active account", style = MaterialTheme.typography.labelSmall, color = L4Green)
                                    }
                                }
                                if (!foxyRunning) {
                                    TextButton(onClick = { viewModel.removeAccount(account.id) }) {
                                        Text(text = "Remove", color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                    Button(
                        onClick = { viewModel.startAddingAccount() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = L4Green, contentColor = L4Background),
                    ) { Text(text = "+ Add another Firefox account", fontWeight = FontWeight.Bold) }
                }
            }

            // Login card: first sign-in, or adding another account.
            AnimatedVisibility(visible = !state.signedIn || state.addingAccount) {
                L4GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (state.addingAccount) "Add another Firefox account" else "Sign in with your Firefox account",
                            fontWeight = FontWeight.Bold,
                            color = L4Text,
                        )
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Firefox account email") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            // ui-ux-pro-max (Forms / Mobile Keyboards):
                            // appropriate keyboard per input type.
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        )
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        )
                        if (state.needsTwoFactor) {
                            OutlinedTextField(
                                value = twoFactorCode,
                                onValueChange = { twoFactorCode = it },
                                label = { Text("Confirmation code sent to your email") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            )
                            Button(
                                onClick = { viewModel.submitTwoFactorCode(twoFactorCode) },
                                enabled = !state.isLoading && twoFactorCode.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = L4Green, contentColor = L4Background),
                            ) { Text("Verify code") }
                        } else {
                            Button(
                                onClick = { viewModel.signIn(email, password) },
                                enabled = !state.isLoading && email.isNotBlank() && password.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = L4Green, contentColor = L4Background),
                            ) { Text(if (state.addingAccount) "Add account" else "Sign in") }
                        }
                        Row {
                            TextButton(
                                onClick = {
                                    context.startActivity(
                                        Intent(Intent.ACTION_VIEW, Uri.parse("https://accounts.firefox.com/signup")),
                                    )
                                },
                            ) { Text("Create a Firefox account", color = L4Green) }
                            if (state.addingAccount) {
                                TextButton(onClick = { viewModel.cancelAddingAccount() }) {
                                    Text("Cancel", color = L4TextDim)
                                }
                            }
                        }
                    }
                }
            }

            // Country panel: horizontal carousel, ping BELOW each country name.
            if (state.signedIn) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(text = "Countries", fontWeight = FontWeight.Bold, color = L4Text)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.pingAllCountries() },
                            enabled = !state.isPinging,
                            modifier = Modifier.height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = L4Green, contentColor = L4Background),
                        ) { Text(if (state.isPinging) "Pinging…" else "Ping all", fontWeight = FontWeight.Bold) }
                        Button(
                            onClick = {
                                val fastest = viewModel.fastestCountry()
                                if (fastest != null) viewModel.selectCountry(fastest.code)
                            },
                            // M17: disabled with a reason, never a silent
                            // no-op, while nothing has a ping yet.
                            enabled = viewModel.fastestCountry() != null,
                            modifier = Modifier.height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = L4Surface, contentColor = L4Amber),
                        ) { Text("Fastest") }
                    }
                }
                if (state.pingMs.isEmpty()) {
                    Text(
                        text = "Fastest is disabled until Ping all measures a country.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                }
                // M10: refresh/cache and per-account Guardian notes, shown
                // plainly instead of silently serving stale data.
                state.countriesNote?.let {
                    Text(text = it, style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                }
                if (state.guardianFailureCount > 0) {
                    Text(
                        text = "Guardian data unavailable for ${state.guardianFailureCount} account(s) — " +
                            "their quota is absent, not zero.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                }
                if (state.isLoading || state.isPinging || state.isConnecting) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = L4Green)
                }
                state.selected?.let { selected ->
                    Text(
                        text = "Selected: ${selected.countryName} (${selected.host}:${selected.port})",
                        style = MaterialTheme.typography.bodyMedium,
                        color = L4TextDim,
                    )
                }
                // compose-performance (choosing-derivedstateof /
                // optimizing-lazy-layouts): sorting is remembered on
                // exactly its inputs (countries + ping map), so unrelated
                // state changes (e.g. isPinging flips) do not re-sort;
                // items are keyed + typed + animateItem'd for stable,
                // jank-free carousel scrolling.
                val sorted = remember(state.countries, state.pingMs) {
                    state.countries.sortedBy { country ->
                        state.pingMs[country.code] ?: Int.MAX_VALUE
                    }
                }
                // Foxy volume is account-level, not per-country: the same
                // real total remaining is shown below every country's ping
                // when an account reports one; null renders no volume line.
                val foxyVolumeText = state.totalQuotaRemaining?.let { remaining ->
                    "Remaining: ${formatBytes(remaining)}"
                }
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(sorted, key = { it.code }, contentType = { "country" }) { country ->
                        val ping = state.pingMs[country.code]
                        val isSelected = state.selected?.countryCode.equals(country.code, ignoreCase = true)
                        L4CountryCard(
                            flag = country.emojiFlag,
                            countryCode = country.code,
                            countryName = country.name,
                            pingText = when {
                                ping != null -> "$ping ms"
                                state.isPinging -> "pinging…"
                                else -> "—"
                            },
                            selected = isSelected,
                            onClick = { viewModel.selectCountry(country.code) },
                            modifier = Modifier.animateItem(),
                            volumeText = foxyVolumeText,
                        )
                    }
                }
                Button(
                    onClick = { viewModel.refreshAccountAndCountries() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Surface, contentColor = L4Text),
                ) { Text("Refresh accounts & countries") }
            }

            state.message?.let {
                Text(text = it, color = MaterialTheme.colorScheme.error)
            }
            // C6: when the Foxy service has stopped with an error (e.g.
            // bounded monitor failure), its verbatim last error is
            // visible here instead of a stale "connected" impression.
            if (foxyState == FoxyConnectionState.DISCONNECTED) {
                foxyLastError?.let {
                    Text(text = it, color = MaterialTheme.colorScheme.error)
                }
            }
            Text(
                text = "FENIX engine based on FoxyVPN (MIT) by Vauth",
                style = MaterialTheme.typography.bodySmall,
                color = L4TextDim,
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
        // No bottom-corner button: the center button above (in flow,
        // after the headline) is the only connect control on this screen.
    }
}

