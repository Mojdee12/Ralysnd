package com.kunk.singbox.engines

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.kunk.singbox.foxy.data.model.ConnectionState as FoxyConnectionState
import com.kunk.singbox.foxy.vpn.FoxyVpnService
import com.kunk.singbox.foxy.vpn.tun.HevSocks5Tunnel
import com.kunk.singbox.foxy.vpn.tun.HevSocks5TunnelConfig
import com.kunk.singbox.service.SingBoxService
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** UI-visible state of the engine VPN service. Never faked: an
 *  Error state carries the core's real message, and Connected is
 *  only published after the TUN interface and hev tunnel are up
 *  AND a real SOCKS5 CONNECT through the gateway to a neutral
 *  public host succeeds (see verifyTrafficThroughProxy). While
 *  that verification runs the state stays Connecting, never
 *  Connected. */
sealed interface EngineVpnState {
    data object Disconnected : EngineVpnState
    data class Connecting(val engine: String) : EngineVpnState
    data class Connected(val engine: String, val detail: String) : EngineVpnState
    data class Error(val engine: String, val message: String) : EngineVpnState
}

/**
 * One VpnService for the MASQUE core only. Psiphon was removed
 * from this service (its branch had no UI callers and is deleted
 * here), and PsiphonTunnelBridge.kt plus PsiphonEngine.kt were
 * deleted outright by the parent together with the ca.psiphon.aar
 * dependency line in app/build.gradle.kts — no Psiphon code or
 * dependency remains in the tree.
 *
 * Traffic flow (same shape as the Foxy tunnel):
 *   app traffic -> TUN -> hev-socks5-tunnel -> local SOCKS5
 *   (127.0.0.1:[socksPort]) -> core -> gateway -> internet.
 * The MASQUE core itself IS the local SOCKS5 server (Rust).
 *
 * Single-VpnService rule: before starting, this service stops
 * Foxy and sing-box explicitly and waits (bounded, 8 s) for the
 * Foxy tunnel to actually report disconnected before dialling.
 * Android additionally allows only one active VPN. The app's own
 * package is disallowed from the TUN (like Foxy does) so the
 * core's own outbound sockets bypass the tunnel instead of
 * looping back into it.
 *
 * Single gateway resolver: the gateway dialled here is exactly
 * the one the sheet resolved (EnginesViewModel.resolveMasqueGateway).
 * There is NO fallback to the cached winner or the documented
 * edge in this service: a null gateway never reaches here
 * (startMasque requires it), and a gateway known to reject
 * CONNECT-UDP is refused up front with a plain reason instead
 * of being dialled and faked as connected.
 */
class EngineVpnService : VpnService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var connectJob: Job? = null
    private var monitorJob: Job? = null
    private var tunFd: ParcelFileDescriptor? = null
    private var currentEngine: String? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> {
                teardown()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                // Second connect while a run is live (Connected or
                // still Connecting) RE-CONNECTS to the newly
                // selected gateway: tear the old run down first,
                // then start the new one. It is never silently
                // ignored, and the old run's cancellation handler
                // (see connect) will not touch the new run's
                // state, because it checks that it is still the
                // current connectJob before tearing anything down.
                if (connectJob != null) {
                    teardown()
                }
                val gateway = intent?.getStringExtra(EXTRA_GATEWAY) ?: return START_NOT_STICKY
                enterForeground()
                connectJob = scope.launch { connect(gateway) }
                return START_STICKY
            }
        }
    }

    override fun onDestroy() {
        // Preserve an Error state here: stopSelf() after a failed
        // start would otherwise destroy the service and erase the
        // rejection the sheet is showing, before the user reads
        // it. A later tap overwrites it with Connecting; an
        // explicit disconnect resets it to Disconnected.
        teardown(resetState = false)
        scope.cancel()
        super.onDestroy()
    }

    override fun onRevoke() {
        // Android replaced this VPN (another VPN took over): no
        // stale "connected" may survive. Tear everything down,
        // reset the published state to Disconnected, and stop.
        teardown()
        stopSelf()
        super.onRevoke()
    }

    private fun enterForeground() {
        val channelId = "ralysnd_engine_vpn"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager?.getNotificationChannel(channelId) == null) {
                manager?.createNotificationChannel(
                    NotificationChannel(
                        channelId,
                        "Ralysnd engine VPN",
                        NotificationManager.IMPORTANCE_LOW,
                    ),
                )
            }
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Ralysnd")
            .setContentText("MASQUE connecting…")
            .setOngoing(true)
            .build()
        startForeground(1, notification)
    }

    private suspend fun connect(gateway: String) {
        val engine = "MASQUE"
        currentEngine = engine
        _state.value = EngineVpnState.Connecting(engine)
        // True only while this invocation is still the current
        // connectJob. A superseded run (a re-connect replaced it)
        // must not tear down the new run's cores or overwrite
        // its state from its own error/cancel handler.
        suspend fun isCurrentRun(): Boolean =
            connectJob === currentCoroutineContext()[Job]
        try {
            // CONNECT-UDP incompatibility is refused up front,
            // before any other VPN is disturbed: the documented
            // WARP edge speaks CONNECT-IP only and can never
            // carry this core's traffic.
            if (MasqueEngine.isConnectUdpIncompatible(gateway)) {
                throw IllegalStateException(INCOMPATIBLE_GATEWAY_MESSAGE)
            }
            // Single-VpnService rule: stop the other two first.
            runCatching { FoxyVpnService.stop(applicationContext) }
            // Same rule for the OpenVPN core: its VpnService must not
            // run alongside this one; stop is a safe no-op if absent.
            runCatching { com.kunk.singbox.openvpn.OpenVpnStarter.stop(applicationContext) }
            runCatching {
                applicationContext.startService(
                    Intent(applicationContext, SingBoxService::class.java)
                        .setAction(SingBoxService.ACTION_STOP),
                )
            }
            // Bounded wait for the other service to actually stop
            // (Dashboard's 8 s pattern), not a blind delay: if the
            // Foxy tunnel still holds the VPN slot after 8 s,
            // report the conflict plainly instead of racing it.
            // Sing-box has no in-process stopped signal readable
            // from this service, so its stop stays an intent and
            // a slot still held at establish() time surfaces as
            // that verbatim failure below.
            if (FoxyVpnService.state.value != FoxyConnectionState.DISCONNECTED) {
                val deadline = System.currentTimeMillis() + OTHER_SERVICE_WAIT_MS
                while (FoxyVpnService.state.value != FoxyConnectionState.DISCONNECTED &&
                    System.currentTimeMillis() < deadline
                ) {
                    delay(100)
                }
                if (FoxyVpnService.state.value != FoxyConnectionState.DISCONNECTED) {
                    throw IllegalStateException(
                        "FENIX did not stop within 8 seconds — disconnect it and try again",
                    )
                }
            }
            val (host, gwPort) = MasqueEngine.parseHostPort(gateway)
            val localPort = freePort()
            val serverName = if (IP_LIKE.matches(host)) "" else host
            MasqueCore.start(host, gwPort, serverName, localPort)
                .getOrElse { throw IllegalStateException(it.message ?: "MASQUE core failed to start") }
            waitForLocalProxy(localPort, 15_000)
                ?: throw IllegalStateException("MASQUE core did not open its local proxy")
            val tun = Builder()
                .setSession("Ralysnd $engine")
                .addAddress(HevSocks5TunnelConfig.TUN_ADDRESS, 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer(HevSocks5TunnelConfig.MAPDNS_ADDRESS)
                .setMtu(HevSocks5TunnelConfig.TUN_MTU)
                .setBlocking(true)
                .apply {
                    runCatching { addDisallowedApplication(packageName) }
                }
                .establish()
                ?: throw IllegalStateException("Could not establish the VPN interface (permission revoked?)")
            tunFd = tun
            val configPath = HevSocks5TunnelConfig.write(applicationContext, localPort)
            if (!HevSocks5Tunnel.start(configPath, tun.fd)) {
                throw IllegalStateException("Failed to start the local tunnel (hev-socks5-tunnel)")
            }
            // Real-traffic proof, before any Connected is published:
            // a SOCKS5 CONNECT through the local proxy, relayed by
            // the gateway, to a neutral public host. A local-port
            // accept alone is NOT proof (the old behaviour): the
            // gateway may reject the stream while the port stays
            // open. On failure this throws and the Error below
            // carries the verbatim SOCKS reason.
            verifyTrafficThroughProxy(localPort)?.let { reason ->
                throw IllegalStateException(reason)
            }
            _state.value = EngineVpnState.Connected(engine, "via $gateway")
            monitorJob = scope.launch { monitor(engine) }
        } catch (e: CancellationException) {
            // Cancel-during-connect ends Idle, never Error: the
            // user asked to stop, so a failure state would be a
            // lie. Only the current run may reset state; a
            // superseded run just exits and leaves the new run
            // alone. Swallowing here is deliberate: the job is
            // already cancelled, and Disconnected is the state.
            Log.i(TAG, "engine $engine connect cancelled")
            if (isCurrentRun()) {
                teardown()
            }
            return
        } catch (e: Exception) {
            if (!isCurrentRun()) {
                return
            }
            Log.e(TAG, "engine $engine failed to start", e)
            // Error is deliberately left in _state: onDestroy
            // preserves it (resetState = false), so the sheet
            // shows the core's rejection verbatim, and the next
            // tap can start again (guard is the job, not state).
            _state.value = EngineVpnState.Error(engine, e.message ?: e.javaClass.simpleName)
            teardown(resetState = false)
            stopSelf()
            connectJob = null
        }
    }

    private suspend fun monitor(engine: String) {
        while (true) {
            delay(2_000)
            // nativeIsRunning now tracks the QUIC session itself
            // (Rust clears it when the QUIC thread exits), so a
            // dead QUIC session turns into Error promptly instead
            // of looking connected forever.
            if (!MasqueCore.isRunning()) {
                _state.value = EngineVpnState.Error(engine, "MASQUE core stopped unexpectedly")
                // Preserve the error: plain teardown() would
                // reset it to Disconnected immediately.
                teardown(resetState = false)
                stopSelf()
                return
            }
        }
    }

    /** Waits until something accepts TCP on the local SOCKS port. */
    private suspend fun waitForLocalProxy(port: Int, timeoutMs: Long): Int? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (!MasqueCore.isRunning()) return null
            val ok = runCatching {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress("127.0.0.1", port), 300)
                }
                true
            }.getOrDefault(false)
            if (ok) return port
            delay(500)
        }
        return null
    }

    /**
     * Proves real traffic through the gateway: a SOCKS5 CONNECT
     * via the core's local proxy to a neutral public host
     * (example.com:80). Returns null on success, or the verbatim
     * failure reason on any rejection/timeout. This is a TCP
     * CONNECT through the gateway's HTTP/3 stream — it proves
     * the gateway relayed a real outbound connection, which a
     * local-port accept cannot. Bounded: 5 s connect + 10 s
     * handshake at most.
     */
    private fun verifyTrafficThroughProxy(port: Int): String? {
        return runCatching {
            Socket().use { socket ->
                socket.connect(InetSocketAddress("127.0.0.1", port), 5_000)
                socket.soTimeout = 10_000
                val input = socket.getInputStream()
                val output = socket.getOutputStream()
                output.write(byteArrayOf(5, 1, 0))
                output.flush()
                val greeting = ByteArray(2)
                if (!readExact(input, greeting)) return "Traffic verification failed: no SOCKS5 greeting reply from the local proxy"
                if (greeting[0] != 5.toByte() || greeting[1] != 0.toByte()) {
                    return "Traffic verification failed: SOCKS5 greeting rejected (method ${greeting[1]})"
                }
                val hostBytes = VERIFY_HOST.toByteArray(Charsets.US_ASCII)
                val request = ByteArray(4 + 1 + hostBytes.size + 2)
                request[0] = 5
                request[1] = 1
                request[2] = 0
                request[3] = 3
                request[4] = hostBytes.size.toByte()
                hostBytes.copyInto(request, 5)
                request[5 + hostBytes.size] = (VERIFY_PORT shr 8).toByte()
                request[6 + hostBytes.size] = (VERIFY_PORT and 0xff).toByte()
                output.write(request)
                output.flush()
                val header = ByteArray(4)
                if (!readExact(input, header)) return "Traffic verification failed: no SOCKS5 CONNECT reply"
                if (header[0] != 5.toByte()) return "Traffic verification failed: bad SOCKS5 CONNECT reply"
                if (header[1] != 0.toByte()) {
                    return "Traffic verification failed: SOCKS5 CONNECT to $VERIFY_HOST:$VERIFY_PORT rejected (reply ${header[1]})"
                }
                val atyp = header[3]
                val tailLen = when (atyp.toInt()) {
                    1 -> 6
                    3 -> {
                        val lenByte = ByteArray(1)
                        if (!readExact(input, lenByte)) return "Traffic verification failed: truncated SOCKS5 CONNECT reply"
                        lenByte[0].toInt() + 2
                    }
                    4 -> 18
                    else -> return "Traffic verification failed: unexpected SOCKS5 address type ($atyp)"
                }
                if (!readExact(input, ByteArray(tailLen))) {
                    return "Traffic verification failed: truncated SOCKS5 CONNECT reply"
                }
                null
            }
        }.getOrElse { e ->
            "Traffic verification failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun readExact(input: InputStream, buffer: ByteArray): Boolean {
        var offset = 0
        while (offset < buffer.size) {
            val read = input.read(buffer, offset, buffer.size - offset)
            if (read < 0) return false
            offset += read
        }
        return true
    }

    private fun teardownCores() {
        runCatching { MasqueCore.stop() }
    }

    private fun teardown(resetState: Boolean = true) {
        monitorJob?.cancel()
        monitorJob = null
        connectJob?.cancel()
        connectJob = null
        runCatching { HevSocks5Tunnel.stop() }
        teardownCores()
        runCatching { tunFd?.close() }
        tunFd = null
        currentEngine = null
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        if (resetState && _state.value !is EngineVpnState.Disconnected) {
            _state.value = EngineVpnState.Disconnected
        }
    }

    private fun freePort(): Int = ServerSocket(0).use { it.localPort }

    companion object {
        private const val TAG = "EngineVpnService"
        private val IP_LIKE = Regex("^[0-9.]+$")

        const val ACTION_CONNECT = "com.kunk.singbox.engines.action.CONNECT"
        const val ACTION_DISCONNECT = "com.kunk.singbox.engines.action.DISCONNECT"
        private const val EXTRA_GATEWAY = "gateway"

        /** Bounded wait for another VPN service to actually stop. */
        private const val OTHER_SERVICE_WAIT_MS = 8_000L

        /** Plain reason shown when a CONNECT-UDP-incompatible gateway is refused. */
        const val INCOMPATIBLE_GATEWAY_MESSAGE =
            "This gateway rejects CONNECT-UDP — add a CONNECT-UDP gateway"

        /** Neutral public host used only for the traffic proof in verifyTrafficThroughProxy. */
        private const val VERIFY_HOST = "example.com"
        private const val VERIFY_PORT = 80

        private val _state = MutableStateFlow<EngineVpnState>(EngineVpnState.Disconnected)
        val state: StateFlow<EngineVpnState> = _state.asStateFlow()

        fun startMasque(context: Context, gateway: String) {
            val intent = Intent(context, EngineVpnService::class.java).apply {
                action = ACTION_CONNECT
                putExtra(EXTRA_GATEWAY, gateway)
            }
            start(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, EngineVpnService::class.java).apply {
                action = ACTION_DISCONNECT
            }
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }

        /**
         * Stops the service and waits (bounded) until its published
         * state is Disconnected. Other ViewModels (Dashboard,
         * Foxy) use this instead of a blind delay so they never
         * start their own VPN while this one still holds the slot.
         * Returns true when the service is confirmed stopped.
         * Existing stop() stays for fire-and-forget callers.
         */
        suspend fun stopAndWait(context: Context, timeoutMs: Long = 8_000L): Boolean {
            stop(context)
            return awaitStopped(timeoutMs)
        }

        /** Bounded wait for the published state to become Disconnected. */
        suspend fun awaitStopped(timeoutMs: Long = 8_000L): Boolean {
            val deadline = System.currentTimeMillis() + timeoutMs
            while (System.currentTimeMillis() < deadline) {
                if (_state.value is EngineVpnState.Disconnected) return true
                delay(100)
            }
            return _state.value is EngineVpnState.Disconnected
        }

        private fun start(context: Context, intent: Intent) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
