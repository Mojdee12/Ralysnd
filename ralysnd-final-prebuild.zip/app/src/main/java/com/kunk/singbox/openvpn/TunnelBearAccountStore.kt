package com.kunk.singbox.openvpn

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * TunnelBear account storage — the app's existing secure-storage
 * pattern, copied from Foxy's FoxySettingsStore: EncryptedSharedPreferences
 * with a MasterKey (AES256_GCM), key encryption AES256_SIV and value
 * encryption AES256_GCM (androidx.security:security-crypto, already a
 * dependency). Credentials are NEVER hard-coded, never logged, never
 * put in chat, and never stored in plain MMKV: only the username
 * (email) and password the user types in the OpenVPN tab live here.
 * There is no network "sign-in validation" step: TunnelBear
 * publishes no public account-check API for this, so saving here is
 * the sign-in, and the credentials are verified by the first real
 * connect attempt, whose error (e.g. auth failure) is shown verbatim.
 */
class TunnelBearAccountStore(context: Context) {
    private val appContext = context.applicationContext

    private val prefs by lazy {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            appContext,
            "ralysnd_tunnelbear_credentials",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    var username: String
        get() = prefs.getString(KEY_USERNAME, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_USERNAME, value.trim()).apply()
        }

    var password: String
        get() = prefs.getString(KEY_PASSWORD, "") ?: ""
        set(value) {
            prefs.edit().putString(KEY_PASSWORD, value).apply()
        }

    /** True when a username is stored (password presence is checked at connect). */
    val hasAccount: Boolean
        get() = username.isNotBlank()

    fun save(username: String, password: String) {
        this.username = username
        this.password = password
    }

    fun clear() {
        prefs.edit().remove(KEY_USERNAME).remove(KEY_PASSWORD).apply()
    }

    companion object {
        private const val KEY_USERNAME = "tunnelbear_username"
        private const val KEY_PASSWORD = "tunnelbear_password"
    }
}
