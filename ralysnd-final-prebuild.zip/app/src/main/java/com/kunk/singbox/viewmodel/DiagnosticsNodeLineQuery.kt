package com.kunk.singbox.viewmodel

import android.app.Application
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.kunk.singbox.R
import com.kunk.singbox.ipc.SingBoxRemote
import com.kunk.singbox.ipc.VpnStateStore
import com.kunk.singbox.model.NodeUi
import com.kunk.singbox.model.Outbound
import com.kunk.singbox.model.DnsServer
import com.kunk.singbox.model.RouteRule
import com.kunk.singbox.model.SingBoxConfig
import com.kunk.singbox.repository.*
import com.kunk.singbox.repository.SettingsRepository
import com.kunk.singbox.utils.NetworkClient
import kotlinx.coroutines.flow.first
import okhttp3.Request

internal class DiagnosticsNodeLineQueryRunner(
    private val application: Application,
    private val configRepository: ConfigRepository,
    private val settingsRepository: SettingsRepository
) {
    private val gson = Gson()

    suspend fun buildReport(): String {
        val activeLabel = SingBoxRemote.activeLabel.value.trim()
        val storedActiveLabel = VpnStateStore.getActiveLabel().trim()
        val activeNodeId = configRepository.activeNodeId.first()
        val activeLabelNode = activeLabel.takeIf { it.isNotBlank() }?.let(configRepository::getNodeByName)
        val storedActiveLabelNode = storedActiveLabel.takeIf { it.isNotBlank() }?.let(configRepository::getNodeByName)
        val fallbackNode = activeNodeId?.let(configRepository::getNodeById)
        val nodeResolution = resolveNodeLineTarget(
            activeLabelNode = activeLabelNode,
            storedActiveLabelNode = storedActiveLabelNode,
            fallbackNode = fallbackNode
        ) ?: return buildUnavailableMessage()

        val settings = settingsRepository.settings.first()
        val coreActive = VpnStateStore.getActive()
        val outbound = configRepository.getOutboundByNodeId(nodeResolution.node.id)
        val queryData = NodeLineQueryData(
            nodeResolution = nodeResolution,
            activeLabel = activeLabel,
            storedActiveLabel = storedActiveLabel,
            outbound = outbound,
            delay = queryNodeDelay(
                node = nodeResolution.node
            ),
            exitPortrait = queryExitPortrait(coreActive = coreActive, proxyPort = settings.proxyPort),
            coreActive = coreActive,
            proxyPort = settings.proxyPort,
            hasSignalConflict = activeLabelNode != null &&
                fallbackNode != null &&
                activeLabelNode.id != fallbackNode.id
        )

        return buildNodeLineQueryMessage(
            data = queryData,
            unknownText = application.getString(R.string.common_unknown)
        )
    }

    private fun buildUnavailableMessage(): String {
        return buildString {
            appendLine("No identifiable active node at the moment.")
            appendLine()
            appendLine("Notes:")
            appendLine("- This result depends on the current runtime label or the selected global node.")
            appendLine("- If you just switched profile or node, try again shortly.")
        }
    }

    private suspend fun queryNodeDelay(node: NodeUi): Int? {
        val latency = configRepository.testNodeLatency(node.id)
        return latency.takeIf { it > 0L && it <= Int.MAX_VALUE }?.toInt()
    }

    private fun queryExitPortrait(coreActive: Boolean, proxyPort: Int): NodeExitPortrait? {
        if (!coreActive || proxyPort <= 0) return null
        val request = Request.Builder()
            .url(EXIT_PORTRAIT_ENDPOINT)
            .header("Accept", "application/json")
            .build()

        return runCatching {
            NetworkClient.createClientWithProxy(
                proxyPort = proxyPort,
                connectTimeoutSeconds = 8,
                readTimeoutSeconds = 8,
                writeTimeoutSeconds = 8,
                callTimeoutSeconds = 12
            ).newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@use null
                val body = response.body.string()
                if (body.isBlank()) return@use null
                gson.fromJson(body, IpSbGeoIpResponse::class.java)?.toExitPortrait(
                    unknownText = application.getString(R.string.common_unknown)
                )
            }
        }.getOrNull()
    }
}

private const val EXIT_PORTRAIT_ENDPOINT = "https://api.ip.sb/geoip"

internal fun buildDnsQuerySuccessMessage(host: String, addresses: List<String>): String {
    val ipList = addresses.joinToString("\n")
    return "Domain: $host\n\n" +
        "Result:\n$ipList\n\n" +
        "Note: System DNS only. KunBox app is excluded from VPN, so this does not represent current node DNS."
}

internal fun buildDnsQueryFailureMessage(host: String, errorMessage: String?): String {
    return "Domain: $host\n\n" +
        "Failed: ${errorMessage ?: "unknown"}\n\n" +
        "Note: System DNS only. KunBox app is excluded from VPN, so this does not represent current node DNS."
}

internal fun buildDnsLeakCheckReport(coreActive: Boolean, runConfig: SingBoxConfig?): String {
    if (!coreActive) {
        return buildString {
            appendLine("DNS static risk: present")
            appendLine()
            appendLine("Reasons:")
            appendLine("- The core is not running; the current connection is not handled by the KunBox VPN.")
        }
    }
    if (runConfig == null) {
        return buildString {
            appendLine("DNS static risk: present")
            appendLine()
            appendLine("Reasons:")
            appendLine("- Cannot read the runtime config, so DNS takeover cannot be confirmed.")
        }
    }

    val reasons = buildDnsLeakReasons(runConfig)
    return buildString {
        appendLine("DNS static risk: ${if (reasons.isEmpty()) "no obvious config gap found" else "present"}")
        appendLine()
        if (reasons.isEmpty()) {
            appendLine("Check results:")
            appendLine("- Runtime config contains a TUN inbound.")
            appendLine("- route.rules already contain a hijack-dns rule covering tun-in:53 or protocol=dns.")
            appendLine("- DNS final points to a valid and safe server tag.")
            appendLine("- No system DNS or cleartext direct DNS server found.")
            appendLine("- This result only checks static config; it does not replace on-device packet capture and does not prove there is no DoH, IPv6, or per-app bypass.")
        } else {
            appendLine("Reasons:")
            reasons.forEach { appendLine("- $it") }
        }
    }
}

private fun buildDnsLeakReasons(runConfig: SingBoxConfig): List<String> {
    val reasons = mutableListOf<String>()
    val tunInbound = runConfig.inbounds.orEmpty().firstOrNull { it.type == "tun" }
    if (tunInbound == null) {
        reasons.add("Runtime config lacks a TUN inbound, so system DNS traffic will not enter the KunBox VPN.")
    }

    val routeRules = runConfig.route?.rules.orEmpty()
    if (!routeRules.any { it.isEffectiveDnsHijackRule() }) {
        reasons.add("Runtime config lacks a DNS hijack rule covering tun-in:53 or protocol=dns.")
    }
    if (!routeRules.any { it.isPort853BlockRule() }) {
        reasons.add("Runtime config lacks a port 853 intercept rule, so Android Private DNS (DoT) can bypass DNS hijacking.")
    }

    val dns = runConfig.dns
    val servers = dns?.servers.orEmpty()
    val finalServer = dns?.finalServer.orEmpty()
    val serversByTag = servers.mapNotNull { server -> server.tag?.let { it to server } }.toMap()
    if (finalServer.isBlank()) {
        reasons.add("DNS final is empty, so the final DNS path is unclear.")
    } else {
        val finalDnsServer = serversByTag[finalServer]
        if (finalDnsServer == null) {
            reasons.add("DNS final points to $finalServer, but that tag does not exist in servers.")
        } else if (finalDnsServer.unsafeDnsReason(serversByTag, runConfig.outbounds.orEmpty()) != null) {
            reasons.add("DNS final points to unsafe server $finalServer.")
        }
    }

    servers.mapNotNull { server -> server.unsafeDnsReason(serversByTag, runConfig.outbounds.orEmpty()) }
        .forEach { reasons.add(it) }
    return reasons.distinct()
}

private fun RouteRule.isEffectiveDnsHijackRule(): Boolean {
    if (action != "hijack-dns") return false
    val coversTunPort53 = inbound.orEmpty().contains("tun-in") && port.orEmpty().contains(53)
    val coversDnsProtocol = protocol.orEmpty().any { it.equals("dns", ignoreCase = true) }
    return coversTunPort53 || coversDnsProtocol
}

private fun RouteRule.isPort853BlockRule(): Boolean {
    return port.orEmpty().contains(853) && action == "reject"
}

private fun DnsServer.unsafeDnsReason(serversByTag: Map<String, DnsServer>, outbounds: List<Outbound>): String? {
    val label = tag ?: "(untagged)"
    val normalizedType = type?.lowercase().orEmpty()
    if (normalizedType == "fakeip") return null
    val target = server ?: address ?: "local"
    return when {
        normalizedType == "local" || normalizedType == "dhcp" -> {
            "DNS server $label uses system DNS type $normalizedType."
        }
        normalizedType == "udp" || normalizedType == "tcp" || normalizedType.isBlank() -> {
            unsafePlainDnsReason(label, normalizedType, target, serversByTag, outbounds)
        }
        target.equals("local", ignoreCase = true) -> {
            "DNS server $label points to system DNS local."
        }
        else -> null
    }
}

private fun DnsServer.unsafePlainDnsReason(
    label: String,
    normalizedType: String,
    target: String,
    serversByTag: Map<String, DnsServer>,
    outbounds: List<Outbound>
): String? {
    val dnsType = normalizedType.ifBlank { "legacy" }
    val detourTag = detour?.takeIf { it.isNotBlank() }
    val outbound = detourTag?.let { tag -> outbounds.firstOrNull { it.tag == tag } }
    return when {
        detourTag == null -> "DNS server $label uses cleartext direct DNS $dnsType://$target."
        serversByTag.containsKey(detourTag) -> "DNS server $label detour points to DNS server $detourTag, not an outbound proxy."
        outbound == null -> "DNS server $label detour points to a nonexistent outbound $detourTag."
        outbound.type.equals("direct", ignoreCase = true) -> "DNS server $label detour points to the direct outbound $detourTag."
        outbound.type.equals("block", ignoreCase = true) -> "DNS server $label detour points to the block outbound $detourTag, so the DNS path is unavailable."
        else -> null
    }
}

private data class NodeLineQueryData(
    val nodeResolution: NodeLineTarget,
    val activeLabel: String,
    val storedActiveLabel: String,
    val outbound: Outbound?,
    val delay: Int?,
    val exitPortrait: NodeExitPortrait?,
    val coreActive: Boolean,
    val proxyPort: Int,
    val hasSignalConflict: Boolean
)

internal data class NodeLineTarget(
    val node: NodeUi,
    val sourceLabel: String
)

internal fun resolveNodeLineTarget(
    activeLabelNode: NodeUi?,
    storedActiveLabelNode: NodeUi?,
    fallbackNode: NodeUi?
): NodeLineTarget? {
    return activeLabelNode?.let {
        NodeLineTarget(it, "Runtime activeLabel")
    } ?: storedActiveLabelNode?.let {
        NodeLineTarget(it, "State-store activeLabel")
    } ?: fallbackNode?.let {
        NodeLineTarget(it, "Currently selected node")
    }
}

private fun buildNodeLineQueryMessage(data: NodeLineQueryData, unknownText: String): String {
    return buildString {
        appendLine("Query target: current global node route")
        appendLine("Node: ${data.nodeResolution.node.displayName}")
        appendLine("Source: ${data.nodeResolution.sourceLabel}")
        appendLine("Protocol: ${data.nodeResolution.node.protocolDisplay}")
        appendLine("Profile ID: ${data.nodeResolution.node.sourceProfileId}")
        appendLine("Core running: ${if (data.coreActive) "yes" else "no"}")
        appendSignalSection(data)
        appendNodeSection(data, unknownText)
        appendExitPortraitSection(data)
        appendNoteSection()
    }
}

private fun StringBuilder.appendSignalSection(data: NodeLineQueryData) {
    if (data.activeLabel.isNotBlank()) {
        appendLine("Runtime label: ${data.activeLabel}")
    }
    if (data.storedActiveLabel.isNotBlank() && data.storedActiveLabel != data.activeLabel) {
        appendLine("State-store label: ${data.storedActiveLabel}")
    }
    if (data.hasSignalConflict) {
        appendLine("State difference: the runtime label differs from the currently selected node; the runtime label was preferred")
    }
}

private fun StringBuilder.appendNodeSection(data: NodeLineQueryData, unknownText: String) {
    appendLine()
    appendLine("=== Node route info ===")
    appendLine("Node label: ${data.nodeResolution.node.name}")
    appendLine("URLTest latency: ${formatNodeDelay(data.delay, unknownText)}")
    data.outbound?.let { outbound ->
        val outboundType = outbound.type.ifBlank { unknownText }
        appendLine("Outbound type: $outboundType")
        appendServerLine(outbound = outbound, unknownText = unknownText)
    }
}

private fun StringBuilder.appendServerLine(outbound: Outbound, unknownText: String) {
    val server = outbound.server?.takeIf { it.isNotBlank() } ?: return
    val portText = outbound.serverPort?.toString() ?: unknownText
    appendLine("Server: $server:$portText")
}

private fun StringBuilder.appendExitPortraitSection(data: NodeLineQueryData) {
    appendLine()
    appendLine("=== Current exit observation ===")
    when {
        !data.coreActive -> appendLine("Core is not running; no proxied exit observation was started.")
        data.proxyPort <= 0 -> appendLine("Local proxy port is unavailable; the current exit portrait cannot be obtained.")
        data.exitPortrait == null -> appendLine("Exit portrait fetch failed or is temporarily unavailable.")
        else -> {
            appendLine("Observation source: api.ip.sb")
            appendLine("Exit IP: ${data.exitPortrait.ip}")
            appendLine("Country/Region: ${data.exitPortrait.country}")
            appendLine("City: ${data.exitPortrait.city}")
            appendLine("ASN: ${data.exitPortrait.asn}")
            appendLine("Organization: ${data.exitPortrait.organization}")
            appendLine("ISP: ${data.exitPortrait.isp}")
        }
    }
}

private fun StringBuilder.appendNoteSection() {
    appendLine()
    appendLine("Notes:")
    appendLine("- Results are inferred primarily from the runtime activeLabel for the current global node.")
    appendLine("- The current exit observation comes from one HTTPS request sent through the local proxy and represents only this diagnostic request.")
    appendLine("- If a selector/urltest split group is hit, real traffic exits may differ from this result.")
}

private fun formatNodeDelay(delay: Int?, unknownText: String): String {
    if (delay == null || delay <= 0) return unknownText
    return "${delay}ms"
}

private data class IpSbGeoIpResponse(
    val ip: String? = null,
    val asn: Long? = null,
    val country: String? = null,
    val city: String? = null,
    val isp: String? = null,
    val organization: String? = null,
    @SerializedName("asn_organization") val asnOrganization: String? = null
) {
    fun toExitPortrait(unknownText: String): NodeExitPortrait? {
        val resolvedIp = ip?.takeIf { it.isNotBlank() } ?: return null
        return NodeExitPortrait(
            ip = resolvedIp,
            country = country?.takeIf { it.isNotBlank() } ?: unknownText,
            city = city?.takeIf { it.isNotBlank() } ?: unknownText,
            asn = asn?.toString() ?: unknownText,
            organization = asnOrganization?.takeIf { it.isNotBlank() }
                ?: organization?.takeIf { it.isNotBlank() }
                ?: unknownText,
            isp = isp?.takeIf { it.isNotBlank() } ?: unknownText
        )
    }
}

private data class NodeExitPortrait(
    val ip: String,
    val country: String,
    val city: String,
    val asn: String,
    val organization: String,
    val isp: String
)
