package com.kunk.singbox.foxy.vpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.InetSocketAddress
import java.net.Socket

/**
 * M39: FENIX/OpenVPN UI ping helper. Contract: 1500 ms TOTAL timeout
 * (withTimeoutOrNull bounds DNS + connect together), Int ms on success,
 * null on any failure or timeout. Unlike TcpPing, the socket is bound
 * and passed through ControlPlaneHttp.socketProtector so the probe
 * bypasses an active VPN tunnel instead of measuring through it.
 * TCP only: a UDP-only server shows no ping, is excluded from
 * "Fastest" by construction, and can still be selected by hand
 * (see OpenVpnViewModel.fastestCountry and the tab footnote).
 */
object PingUtil {
    private const val TIMEOUT_MS = 1_500

    suspend fun measureTcpLatencyMs(host: String, port: Int): Int? = withContext(Dispatchers.IO) {
        withTimeoutOrNull(TIMEOUT_MS.toLong()) {
            runCatching {
                val start = System.nanoTime()
                Socket().use { socket ->
                    socket.bind(InetSocketAddress(0))
                    com.kunk.singbox.foxy.data.ControlPlaneHttp.socketProtector?.invoke(socket)
                    socket.connect(InetSocketAddress(host, port), TIMEOUT_MS)
                }
                ((System.nanoTime() - start) / 1_000_000L).toInt()
            }.onFailure {
                com.kunk.singbox.foxy.data.AppLogger.d("PingUtil", "ping failed to $host:$port: ${it.message}")
            }.getOrNull()
        }
    }
}
