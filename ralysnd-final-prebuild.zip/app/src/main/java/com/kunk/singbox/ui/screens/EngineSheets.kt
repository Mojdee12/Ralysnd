package com.kunk.singbox.ui.screens

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kunk.singbox.engines.ENGINE_GRID
import com.kunk.singbox.engines.EngineId
import com.kunk.singbox.engines.EngineVpnState
import com.kunk.singbox.engines.EnginesViewModel
import com.kunk.singbox.engines.MasqueExitSelection
import com.kunk.singbox.ui.navigation.Screen
import java.util.Locale
import com.kunk.singbox.ui.theme.L4EngineTile
import com.kunk.singbox.ui.theme.L4Green
import com.kunk.singbox.ui.theme.L4GreenDark
import com.kunk.singbox.ui.theme.L4PastelCyan
import com.kunk.singbox.ui.theme.L4PastelSlate
import com.kunk.singbox.ui.theme.L4PastelViolet
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim

/**
 * Home engine grid (mlm-style, sample-4 light tiles) + per-engine
 * sheets. Only wanted engines appear here — no rejected engine has
 * a tile, placeholder, or reserved space. The grid is MASQUE,
 * WireGuard, FENIX, in that order.
 *
 * Wiring (honest):
 * - WireGuard -> Nodes screen (existing nodes).
 * - FENIX -> FENIX tab (existing Foxy tunnel).
 * - MASQUE -> exit-country screen: Ping every country over the
 *   gateway pool grouped by geolocated country, Fastest, Direct,
 *   and a live Connect button through the native QUIC core. There
 *   is no exit-mode switch: exit mode is determined by the
 *   gateway (the old IPv6 NAT64 / IPv4 proxy toggle changed
 *   nothing about the connection, so it was removed rather than
 *   left as a fake control). A CONNECT-IP-only gateway (like the
 *   WARP edge) rejects CONNECT-UDP: Connect is disabled for it
 *   with a plain reason line, never a fake connected state.
 */
@Composable
fun EngineGridSection(
    onNavigate: (String) -> Unit,
    onAddNode: (String) -> Unit,
    onOpenScanner: () -> Unit,
    enginesViewModel: EnginesViewModel = viewModel(),
) {
    var sheet by remember { mutableStateOf<EngineId?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Engines", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = L4Text)
            TextButton(onClick = onOpenScanner) { Text("Scanner", color = L4Green) }
        }
        for (row in ENGINE_GRID.chunked(2)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (engine in row) {
                    L4EngineTile(
                        title = engine.title,
                        subtitle = engine.statusNote,
                        pastel = when (engine.id) {
                            EngineId.MASQUE -> L4PastelCyan
                            EngineId.WIREGUARD -> L4PastelSlate
                            EngineId.FENIX -> L4PastelViolet
                        },
                        badge = engine.badge,
                        enabled = true,
                        onClick = {
                            when (engine.id) {
                                EngineId.WIREGUARD -> onNavigate(Screen.Nodes.route)
                                EngineId.FENIX -> onNavigate(Screen.Fenix.route)
                                else -> sheet = engine.id
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (row.size == 1) Spacer(modifier = Modifier.weight(1f))
            }
        }
    }

    when (sheet) {
        EngineId.MASQUE -> MasqueSheet(enginesViewModel = enginesViewModel, onDismiss = { sheet = null })
        else -> Unit
    }
}


/** Flag emoji for an ISO country code, computed from regional indicators — no hard-coded flag list. */
private fun flagForCountryCode(code: String): String {
    val upper = code.uppercase()
    if (upper.length != 2 || !upper.all { it in 'A'..'Z' }) return "🌍"
    return upper.map { char -> String(Character.toChars(0x1F1E6 + (char - 'A'))) }.joinToString("")
}

private fun countryNameForCode(code: String): String {
    return Locale("", code).displayCountry.takeIf { it.isNotBlank() } ?: code
}

@Composable
private fun MasqueSheet(
    enginesViewModel: EnginesViewModel,
    onDismiss: () -> Unit,
) {
    val countries by enginesViewModel.masqueCountries.collectAsStateWithLifecycle()
    val pinging by enginesViewModel.masquePinging.collectAsStateWithLifecycle()
    val masqueError by enginesViewModel.masqueError.collectAsStateWithLifecycle()
    val selection by enginesViewModel.masqueSelection.collectAsStateWithLifecycle()
    val fastest = enginesViewModel.masqueFastest
    val engineState by enginesViewModel.engineVpnState.collectAsStateWithLifecycle()
    var manual by remember { mutableStateOf("") }
    var showAdvanced by remember { mutableStateOf(false) }
    var pendingConnect by remember { mutableStateOf(false) }
    // A denied VPN-permission dialog used to swallow the tap
    // silently (pendingConnect just cleared, no message). It now
    // shows as a plain line above the button, with a retry tap.
    var permissionDenied by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingConnect) {
            permissionDenied = false
            enginesViewModel.connectMasque()
        } else if (pendingConnect) {
            permissionDenied = true
        }
        pendingConnect = false
    }
    // Zero input: ping the gateway pool as soon as the sheet opens.
    LaunchedEffect(Unit) {
        if (countries.isEmpty()) enginesViewModel.pingMasqueCountries()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("MASQUE — Exit country", color = L4Text) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                // No exit-mode switch here on purpose: the old
                // toggle changed nothing about the connection
                // (the core takes no exit-mode parameter), so it
                // was removed and replaced with this honest note.
                Text(
                    text = "Exit mode is determined by the gateway — the gateway chooses the exit route.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                Button(
                    onClick = { enginesViewModel.pingMasqueCountries() },
                    enabled = !pinging,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text(if (pinging) "Pinging…" else "Ping every country") }
                if (masqueError != null) Text(text = masqueError ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text(
                    text = "A short real connection to each gateway: ping, speed where measurable, and whether it works.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                when (val state = engineState) {
                    is EngineVpnState.Connecting -> if (state.engine == "MASQUE") {
                        Text(text = "Connecting…", style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                    }
                    is EngineVpnState.Connected -> if (state.engine == "MASQUE") {
                        Text(text = "Connected: ${state.detail}", style = MaterialTheme.typography.bodySmall, color = L4Text)
                    }
                    is EngineVpnState.Error -> if (state.engine == "MASQUE") {
                        Text(text = state.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                    else -> Unit
                }
                // The Connect button is always visible here, above
                // the country list and never behind Advanced. Its
                // label and route line always name what a tap will
                // actually dial — the SAME resolution connectMasque()
                // uses, computed from the collected countries and
                // selection, so a Canada row tap can never dial a
                // different gateway. Row taps below only SELECT;
                // only this button connects.
                val isMasqueConnected = engineState is EngineVpnState.Connected &&
                    (engineState as EngineVpnState.Connected).engine == "MASQUE"
                val isMasqueConnecting = engineState is EngineVpnState.Connecting &&
                    (engineState as EngineVpnState.Connecting).engine == "MASQUE"
                val resolvedGateway = enginesViewModel.resolveMasqueGateway(countries, selection)
                val selectionLabel = when (selection) {
                    is MasqueExitSelection.Country -> countries.firstOrNull { it.code == selection.code }?.name
                        ?: countryNameForCode(selection.code)
                    is MasqueExitSelection.Fastest -> "Fastest"
                    is MasqueExitSelection.Direct -> "Direct"
                }
                if (permissionDenied) {
                    Text(
                        text = "VPN permission was not granted — tap Connect MASQUE again to retry.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                if (resolvedGateway != null) {
                    Text(
                        text = "Selected: $selectionLabel · via $resolvedGateway",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                } else if (selection is MasqueExitSelection.Country) {
                    // A country whose only gateways reject
                    // CONNECT-UDP gets the plain incompatibility
                    // reason, not the generic "no gateway" line.
                    val selectedCountry = countries.firstOrNull { it.code == selection.code }
                    if (selectedCountry != null && selectedCountry.gateways.isNotEmpty() &&
                        selectedCountry.gateways.all { enginesViewModel.isMasqueGatewayIncompatible(it) }
                    ) {
                        Text(
                            text = "This gateway rejects CONNECT-UDP — add a CONNECT-UDP gateway",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    } else {
                        Text(
                            text = "No gateway measured yet for $selectionLabel — tap Ping every country first, then Connect.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                    }
                } else {
                    // Direct/Fastest resolve to null only when no
                    // CONNECT-UDP-compatible gateway exists: the
                    // only fallback would have been the documented
                    // edge, which rejects CONNECT-UDP. Connect
                    // stays disabled (see enabled below) with
                    // this plain reason instead of silently
                    // dialling that edge.
                    Text(
                        text = "This gateway rejects CONNECT-UDP — add a CONNECT-UDP gateway",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
                Button(
                    onClick = {
                        if (isMasqueConnected) {
                            enginesViewModel.disconnectEngine()
                        } else {
                            val intent = enginesViewModel.vpnPermissionIntent()
                            if (intent != null) {
                                // Permission not yet granted: the
                                // launcher completes THIS tap —
                                // on RESULT_OK it calls
                                // connectMasque() itself, so the
                                // user never has to tap twice.
                                permissionDenied = false
                                pendingConnect = true
                                permissionLauncher.launch(intent)
                            } else {
                                enginesViewModel.connectMasque()
                            }
                        }
                    },
                    // Enabled whenever a compatible gateway exists
                    // for the selection (Direct/Fastest resolve via
                    // the cached winner only — never the documented
                    // edge, which rejects CONNECT-UDP; a country
                    // resolves via its own row or its persisted
                    // gateway). Disabled when no compatible gateway
                    // is known, and then the reason line above says
                    // why. While connecting it is disabled with a
                    // Connecting label (a second tap cannot start a
                    // duplicate service); while connected it becomes
                    // the Disconnect action, so it is never a dead
                    // button in any state.
                    enabled = isMasqueConnected || (!isMasqueConnecting && resolvedGateway != null),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isMasqueConnected) MaterialTheme.colorScheme.error else L4Green,
                    ),
                ) {
                    Text(
                        when {
                            isMasqueConnected -> "Disconnect MASQUE"
                            isMasqueConnecting -> "Connecting…"
                            else -> "Connect MASQUE · $selectionLabel"
                        },
                    )
                }
                MasqueExitRow(
                    title = "Direct connection",
                    subtitle = "No country change, and the fastest route. Filtered sites open without a MASQUE exit.",
                    selected = selection is MasqueExitSelection.Direct,
                    onClick = { enginesViewModel.selectMasqueExit(MasqueExitSelection.Direct) },
                )
                MasqueExitRow(
                    title = "Fastest country",
                    subtitle = fastest?.let { "${flagForCountryCode(it.code)} ${it.name} · ${it.bestRttMs} ms" }
                        ?: "Automatic: the country that was fastest in the last ping.",
                    selected = selection is MasqueExitSelection.Fastest,
                    onClick = { enginesViewModel.selectMasqueExit(MasqueExitSelection.Fastest) },
                )
                Text(text = "Countries", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = L4Text)
                if (countries.isEmpty() && !pinging) {
                    Text(
                        text = "No gateways measured yet — tap Ping every country, or add a gateway below in Advanced.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                }
                for (country in countries) {
                    MasqueExitRow(
                        title = "${flagForCountryCode(country.code)} ${country.name}",
                        subtitle = "${country.serverCount} gateways · " +
                            if (country.reachable) {
                                "${country.bestRttMs} ms" + (country.speedKBps?.let { " · ${it.toInt()} KB/s" } ?: "")
                            } else {
                                // Rows only exist after a ping run, so a
                                // non-reachable row was tested and failed.
                                "unreachable"
                            },
                        selected = selection is MasqueExitSelection.Country &&
                            (selection as MasqueExitSelection.Country).code == country.code,
                        onClick = { enginesViewModel.selectMasqueExit(MasqueExitSelection.Country(country.code)) },
                    )
                }
                Text(
                    text = "Connect runs the native MASQUE core (QUIC + HTTP/3 CONNECT-UDP) to the selected gateway and routes the device through it. A gateway that only speaks CONNECT-IP (like the WARP edge, which authenticates as a WARP client) rejects the request — its exact error is shown above, never a fake connected state. Countries shown are geolocated gateways from the pool (cached winner, your endpoints, and one documented public Cloudflare edge), never an assumed list.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                TextButton(onClick = { showAdvanced = !showAdvanced }) {
                    Text(if (showAdvanced) "Hide advanced" else "Advanced", color = L4Green)
                }
                if (showAdvanced) {
                    OutlinedTextField(value = manual, onValueChange = { manual = it }, label = { Text("Gateway endpoint (host or host:port)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    // M17/M18 (dead-button guard only; MASQUE sheet
                    // logic untouched): disabled while the field is
                    // blank — never a silent no-op on tap.
                    TextButton(
                        onClick = {
                            enginesViewModel.setMasqueManualEndpoint(manual)
                            enginesViewModel.pingMasqueCountries()
                            manual = ""
                        },
                        enabled = manual.isNotBlank()
                    ) { Text("Add gateway and ping", color = L4Green) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun MasqueExitRow(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    // Tapping anywhere on the row only SELECTS the country — it
    // never connects. Only the Connect MASQUE button connects.
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().clickable { onClick() },
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = L4Text)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = L4TextDim)
        }
        if (selected) {
            Text(text = "✓", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = L4GreenDark)
        }
        TextButton(onClick = onClick) { Text(if (selected) "Selected" else "Select", color = L4Green) }
    }
}

