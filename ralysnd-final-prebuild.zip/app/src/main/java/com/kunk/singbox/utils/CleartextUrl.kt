package com.kunk.singbox.utils

/**
 * M31/M33: cleartext (http://) detection shared by every place a URL
 * enters the app (manual subscription input, deep-link import, QR-scan
 * import, remote rule-set editor). Cleartext URLs are never silently
 * upgraded and never silently fetched: callers show the
 * profiles_cleartext_warning and require explicit confirmation first.
 * The manifest still allows cleartext only narrowly: local proxy /
 * loopback traffic (127.0.0.1) plus user-confirmed http fetches.
 * All built-in services (geo lookup, diagnostics, update checks)
 * use HTTPS.
 */
object CleartextUrl {
    fun isCleartext(url: String): Boolean =
        url.trim().startsWith("http://", ignoreCase = true)
}
