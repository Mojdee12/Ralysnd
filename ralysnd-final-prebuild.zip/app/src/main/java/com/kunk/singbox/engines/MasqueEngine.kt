package com.kunk.singbox.engines

import android.content.Context
import com.tencent.mmkv.MMKV
import com.kunk.singbox.utils.TcpPing
import java.net.InetAddress
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * MASQUE engine — configuration, gateway discovery, and winner cache.
 *
 * What is real here: the config model (transport, TLS profile,
 * fragmentation, MTU 1304), live TCP reachability probing of
 * candidate gateways (user-supplied, previously cached, or the one
 * documented public edge), fastest-first ordering, and a cached
 * winner reused on the next connect attempt.
 *
 * Live data plane: see MasqueCore (Rust, quiche-based, in
 * app/src/main/rust/masque-core) + EngineVpnService. The core is
 * a generic CONNECT-UDP client: it connects to generic
 * CONNECT-UDP gateways (cached winner, user-added endpoints) and
 * routes the device through them. A CONNECT-IP-only gateway (e.g.
 * the WARP MASQUE edge, which authenticates as a WARP client)
 * rejects CONNECT-UDP, and that rejection is surfaced verbatim —
 * never faked as connected. There is no documented public
 * CONNECT-UDP gateway to ship as a default, so the default edge
 * is the WARP edge and a tap on Connect with no other gateway
 * will show that rejection honestly; a user-added CONNECT-UDP
 * gateway connects for real.
 *
 * No gateway list is invented: candidates come only from the
 * user's manual endpoint, from a previously cached winner, or
 * from one publicly documented Cloudflare WARP MASQUE edge
 * (anycast) used as a discovery candidate. A country shown for a
 * gateway is the geolocated country of the edge actually serving
 * the user, never an assumed exit country. The pool is small by
 * design (usually one edge) — the country list renders what was
 * actually measured, not a multi-country list the app does not have.
 */
enum class MasqueTransport { AUTO_H3_THEN_H2, HTTP3, HTTP2, SPLIT_HTTP2 }
enum class MasqueTlsProfile { CHROME, COMPAT }

data class MasqueConfig(
    val transport: MasqueTransport = MasqueTransport.AUTO_H3_THEN_H2,
    val tlsProfile: MasqueTlsProfile = MasqueTlsProfile.CHROME,
    val fragmentH2: Boolean = true,
    val mtu: Int = 1304,
    /** host:port of the discovered gateway, null until discovery runs. */
    val endpoint: String? = null,
)

data class GatewayProbe(
    val endpoint: String,
    /** TCP connect RTT in ms, or -1 when unreachable. Never invented. */
    val rttMs: Long,
    val reachable: Boolean,
)

/** One exit country row: real gateways, real measured ping. */
data class MasqueExitCountry(
    /**
     * ISO country code for a geolocated row, or "unknown:<host>" when
     * geolocation failed (M9: never a shared "??" row — unlike gateways
     * must never be grouped under one fake country, and the key stays
     * unique per gateway so a tap dials exactly that gateway).
     */
    val code: String,
    val name: String,
    /** Gateway endpoints (host or host:port) in this country. */
    val gateways: List<String>,
    /** Best (lowest) measured TCP RTT in ms, null when none reachable. */
    val bestRttMs: Long?,
    val reachable: Boolean,
    /**
     * Best-effort measured download speed in KB/s, null when
     * unmeasured. Named KBps (not Kbps): the value is kilobytes per
     * second (bytes/1024/elapsed), and the sheet renders "KB/s".
     */
    val speedKBps: Double?,
) {
    val serverCount: Int
        get() = gateways.size
}

/** How the user wants MASQUE to exit: direct, fastest, or a country. */
sealed class MasqueExitSelection {
    data object Direct : MasqueExitSelection()
    data object Fastest : MasqueExitSelection()
    data class Country(val code: String) : MasqueExitSelection()
}

class MasqueEngine(context: Context) {
    private val kv = MMKV.mmkvWithID("ralysnd_masque", MMKV.SINGLE_PROCESS_MODE)

    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    /** Stored exit selection (Direct by default — fastest route). */
    var exitSelection: MasqueExitSelection
        get() = when (val raw = kv.decodeString("exit_selection", "") ?: "") {
            "fastest" -> MasqueExitSelection.Fastest
            else -> if (raw.startsWith("country:")) {
                MasqueExitSelection.Country(raw.removePrefix("country:"))
            } else {
                MasqueExitSelection.Direct
            }
        }
        set(value) {
            kv.encode(
                "exit_selection",
                when (value) {
                    MasqueExitSelection.Direct -> "direct"
                    MasqueExitSelection.Fastest -> "fastest"
                    is MasqueExitSelection.Country -> "country:${value.code}"
                },
            )
        }

    /**
     * Gateway pool: the cached winner, user-added endpoints, and
     * one publicly documented Cloudflare WARP MASQUE endpoint
     * (anycast, from public client documentation — not any other
     * app's data). No other gateway is invented: a pool entry is
     * only ever a winner, a user entry, or this documented edge.
     * The edge's country is the edge actually serving the user,
     * resolved by geolocation at ping time — never assumed.
     */
    fun candidateGateways(): List<String> {
        val stored = kv.decodeString("candidates", "")
            ?.split("\n")
            ?.map { it.trim() }
            ?.filter { it.isNotBlank() }
            .orEmpty()
        val pool = mutableListOf<String>()
        cachedWinner?.let { pool.add(it) }
        pool.addAll(stored)
        pool.add(DOCUMENTED_MASQUE_EDGE)
        return pool.distinct()
    }

    fun addCandidate(endpoint: String) {
        val trimmed = endpoint.trim()
        if (trimmed.isBlank()) return
        val current = candidateGateways().toMutableList()
        if (trimmed !in current) {
            kv.encode("candidates", (current + trimmed).joinToString("\n"))
        }
    }

    /**
     * Geolocates a gateway host via the free ip-api service (no
     * key, already used elsewhere in this project family). Returns
     * code + country name, cached per host for 7 days (M9: the old
     * never-expiring cache could pin a moved anycast edge to a
     * stale country forever; legacy timestamp-less entries are
     * treated as expired and re-fetched once). Best-effort: null
     * on any failure, and callers fall back to the host itself.
     * M32: HTTPS, never HTTP — the queried gateway IPs must not
     * leak in cleartext or be spoofable by a network attacker.
     */
    suspend fun geoCountryFor(host: String): Pair<String, String>? = withContext(Dispatchers.IO) {
        val cached = kv.decodeString("geo_$host", "")
        if (!cached.isNullOrBlank()) {
            val parts = cached.split("|", limit = 3)
            if (parts.size == 3) {
                val savedAt = parts[2].toLongOrNull() ?: 0L
                if (System.currentTimeMillis() - savedAt < GEO_CACHE_TTL_MS) {
                    return@withContext parts[0] to parts[1]
                }
            }
            // Legacy 2-part entry or expired entry: fall through and re-fetch.
        }
        try {
            val ip = if (IP_LIKE.matches(host)) host else InetAddress.getByName(host).hostAddress ?: return@withContext null
            val request = Request.Builder()
                .url("https://ip-api.com/json/$ip?fields=status,country,countryCode")
                .build()
            val text = http.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext null
                response.body?.string().orEmpty()
            }
            val json = JSONObject(text)
            if (json.optString("status") != "success") return@withContext null
            val code = json.optString("countryCode").takeIf { it.isNotBlank() } ?: return@withContext null
            val name = json.optString("country").takeIf { it.isNotBlank() } ?: code
            kv.encode("geo_$host", "$code|$name|${System.currentTimeMillis()}")
            code to name
        } catch (_: Exception) {
            null
        }
    }

    /**
     * "Ping every country": a short real connection to each pool
     * gateway (TCP connect RTT), grouped by geolocated country,
     * fastest-first, with a best-effort real speed sample (a small
     * capped HTTPS fetch, KB/s) where the gateway answers one.
     * Nothing is invented: unreachable gateways report unreachable,
     * and speed stays null when it could not be measured.
     */
    suspend fun pingExitCountries(): List<MasqueExitCountry> = withContext(Dispatchers.IO) {
        val probed = candidateGateways().map { endpoint ->
            val (host, port) = parseHostPort(endpoint)
            val rtt = if (host.isBlank()) -1L else TcpPing.connect(host, port, timeout = 3000)
            val geo = if (host.isNotBlank()) geoCountryFor(host) else null
            ProbedGateway(endpoint, host, rtt, geo)
        }
        // M9: gateways whose country could not be determined are NOT
        // grouped under one shared "??" row — each gets its own row
        // keyed "unknown:<host>" (name = host, globe flag in the sheet),
        // so selecting it dials exactly that gateway, never another
        // edge's gateway that merely shared the fake row.
        val grouped = probed.groupBy { it.geo?.first ?: "unknown:${it.host}" }
        val countries = grouped.map { (code, gateways) ->
            // Gateways inside one country, fastest TCP RTT first
            // (unreachable last), so gateways.first() is that
            // country's fastest measured gateway — the one a tap
            // on Connect must dial for this country.
            val sorted = gateways.sortedWith(
                compareBy<ProbedGateway> { it.rtt < 0 }.thenBy { if (it.rtt < 0) Long.MAX_VALUE else it.rtt },
            )
            val name = sorted.firstNotNullOfOrNull { it.geo?.second } ?: sorted.first().host
            val reachable = sorted.filter { it.rtt >= 0 }
            val bestRtt = reachable.minOfOrNull { it.rtt }
            var speed: Double? = null
            if (bestRtt != null) {
                val fastest = reachable.minByOrNull { it.rtt }!!
                speed = measureSpeedKBps(fastest.host)
            }
            // Persist this country's fastest reachable gateway so
            // a country selection survives a process restart: the
            // ViewModel resolves a selected country to this gateway
            // even when the in-memory ping list is still empty.
            // Blank when nothing in the country was reachable, so a
            // stale gateway is never reused for a dead country.
            kv.encode(
                "country_gateway_$code",
                reachable.minByOrNull { it.rtt }?.endpoint ?: "",
            )
            MasqueExitCountry(
                code = code,
                name = name,
                gateways = sorted.map { it.endpoint },
                bestRttMs = bestRtt,
                reachable = reachable.isNotEmpty(),
                speedKBps = speed,
            )
        }
        countries.sortedWith(
            compareBy<MasqueExitCountry> { !it.reachable }
                .thenBy { it.bestRttMs ?: Long.MAX_VALUE },
        )
    }

    /** Fastest reachable country from the last ping, if any. */
    fun fastestCountry(countries: List<MasqueExitCountry>): MasqueExitCountry? =
        countries.firstOrNull { it.reachable }

    private data class ProbedGateway(
        val endpoint: String,
        val host: String,
        val rtt: Long,
        val geo: Pair<String, String>?,
    )

    /** Small capped HTTPS fetch; returns KB/s (bytes/1024/elapsed seconds). */
    private suspend fun measureSpeedKBps(host: String): Double? = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url("https://$host/").header("User-Agent", "Ralysnd").build()
            val start = System.nanoTime()
            http.newCall(request).execute().use { response ->
                val body = response.body ?: return@withContext null
                val bytes = body.byteStream().use { stream ->
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (total < 65536) {
                        val read = stream.read(buffer)
                        if (read < 0) break
                        total += read
                    }
                    total
                }
                val elapsedMs = (System.nanoTime() - start) / 1_000_000.0
                if (elapsedMs <= 0 || bytes <= 0) return@withContext null
                bytes / 1024.0 / (elapsedMs / 1000.0)
            }
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        /** Geo-cache lifetime: country lookups refresh weekly (M9). */
        const val GEO_CACHE_TTL_MS: Long = 7L * 24 * 60 * 60 * 1000
        /** Publicly documented Cloudflare WARP MASQUE edge (anycast). */
        const val DOCUMENTED_MASQUE_EDGE = "162.159.198.1:443"
        private val IP_LIKE = Regex("^[0-9.]+$")

        /**
         * True when an endpoint is a gateway known to reject
         * CONNECT-UDP: the documented WARP edge speaks CONNECT-IP
         * only, so this core (a CONNECT-UDP client) can never use
         * it. The sheet disables Connect for such a gateway and
         * the resolver never falls back to it. A bare host form
         * of the same edge (no port, default 443) counts too; any
         * other host or port is not blocked on this evidence.
         */
        fun isConnectUdpIncompatible(endpoint: String): Boolean {
            val (host, port) = parseHostPort(endpoint)
            return host == "162.159.198.1" && port == 443
        }

        fun parseHostPort(raw: String): Pair<String, Int> {
            val trimmed = raw.trim()
            val lastColon = trimmed.lastIndexOf(':')
            if (lastColon > 0) {
                val port = trimmed.substring(lastColon + 1).toIntOrNull()
                if (port != null) return trimmed.substring(0, lastColon) to port
            }
            return trimmed to 443
        }
    }

    var config: MasqueConfig
        get() {
            val endpoint = kv.decodeString("winner_endpoint", "")?.takeIf { it.isNotBlank() }
            return MasqueConfig(endpoint = endpoint)
        }
        private set(value) {
            if (value.endpoint != null) kv.encode("winner_endpoint", value.endpoint)
        }

    /** Cached discovery winner, if any. */
    val cachedWinner: String?
        get() = kv.decodeString("winner_endpoint", "")?.takeIf { it.isNotBlank() }

    /**
     * Gateway persisted for a country code at the last ping (its
     * fastest reachable gateway then), or null when the country
     * was never measured reachable. Used to resolve a persisted
     * country selection after a process restart, before the next
     * ping list exists.
     */
    fun gatewayForCountry(code: String): String? =
        kv.decodeString("country_gateway_$code", "")?.takeIf { it.isNotBlank() }

    val cachedWinnerRttMs: Long
        get() = kv.decodeLong("winner_rtt", -1L)

    /**
     * Probes each candidate (host or host:port, default port 443)
     * with a real TCP connect and returns results fastest-first
     * (unreachable last). The winner is cached for the next attempt.
     * Emits live: callers should collect [EngineScanner.scan] instead
     * for streaming; this is the one-shot variant.
     */
    suspend fun probeCandidates(candidates: List<String>): List<GatewayProbe> {
        val results = candidates.map { raw ->
            val (host, port) = parseHostPort(raw)
            val rtt = if (host.isBlank()) -1L else TcpPing.connect(host, port, timeout = 3000)
            GatewayProbe(endpoint = raw, rttMs = rtt, reachable = rtt >= 0)
        }
        val sorted = results.sortedWith(
            compareBy<GatewayProbe> { !it.reachable }.thenBy { if (it.rttMs < 0) Long.MAX_VALUE else it.rttMs },
        )
        sorted.firstOrNull { it.reachable }?.let { winner ->
            kv.encode("winner_endpoint", winner.endpoint)
            kv.encode("winner_rtt", winner.rttMs)
            config = config.copy(endpoint = winner.endpoint)
        }
        return sorted
    }

    fun setManualEndpoint(endpoint: String) {
        val trimmed = endpoint.trim()
        if (trimmed.isNotBlank()) {
            kv.encode("winner_endpoint", trimmed)
            kv.encode("winner_rtt", -1L)
            config = config.copy(endpoint = trimmed)
        }
    }
}
