package com.kunk.singbox.ui.theme

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min

/**
 * DORMANT — DO NOT USE (audit m5, 2026-10-27). This file's five
 * composables (V2GlassCard, V2CodeBadge, V2UsageRing,
 * V2CountryCard, V2CenterConnectButton) and its V2* dark palette
 * have ZERO callers anywhere in the app: the live UI is the
 * sample-4 light theme (RalysndLightDesign.kt), and Theme.kt
 * always renders the light scheme. This file is kept only as a
 * reference for the approved center-connect mockup look. Do NOT
 * revive these components into a light screen without reworking
 * their dark surfaces — pasting dark v2 surfaces under
 * light-theme text is exactly what caused the unreadable
 * dark-on-dark text fixed in the theme-contrast pass. If the dark
 * look is ever wanted again, re-derive it from this file as a
 * whole theme, never component-by-component. Delete this file
 * outright if the reference is no longer wanted; nothing breaks.
 *
 * RALYSND CENTER-CONNECT DESIGN SYSTEM — approved center-connect mockups
 * (main + Foxy). The whole app must look like those mockups.
 *
 * Deep navy-black background (#070B12), cyan primary + amber secondary.
 * Layout vocabulary: big bold RALYSND headline, a LARGE CENTERED connect
 * button (thin cyan-to-amber gradient ring, power icon, CONNECT /
 * DISCONNECT label + status line below it) as the hero of both connect
 * screens, a large circular usage ring, a HORIZONTAL carousel of country
 * cards, an accounts strip, and a floating pill bottom bar. There is NO
 * bottom-corner / bottom-right connect button anywhere in this system:
 * the previous v2 floating corner button was the exact thing the user
 * rejected, and it has been removed.
 *
 * Presentation only: no navigation, ViewModel, protocol, database, or
 * permission logic lives here, and no sample data is produced here.
 * Every card renders only the real values its caller passes in; the
 * usage ring shows an explicit empty state when there is no data.
 * NO profile pictures, NO avatar images anywhere in this file:
 * countries are identified by flag emoji text + country-code text
 * badge, accounts by email text only.
 */

/** v2 palette. */
val V2Background = Color(0xFF070B12)
val V2Surface = Color(0xFF0E1626)
val V2SurfaceAlt = Color(0xFF13203A)
val V2Outline = Color(0xFF22314F)
val V2Cyan = Color(0xFF22D3EE)
val V2CyanDim = Color(0xFF0E7490)
val V2Amber = Color(0xFFF59E0B)
val V2Text = Color(0xFFFFFFFF)
val V2TextDim = Color(0xFF94A3B8)

/** v2 glass card: navy surface, thin outline, 20dp corners, cyan when selected. */
@Composable
fun V2GlassCard(
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(20.dp)
    val borderColor = if (selected) V2Cyan else V2Outline
    val borderWidth = if (selected) 1.5.dp else 1.dp
    val clickModifier = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    Box(
        modifier = modifier
            .clip(shape)
            .background(V2Surface, shape)
            .border(borderWidth, borderColor, shape)
            .then(clickModifier)
            .animateContentSize(),
    ) {
        Column(modifier = Modifier.fillMaxWidth(), content = content)
    }
}

/** Small text badge showing a country code (e.g. DE) — text only, never an image. */
@Composable
fun V2CodeBadge(code: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(V2SurfaceAlt)
            .border(1.dp, V2Outline, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = code.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
            color = V2Cyan,
        )
    }
}

/**
 * Large circular usage ring. [progress] is 0f..1f (used / total).
 * When [hasData] is false, the ring is empty and the center shows the
 * empty-state text instead of any invented percentage.
 */
@Composable
fun V2UsageRing(
    progress: Float,
    centerTop: String,
    centerBottom: String,
    modifier: Modifier = Modifier,
) {
    val clamped = progress.coerceIn(0f, 1f)
    Box(modifier = modifier.size(180.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(180.dp)) {
            val stroke = 14.dp.toPx()
            val diameter = min(size.width, size.height) - stroke
            val topLeft = Offset(stroke / 2f, stroke / 2f)
            drawArc(
                color = V2Outline,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = Size(diameter, diameter),
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
            if (clamped > 0f) {
                drawArc(
                    color = V2Cyan,
                    startAngle = -90f,
                    sweepAngle = 360f * clamped,
                    useCenter = false,
                    topLeft = topLeft,
                    size = Size(diameter, diameter),
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = centerTop,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                color = V2Text,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = centerBottom,
                style = MaterialTheme.typography.bodySmall,
                color = V2TextDim,
            )
        }
    }
}

/**
 * One country card for the horizontal carousel.
 * Layout (exact, per the approved center-connect mockups): flag
 * (emoji text) + country-code text badge on the top row, country name
 * below, the PING BELOW the country name in large, clearly visible
 * text, live-updating as results arrive, and the VOLUME BELOW the ping
 * when the caller supplies one. No corner-only ping badge.
 * [pingText] is the caller-supplied live value ("123 ms", "pinging…",
 * or "—" when unmeasured) — never invented here. [volumeText] is the
 * caller-supplied real remaining volume (e.g. a "Remaining: …" line);
 * null means no volume data exists for this country, and then no
 * volume line is rendered at all — never a fake number.
 */
@Composable
fun V2CountryCard(
    flag: String,
    countryCode: String,
    countryName: String,
    pingText: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    volumeText: String? = null,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "v2CountryCardScale",
    )
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = modifier
            .width(168.dp)
            // compose-performance (deferring-state-reads): the press
            // scale is read in the Draw phase via graphicsLayer, so the
            // card subtree does not recompose on every animation frame.
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(V2Surface, shape)
            .border(if (selected) 1.5.dp else 1.dp, if (selected) V2Cyan else V2Outline, shape)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .animateContentSize(),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = flag, fontSize = 26.sp)
                Spacer(modifier = Modifier.width(8.dp))
                V2CodeBadge(code = countryCode)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = countryName,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = V2Text,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = pingText,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = if (selected) V2Cyan else V2Amber,
            )
            Text(
                text = "ping",
                style = MaterialTheme.typography.labelSmall,
                color = V2TextDim,
            )
            if (volumeText != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = volumeText,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = V2Amber,
                )
            }
        }
    }
}

/**
 * CENTER connect button — the hero control of both connect screens
 * (Dashboard and Foxy), exactly as in the approved center-connect
 * mockups. 216dp circle, dark inner disc, thin 2dp cyan-to-amber
 * gradient ring, Canvas-drawn power icon, CONNECT / DISCONNECT label
 * and status line below it. One tap target (the whole column), spring
 * press-scale, far above the 48dp minimum. This REPLACES the old
 * bottom-right floating power button: no caller may place this at a
 * screen corner.
 */
@Composable
fun V2CenterConnectButton(
    isRunning: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "v2CenterConnectScale",
    )
    val label = if (isRunning) "DISCONNECT" else "CONNECT"
    val status = if (isRunning) "Connected" else "Not Connected"
    val iconColor = if (isRunning) V2Cyan else V2Text
    Column(
        modifier = modifier
            .semantics {
                contentDescription = label
                role = Role.Button
            }
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(216.dp)
                // compose-performance (deferring-state-reads): Draw-phase
                // scale read, so pressing the button never recomposes
                // the whole screen on every animation frame.
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .clip(CircleShape)
                .background(V2Background, CircleShape)
                .border(
                    width = 2.dp,
                    brush = Brush.sweepGradient(colors = listOf(V2Cyan, V2Amber, V2Cyan)),
                    shape = CircleShape,
                ),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(modifier = Modifier.size(72.dp)) {
                val stroke = 7.dp.toPx()
                val radius = (size.minDimension - stroke) / 2f
                val center = Offset(size.width / 2f, size.height / 2f)
                drawArc(
                    color = iconColor,
                    startAngle = 300f,
                    sweepAngle = 300f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = Size(radius * 2f, radius * 2f),
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
                drawLine(
                    color = iconColor,
                    start = Offset(center.x, center.y - radius),
                    end = Offset(center.x, center.y - radius * 0.15f),
                    strokeWidth = stroke,
                    cap = StrokeCap.Round,
                )
            }
        }
        Spacer(modifier = Modifier.height(28.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Medium, letterSpacing = 6.sp),
            color = V2Text,
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = status,
            style = MaterialTheme.typography.bodyMedium,
            color = if (isRunning) V2Cyan else V2TextDim,
        )
    }
}
