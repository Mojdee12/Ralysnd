package com.kunk.singbox.ui.screens

import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.kunk.singbox.model.ConnectionState
import com.kunk.singbox.openvpn.OpenVpnViewModel
import com.kunk.singbox.openvpn.countryNameForCode
import com.kunk.singbox.openvpn.flagForCountryCode
import com.kunk.singbox.ui.theme.L4Amber
import com.kunk.singbox.ui.theme.L4Background
import com.kunk.singbox.ui.theme.L4CenterConnectButton
import com.kunk.singbox.ui.theme.L4CountryCard
import com.kunk.singbox.ui.theme.L4GlassCard
import com.kunk.singbox.ui.theme.L4Green
import com.kunk.singbox.ui.theme.L4Surface
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim
import com.kunk.singbox.viewmodel.DashboardViewModel

/**
 * OpenVPN bottom-tab screen — the FENIX tab's shape, for TunnelBear:
 * big bold RALYSND headline at top, a CENTER connect button in the
 * normal flow (only when signed in), an account area on top (email
 * TEXT ONLY — never a profile photo — with Sign out, or a login
 * card with username + password when not signed in), and a
 * HORIZONTAL carousel of country cards. Each card shows its flag
 * (emoji text) + country-code badge, the country name, and its
 * PING BELOW the country name in large text, live-updating as ping
 * results arrive. Ping all is a prominent primary action; Fastest
 * picks the lowest measured ping. Same as FENIX, tapping a country
 * row only SELECTS it — only the center button connects.
 *
 * Honest labels (see TunnelBearServers.kt): only AU's full profile
 * is published; the other seven hostnames are documented but their
 * port/proto follow the AU pattern, and a footnote says so. Ping
 * is a TCP reachability probe: a server that answers only UDP
 * shows no ping and can still be connected; connect reports its
 * own real result. Sign-in only SAVES the credentials securely —
 * they are verified by the first connect attempt.
 *
 * Footer credit (ics-openvpn GPLv2): "OpenVPN core: ics-openvpn
 * (GPLv2) by Arne Schwabe" — no mlm code or data is used here.
 */
@Composable
fun OpenVpnScreen(
    navController: NavController,
    viewModel: OpenVpnViewModel = viewModel(),
    dashboardViewModel: DashboardViewModel = viewModel(),
    // m4: shared bottom padding from AppNavigation (same value the
    // other top-level screens get) — replaces the hardcoded 96dp.
    bottomContentPadding: Dp = 0.dp,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val connectionState by dashboardViewModel.connectionState.collectAsStateWithLifecycle()
    var pendingOpenVpnConnect by remember { mutableStateOf(false) }
    var permissionDenied by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingOpenVpnConnect) {
            pendingOpenVpnConnect = false
            permissionDenied = false
            viewModel.connectSelected(context, dashboardViewModel)
        } else {
            pendingOpenVpnConnect = false
            permissionDenied = true
        }
    }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    val openVpnRunning = state.connection == ConnectionState.Connected ||
        state.connection == ConnectionState.Connecting
    val isRunning = openVpnRunning ||
        connectionState == ConnectionState.Connected ||
        connectionState == ConnectionState.Connecting

    val onPowerClick: () -> Unit = {
        if (isRunning) {
            if (openVpnRunning) {
                viewModel.disconnect(context, dashboardViewModel)
            } else {
                dashboardViewModel.toggleConnection()
            }
        } else {
            val prepareIntent = VpnService.prepare(context)
            if (prepareIntent != null) {
                pendingOpenVpnConnect = true
                vpnPermissionLauncher.launch(prepareIntent)
            } else {
                viewModel.connectSelected(context, dashboardViewModel)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(L4Background),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
                .padding(bottom = bottomContentPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = "RALYSND",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp,
                ),
                color = L4Text,
            )
            Text(
                text = "OpenVPN — TunnelBear on your own account",
                style = MaterialTheme.typography.bodyMedium,
                color = L4TextDim,
            )

            // M21: also rendered while signed out when sing-box (or
            // OpenVPN itself) is running, so the running tunnel can be
            // stopped from here — the handler already covered that
            // branch, it was just unreachable.
            if (state.signedIn ||
                connectionState == ConnectionState.Connected ||
                connectionState == ConnectionState.Connecting ||
                openVpnRunning
            ) {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    L4CenterConnectButton(isRunning = isRunning, onClick = onPowerClick)
                }
            }

            // Account area on top: email text only, or the login card.
            if (state.signedIn) {
                Text(text = "TunnelBear Account", fontWeight = FontWeight.Bold, color = L4Text)
                L4GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = state.username.ifBlank { "TunnelBear account" },
                                fontWeight = FontWeight.SemiBold,
                                color = L4Text,
                            )
                            Text(
                                text = "Credentials stored securely on this device",
                                style = MaterialTheme.typography.bodySmall,
                                color = L4TextDim,
                            )
                        }
                        if (!openVpnRunning) {
                            TextButton(onClick = { viewModel.signOut(context, dashboardViewModel) }) {
                                Text(text = "Sign out", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
            AnimatedVisibility(visible = !state.signedIn) {
                L4GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = "Sign in with your TunnelBear account",
                            fontWeight = FontWeight.Bold,
                            color = L4Text,
                        )
                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("TunnelBear username (email)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        )
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        )
                        Button(
                            onClick = { viewModel.signIn(username, password) },
                            // M18: disabled while username/password are
                            // blank, like FENIX.
                            enabled = username.isNotBlank() && password.isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = L4Green, contentColor = L4Background),
                        ) { Text(text = "Sign in", fontWeight = FontWeight.Bold) }
                        Text(
                            text = "Sign-in only saves your credentials securely here; " +
                                "they are verified by the first connect attempt.",
                            style = MaterialTheme.typography.bodySmall,
                            color = L4TextDim,
                        )
                    }
                }
            }

            // Country panel: horizontal carousel, ping BELOW each country name.
            if (state.signedIn) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(text = "Countries", fontWeight = FontWeight.Bold, color = L4Text)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.pingAllCountries() },
                            enabled = !state.isPinging,
                            modifier = Modifier.height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = L4Green, contentColor = L4Background),
                        ) { Text(if (state.isPinging) "Pinging…" else "Ping all", fontWeight = FontWeight.Bold) }
                        Button(
                            onClick = {
                                val fastest = viewModel.fastestCountry()
                                if (fastest != null) viewModel.selectCountry(fastest)
                            },
                            // M17: disabled with a reason, never a silent
                            // no-op, while nothing has a ping yet.
                            enabled = viewModel.fastestCountry() != null,
                            modifier = Modifier.height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = L4Surface, contentColor = L4Amber),
                        ) { Text("Fastest") }
                    }
                }
                if (state.pingMs.isEmpty()) {
                    Text(
                        text = "Fastest is disabled until Ping all measures a country.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                }
                if (state.isPinging || state.isConnecting) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = L4Green)
                }
                state.selected?.let { selected ->
                    Text(
                        text = "Selected: ${countryNameForCode(selected.code)} (${selected.host}:${selected.port})",
                        style = MaterialTheme.typography.bodyMedium,
                        color = L4TextDim,
                    )
                }
                val sorted = remember(state.servers, state.pingMs) {
                    state.servers.sortedBy { server ->
                        state.pingMs[server.code] ?: Int.MAX_VALUE
                    }
                }
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(sorted, key = { it.code }, contentType = { "country" }) { server ->
                        val ping = state.pingMs[server.code]
                        val isSelected = state.selected?.code.equals(server.code, ignoreCase = true)
                        L4CountryCard(
                            flag = flagForCountryCode(server.code),
                            countryCode = server.code,
                            countryName = countryNameForCode(server.code),
                            pingText = when {
                                ping != null -> "$ping ms"
                                state.isPinging -> "pinging…"
                                else -> "—"
                            },
                            selected = isSelected,
                            onClick = { viewModel.selectCountry(server) },
                            modifier = Modifier.animateItem(),
                            // --- M28-UNVERIFIED-BADGE (delimited edit;
                            // padding work on this screen is separate) ---
                            // Only AU has portDocumented=true; every
                            // other country renders an UNVERIFIED badge
                            // so it is never identical to AU.
                            badge = if (!server.portDocumented) "UNVERIFIED" else null,
                            // --- END M28-UNVERIFIED-BADGE ---
                        )
                    }
                }
                // --- M28-UNVERIFIED-BADGE (delimited edit) ---
                Text(
                    text = "Ping is a TCP reachability probe only — it is not a UDP " +
                        "ping, and this tab does not claim one. A UDP-only server " +
                        "can still connect even with no ping, and connect reports " +
                        "its own real result. Only Australia (AU) is fully " +
                        "documented — its full profile is published. The other seven " +
                        "countries carry an UNVERIFIED badge on their cards: only their " +
                        "hostname is documented, and their port/protocol merely follow " +
                        "the AU profile pattern.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                // --- END M28-UNVERIFIED-BADGE ---
            }

            if (permissionDenied) {
                Text(
                    text = "VPN permission was not granted — tap the center button again to retry.",
                    color = MaterialTheme.colorScheme.error,
                )
            }
            state.message?.let {
                Text(text = it, color = MaterialTheme.colorScheme.error)
            }
            Text(
                text = "OpenVPN core: ics-openvpn (GPLv2) by Arne Schwabe",
                style = MaterialTheme.typography.bodySmall,
                color = L4TextDim,
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
