package com.kunk.singbox.openvpn

import android.content.Context
import java.io.InputStream

/**
 * TunnelBear server list — documented hostnames ONLY, never invented.
 *
 * Sourcing, stated exactly:
 * - AU (Australia), au.lazerpenguin.com:443 UDP, cipher AES-256-GCM,
 *   auth SHA256: from a published TunnelBear .ovpn example (dev.to,
 *   "OpenVPN configuration for Tunnelbear in Windows"), which quotes
 *   the profile verbatim: proto udp, remote au.lazerpenguin.com 443,
 *   cipher AES-256-GCM, auth SHA256, dhcp DNS 8.8.8.8 / 8.8.4.4,
 *   redirect-gateway, auth-user-pass, ca/cert/key files.
 * - JP / DK / BE / ES / PE / CH / AE hostnames (jp/dk/be/es/pe/ch/ae
 *   .lazerpenguin.com): from public IP-attribution pages that name
 *   the TunnelBear server in that city and list the matching
 *   <cc>.lazerpenguin.com hostname (Tokyo, Copenhagen, Brussels,
 *   Barcelona, Lima, Zurich, Dubai). For these, ONLY the hostname
 *   and country are documented: their port/proto follow the AU
 *   profile pattern (443 UDP) and are marked [portDocumented] =
 *   false. A country that does not answer on that port shows no
 *   ping and its connect attempt surfaces the core's real error —
 *   never a claimed working server.
 * - M28 UI MARKING (no hostnames changed here): every server with
 *   [portDocumented] = false is UNVERIFIED and must render with an
 *   UNVERIFIED badge on its country card (see OpenVpnScreen) plus
 *   the strengthened footnote — never rendered identical to AU,
 *   the only fully documented country.
 * - NO mlm data is used anywhere here: no server list, IP, or
 *   credential from any other app. The country codes are the
 *   standard ISO codes of the documented cities.
 *
 * Ping (FENIX pattern): a TCP reachability probe to host:443 via
 * PingUtil (same helper FENIX uses). A server that answers only
 * UDP shows no ping — that row sorts last, is never the Fastest
 * pick, and can still be selected and connected; connect uses the
 * UDP profile and reports its own real result.
 *
 * Certificates: TunnelBear's published .ovpn bundle needs a CA
 * certificate plus a client certificate/key (CACertificate.crt,
 * UserCertificate.crt, PrivateKey.key in their official Linux
 * bundle). Those files are NOT shipped or invented here: the
 * builder inlines them from app assets ONLY if the build added
 * them (app/src/main/assets/tunnelbear/ — copy the three files
 * from TunnelBear's official openvpn.zip at build time). If they
 * are absent, [buildOvpnConfig] throws a plain error and the tab
 * shows it — connect is never attempted without them, and no
 * certificate is fabricated.
 */
data class TunnelBearServer(
    /** ISO country code, e.g. "AU". */
    val code: String,
    val host: String,
    val port: Int = 443,
    val useUdp: Boolean = true,
    /** True only for AU, whose full profile is published. */
    val portDocumented: Boolean = false,
)

val TUNNELBEAR_SERVERS: List<TunnelBearServer> = listOf(
    TunnelBearServer(code = "AU", host = "au.lazerpenguin.com", portDocumented = true),
    TunnelBearServer(code = "JP", host = "jp.lazerpenguin.com"),
    TunnelBearServer(code = "DK", host = "dk.lazerpenguin.com"),
    TunnelBearServer(code = "BE", host = "be.lazerpenguin.com"),
    TunnelBearServer(code = "ES", host = "es.lazerpenguin.com"),
    TunnelBearServer(code = "PE", host = "pe.lazerpenguin.com"),
    TunnelBearServer(code = "CH", host = "ch.lazerpenguin.com"),
    TunnelBearServer(code = "AE", host = "ae.lazerpenguin.com"),
)

/** Flag emoji for an ISO country code (regional indicators). */
fun flagForCountryCode(code: String): String {
    val upper = code.uppercase()
    if (upper.length != 2 || !upper.all { it in 'A'..'Z' }) return "🌍"
    return upper.map { char -> String(Character.toChars(0x1F1E6 + (char - 'A'))) }.joinToString("")
}

/** Display country name for an ISO code, falling back to the code. */
fun countryNameForCode(code: String): String {
    return java.util.Locale("", code).displayCountry.takeIf { it.isNotBlank() } ?: code
}

private fun readAssetText(context: Context, path: String): String? = runCatching {
    context.assets.open(path).use { stream: InputStream ->
        stream.bufferedReader().readText().takeIf { it.isNotBlank() }
    }
}.getOrNull()

/**
 * Builds a standard .ovpn profile for [server] from the published
 * AU profile's directives. Throws [IllegalStateException] with a
 * plain message when the TunnelBear certificate bundle is missing
 * from assets — callers surface that message verbatim.
 */
fun buildOvpnConfig(context: Context, server: TunnelBearServer): String {
    val ca = readAssetText(context, "tunnelbear/CACertificate.crt")
        ?: throw IllegalStateException(
            "TunnelBear certificate bundle is not included in this build: " +
                "add CACertificate.crt, UserCertificate.crt and PrivateKey.key " +
                "from TunnelBear's official OpenVPN files to app/src/main/assets/tunnelbear/",
        )
    val cert = readAssetText(context, "tunnelbear/UserCertificate.crt")
        ?: throw IllegalStateException("TunnelBear certificate bundle is incomplete: UserCertificate.crt is missing from assets/tunnelbear/")
    val key = readAssetText(context, "tunnelbear/PrivateKey.key")
        ?: throw IllegalStateException("TunnelBear certificate bundle is incomplete: PrivateKey.key is missing from assets/tunnelbear/")
    return buildString {
        appendLine("client")
        appendLine("dev tun")
        appendLine(if (server.useUdp) "proto udp" else "proto tcp-client")
        appendLine("remote ${server.host} ${server.port}")
        appendLine("resolv-retry infinite")
        appendLine("nobind")
        appendLine("persist-key")
        appendLine("persist-tun")
        appendLine("remote-cert-tls server")
        appendLine("cipher AES-256-GCM")
        appendLine("auth SHA256")
        appendLine("auth-user-pass")
        appendLine("redirect-gateway def1")
        appendLine("dhcp-option DNS 8.8.8.8")
        appendLine("dhcp-option DNS 8.8.4.4")
        appendLine("verb 3")
        appendLine("<ca>")
        appendLine(ca.trim())
        appendLine("</ca>")
        appendLine("<cert>")
        appendLine(cert.trim())
        appendLine("</cert>")
        appendLine("<key>")
        appendLine(key.trim())
        appendLine("</key>")
    }
}
