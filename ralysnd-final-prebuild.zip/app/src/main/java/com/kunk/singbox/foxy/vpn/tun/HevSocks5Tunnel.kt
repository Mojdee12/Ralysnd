package com.kunk.singbox.foxy.vpn.tun

import com.kunk.singbox.foxy.data.AppLogger

private const val TAG = "HevSocks5Tunnel"

/**
 * JNI bridge to hev-socks5-tunnel. The native library is NOT faked:
 * if libhev-socks5-tunnel.so is missing from the build, loading fails
 * here and [isAvailable] is false — callers then report a plain error
 * (FoxyVpnService errors "Failed to start the tun2socks tunnel", the
 * Engine path errors the same way) instead of the app crashing in
 * this object's init. Every native call is guarded the same way, so a
 * missing .so can never crash a caller that checks [isAvailable] or
 * the Boolean result of [start].
 */
object HevSocks5Tunnel {
    private external fun TProxyStartService(config_path: String, fd: Int): Boolean
    private external fun TProxyStopService(): Boolean
    private external fun TProxyIsRunning(): Boolean
    private external fun TProxyGetStats(): LongArray

    /** False when the native library could not be loaded (missing .so); never throws. */
    val isAvailable: Boolean

    init {
        var loaded = false
        runCatching { System.loadLibrary("hev-socks5-tunnel") }
            .onSuccess { loaded = true }
            .onFailure { AppLogger.e(TAG, "hev-socks5-tunnel native library is not in this build", it) }
        isAvailable = loaded
    }

    fun start(configPath: String, tunFd: Int): Boolean {
        if (!isAvailable) {
            AppLogger.w(TAG, "cannot start hev-socks5-tunnel: native library is not in this build")
            return false
        }
        return runCatching { TProxyStartService(configPath, tunFd) }
            .onFailure { AppLogger.e(TAG, "failed to start hev-socks5-tunnel", it) }
            .getOrDefault(false)
    }

    fun stop(): Boolean {
        if (!isAvailable) return false
        return runCatching { TProxyStopService() }
            .onFailure { AppLogger.w(TAG, "failed to stop hev-socks5-tunnel", it) }
            .getOrDefault(false)
    }

    fun isRunning(): Boolean {
        if (!isAvailable) return false
        return runCatching { TProxyIsRunning() }.getOrDefault(false)
    }

    fun stats(): LongArray {
        if (!isAvailable) return LongArray(4)
        return runCatching { TProxyGetStats() }.getOrDefault(LongArray(4))
    }
}
