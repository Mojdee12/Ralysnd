package com.kunk.singbox.openvpn

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kunk.singbox.foxy.vpn.FoxyVpnService
import com.kunk.singbox.foxy.vpn.PingUtil
import com.kunk.singbox.model.ConnectionState
import com.kunk.singbox.viewmodel.DashboardViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * OpenVPN tab state. Mirrors the FENIX tab's shape exactly:
 * account area on top, country list, ping below each country name.
 * No ping, server, or connected state is ever invented: pings come
 * from real TCP probes, "Connected" only from the system reporting
 * an active VPN transport while our launch is in progress, and
 * every failure is shown verbatim.
 */
data class OpenVpnUiState(
    val signedIn: Boolean = false,
    val username: String = "",
    val servers: List<TunnelBearServer> = TUNNELBEAR_SERVERS,
    val selected: TunnelBearServer? = null,
    val pingMs: Map<String, Int> = emptyMap(),
    val isPinging: Boolean = false,
    val isConnecting: Boolean = false,
    /** Idle / Connecting / Connected / Error — Error carries a real message, never a fake state. */
    val connection: ConnectionState = ConnectionState.Idle,
    /**
     * True when a VPN transport is active but it is NOT our TunnelBear
     * launch (C5): another engine is up, or our starter session is not
     * alive. Shown as "VPN active (unverified tunnel)", never as
     * "OpenVPN connected via TunnelBear".
     */
    val unverifiedVpnActive: Boolean = false,
    val message: String? = null,
)

class OpenVpnViewModel(application: Application) : AndroidViewModel(application) {
    private val accountStore = TunnelBearAccountStore(application)
    private val _uiState = MutableStateFlow(
        OpenVpnUiState(
            signedIn = accountStore.hasAccount,
            username = accountStore.username,
            selected = TUNNELBEAR_SERVERS.firstOrNull(),
        ),
    )
    val uiState: StateFlow<OpenVpnUiState> = _uiState.asStateFlow()

    private var monitorJob: Job? = null
    private var connectJob: Job? = null
    private var disconnectVerifyJob: Job? = null

    /** Saves the typed credentials securely (sign-in = save; verified by the first connect). */
    fun signIn(username: String, password: String) {
        if (username.isBlank() || password.isBlank()) {
            _uiState.update { it.copy(message = "Enter your TunnelBear username and password") }
            return
        }
        accountStore.save(username, password)
        _uiState.update {
            it.copy(signedIn = true, username = accountStore.username, message = null)
        }
    }

    /**
     * Removes stored credentials (M12). Never wipes credentials while
     * connected: an active tunnel is stopped first, and a tunnel still
     * connecting is refused with a plain message until it is stopped.
     */
    fun signOut(context: Context, dashboardViewModel: DashboardViewModel? = null) {
        val state = _uiState.value
        if (state.isConnecting || state.connection == ConnectionState.Connecting) {
            _uiState.update {
                it.copy(message = "Still connecting — disconnect first, then sign out")
            }
            return
        }
        if (state.connection == ConnectionState.Connected || state.unverifiedVpnActive) {
            // Stop (cancel + core stop) happens BEFORE the credential
            // wipe below; disconnect's bounded verification then
            // reports Idle/Error afterwards.
            disconnect(context, dashboardViewModel)
        }
        accountStore.clear()
        _uiState.update { it.copy(signedIn = false, username = "", message = null) }
    }

    fun selectCountry(server: TunnelBearServer) {
        _uiState.update { it.copy(selected = server, message = null) }
    }

    /**
     * Ping all countries — the FENIX pattern exactly: loop countries,
     * probe the first (only) server per country with PingUtil's TCP
     * probe, publish each result LIVE as it arrives. Unpinged
     * countries keep no entry and sort last; nothing is invented.
     */
    fun pingAllCountries() {
        if (_uiState.value.isPinging) return
        viewModelScope.launch {
            _uiState.update { it.copy(isPinging = true, message = null) }
            try {
                withContext(Dispatchers.IO) {
                    for (server in _uiState.value.servers) {
                        val ms = PingUtil.measureTcpLatencyMs(server.host, server.port)
                        if (ms != null) {
                            _uiState.update { state ->
                                state.copy(pingMs = state.pingMs + (server.code to ms))
                            }
                        }
                    }
                }
            } finally {
                _uiState.update { it.copy(isPinging = false) }
            }
        }
    }

    /**
     * Fastest measured country, null when nothing has a ping (same rule
     * as FENIX). Unpinged countries are EXCLUDED by construction: only
     * codes present in pingMs can win (M39) — a UDP-only server with
     * no TCP ping can still be selected and connected by hand, it just
     * never becomes "Fastest" on a probe it did not answer.
     */
    fun fastestCountry(): TunnelBearServer? {
        val pings = _uiState.value.pingMs
        if (pings.isEmpty()) return null
        val code = pings.minByOrNull { it.value }?.key ?: return null
        return _uiState.value.servers.firstOrNull { it.code.equals(code, ignoreCase = true) }
    }

    /**
     * True when any engine OTHER than our OpenVPN launch is running:
     * sing-box (Dashboard), FENIX (Foxy), or the MASQUE Engine. Used
     * both to refuse a misleading "TunnelBear connected" claim (C5)
     * and to interpret a VPN transport after disconnect (M12).
     */
    private fun otherEngineRunning(dashboardViewModel: DashboardViewModel?): Boolean {
        val dash = dashboardViewModel?.connectionState?.value
        if (dash == ConnectionState.Connected || dash == ConnectionState.Connecting) return true
        if (FoxyVpnService.state.value != com.kunk.singbox.foxy.data.model.ConnectionState.DISCONNECTED) return true
        val engine = com.kunk.singbox.engines.EngineVpnService.state.value
        if (engine is com.kunk.singbox.engines.EngineVpnState.Connected ||
            engine is com.kunk.singbox.engines.EngineVpnState.Connecting
        ) return true
        return false
    }

    private fun hasVpnTransport(context: Context): Boolean {
        val connectivity = runCatching {
            context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        }.getOrNull() ?: return false
        val active = connectivity.activeNetwork ?: return false
        val caps = connectivity.getNetworkCapabilities(active) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
    }

    /**
     * One-tap connect. Mutual exclusion (single-VpnService rule):
     * stops sing-box (Dashboard toggle, +700 ms like FENIX), stops
     * Foxy, and stops the MASQUE-only EngineVpnService — all
     * guarded, all before launching the ics-openvpn core. The
     * reverse hooks live in DashboardViewModel, FoxyViewModel and
     * EngineVpnService (see the delivery report). Android itself
     * allows only one active VpnService, but these explicit stops
     * are what keep the UI states honest.
     *
     * "Connected" is NOT set on launch: it is published only when
     * the system reports an active VPN transport AND our starter
     * session is alive AND no other engine is running (C5, 60 s
     * timeout → plain error). If the core never brings the tunnel
     * up, the tab stays in Connecting and then reports the timeout
     * — never "Connected" on hope.
     *
     * Sing-box state is RE-READ at toggle time (m8): a stale one-shot
     * read could toggle a Disconnecting/Error sing-box back on. A
     * Disconnecting sing-box is waited on (bounded); an Error sing-box
     * is never toggled, and a sing-box still up after the toggle
     * aborts the launch instead of stacking a second tunnel on it.
     */
    fun connectSelected(context: Context, dashboardViewModel: DashboardViewModel) {
        val selected = _uiState.value.selected
        if (selected == null) {
            _uiState.update { it.copy(message = "Pick a country first") }
            return
        }
        val username = accountStore.username
        val password = accountStore.password
        if (username.isBlank() || password.isBlank()) {
            _uiState.update { it.copy(message = "Sign in with your TunnelBear account first") }
            return
        }
        connectJob?.cancel()
        connectJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isConnecting = true, connection = ConnectionState.Connecting,
                    unverifiedVpnActive = false, message = null,
                )
            }
            try {
                val dashState = dashboardViewModel.connectionState.value
                if (dashState == ConnectionState.Connected || dashState == ConnectionState.Connecting) {
                    dashboardViewModel.toggleConnection()
                    delay(700)
                    // Re-read: did sing-box actually stop?
                    val afterToggle = dashboardViewModel.connectionState.value
                    if (afterToggle == ConnectionState.Connected || afterToggle == ConnectionState.Connecting) {
                        error("Could not stop the Dashboard VPN — stop it there first, then connect OpenVPN")
                    }
                } else if (dashState == ConnectionState.Disconnecting) {
                    // Bounded wait for the in-flight disconnect to land.
                    var waitedMs = 0L
                    while (waitedMs < 3_000L &&
                        dashboardViewModel.connectionState.value == ConnectionState.Disconnecting
                    ) {
                        delay(500)
                        waitedMs += 500
                    }
                    if (dashboardViewModel.connectionState.value == ConnectionState.Disconnecting) {
                        error("The Dashboard VPN is still disconnecting — try again in a moment")
                    }
                    if (dashboardViewModel.connectionState.value == ConnectionState.Connected ||
                        dashboardViewModel.connectionState.value == ConnectionState.Connecting
                    ) {
                        error("The Dashboard VPN came back up — stop it there first, then connect OpenVPN")
                    }
                } else if (dashState == ConnectionState.Error) {
                    error("The Dashboard VPN is in an error state — stop it there first, then connect OpenVPN")
                }
                runCatching { FoxyVpnService.stop(getApplication()) }
                runCatching { com.kunk.singbox.engines.EngineVpnService.stop(getApplication()) }
                val config = buildOvpnConfig(context, selected)
                OpenVpnStarter.start(
                    context = context,
                    config = config,
                    username = username,
                    password = password,
                    displayName = "Ralysnd · TunnelBear ${selected.code}",
                    serverCode = selected.code,
                ).getOrThrow()
                startVpnMonitor(context, selected, dashboardViewModel)
            } catch (e: Throwable) {
                if (e is kotlinx.coroutines.CancellationException) throw e
                _uiState.update {
                    it.copy(
                        isConnecting = false,
                        connection = ConnectionState.Error,
                        message = e.message ?: "OpenVPN connect failed",
                    )
                }
            }
        }
    }

    /** Cancels the launch/monitor and stops the core (M12). Shared by [disconnect] and [signOut]. */
    private fun stopTunnel(context: Context) {
        connectJob?.cancel()
        connectJob = null
        monitorJob?.cancel()
        monitorJob = null
        OpenVpnStarter.stop(context)
        _uiState.update {
            it.copy(isConnecting = false, connection = ConnectionState.Disconnecting, unverifiedVpnActive = false)
        }
    }

    /**
     * Disconnect guarantee (M12): cancels any in-progress launch and
     * monitor, stops the core, then verifies (bounded 5 s wait) that
     * our session is gone and — when no other engine is running —
     * that no VPN transport remains. Only then is Idle reported; a
     * transport that survives with no other engine to explain it is
     * reported as an Error, never silently as Idle.
     */
    fun disconnect(context: Context, dashboardViewModel: DashboardViewModel? = null) {
        disconnectVerifyJob?.cancel()
        stopTunnel(context)
        disconnectVerifyJob = viewModelScope.launch {
            var waitedMs = 0L
            while (waitedMs < 5_000L) {
                val sessionGone = !OpenVpnStarter.isSessionAlive()
                val transportExplained = !hasVpnTransport(context) || otherEngineRunning(dashboardViewModel)
                if (sessionGone && transportExplained) break
                delay(500)
                waitedMs += 500
            }
            if (OpenVpnStarter.isSessionAlive()) {
                _uiState.update {
                    it.copy(
                        connection = ConnectionState.Error,
                        message = "OpenVPN did not stop — its launch session is still active; try disconnect again",
                    )
                }
            } else if (hasVpnTransport(context) && !otherEngineRunning(dashboardViewModel)) {
                _uiState.update {
                    it.copy(
                        connection = ConnectionState.Error,
                        message = "A VPN transport is still active after disconnect and no other engine explains it — " +
                            "check the core's notification",
                    )
                }
            } else {
                _uiState.update {
                    it.copy(connection = ConnectionState.Idle, message = null)
                }
            }
        }
    }

    /**
     * Polls the system for an active VPN transport. A launch that
     * never produces one within 60 s is reported as a timeout
     * error — the core's own notification may hold more detail.
     *
     * Identity rule (C5): "OpenVPN connected via TunnelBear" requires
     * ALL of: a VPN transport, our starter session alive, and no other
     * engine running. A transport without our session (or with another
     * engine up) is reported as "VPN active (unverified tunnel)" and
     * never claims TunnelBear.
     */
    private fun startVpnMonitor(context: Context, selected: TunnelBearServer, dashboardViewModel: DashboardViewModel) {
        monitorJob?.cancel()
        monitorJob = viewModelScope.launch {
            val connectivity =
                context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            var waitedMs = 0L
            while (waitedMs < 60_000L) {
                val active = connectivity.activeNetwork
                val caps = active?.let { connectivity.getNetworkCapabilities(it) }
                if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) {
                    if (OpenVpnStarter.isSessionAlive() && !otherEngineRunning(dashboardViewModel)) {
                        _uiState.update {
                            it.copy(
                                isConnecting = false,
                                connection = ConnectionState.Connected,
                                unverifiedVpnActive = false,
                                message = "OpenVPN connected via TunnelBear ${countryNameForCode(selected.code)}",
                            )
                        }
                    } else {
                        _uiState.update {
                            it.copy(
                                isConnecting = false,
                                connection = ConnectionState.Idle,
                                unverifiedVpnActive = true,
                                message = "VPN active (unverified tunnel) — " +
                                    "this VPN transport is not our TunnelBear launch",
                            )
                        }
                    }
                    // Keep watching: if the tunnel drops, report it.
                    while (true) {
                        delay(2_000)
                        val now = connectivity.activeNetwork
                        val nowCaps = now?.let { connectivity.getNetworkCapabilities(it) }
                        if (nowCaps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) != true) {
                            _uiState.update {
                                it.copy(
                                    connection = ConnectionState.Idle,
                                    unverifiedVpnActive = false,
                                    message = "OpenVPN tunnel is no longer active",
                                )
                            }
                            return@launch
                        }
                        // Re-evaluate identity while the transport lives:
                        // another engine starting up must demote a
                        // TunnelBear claim to unverified, and our session
                        // dying must do the same.
                        val verified = OpenVpnStarter.isSessionAlive() && !otherEngineRunning(dashboardViewModel)
                        val currentlyVerified = _uiState.value.connection == ConnectionState.Connected &&
                            !_uiState.value.unverifiedVpnActive
                        if (verified != currentlyVerified) {
                            if (verified) {
                                _uiState.update {
                                    it.copy(
                                        connection = ConnectionState.Connected,
                                        unverifiedVpnActive = false,
                                        message = "OpenVPN connected via TunnelBear ${countryNameForCode(selected.code)}",
                                    )
                                }
                            } else {
                                _uiState.update {
                                    it.copy(
                                        connection = ConnectionState.Idle,
                                        unverifiedVpnActive = true,
                                        message = "VPN active (unverified tunnel) — " +
                                            "this VPN transport is not our TunnelBear launch",
                                    )
                                }
                            }
                        }
                    }
                }
                delay(2_000)
                waitedMs += 2_000
            }
            _uiState.update {
                it.copy(
                    isConnecting = false,
                    connection = ConnectionState.Error,
                    unverifiedVpnActive = false,
                    message = "OpenVPN did not come up within 60s — " +
                        "check the core's notification and your TunnelBear credentials",
                )
            }
        }
    }

    override fun onCleared() {
        connectJob?.cancel()
        monitorJob?.cancel()
        disconnectVerifyJob?.cancel()
        super.onCleared()
    }
}
