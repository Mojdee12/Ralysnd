package com.kunk.singbox.openvpn

import android.content.Context
import android.content.Intent
import android.util.Log
import java.io.StringReader

/**
 * Bridge to the official open-source OpenVPN core, ics-openvpn
 * (github.com/schwabe/ics-openvpn, package de.blinkt.openvpn).
 *
 * GPL NOTICE: OpenVPN as used by ics-openvpn is under GPLv2 (the
 * project's own note: "Please note that OpenVPN used by this
 * project is under GPLv2"). Shipping this core in Ralysnd is fine
 * for the user's personal use; a public release of the combined
 * app carries GPL implications (the combined work must be offered
 * under GPL terms). Nothing here hides that, and no mlm code is
 * used for this feature at all.
 *
 * WHY REFLECTION: ics-openvpn is published as a full Android app
 * module, not as a versioned Maven AAR, so the build includes it
 * as a library module (see the build notes in the delivery report).
 * This bridge therefore resolves the core's classes at runtime
 * instead of importing them: the tab, ViewModel and server list
 * compile and run without the core, and a missing core surfaces
 * as the plain error below — never a fake connected state.
 *
 * VERIFIED against ics-openvpn's own tree (class locations and
 * the parse path, from its docs/source index):
 * - de.blinkt.openvpn.VpnProfile (profile model; connections live
 *   in Connection objects; getConfigFile() regenerates config).
 * - de.blinkt.openvpn.core.ConfigParser with parseConfig() turning
 *   .ovpn text into a VpnProfile.
 * - de.blinkt.openvpn.core.ProfileManager (profile store).
 * - de.blinkt.openvpn.core.VPNLaunchHelper (profile launcher).
 * - de.blinkt.openvpn.core.OpenVPNService (the VpnService).
 * - External API (separate-app route, not used here):
 *   de.blinkt.openvpn.api.ExternalOpenVPNService.startVPN(config)
 *   / startProfile(uuid).
 *
 * TO-CONFIRM AT BUILD TIME (the only unverified surface, confined
 * to this file): the exact launch-call signatures — ConfigParser's
 * parseConfig parameter type (tried: Reader, then InputStream,
 * then String), ProfileManager's add/save method names, and
 * VPNLaunchHelper.startVpn's parameter order. [start] tries the
 * plausible forms in order and, if none matches, fails with a
 * plain error naming what was tried; the build step then fixes
 * ONLY this file. If the checked-out tree's launch entry differs,
 * do not paper over it with a fake success.
 *
 * Credentials: the .ovpn text uses bare `auth-user-pass`, and the
 * username/password are handed to the core's launch call when its
 * signature accepts them (the 4-argument form); when only the
 * profile form exists, they are set on the profile's username /
 * password fields before launch. Either way they come from
 * [TunnelBearAccountStore], never from source.
 */
object OpenVpnStarter {
    private const val TAG = "OpenVpnStarter"

    /** True only when the ics-openvpn service class is present at runtime. */
    val isAvailable: Boolean
        get() = runCatching {
            Class.forName("de.blinkt.openvpn.core.OpenVPNService")
            true
        }.getOrDefault(false)

    /** True only while a launch from this bridge is believed active. Set false by [stop]. */
    @Volatile
    var isActive: Boolean = false
        private set

    /**
     * Our own launch session (C5). The ics-openvpn core exposes no
     * "is this tunnel ours" signal, so the ViewModel identifies OUR
     * tunnel by BOTH a live system VPN transport AND this session
     * being alive — never by the transport alone, which could belong
     * to sing-box, FENIX, or the MASQUE engine. A fresh token per
     * launch means a stale session can never validate a later tunnel.
     */
    data class LaunchSession(
        val serverCode: String,
        val startedAtMs: Long,
        val token: Long,
    )

    @Volatile
    var activeSession: LaunchSession? = null
        private set

    private var launchCounter = 0L

    /** True only while a launch from this bridge has not been stopped. */
    fun isSessionAlive(): Boolean = isActive && activeSession != null

    /**
     * Starts the core for [config] (a full .ovpn text). Returns
     * success only when a launch call was accepted; the tunnel
     * being actually up is reported separately by the ViewModel's
     * system-VPN monitor, never assumed here.
     */
    fun start(
        context: Context,
        config: String,
        username: String,
        password: String,
        displayName: String,
        serverCode: String = "",
    ): Result<Unit> {
        if (!isAvailable) {
            return Result.failure(
                IllegalStateException(
                    "ics-openvpn core module is not included in this build — " +
                        "add the schwabe/ics-openvpn module and rebuild; OpenVPN cannot start without it",
                ),
            )
        }
        return runCatching {
            val profile = parseProfile(config)
            setFieldIfPresent(profile, "mName", displayName)
            saveProfile(context, profile)
            launchProfile(context, profile, username, password)
            launchCounter++
            activeSession = LaunchSession(
                serverCode = serverCode,
                startedAtMs = System.currentTimeMillis(),
                token = launchCounter,
            )
            isActive = true
        }.onFailure { error ->
            activeSession = null
            isActive = false
            Log.e(TAG, "OpenVPN launch failed", error)
        }
    }

    /** Stops the core service. Safe no-op when it is not running. */
    fun stop(context: Context) {
        activeSession = null
        isActive = false
        runCatching {
            val serviceClass = Class.forName("de.blinkt.openvpn.core.OpenVPNService")
            context.stopService(Intent(context, serviceClass))
        }.onFailure { Log.w(TAG, "OpenVPN stop failed", it) }
    }

    private fun parseProfile(config: String): Any {
        val parserClass = Class.forName("de.blinkt.openvpn.core.ConfigParser")
        val parser = parserClass.getDeclaredConstructor().newInstance()
        val method = parserClass.methods.firstOrNull { it.name == "parseConfig" }
            ?: throw IllegalStateException("ics-openvpn ConfigParser.parseConfig not found in this build")
        val params = method.parameterTypes
        val arg: Any? = when {
            params.size == 1 && java.io.Reader::class.java.isAssignableFrom(params[0]) -> StringReader(config)
            params.size == 1 && java.io.InputStream::class.java.isAssignableFrom(params[0]) ->
                config.byteInputStream(Charsets.UTF_8)
            params.size == 1 && params[0] == String::class.java -> config
            else -> throw IllegalStateException(
                "ics-openvpn ConfigParser.parseConfig has an unexpected signature: " +
                    params.joinToString(", ") { it.simpleName },
            )
        }
        return method.invoke(parser, arg)
            ?: throw IllegalStateException("ics-openvpn ConfigParser.parseConfig returned nothing")
    }

    private fun saveProfile(context: Context, profile: Any) {
        val managerClass = Class.forName("de.blinkt.openvpn.core.ProfileManager")
        val getInstance = managerClass.methods.firstOrNull {
            it.name == "getInstance" && it.parameterTypes.size == 1
        } ?: throw IllegalStateException("ics-openvpn ProfileManager.getInstance not found in this build")
        val manager = getInstance.invoke(null, context)
            ?: throw IllegalStateException("ics-openvpn ProfileManager.getInstance returned nothing")
        val profileClass = profile.javaClass
        // addProfile first (registers the profile), then saveProfile
        // (persists it); either may be absent in a given tree, but at
        // least one must succeed.
        var saved = false
        // m9: accumulate EVERY tried signature and its error, so a
        // partially-matching build reports all of them, not just the last.
        val attempts = mutableListOf<String>()
        for (name in listOf("addProfile", "saveProfile")) {
            val method = managerClass.methods.firstOrNull {
                it.name == name && it.parameterTypes.size == 1 &&
                    it.parameterTypes[0].isAssignableFrom(profileClass)
            }
            if (method == null) {
                attempts += "$name(profile: ${profileClass.simpleName}) — no such method in this build"
                continue
            }
            try {
                method.invoke(manager, profile)
                saved = true
                attempts += "$name(profile) — ok"
            } catch (e: Exception) {
                attempts += "$name(profile) — failed: ${e.message ?: e::class.simpleName}"
            }
        }
        if (!saved) {
            throw IllegalStateException(
                "ics-openvpn ProfileManager could not store the profile. Tried: " +
                    attempts.joinToString("; "),
            )
        }
    }

    private fun launchProfile(context: Context, profile: Any, username: String, password: String) {
        setFieldIfPresent(profile, "mUsername", username)
        setFieldIfPresent(profile, "mPassword", password)
        val helperClass = Class.forName("de.blinkt.openvpn.core.VPNLaunchHelper")
        val profileClass = profile.javaClass
        val candidates = helperClass.methods.filter { it.name == "startVpn" }
        if (candidates.isEmpty()) {
            throw IllegalStateException(
                "ics-openvpn VPNLaunchHelper.startVpn not found in this build — " +
                    "check the checked-out tree's launch entry point",
            )
        }
        // Preferred forms, in order: (profile, context), then
        // (profile, username, password, context), then (context, profile).
        // m9: every tried signature and its error is accumulated, so a
        // partially-matching build reports all of them, not just the last.
        val attempts: List<List<Any?>> = listOf(
            listOf(profile, context),
            listOf(profile, username, password, context),
            listOf(context, profile),
        )
        val tried = mutableListOf<String>()
        for (args in attempts) {
            val signature = args.joinToString(", ") { arg ->
                when (arg) {
                    is Context -> "Context"
                    is String -> "String"
                    else -> arg?.javaClass?.simpleName ?: "null"
                }
            }
            val method = candidates.firstOrNull { candidate ->
                candidate.parameterTypes.size == args.size &&
                    args.indices.all { i ->
                        args[i] == null || candidate.parameterTypes[i].isInstance(args[i])
                    }
            }
            if (method == null) {
                tried += "startVpn($signature) — no matching method in this build " +
                    "(available: ${candidates.joinToString("; ") { c -> c.parameterTypes.joinToString(", ") { it.simpleName } }})"
                continue
            }
            try {
                method.invoke(null, *args.toTypedArray())
                return
            } catch (e: Exception) {
                tried += "startVpn($signature) — failed: ${e.message ?: e::class.simpleName}"
            }
        }
        throw IllegalStateException(
            "ics-openvpn VPNLaunchHelper.startVpn accepted none of the tried signatures. Tried: " +
                tried.joinToString("; "),
        )
    }

    private fun setFieldIfPresent(target: Any, fieldName: String, value: String) {
        runCatching {
            var clazz: Class<*>? = target.javaClass
            while (clazz != null) {
                try {
                    val field = clazz.getDeclaredField(fieldName)
                    field.isAccessible = true
                    field.set(target, value)
                    return
                } catch (_: NoSuchFieldException) {
                    clazz = clazz.superclass
                }
            }
        }
    }
}
