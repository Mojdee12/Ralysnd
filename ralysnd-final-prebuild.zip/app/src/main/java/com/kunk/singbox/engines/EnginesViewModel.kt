package com.kunk.singbox.engines

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * ViewModel for MASQUE (plus the WARP identity registration that
 * the Nodes path still uses) and the MASQUE scanner. All state
 * here is measured or user-supplied: no invented gateways,
 * servers, latencies, or quotas.
 *
 * Single-VpnService rule is preserved by construction: WARP
 * produces sing-box nodes/profiles that run through the existing
 * sing-box service, while MASQUE connects through the one shared
 * EngineVpnService — which stops Foxy and sing-box before it
 * starts, so at most one VPN is ever active.
 *
 * WARP² and Psiphon paths were deleted from this file (audit
 * M42/M43): they had no UI callers, and the Psiphon branch in
 * EngineVpnService is deleted with them. PsiphonEngine.kt and
 * PsiphonTunnelBridge.kt were deleted outright by the parent,
 * and the ca.psiphon.aar dependency line was removed from
 * app/build.gradle.kts — no Psiphon code or dependency remains
 * in the tree, and nothing here references them.
 */
class EnginesViewModel(application: Application) : AndroidViewModel(application) {
    private val context: Context
        get() = getApplication<Application>().applicationContext

    private val warpStore by lazy { WarpIdentityStore(context) }
    private val masqueEngine by lazy { MasqueEngine(context) }

    // ---- WARP ----
    private val _warpIdentity = MutableStateFlow<WarpIdentity?>(null)
    val warpIdentity: StateFlow<WarpIdentity?> = _warpIdentity.asStateFlow()
    private val _warpBusy = MutableStateFlow(false)
    val warpBusy: StateFlow<Boolean> = _warpBusy.asStateFlow()
    private val _warpError = MutableStateFlow<String?>(null)
    val warpError: StateFlow<String?> = _warpError.asStateFlow()
    /** Fresh wireguard:// link for the registered WARP identity, if any. */
    private val _warpLink = MutableStateFlow<String?>(null)
    val warpLink: StateFlow<String?> = _warpLink.asStateFlow()

    // ---- MASQUE scan ----
    private val _masqueResults = MutableStateFlow<List<ScanResult>>(emptyList())
    val masqueResults: StateFlow<List<ScanResult>> = _masqueResults.asStateFlow()
    private val _masqueScanning = MutableStateFlow(false)
    val masqueScanning: StateFlow<Boolean> = _masqueScanning.asStateFlow()
    /**
     * M11: plain-language outcome of the last scan when it produced no
     * rows (empty input, overall timeout, or zero answers). The Scanner
     * tab shows this instead of a blank page; cleared on the next scan.
     */
    private val _masqueScanNotice = MutableStateFlow<String?>(null)
    val masqueScanNotice: StateFlow<String?> = _masqueScanNotice.asStateFlow()
    val masqueWinner: String?
        get() = masqueEngine.cachedWinner

    // ---- MASQUE exit country (reference screen parity) ----
    private val _masqueCountries = MutableStateFlow<List<MasqueExitCountry>>(emptyList())
    val masqueCountries: StateFlow<List<MasqueExitCountry>> = _masqueCountries.asStateFlow()
    private val _masquePinging = MutableStateFlow(false)
    val masquePinging: StateFlow<Boolean> = _masquePinging.asStateFlow()
    /** Last MASQUE ping failure, surfaced in the sheet with a retry. Never swallowed. */
    private val _masqueError = MutableStateFlow<String?>(null)
    val masqueError: StateFlow<String?> = _masqueError.asStateFlow()
    private val _masqueSelection = MutableStateFlow(masqueEngine.exitSelection)
    val masqueSelection: StateFlow<MasqueExitSelection> = _masqueSelection.asStateFlow()
    val masqueFastest: MasqueExitCountry?
        get() = masqueEngine.fastestCountry(_masqueCountries.value)

    init {
        _warpIdentity.value = warpStore.load()
        _warpIdentity.value?.let { _warpLink.value = WarpClient.buildWireGuardLink(it) }
    }

    /** Registers a fresh WARP identity and publishes its node link. */
    fun registerWarp() {
        if (_warpBusy.value) return
        viewModelScope.launch {
            _warpBusy.value = true
            _warpError.value = null
            try {
                val keyPair = WarpClient.generateKeyPair()
                val identity = WarpClient.register(keyPair)
                warpStore.save(identity)
                _warpIdentity.value = identity
                _warpLink.value = WarpClient.buildWireGuardLink(identity)
            } catch (e: Exception) {
                _warpError.value = e.message ?: "WARP registration failed"
            } finally {
                _warpBusy.value = false
            }
        }
    }

    fun clearWarpError() {
        _warpError.value = null
    }

    /** Scans MASQUE candidates live; caches the fastest reachable winner. */
    fun scanMasque(input: String) {
        val targets = EngineScanner.parseTargets(input)
        if (_masqueScanning.value) return
        if (targets.isEmpty()) {
            // M11: was a silent no-op (e.g. input ",,," passes isNotBlank
            // but parses to zero targets) leaving a blank results area.
            _masqueScanNotice.value = "No valid gateways in the input — nothing was scanned."
            return
        }
        viewModelScope.launch {
            _masqueScanning.value = true
            _masqueScanNotice.value = null
            _masqueResults.value = emptyList()
            try {
                val collected = mutableListOf<ScanResult>()
                // M11: overall scan timeout. The 3s per-probe TCP timeout
                // does NOT bound DNS resolution inside InetSocketAddress,
                // so a hung DNS lookup could otherwise spin forever with
                // only a progress bar and no feedback.
                val finished = withTimeoutOrNull(SCAN_OVERALL_TIMEOUT_MS) {
                    EngineScanner.scan(targets).collect { result ->
                        collected.add(result)
                        _masqueResults.value = EngineScanner.fastestFirst(collected)
                    }
                    true
                }
                if (finished == null) {
                    _masqueScanNotice.value =
                        "Scan timed out after ${SCAN_OVERALL_TIMEOUT_MS / 1000}s — " +
                        "some targets did not answer (a hung DNS lookup is not " +
                        "bounded by the 3s TCP timeout). Results shown so far are real."
                } else if (collected.isEmpty()) {
                    _masqueScanNotice.value = "Scan finished with no results — no target answered."
                } else {
                    collected.firstOrNull { it.reachable }?.let { winner ->
                        masqueEngine.setManualEndpoint(winner.target.label)
                    }
                }
            } finally {
                _masqueScanning.value = false
            }
        }
    }

    private companion object {
        /** Overall wall-clock bound for one Scanner run (M11). */
        const val SCAN_OVERALL_TIMEOUT_MS: Long = 30_000L
    }

    fun setMasqueManualEndpoint(endpoint: String) {
        masqueEngine.setManualEndpoint(endpoint)
        masqueEngine.addCandidate(endpoint)
    }

    /**
     * "Ping every country": real probes over the gateway pool, grouped by country.
     * Failures are published as [masqueError] (sheet shows them + a retry button),
     * never swallowed: a ping that throws or returns nothing must not look like
     * an empty country list.
     */
    fun pingMasqueCountries() {
        if (_masquePinging.value) return
        viewModelScope.launch {
            _masquePinging.value = true
            _masqueError.value = null
            try {
                val countries = masqueEngine.pingExitCountries()
                if (countries.isEmpty()) {
                    _masqueError.value = "Ping returned no gateways — check the connection and tap Ping every country again."
                } else {
                    _masqueCountries.value = countries
                }
            } catch (e: Exception) {
                _masqueError.value = e.message ?: "MASQUE ping failed (${e.javaClass.simpleName})"
            } finally {
                _masquePinging.value = false
            }
        }
    }

    fun clearMasqueError() {
        _masqueError.value = null
    }

    fun selectMasqueExit(selection: MasqueExitSelection) {
        masqueEngine.exitSelection = selection
        _masqueSelection.value = selection
    }

    // ---- Engine VPN (MASQUE core) ----
    /** Live state of the shared engine VPN service. */
    val engineVpnState: StateFlow<EngineVpnState> = EngineVpnService.state

    /** Returns the VPN-permission intent when the app is not yet authorised, else null. */
    fun vpnPermissionIntent(): android.content.Intent? =
        android.net.VpnService.prepare(context)

    /** Resolves the user's MASQUE exit selection to a gateway and starts the core. */
    fun connectMasque() {
        val gateway = resolveMasqueGateway() ?: return
        EngineVpnService.startMasque(context, gateway)
    }

    /** True when an endpoint is a gateway known to reject CONNECT-UDP (see MasqueEngine). */
    fun isMasqueGatewayIncompatible(endpoint: String): Boolean =
        MasqueEngine.isConnectUdpIncompatible(endpoint)

    /**
     * Resolves the MASQUE exit selection to the gateway the core
     * must actually dial — this is the SINGLE resolution the sheet
     * and [connectMasque] both use, so the button can never show
     * one country and dial another, and EngineVpnService dials
     * exactly this value with no fallback of its own (audit M41).
     *
     * - Country: the FIRST CONNECT-UDP-compatible gateway of that
     *   country's row in the current ping list (rows are sorted
     *   fastest-first, so this is the country's fastest measured
     *   compatible gateway), or — when the list is empty because
     *   the process restarted after the user picked a country —
     *   the gateway persisted for that country at the last ping,
     *   if it is compatible. It NEVER falls back to the cached
     *   winner or the documented edge: falling back would silently
     *   dial a different country than the one the user selected.
     *   When no compatible gateway is known for the selected
     *   country at all, this returns null and the sheet disables
     *   Connect with a reason instead of dialling something else.
     * - Fastest: the first reachable country with a compatible
     *   gateway, else the cached winner if compatible, else null.
     *   It NEVER falls back to the documented edge, which rejects
     *   CONNECT-UDP (audit C2): a Fastest tap with only that edge
     *   available disables Connect with the plain reason line.
     * - Direct: the cached winner if compatible, else null (same
     *   no-edge-fallback rule; Direct means "no country change",
     *   so any measured compatible gateway is the direct route).
     */
    fun resolveMasqueGateway(
        countries: List<MasqueExitCountry> = _masqueCountries.value,
        selection: MasqueExitSelection = _masqueSelection.value,
    ): String? {
        val compatible: (String) -> Boolean = { !MasqueEngine.isConnectUdpIncompatible(it) }
        return when (selection) {
            is MasqueExitSelection.Country -> {
                countries.firstOrNull { it.code == selection.code }
                    ?.gateways?.firstOrNull(compatible)
                    ?: masqueEngine.gatewayForCountry(selection.code)?.takeIf(compatible)
            }
            is MasqueExitSelection.Fastest -> {
                countries.firstOrNull { it.reachable && it.gateways.any(compatible) }
                    ?.gateways?.firstOrNull(compatible)
                    ?: masqueEngine.cachedWinner?.takeIf(compatible)
            }
            is MasqueExitSelection.Direct -> {
                masqueEngine.cachedWinner?.takeIf(compatible)
            }
        }
    }

    /** Disconnects whichever engine VPN is running, if any. */
    fun disconnectEngine() {
        EngineVpnService.stop(context)
    }

}
