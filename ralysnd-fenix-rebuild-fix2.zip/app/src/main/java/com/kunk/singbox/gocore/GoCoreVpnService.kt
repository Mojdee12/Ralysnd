// New code written for the Ralysnd FENIX rebuild (Go-core integration).
// Package: com.kunk.singbox.gocore (new; the old FENIX
// package is deleted). All Go-core calls go through GoCoreBinding
// (VERIFY-AGAINST-AAR) — no other file touches the binding.
//
// LIFECYCLE (see TUN-HANDOFF-MUTEX.md):
// - The service owns the TUN while the Go core is the active transport.
// - startTunnel(): ensure the daemon runs (Start if needed) → Builder +
//   establish() → StartTun(fd) → SetOn(true) → Connect().
// - stopTunnel(): StopTun() → SetOn(false) → Stop() (daemon down; the
//   next FENIX visit restarts it via ensureCore). The fd is closed once.
// - The service maintains VpnStateStore (mode GO_CORE, active, label) so
//   the Quick Settings tile and generic stop paths see FENIX correctly.
// - The app itself is excluded from its own VPN, or the core's loopback
//   dashboard calls would loop back through the tunnel (mobile.go note).

package com.kunk.singbox.gocore

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.kunk.singbox.R
import com.kunk.singbox.ipc.VpnStateStore
import com.kunk.singbox.repository.LogRepository
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Actions this service understands. */
object GoCoreServiceActions {
    const val ACTION_START = "com.kunk.singbox.gocore.ACTION_START"
    const val ACTION_STOP = "com.kunk.singbox.gocore.ACTION_STOP"
}

/** Observable transport state for the FENIX tab (no secrets). */
data class GoCoreTransportState(
    val running: Boolean = false,
    val connected: Boolean = false,
    val exitCountry: String? = null,
    val error: String? = null,
)

/** Daemon data dir (daemon accounts, config, token file live here). */
fun goCoreDataDir(context: Context): File = File(context.filesDir, "gocore")

/**
 * VpnService owning the TUN while the Go core is the active transport.
 * Owns exactly one fd; closes it exactly once; clears the owner record
 * on destroy (best-effort) so a dead service never blocks the next start.
 */
class GoCoreVpnService : VpnService() {

    companion object {
        private const val CHANNEL_ID = "gocore_vpn"
        private const val NOTIF_ID = 4401

        @Volatile var isRunning: Boolean = false
            private set

        @Volatile var isStarting: Boolean = false
            private set

        private val _transportState = MutableStateFlow(GoCoreTransportState())
        val transportState: StateFlow<GoCoreTransportState> = _transportState.asStateFlow()
    }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var tunFd: ParcelFileDescriptor? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private fun logEvent(level: String, message: String) {
        LogRepository.getInstance().addAlwaysLog("$level [FENIX] $message")
        runCatching {
            FenixEventStore(applicationContext).append(level, message)
        }
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            GoCoreServiceActions.ACTION_STOP -> {
                stopTunnel()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                isStarting = true
                startForeground(NOTIF_ID, buildNotification())
                startTunnel()
                return START_STICKY
            }
        }
    }

    private fun startTunnel() {
        scope.launch {
            try {
                // Ensure the daemon runs (the ViewModel normally starts it
                // with on=false for account listing; here it must be on).
                if (!GoCoreBinding.running()) {
                    GoCoreBinding.start(goCoreDataDir(applicationContext).absolutePath, true)
                        .getOrThrow()
                }
                VpnStateStore.setMode(VpnStateStore.CoreMode.GO_CORE)
                VpnStateStore.setPending("starting")
                // M1: mirror the upstream proven-working Builder set
                // exactly (the old 10.8.0.x values were reused from the
                // deleted old tunnel, not from the Go core). The IPv6
                // address + ::/0 route matter: without them IPv6 traffic
                // bypasses the tunnel entirely on IPv6-capable networks.
                val builder = Builder()
                    .setSession("Ralysnd FENIX")
                    .setMtu(1500)
                    .addAddress("172.19.0.1", 30)
                    .addRoute("0.0.0.0", 0)
                    .addAddress("fdfe:dcba:9876::1", 126)
                    .addRoute("::", 0)
                    .addDnsServer("172.19.0.2")
                    // The app itself must be excluded from its own VPN, or
                    // the core's loopback dashboard calls loop through TUN.
                    .addDisallowedApplication(packageName)
                val pfd = builder.establish()
                    ?: throw IllegalStateException("VpnService.Builder.establish() returned null")
                tunFd = pfd
                // StartTun takes the raw fd int and closes it on failure.
                GoCoreBinding.startTun(pfd.fd).getOrThrow()
                GoCoreBinding.setOn(true).getOrThrow()
                GoCoreBinding.connect().getOrThrow()
                registerNetworkCallback()
                isStarting = false
                VpnStateStore.setActive(true)
                VpnStateStore.setActiveLabel("FENIX")
                VpnStateStore.setPending("")
                _transportState.value = GoCoreTransportState(
                    running = true,
                    connected = true,
                    exitCountry = GoCoreBinding.exitCountry().takeIf { it.isNotBlank() },
                )
                logEvent("INFO", "tunnel started")
            } catch (e: Exception) {
                // Stale-flag fix: the tunnel never came up; do not keep
                // reporting the service as running until onDestroy lands.
                isRunning = false
                isStarting = false
                _transportState.value = GoCoreTransportState(
                    running = false,
                    error = "Tunnel failed to start",
                )
                logEvent("ERROR", "tunnel start failed")
                runCatching { tunFd?.close() }
                tunFd = null
                VpnStateStore.setMode(VpnStateStore.CoreMode.NONE)
                VpnStateStore.setActive(false)
                VpnStateStore.setPending("")
                stopSelf()
            }
        }
    }

    /**
     * M5: if Android revokes this VpnService (e.g. another VPN starts),
     * tear down the tunnel + daemon instead of leaving the daemon
     * running with a dead fd while state still says FENIX-connected.
     */
    override fun onRevoke() {
        logEvent("INFO", "vpn revoked by system")
        stopTunnel()
        stopSelf()
        super.onRevoke()
    }

    private fun stopTunnel() {
        try {
            // StopTun first, then proxy off, then the daemon itself.
            // (Go's Stop() also stops the tunnel; calling both is safe.)
            GoCoreBinding.stopTun()
            GoCoreBinding.setOn(false)
            GoCoreBinding.stop()
        } catch (ignored: Exception) {
            // Best-effort: never crash the service teardown path.
        } finally {
            unregisterNetworkCallback()
            runCatching { tunFd?.close() }
            tunFd = null
            // Stale-flag fix: the tunnel is down from here on, even
            // though onDestroy (which also clears these) may follow later.
            isRunning = false
            isStarting = false
            _transportState.value = GoCoreTransportState()
            VpnStateStore.setMode(VpnStateStore.CoreMode.NONE)
            VpnStateStore.setActive(false)
            VpnStateStore.setPending("")
            logEvent("INFO", "tunnel stopped")
        }
    }

    private fun registerNetworkCallback() {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                GoCoreBinding.networkChanged(true)
            }

            override fun onLost(network: Network) {
                GoCoreBinding.networkChanged(false)
            }

            override fun onCapabilitiesChanged(
                network: Network,
                capabilities: NetworkCapabilities,
            ) {
                val connected = capabilities.hasCapability(
                    NetworkCapabilities.NET_CAPABILITY_INTERNET,
                )
                GoCoreBinding.networkChanged(connected)
            }
        }
        networkCallback = callback
        runCatching {
            cm.registerNetworkCallback(
                NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build(),
                callback,
            )
        }
    }

    private fun unregisterNetworkCallback() {
        val callback = networkCallback ?: return
        networkCallback = null
        runCatching {
            getSystemService(ConnectivityManager::class.java)
                ?.unregisterNetworkCallback(callback)
        }
    }

    override fun onDestroy() {
        stopTunnel()
        scope.cancel()
        isRunning = false
        isStarting = false
        super.onDestroy()
    }

    private fun createChannel() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "FENIX", NotificationManager.IMPORTANCE_LOW),
            )
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.gocore_notification_title))
            .setContentText(getString(R.string.gocore_notification_text))
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
    }
}
