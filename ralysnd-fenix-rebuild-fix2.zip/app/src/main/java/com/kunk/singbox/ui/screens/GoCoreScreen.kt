// New FENIX screen for the Go-core rebuild (replaces the deleted
// old FENIX screen). Layout language is the app's EXISTING
// approved light bento palette — no new color scheme, no imported visual
// style. Data comes from GoCoreViewModel (dashboard API), never from the
// old FENIX code. No lazy layouts are used here (plain Column +
// verticalScroll), so no LazyListScope/LazyGridScope import pitfalls.
//
// Sections (top to bottom, per UI-STRUCTURE.md): account card, status +
// quota card, connect tile (green when fully connected), country list
// with search + ping-all + fastest, recent-events strip, settings row.

package com.kunk.singbox.ui.screens

import android.app.Activity
import android.graphics.BitmapFactory
import android.net.VpnService
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.kunk.singbox.gocore.GoAccount
import com.kunk.singbox.gocore.GoConnectionState
import com.kunk.singbox.gocore.GoCoreViewModel
import com.kunk.singbox.gocore.GoLocation
import com.kunk.singbox.gocore.GoSignInStep
import com.kunk.singbox.gocore.GoSignInUiState
import com.kunk.singbox.gocore.SignInFailureCategory
import com.kunk.singbox.ui.components.StandardCard
import com.kunk.singbox.ui.navigation.Screen
import com.kunk.singbox.ui.theme.BentoAmber
import com.kunk.singbox.ui.theme.BentoBackground
import com.kunk.singbox.ui.theme.BentoBlue
import com.kunk.singbox.ui.theme.BentoCoral
import com.kunk.singbox.ui.theme.BentoInk
import com.kunk.singbox.ui.theme.BentoInkDim
import com.kunk.singbox.ui.theme.BentoMint
import com.kunk.singbox.ui.theme.BentoMintDark
import com.kunk.singbox.ui.theme.BentoSurfaceAlt
import com.kunk.singbox.ui.theme.BentoViolet

/** Country code (ISO) → flag emoji via regional indicators (algorithm, not data). */
private fun countryFlag(code: String): String {
    val upper = code.uppercase()
    if (upper.length != 2 || !upper.all { it in 'A'..'Z' }) return "🏳"
    val base = 0x1F1E6
    return buildString {
        for (ch in upper) {
            val point = base + (ch - 'A')
            append(Character.toChars(point))
        }
    }
}

/** Bytes → human-readable string (e.g. 1.5 GB). Never invents a max. */
private fun formatBytes(bytes: Long): String {
    if (bytes < 0) return "—"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unit = 0
    while (value >= 1024.0 && unit < units.lastIndex) {
        value /= 1024.0
        unit++
    }
    return if (unit == 0) "$bytes B" else "%.1f %s".format(value, units[unit])
}

/** Plain-words error text for a sign-in failure category (never raw bodies). */
private fun signInErrorText(category: SignInFailureCategory): String {
    return when (category) {
        SignInFailureCategory.WRONG_CREDENTIALS -> "Email or password is wrong."
        SignInFailureCategory.NO_ACCOUNT -> "No Firefox account with that email."
        SignInFailureCategory.NO_PASSWORD -> "This account has no password (Google or Apple sign-in)."
        SignInFailureCategory.CODE_INVALID -> "That code didn't work. Try again."
        SignInFailureCategory.TOO_MANY_ATTEMPTS -> "Too many attempts. Wait a while, then try again."
        SignInFailureCategory.BLOCKED -> "This sign-in was blocked. Try again."
        SignInFailureCategory.NETWORK -> "Can't reach the sign-in service. Check your connection."
        SignInFailureCategory.TIMEOUT -> "Sign-in timed out. Try again."
        SignInFailureCategory.UNKNOWN -> "Sign-in failed. Try again."
    }
}

/** Decode a CAPTCHA payload (data URI or raw base64) to a bitmap, or null. */
private fun decodeCaptchaBitmap(payload: String?): android.graphics.Bitmap? {
    if (payload.isNullOrBlank()) return null
    val base64 = when {
        payload.startsWith("data:") -> payload.substringAfter(",", "")
        else -> payload
    }
    if (base64.isBlank()) return null
    return runCatching {
        val bytes = Base64.decode(base64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }.getOrNull()
}

@Composable
fun GoCoreScreen(
    navController: NavController,
    bottomContentPadding: androidx.compose.ui.unit.Dp = 0.dp,
    viewModel: GoCoreViewModel = viewModel(),
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val events by viewModel.eventStore.lines.collectAsStateWithLifecycle()
    val signIn by viewModel.signInState.collectAsStateWithLifecycle()

    var showSignIn by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var accountToRemove by remember { mutableStateOf<GoAccount?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.connectSelected()
        } else {
            // Permission denial used to leave the tile unchanged with no
            // feedback at all; say plainly what is missing.
            viewModel.showNotice("VPN permission is needed to connect FENIX.")
        }
    }

    // Close the sheet on a terminal sign-in state (success refreshes accounts).
    LaunchedEffect(signIn) {
        if (signIn is GoSignInUiState.Done) {
            showSignIn = false
        }
    }

    val isConnected = uiState.connectionState == GoConnectionState.CONNECTED
    val isConnecting = uiState.connectionState == GoConnectionState.CONNECTING
    val signInBusy = signIn is GoSignInUiState.Starting ||
        signIn is GoSignInUiState.WaitingStep ||
        signIn is GoSignInUiState.Waiting ||
        signIn is GoSignInUiState.Answering

    val filteredCountries = remember(search, uiState.locations) {
        val query = search.trim().lowercase()
        if (query.isBlank()) {
            uiState.locations
        } else {
            uiState.locations.filter {
                it.name.lowercase().contains(query) || it.code.lowercase().contains(query)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BentoBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .padding(bottom = bottomContentPadding),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // ---- Account card ----
        StandardCard {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Person,
                        contentDescription = null,
                        tint = BentoCoral,
                        modifier = Modifier.size(24.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Firefox account",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                        ),
                        color = BentoInk,
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = { viewModel.refreshAll() }) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                if (uiState.accounts.isEmpty()) {
                    Text(
                        text = "No Firefox account added yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BentoInkDim,
                    )
                } else {
                    val active = uiState.accounts.firstOrNull { it.active }
                    if (active != null) {
                        Text(
                            text = active.email,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                            ),
                            color = BentoInk,
                        )
                    }
                    for (account in uiState.accounts) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (!account.active) viewModel.switchAccount(account.id)
                                }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = if (account.active) "● " else "○ ",
                                color = if (account.active) BentoViolet else BentoInkDim,
                            )
                            Text(
                                text = account.email,
                                style = MaterialTheme.typography.bodyMedium,
                                color = BentoInk,
                                modifier = Modifier.weight(1f),
                            )
                            if (!account.active) {
                                TextButton(onClick { viewModel.switchAccount(account.id) }) {
                                    Text(text = "Use")
                                }
                            }
                            TextButton(onClick = { accountToRemove = account }) {
                                Icon(
                                    imageVector = Icons.Rounded.Delete,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { showSignIn = true },
                    colors = ButtonDefaults.buttonColors(containerColor = BentoCoral),
                ) {
                    Text(text = "Add account")
                }
                if (uiState.coreError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = uiState.coreError!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = BentoCoral,
                    )
                }
            }
        }

        // ---- Status + quota card ----
        StandardCard {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = when (uiState.connectionState) {
                        GoConnectionState.CONNECTED -> "Connected"
                        GoConnectionState.CONNECTING -> "Connecting…"
                        GoConnectionState.RECONNECTING -> "Reconnecting…"
                        GoConnectionState.ERROR -> "Connection error"
                        GoConnectionState.DISCONNECTED -> "Disconnected"
                    },
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                    ),
                    color = BentoInk,
                )
                Spacer(modifier = Modifier.height(8.dp))
                if (uiState.exitCountry != null) {
                    Text(
                        text = "Exit: ${countryFlag(uiState.exitCountry!!)} ${uiState.exitCountry}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BentoInk,
                    )
                }
                if (isConnected) {
                    Text(
                        text = "↓ ${formatBytes(uiState.speedDownBps)}/s  ↑ " +
                            "${formatBytes(uiState.speedUpBps)}/s",
                        style = MaterialTheme.typography.bodyMedium,
                        color = BentoInkDim,
                    )
                }
                val activeAccount = uiState.accounts.firstOrNull { it.active }
                val usage = activeAccount?.usage
                Spacer(modifier = Modifier.height(8.dp))
                when {
                    activeAccount == null -> {
                        Text(
                            text = "Sign in to see your quota.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BentoInkDim,
                        )
                    }
                    usage == null -> {
                        Text(
                            text = "Quota unavailable.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BentoInkDim,
                        )
                    }
                    usage.unlimited -> {
                        Text(
                            text = "Unlimited quota.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BentoInk,
                        )
                    }
                    else -> {
                        // Remaining-only when no max is reported: never invent one.
                        val remainingText = "${formatBytes(usage.remainingBytes)} left"
                        val maxText = if (usage.limitBytes > 0) {
                            " of ${formatBytes(usage.limitBytes)}"
                        } else {
                            ""
                        }
                        Text(
                            text = remainingText + maxText,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                            ),
                            color = BentoInk,
                        )
                    }
                }
                if (uiState.errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = uiState.errorMessage!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = BentoCoral,
                    )
                }
            }
        }

        // ---- Connect tile (blue; green when fully connected) ----
        StandardCard(
            tileColor = if (isConnected) BentoMint else BentoBlue,
            onClick = {
                if (signInBusy) return@StandardCard
                if (isConnected) {
                    viewModel.disconnectFenix()
                } else if (!isConnecting) {
                    val prepareIntent = VpnService.prepare(context)
                    if (prepareIntent != null) {
                        permissionLauncher.launch(prepareIntent)
                    } else {
                        viewModel.connectSelected()
                    }
                }
            },
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(
                    imageVector = Icons.Rounded.Power,
                    contentDescription = null,
                    tint = if (isConnected) BentoMintDark else Color.White,
                    modifier = Modifier.size(28.dp),
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = when {
                            isConnected -> "Connected — tap to disconnect"
                            isConnecting -> "Connecting…"
                            else -> "Connect"
                        },
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                        ),
                        color = if (isConnected) BentoMintDark else Color.White,
                    )
                    if (uiState.selectedCountry.isNotBlank()) {
                        Text(
                            text = "Exit: ${countryFlag(uiState.selectedCountry)} " +
                                uiState.selectedCountry,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isConnected) BentoMintDark else Color.White,
                        )
                    }
                }
            }
        }

        // ---- Country list card ----
        StandardCard {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.LocationOn,
                        contentDescription = null,
                        tint = BentoViolet,
                        modifier = Modifier.size(24.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Countries",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                        ),
                        color = BentoInk,
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(
                        onClick = { viewModel.pingAllCountries() },
                        enabled = !uiState.isPinging,
                    ) {
                        Text(text = if (uiState.isPinging) "Pinging…" else "Ping all")
                    }
                    TextButton(
                        onClick = {
                            val fastest = viewModel.fastestCountry()
                            if (fastest != null) {
                                viewModel.selectCountry(fastest.code)
                            } else {
                                // Fastest used to do nothing at all with no
                                // pings measured; say what to do instead.
                                viewModel.showNotice(
                                    "No pings yet — tap Ping all first.",
                                )
                            }
                        },
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Star,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(text = "Fastest")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    placeholder = { Text(text = "Search countries") },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = null,
                        )
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(modifier = Modifier.height(8.dp))
                if (uiState.isPinging) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(8.dp))
                }
                if (filteredCountries.isEmpty()) {
                    Text(
                        text = if (uiState.locations.isEmpty()) {
                            "No countries yet — sign in first."
                        } else {
                            "No match."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = BentoInkDim,
                    )
                }
                for (country in filteredCountries) {
                    CountryRow(
                        country = country,
                        selected = country.code == uiState.selectedCountry,
                        onClick = { viewModel.selectCountry(country.code) },
                    )
                }
            }
        }

        // ---- Recent events strip (always visible; fixes the empty log) ----
        StandardCard(tileColor = BentoSurfaceAlt) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.BarChart,
                        contentDescription = null,
                        tint = BentoViolet,
                        modifier = Modifier.size(20.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Recent events",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                        ),
                        color = BentoInk,
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = { viewModel.eventStore.clear() }) {
                        Text(text = "Clear")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                if (events.isEmpty()) {
                    Text(
                        text = "No events yet.",
                        style = MaterialTheme.typography.bodySmall,
                        color = BentoInkDim,
                    )
                } else {
                    for (line in events.takeLast(30)) {
                        Text(
                            text = line,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                            ),
                            color = BentoInkDim,
                        )
                    }
                }
            }
        }

        // ---- Settings row ----
        StandardCard {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { navController.navigate(Screen.Logs.route) }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "View full logs",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                    ),
                    color = BentoBlue,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = "Settings > Tools > Logs",
                    style = MaterialTheme.typography.bodySmall,
                    color = BentoInkDim,
                )
            }
        }
    }

    if (showSignIn) {
        SignInDialog(
            signIn = signIn,
            onDismiss = {
                viewModel.cancelSignIn()
                showSignIn = false
            },
            onStart = { email, password -> viewModel.startSignIn(email, password) },
            onAnswer = { value -> viewModel.answerSignInStep(value) },
            onCancel = {
                viewModel.cancelSignIn()
                showSignIn = false
            },
        )
    }

    if (accountToRemove != null) {
        val account = accountToRemove!!
        AlertDialog(
            onDismissRequest = { accountToRemove = null },
            title = { Text(text = "Remove account?") },
            text = { Text(text = account.email) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.removeAccount(account.id)
                        accountToRemove = null
                    },
                ) {
                    Text(text = "Remove")
                }
            },
            dismissButton = {
                TextButton(onClick = { accountToRemove = null }) {
                    Text(text = "Cancel")
                }
            },
        )
    }
}

@Composable
private fun CountryRow(
    country: GoLocation,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = countryFlag(country.code),
            fontSize = 20.sp,
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = country.name.ifBlank { country.code },
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                ),
                color = BentoInk,
            )
            if (!country.city.isNullOrBlank()) {
                Text(
                    text = country.city!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = BentoInkDim,
                )
            }
        }
        if (country.recommended) {
            Text(
                text = "★ ",
                color = BentoAmber,
            )
        }
        Text(
            text = country.pingMs?.let { "$it ms" } ?: "—",
            style = MaterialTheme.typography.bodyMedium,
            color = if (selected) BentoViolet else BentoInkDim,
        )
    }
}

@Composable
private fun SignInDialog(
    signIn: GoSignInUiState,
    onDismiss: () -> Unit,
    onStart: (email: String, password: String) -> Unit,
    onAnswer: (value: String) -> Unit,
    onCancel: () -> Unit,
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var showForm by remember { mutableStateOf(true) }

    // A failed attempt returns to the form (email kept, password never kept).
    LaunchedEffect(signIn) {
        if (signIn is GoSignInUiState.Failed) {
            showForm = true
            password = ""
            code = ""
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        StandardCard {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Firefox sign-in",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                    ),
                    color = BentoInk,
                )
                Spacer(modifier = Modifier.height(12.dp))
                when (signIn) {
                    is GoSignInUiState.Starting -> {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Signing in…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BentoInkDim,
                        )
                    }
                    is GoSignInUiState.Answering -> {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Checking…",
                            style = MaterialTheme.typography.bodyMedium,
                            color = BentoInkDim,
                        )
                    }
                    is GoSignInUiState.WaitingStep -> {
                        val step = signIn.step
                        val stepType = step.step
                        val message = step.message.ifBlank { "Enter the code." }
                        Text(
                            text = message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = BentoInk,
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        if (stepType == GoSignInStep.NEED_CAPTCHA) {
                            val bitmap = remember(step.captcha) {
                                decodeCaptchaBitmap(step.captcha)
                            }
                            if (bitmap != null) {
                                androidx.compose.foundation.Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxWidth(),
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                            }
                            OutlinedTextField(
                                value = code,
                                onValueChange = { code = it },
                                label = { Text(text = "Characters shown") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                            )
                        } else {
                            OutlinedTextField(
                                value = code,
                                onValueChange = { code = it },
                                label = { Text(text = "Code") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                ),
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val answer = code
                                code = ""
                                onAnswer(answer)
                            },
                            enabled = code.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = BentoCoral,
                            ),
                        ) {
                            Text(text = "Continue")
                        }
                    }
                    is GoSignInUiState.Waiting -> {
                        // M6: the email-link text belongs ONLY to the
                        // email-link wait. Other no-action waits (daemon
                        // working, token fetch) get a generic text — the
                        // old code told the user to check email even when
                        // no email was involved. The machine keeps polling
                        // every 1.5 s, so there is no manual re-poll
                        // button — waiting is the action.
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (signIn.hint == GoSignInStep.NEED_EMAIL_LINK) {
                                "Check your email and open the link, then come back here."
                            } else {
                                "Working…"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = BentoInk,
                        )
                    }
                    is GoSignInUiState.Failed -> {
                        Text(
                            text = signInErrorText(signIn.category),
                            style = MaterialTheme.typography.bodyMedium,
                            color = BentoCoral,
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        SignInForm(
                            email = email,
                            password = password,
                            onEmailChange = { email = it },
                            onPasswordChange = { password = it },
                            onSubmit = { onStart(email, password) },
                        )
                    }
                    else -> {
                        if (showForm) {
                            SignInForm(
                                email = email,
                                password = password,
                                onEmailChange = { email = it },
                                onPasswordChange = { password = it },
                                onSubmit = {
                                    showForm = false
                                    onStart(email, password)
                                },
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                ) {
                    TextButton(onClick = onCancel) {
                        Text(text = "Cancel")
                    }
                }
            }
        }
    }
}

@Composable
private fun SignInForm(
    email: String,
    password: String,
    onEmailChange: (String) -> Unit,
    onPasswordChange: (String) -> Unit,
    onSubmit: () -> Unit,
) {
    OutlinedTextField(
        value = email,
        onValueChange = onEmailChange,
        label = { Text(text = "Email") },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
        modifier = Modifier.fillMaxWidth(),
    )
    Spacer(modifier = Modifier.height(8.dp))
    OutlinedTextField(
        value = password,
        onValueChange = onPasswordChange,
        label = { Text(text = "Password") },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        modifier = Modifier.fillMaxWidth(),
    )
    Spacer(modifier = Modifier.height(12.dp))
    Button(
        onClick = onSubmit,
        enabled = email.isNotBlank() && password.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = BentoCoral),
    ) {
        Text(text = "Sign in")
    }
}
