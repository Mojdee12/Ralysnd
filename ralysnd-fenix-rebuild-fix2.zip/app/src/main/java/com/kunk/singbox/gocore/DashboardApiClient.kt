// New code written for the Ralysnd FENIX rebuild (Go-core integration).
// Package: com.kunk.singbox.gocore (new).
//
// DESIGN RULES (non-negotiable):
//  1. Loopback only. The base URL is http://127.0.0.1:<port> where <port>
//     is resolved at runtime from the daemon's own config.json
//     (dashboard.listen), defaulting to 10820 only when the file has no
//     listen address. The port is NEVER hardcoded as the only value.
//  2. Local token: read fresh from <dataDir>/local-api.token (trimmed),
//     sent as the X-Local-Token header — the mechanism confirmed from the
//     upstream localtoken.go + reference dashboard client. The daemon
//     removes the previous run's token file on Start and writes a fresh
//     one once bound, so the provider re-reads the file on every call
//     and can wait briefly for it after a start. Calls FAIL CLOSED when
//     no token file exists — no dummy token, no guessed header.
//  3. Never log request/response bodies, tokens, emails, passwords, or
//     codes. Errors carry route + HTTP status only.
//  4. All calls run on the caller's dispatcher (callers use Dispatchers.IO).
//     Timeouts are short; polling lives in the state machine, not here.

package com.kunk.singbox.gocore

import com.google.gson.Gson
import com.google.gson.JsonParser
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.util.concurrent.TimeUnit

/** Resolves the daemon's loopback endpoint + local token from its data dir. */
class GoCoreEndpoint(private val dataDir: File) {

    /** Dashboard port from config.json (dashboard.listen), fallback 10820. */
    fun dashboardPort(): Int {
        val listen = runCatching {
            val configFile = File(dataDir, "config.json")
            if (!configFile.exists()) return@runCatching null
            val root = JsonParser.parseString(configFile.readText()).asJsonObject
            val dashboard = root.getAsJsonObject("dashboard") ?: return@runCatching null
            dashboard.get("listen")?.takeIf { it.isJsonPrimitive }?.asString
        }.getOrNull() ?: return DEFAULT_DASHBOARD_PORT
        // listen looks like "127.0.0.1:10820" (or a wildcard host, or bare ":10820").
        val portPart = listen.substringAfterLast(":", "")
        return portPart.toIntOrNull() ?: DEFAULT_DASHBOARD_PORT
    }

    fun baseUrl(): String = "http://127.0.0.1:${dashboardPort()}"

    /**
     * Current local token, or null when the file does not exist (yet).
     * The token file is <dataDir>/local-api.token; its content is trimmed.
     */
    fun currentToken(): String? {
        val file = File(dataDir, "local-api.token")
        if (!file.exists()) return null
        return runCatching { file.readText().trim() }.getOrNull()
            ?.takeIf { it.isNotEmpty() }
    }

    /**
     * Wait briefly for the daemon to write its fresh token file after a
     * start (Start removes the old file first). Returns the token, or null
     * when it never appears within [timeoutMs].
     */
    fun awaitToken(timeoutMs: Long = 10_000L): String? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() <= deadline) {
            currentToken()?.let { return it }
            Thread.sleep(250L)
        }
        return currentToken()
    }

    companion object {
        // Fallback only: used when config.json has no dashboard.listen.
        // TODO-VERIFY: confirm the mobile daemon's actual listen address
        // from a running daemon; the endpoint resolution above already
        // prefers the file, so this value is only a last resort.
        const val DEFAULT_DASHBOARD_PORT = 10820
    }
}

/** Thin HTTP client over the Go daemon's loopback dashboard API. */
class DashboardApiClient(
    private val endpoint: GoCoreEndpoint,
    httpClient: OkHttpClient? = null,
) {
    private val gson = Gson()

    private val client: OkHttpClient = httpClient ?: OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        // Loopback only: never route through a proxy, never leave the device.
        .proxy(null)
        .build()

    /**
     * M2: ping-all over many countries can take up to ~2 minutes on the
     * daemon side, so ping calls get their own 180 s read timeout. Every
     * other call keeps the 30 s timeout above.
     */
    private val pingClient: OkHttpClient = client.newBuilder()
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    private fun requestBuilder(path: String): Request.Builder {
        val token = endpoint.currentToken()
            ?: throw IllegalStateException("Dashboard local token unavailable")
        return Request.Builder()
            .url(endpoint.baseUrl() + path)
            .header("X-Local-Token", token)
    }

    private fun get(path: String): String {
        val request = requestBuilder(path).get().build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            check(response.isSuccessful) {
                throw fail(path, response.code, body)
            }
            return body
        }
    }

    private fun post(
        path: String,
        jsonBody: String? = null,
        useClient: OkHttpClient = client,
    ): String {
        val body = (jsonBody ?: "").toRequestBody("application/json".toMediaType())
        val request = requestBuilder(path).post(body).build()
        useClient.newCall(request).execute().use { response ->
            val respBody = response.body?.string().orEmpty()
            check(response.isSuccessful) {
                throw fail(path, response.code, respBody)
            }
            return respBody
        }
    }

    private fun delete(path: String): String {
        val request = requestBuilder(path).delete().build()
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            check(response.isSuccessful) {
                throw fail(path, response.code, body)
            }
            return body
        }
    }

    private fun fail(path: String, code: Int, body: String): GoApiException {
        val message = runCatching {
            gson.fromJson(body, GoApiErrorBody::class.java)?.message
        }.getOrNull()?.takeIf { it.isNotBlank() } ?: "request failed"
        return GoApiException(path, code, message)
    }

    private inline fun <reified T> decode(body: String): T =
        gson.fromJson(body, T::class.java)

    // ---- Sign-in ----

    /** Start a sign-in (202 Accepted). Returns the view to poll. */
    fun startSignIn(email: String, password: String): GoSignInView {
        // The password lives only in this request object; never stored/logged.
        val payload = gson.toJson(mapOf("email" to email, "password" to password))
        return decode(post("/api/signin", payload))
    }

    /** Poll one sign-in attempt. */
    fun getSignIn(id: String): GoSignInView =
        decode(get("/api/signin/$id"))

    /** Answer the currently waiting step. Body field is "value" (confirmed). */
    fun answerSignIn(id: String, value: String): GoSignInView {
        val payload = gson.toJson(mapOf("value" to value))
        return decode(post("/api/signin/$id", payload))
    }

    /** Cancel a sign-in attempt (always 200, even for unknown ids). */
    fun cancelSignIn(id: String) {
        delete("/api/signin/$id")
    }

    // ---- Status / accounts / locations ----

    fun getStatus(): GoStatus =
        decode(get("/api/status"))

    fun getAccounts(): GoAccountsResponse =
        decode(get("/api/accounts"))

    fun activateAccount(id: String) {
        post("/api/accounts/$id/activate", "{}")
    }

    fun refreshAccount(id: String) {
        post("/api/accounts/$id/refresh", "{}")
    }

    fun deleteAccount(id: String) {
        delete("/api/accounts/$id")
    }

    fun getLocations(): GoLocationsResponse =
        decode(get("/api/locations"))

    /** Ping locations (empty list = all). Result is kept for GET /locations. */
    fun pingLocations(codes: List<String> = emptyList()): GoLocationsResponse =
        decode(
            post(
                "/api/locations/ping",
                gson.toJson(mapOf("codes" to codes)),
                pingClient,
            ),
        )

    /** Select an exit country (empty string = recommended). */
    fun setLocation(country: String) {
        post("/api/location", gson.toJson(mapOf("country" to country)))
    }
}
