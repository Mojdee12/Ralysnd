// BINDING CONFIRMED against the real .aar (javap of core-trial.aar classes.jar,
// 2026-10-30): Java class is `mobile.Mobile`, methods as used below.
// This file is the ONLY place in the app that calls the gomobile-generated
// binding for the Go core (core.aar, built from core/mobile with
// `gomobile bind -target=android -androidapi 24 -trimpath`).
// No other file references the binding directly.
//
// Convention confirmed from the real .aar:
//   Go package `mobile`  -> Java class `mobile.Mobile`
//   Go func `Start`      -> Java static method `start` (lowerCamelCase)
//   Go `int32` fd        -> Java `int`
//   Go `error` return    -> Java `throws Exception`
//
// Go API surface (from core/mobile/mobile.go — factual API, not copied code):
//   Start(dataDir String, on Boolean) throws Exception — daemon start;
//     removes the previous run's token file and writes a fresh one once bound.
//   Stop() — shuts the daemon down (calls StopTun first).
//   Running() Boolean, LastError() String.
//   SetOn(Boolean) — proxy on/off; the daemon and its API keep running.
//   Connect() — turns the proxy on for the user.
//   IsOn() Boolean — false once the core gave up a connect.
//   ProxyAddress() String — e.g. 127.0.0.1:10810, "" when not listening.
//   Speed() String — "down,up" bytes/sec, "0,0" while off.
//   ExitCountry() String — country code, "" while unknown.
//   DirectApps() String — newline-separated package names left out.
//   NetworkChanged(Boolean) — Android network state after a change.
//   StartTun(fd Int) throws Exception — takes over the TUN fd; closes it on
//     failure. The app MUST exclude itself from the VPN.
//   StopTun() — ends the VPN stack and closes its device.
//
// No tokens, emails, passwords, or codes are handled here.

package com.kunk.singbox.gocore

import mobile.Mobile

/**
 * Single adapter over the gomobile binding. All calls are wrapped in
 * [Result] so a binding mismatch surfaces as a clean error, never a crash.
 */
object GoCoreBinding {

    /** Start the daemon with its data in [dataDir] (created when missing). */
    fun start(dataDir: String, on: Boolean): Result<Unit> = runCatching {
        Mobile.start(dataDir, on)
    }

    /** Stop the daemon (also stops the tunnel first, per mobile.go). */
    fun stop(): Result<Unit> = runCatching { Mobile.stop() }

    fun running(): Boolean = runCatching { Mobile.running() }.getOrDefault(false)

    fun lastError(): String = runCatching { Mobile.lastError() }.getOrDefault("")

    fun setOn(on: Boolean): Result<Unit> = runCatching { Mobile.setOn(on) }

    fun connect(): Result<Unit> = runCatching { Mobile.connect() }

    fun isOn(): Boolean = runCatching { Mobile.isOn() }.getOrDefault(false)

    fun proxyAddress(): String = runCatching { Mobile.proxyAddress() }.getOrDefault("")

    fun speed(): String = runCatching { Mobile.speed() }.getOrDefault("0,0")

    fun exitCountry(): String = runCatching { Mobile.exitCountry() }.getOrDefault("")

    fun directApps(): String = runCatching { Mobile.directApps() }.getOrDefault("")

    fun networkChanged(connected: Boolean): Result<Unit> =
        runCatching { Mobile.networkChanged(connected) }

    /** Hand the raw TUN fd to the core. Throws on failure (fd closed by Go). */
    fun startTun(fd: Int): Result<Unit> = runCatching { Mobile.startTun(fd) }

    fun stopTun(): Result<Unit> = runCatching { Mobile.stopTun() }
}
