package com.kunk.singbox.foxy.vpn.socks

import com.kunk.singbox.foxy.data.AppLogger
import com.kunk.singbox.foxy.vpn.RelayDispatchers
import com.kunk.singbox.foxy.vpn.upstream.UpstreamSession
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

private const val TAG = "Socks5UdpDnsRelay"

internal const val DNS_PORT = 53

internal const val MAX_DNS_MESSAGE_BYTES = 4096

private const val SOCKS5_UDP_HEADER_MIN_BYTES = 10

private const val MAX_INFLIGHT_QUERIES = 32

private const val DNS_TOTAL_FAILURE_THRESHOLD = 3

internal class Socks5UdpDnsRelay(
    private val bindAddress: InetAddress,
    private val clientAddress: InetAddress,
    private val socksProxy: InetSocketAddress?,
    private val dohUrl: String? = null,
    private val sessionProvider: () -> UpstreamSession?,
    private val onUnsupportedFlow: () -> Unit = {},
    private val onSessionUnhealthy: () -> Unit = {},
) {

    private val socket = DatagramSocket(0, bindAddress)

    private val inflight = Semaphore(MAX_INFLIGHT_QUERIES)

    private val queriesOverHttps = AtomicInteger(0)
    private val nonDnsDropped = AtomicInteger(0)
    private val foreignSourceDropped = AtomicInteger(0)
    private val otherDropped = AtomicInteger(0)
    private val consecutiveTotalDnsFailures = AtomicInteger(0)
    private val unsupportedFlowReported = AtomicBoolean(false)

    private val exceptionHandler = CoroutineExceptionHandler { _, throwable ->
        AppLogger.d(TAG, "dropped a DNS datagram: ${throwable.message}")
        otherDropped.incrementAndGet()
    }
    private val scope = CoroutineScope(RelayDispatchers.relay + SupervisorJob() + exceptionHandler)

    val boundAddress: InetAddress get() = bindAddress

    val boundPort: Int get() = socket.localPort

    fun start() {
        AppLogger.d(TAG, "started UDP DNS relay on $bindAddress:${socket.localPort}; upstream DoH=${dohUrl ?: "<per-resolver>"}")
        scope.launch {
            val buffer = ByteArray(MAX_DNS_MESSAGE_BYTES + SOCKS5_UDP_HEADER_MIN_BYTES + 256)
            while (!socket.isClosed) {
                val packet = DatagramPacket(buffer, buffer.size)
                try {
                    socket.receive(packet)
                } catch (e: IOException) {
                    break 
                }

                if (packet.address != clientAddress) {
                    if (foreignSourceDropped.getAndIncrement() == 0) {
                        AppLogger.w(
                            TAG,
                            "dropping a datagram from ${packet.address}: this association belongs to " +
                                "$clientAddress, and relaying for anyone else would make this an open resolver",
                        )
                    }
                    continue
                }

                val targetPort = extractTargetPort(packet.data, packet.offset, packet.length)
                if (targetPort != DNS_PORT) {
                    nonDnsDropped.incrementAndGet()
                    if (unsupportedFlowReported.compareAndSet(false, true)) {
                        AppLogger.d(
                            TAG,
                            "dropping a datagram for port $targetPort: this tunnel carries TCP only, so general " +
                                "UDP (QUIC included) cannot be relayed and the sender has to fall back to TCP. " +
                                "The DNS association stays up.",
                        )
                        runCatching { onUnsupportedFlow() }
                    }
                    continue
                }

                val datagram = packet.data.copyOfRange(packet.offset, packet.offset + packet.length)
                val replyTo = InetSocketAddress(packet.address, packet.port)

                if (!inflight.tryAcquire()) {
                    otherDropped.incrementAndGet()
                    continue
                }
                scope.launch {
                    try {
                        relay(datagram, replyTo)
                    } finally {
                        inflight.release()
                    }
                }
            }
        }
    }

    fun stop() {
        runCatching { socket.close() }
        scope.cancel()
        val https = queriesOverHttps.get()
        val nonDns = nonDnsDropped.get()
        val foreign = foreignSourceDropped.get()
        val other = otherDropped.get()

        if (https > 0 || nonDns > 0 || foreign > 0 || other > 0) {
            AppLogger.d(
                TAG,
                "UDP association closed: $https DNS queries over HTTPS, $nonDns non-DNS datagrams dropped, " +
                    "$foreign from unassociated sources, $other other drops",
            )
        }
    }

    private suspend fun relay(datagram: ByteArray, replyTo: InetSocketAddress) {
        val request = parseRequest(datagram)
        if (request == null) {
            otherDropped.incrementAndGet()
            return
        }

        val query = datagram.copyOfRange(request.payloadOffset, datagram.size)
        if (query.isEmpty() || query.size > MAX_DNS_MESSAGE_BYTES) {
            otherDropped.incrementAndGet()
            return
        }

        val session = sessionProvider()?.takeIf { it.isConnected }
        if (session == null) {
            otherDropped.incrementAndGet()
            return
        }

        val answer = resolve(request.host, query)
        if (answer == null) {
            otherDropped.incrementAndGet()
            return
        }

        val response = datagram.copyOfRange(0, request.payloadOffset) + answer
        runCatching { socket.send(DatagramPacket(response, response.size, replyTo)) }
            .onFailure { otherDropped.incrementAndGet() }
    }

    private fun resolve(
        resolverHost: String,
        query: ByteArray,
    ): ByteArray? {
        if (socksProxy == null) return null
        // Fallback chain: the configured endpoint first (unchanged
        // happy path — a first-endpoint success costs no extra
        // attempt), then one primary endpoint per other operator.
        // Endpoints suppressed after repeated failures are skipped
        // unless every candidate is suppressed, so a dead endpoint
        // stops stalling every query after a few failures.
        val first = dohUrl ?: DohDnsClient.endpointFor(resolverHost)
        val candidates = (listOf(first) + DohEndpoints.primaryEndpoints()).distinct()
        val attemptOrder = candidates.filterNot { DohDnsClient.isSuppressed(it) }.ifEmpty { candidates }
        for (endpoint in attemptOrder) {
            val answer = DohDnsClient.query(socksProxy, endpoint, query)
            if (answer != null) {
                queriesOverHttps.incrementAndGet()
                consecutiveTotalDnsFailures.set(0)
                return answer
            }
        }
        // Every candidate failed: the tunnel's DNS is dead as a whole,
        // not just one query. After a few such queries in a row, say
        // so through the existing unhealthy path so the watchdog
        // redials instead of leaving the session "Connected" with
        // no working DNS. The service's own 30s cooldown gates
        // redials; the counter resets here so a still-dead session
        // keeps being reported.
        val failures = consecutiveTotalDnsFailures.incrementAndGet()
        if (failures >= DNS_TOTAL_FAILURE_THRESHOLD) {
            consecutiveTotalDnsFailures.set(0)
            AppLogger.w(
                TAG,
                "all DoH endpoints failed for $failures DNS queries in a row; " +
                    "reporting the upstream session as unhealthy",
            )
            runCatching { onSessionUnhealthy() }
        }
        return null
    }

    private class Request(val payloadOffset: Int, val host: String, val port: Int)

    private fun parseRequest(datagram: ByteArray): Request? {
        if (datagram.size < SOCKS5_UDP_HEADER_MIN_BYTES) return null

        if (datagram[0].toInt() != 0 || datagram[1].toInt() != 0) return null

        if (datagram[2].toInt() != 0) return null

        var offset = 3
        val addressType = datagram[offset++].toInt() and 0xFF
        val host = when (addressType) {
            0x01 -> {
                if (datagram.size < offset + 4 + 2) return null
                val bytes = datagram.copyOfRange(offset, offset + 4)
                offset += 4
                bytes.joinToString(".") { (it.toInt() and 0xFF).toString() }
            }
            0x03 -> {
                val length = datagram[offset++].toInt() and 0xFF
                if (length == 0) return null
                if (datagram.size < offset + length + 2) return null
                val name = String(datagram, offset, length, Charsets.US_ASCII)
                offset += length
                name
            }
            0x04 -> {
                if (datagram.size < offset + 16 + 2) return null
                val bytes = datagram.copyOfRange(offset, offset + 16)
                offset += 16
                InetAddress.getByAddress(bytes).hostAddress ?: return null
            }
            else -> return null
        }
        val port = ((datagram[offset].toInt() and 0xFF) shl 8) or (datagram[offset + 1].toInt() and 0xFF)
        offset += 2
        return Request(offset, host, port)
    }

    private fun extractTargetPort(data: ByteArray, offset: Int, length: Int): Int {
        if (length < SOCKS5_UDP_HEADER_MIN_BYTES) return -1
        if (data[offset].toInt() != 0 || data[offset + 1].toInt() != 0 || data[offset + 2].toInt() != 0) return -1
        var pos = offset + 3
        val addressType = data[pos++].toInt() and 0xFF
        when (addressType) {
            0x01 -> pos += 4
            0x03 -> {
                if (pos >= offset + length) return -1
                val domainLen = data[pos++].toInt() and 0xFF
                pos += domainLen
            }
            0x04 -> pos += 16
            else -> return -1
        }
        if (pos + 2 > offset + length) return -1
        return ((data[pos].toInt() and 0xFF) shl 8) or (data[pos + 1].toInt() and 0xFF)
    }
}
