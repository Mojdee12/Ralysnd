package com.kunk.singbox.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kunk.singbox.engines.ENGINE_GRID
import com.kunk.singbox.engines.EngineId
import com.kunk.singbox.engines.EnginesViewModel
import com.kunk.singbox.engines.MasqueExitMode
import com.kunk.singbox.engines.MasqueExitSelection
import com.kunk.singbox.model.NodeUi
import com.kunk.singbox.ui.navigation.Screen
import java.util.Locale
import com.kunk.singbox.ui.theme.L4EngineTile
import com.kunk.singbox.ui.theme.L4Green
import com.kunk.singbox.ui.theme.L4GreenDark
import com.kunk.singbox.ui.theme.L4Surface
import com.kunk.singbox.ui.theme.L4SurfaceAlt
import com.kunk.singbox.ui.theme.L4PastelAmber
import com.kunk.singbox.ui.theme.L4PastelCyan
import com.kunk.singbox.ui.theme.L4PastelRose
import com.kunk.singbox.ui.theme.L4PastelSlate
import com.kunk.singbox.ui.theme.L4PastelViolet
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim

/**
 * Home engine grid (mlm-style, sample-4 light tiles) + per-engine
 * sheets. Only wanted engines appear here — no rejected engine has
 * a tile, placeholder, or reserved space. Plain WARP is NOT a
 * user-facing engine anymore: the grid is MASQUE, WARP², Psiphon,
 * WireGuard, FENIX, in that order. The WARP identity and
 * registration code still exist underneath because WARP² needs
 * them as its outer layer — but the user never sees a plain-WARP
 * tile, sheet, or label.
 *
 * Wiring (honest):
 * - WireGuard -> Nodes screen (existing nodes).
 * - FENIX -> FENIX tab (existing Foxy tunnel).
 * - WARP² -> ONE TAP, no typing: registers a WARP identity
 *   if none is stored, builds the two-outbound chain (outer WARP
 *   + inner WireGuard with detour, MTU 1220) from one of the
 *   user's own WireGuard nodes, selects the inner node, and
 *   starts it through the normal Dashboard path. Connected status
 *   is the real sing-box state. Disconnect is the normal
 *   Dashboard stop. Manual host/port/key entry survives only
 *   behind Advanced. No JSON copy step.
 * - MASQUE -> exit-country screen: IPv6 NAT64 / IPv4 proxy
 *   toggle, Ping every country over the gateway pool grouped by
 *   geolocated country, Fastest, Direct (live connect needs a
 *   QUIC core — stated in the sheet, no connect button).
 * - Psiphon -> auto-fetched public server list (zlib-aware) +
 *   regions with measured pings (live connect needs the official
 *   Go core — stated, no button).
 */
@Composable
fun EngineGridSection(
    onNavigate: (String) -> Unit,
    onAddNode: (String) -> Unit,
    onOpenScanner: () -> Unit,
    enginesViewModel: EnginesViewModel = viewModel(),
    /** Called with the inner node id when a WARP² chain is ready; the caller selects it and starts the service. */
    onConnectNode: (String) -> Unit = {},
    /** The user's nodes, so WARP² can offer its own WireGuard nodes with zero typing. */
    nodes: List<NodeUi> = emptyList(),
) {
    var sheet by remember { mutableStateOf<EngineId?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Engines", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = L4Text)
            TextButton(onClick = onOpenScanner) { Text("Scanner", color = L4Green) }
        }
        for (row in ENGINE_GRID.chunked(2)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (engine in row) {
                    L4EngineTile(
                        title = engine.title,
                        subtitle = engine.statusNote,
                        pastel = when (engine.id) {
                            EngineId.MASQUE -> L4PastelCyan
                            EngineId.WARP2 -> L4PastelAmber
                            EngineId.PSIPHON -> L4PastelRose
                            EngineId.WIREGUARD -> L4PastelSlate
                            EngineId.FENIX -> L4PastelViolet
                        },
                        badge = engine.badge,
                        enabled = true,
                        onClick = {
                            when (engine.id) {
                                EngineId.WIREGUARD -> onNavigate(Screen.Nodes.route)
                                EngineId.FENIX -> onNavigate(Screen.Fenix.route)
                                else -> sheet = engine.id
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (row.size == 1) Spacer(modifier = Modifier.weight(1f))
            }
        }
    }

    when (sheet) {
        EngineId.WARP2 -> Warp2Sheet(enginesViewModel = enginesViewModel, onConnectNode = onConnectNode, onDismiss = { sheet = null }, nodes = nodes, onOpenNodes = { onNavigate(Screen.Nodes.route) })
        EngineId.MASQUE -> MasqueSheet(enginesViewModel = enginesViewModel, onDismiss = { sheet = null })
        EngineId.PSIPHON -> PsiphonSheet(enginesViewModel = enginesViewModel, onDismiss = { sheet = null })
        else -> Unit
    }
}


/** Flag emoji for an ISO country code, computed from regional indicators — no hard-coded flag list. */
private fun flagForCountryCode(code: String): String {
    val upper = code.uppercase()
    if (upper.length != 2 || !upper.all { it in 'A'..'Z' }) return "🌍"
    return upper.map { char -> String(Character.toChars(0x1F1E6 + (char - 'A'))) }.joinToString("")
}

private fun countryNameForCode(code: String): String {
    return Locale("", code).displayCountry.takeIf { it.isNotBlank() } ?: code
}

@Composable
private fun Warp2Sheet(
    enginesViewModel: EnginesViewModel,
    onConnectNode: (String) -> Unit,
    onDismiss: () -> Unit,
    nodes: List<NodeUi> = emptyList(),
    onOpenNodes: () -> Unit = {},
) {
    val identity by enginesViewModel.warpIdentity.collectAsStateWithLifecycle()
    val busy by enginesViewModel.warp2Busy.collectAsStateWithLifecycle()
    val error by enginesViewModel.warp2Error.collectAsStateWithLifecycle()
    val relay by enginesViewModel.warp2WorkerRelay.collectAsStateWithLifecycle()
    val relayUrl by enginesViewModel.warp2WorkerRelayUrl.collectAsStateWithLifecycle()
    val report by enginesViewModel.warp2Report.collectAsStateWithLifecycle()
    var showAdvanced by remember { mutableStateOf(false) }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("51820") }
    var serverKey by remember { mutableStateOf("") }
    var privateKey by remember { mutableStateOf("") }
    val wireguardNodes = nodes.filter { it.protocol == "wireguard" }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("WARP in WARP", color = L4Text) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                Text(
                    text = "One tap, no typing: your WARP identity is registered automatically if you do not have one yet, then the chain is built from one of your own WireGuard servers and the tunnel starts. Disconnect from the Dashboard like any other connection.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                if (identity == null) {
                    Text(
                        text = "No WARP identity stored yet — one will be registered automatically when you connect.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                }
                if (error != null) Text(text = error ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Make identity through worker",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4Text,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(checked = relay, onCheckedChange = { enginesViewModel.setWarp2WorkerRelay(it) })
                }
                Text(
                    text = "Off by default. Only turn this on once if making an identity is filtered on your network.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                if (relay) {
                    OutlinedTextField(
                        value = relayUrl,
                        onValueChange = { enginesViewModel.setWarp2WorkerRelayUrl(it) },
                        label = { Text("Your worker relay URL") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                    if (relayUrl.isBlank()) {
                        Text(
                            text = "No relay is built into this app — with this on and no URL set, connecting will stop and say so.",
                            style = MaterialTheme.typography.bodySmall,
                            color = L4TextDim,
                        )
                    }
                }
                Text(text = "Exit country", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = L4Text)
                Text(
                    text = "Direct connection — no country change. The inner server's own location is the exit; filtered sites open through the two layers.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                Text(text = "How this works", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = L4Text)
                Text(
                    text = "A WireGuard tunnel carried inside a WARP tunnel — two layers instead of one. It is slower to establish, and the reason to reach for it is a network that blocks either layer on its own.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                Text(text = "Your WireGuard servers", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = L4Text)
                if (wireguardNodes.isEmpty()) {
                    Text(
                        text = "No WireGuard servers yet — add one from Nodes, then come back here and tap it. Nothing needs to be typed here.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                    Button(
                        onClick = onOpenNodes,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                    ) { Text("Open Nodes") }
                } else {
                    for (node in wireguardNodes) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = node.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = L4Text)
                                Text(
                                    text = (node.group.takeIf { it.isNotBlank() } ?: "Default") +
                                        " · " + (node.latencyMs?.let { "$it ms" } ?: "not tested yet"),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = L4TextDim,
                                )
                            }
                            Button(
                                onClick = {
                                    enginesViewModel.connectWarp2FromNode(node.id) { nodeId ->
                                        onConnectNode(nodeId)
                                        onDismiss()
                                    }
                                },
                                enabled = !busy,
                                colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                            ) { Text(if (busy) "…" else "Connect") }
                        }
                    }
                }
                Text(text = "Settings", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = L4Text)
                TextButton(onClick = { showAdvanced = !showAdvanced }) {
                    Text(if (showAdvanced) "Hide advanced settings" else "Advanced settings", color = L4Green)
                }
                if (showAdvanced) {
                    Text(
                        text = "Manual inner server (only if you have no WireGuard node saved): type its details once and tap Connect WARP².",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                    OutlinedTextField(value = host, onValueChange = { host = it }, label = { Text("Inner server host") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = port, onValueChange = { port = it }, label = { Text("Inner server port") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = serverKey, onValueChange = { serverKey = it }, label = { Text("Inner server public key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = privateKey, onValueChange = { privateKey = it }, label = { Text("Your inner private key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(
                        onClick = {
                            val p = port.toIntOrNull() ?: 51820
                            if (host.isNotBlank() && serverKey.isNotBlank() && privateKey.isNotBlank()) {
                                enginesViewModel.connectWarp2(host, p, serverKey, privateKey) { nodeId ->
                                    onConnectNode(nodeId)
                                    onDismiss()
                                }
                            }
                        },
                        enabled = !busy && host.isNotBlank() && serverKey.isNotBlank() && privateKey.isNotBlank(),
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                    ) { Text(if (busy) "Connecting…" else "Connect WARP²") }
                }
                Text(
                    text = "Connection report: ${report.attempts} attempts" +
                        (report.lastOutcome?.let { " · last: $it" } ?: ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun MasqueSheet(
    enginesViewModel: EnginesViewModel,
    onDismiss: () -> Unit,
) {
    val countries by enginesViewModel.masqueCountries.collectAsStateWithLifecycle()
    val pinging by enginesViewModel.masquePinging.collectAsStateWithLifecycle()
    val mode by enginesViewModel.masqueExitMode.collectAsStateWithLifecycle()
    val selection by enginesViewModel.masqueSelection.collectAsStateWithLifecycle()
    val fastest = enginesViewModel.masqueFastest
    var manual by remember { mutableStateOf("") }
    var showAdvanced by remember { mutableStateOf(false) }
    // Zero input: ping the gateway pool as soon as the sheet opens.
    LaunchedEffect(Unit) {
        if (countries.isEmpty()) enginesViewModel.pingMasqueCountries()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("MASQUE — Exit country", color = L4Text) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { enginesViewModel.setMasqueExitMode(MasqueExitMode.IPV6_NAT64) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (mode == MasqueExitMode.IPV6_NAT64) L4Green else L4SurfaceAlt,
                            contentColor = if (mode == MasqueExitMode.IPV6_NAT64) L4Surface else L4Text,
                        ),
                    ) { Text("IPv6 · NAT64 gateway") }
                    Button(
                        onClick = { enginesViewModel.setMasqueExitMode(MasqueExitMode.IPV4_PROXY) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (mode == MasqueExitMode.IPV4_PROXY) L4Green else L4SurfaceAlt,
                            contentColor = if (mode == MasqueExitMode.IPV4_PROXY) L4Surface else L4Text,
                        ),
                    ) { Text("IPv4 · proxy") }
                }
                Button(
                    onClick = { enginesViewModel.pingMasqueCountries() },
                    enabled = !pinging,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text(if (pinging) "Pinging…" else "Ping every country") }
                Text(
                    text = "A short real connection to each gateway: ping, speed where measurable, and whether it works.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                MasqueExitRow(
                    title = "Direct connection",
                    subtitle = "No country change, and the fastest route. Filtered sites open without a MASQUE exit.",
                    selected = selection is MasqueExitSelection.Direct,
                    onClick = { enginesViewModel.selectMasqueExit(MasqueExitSelection.Direct) },
                )
                MasqueExitRow(
                    title = "Fastest country",
                    subtitle = fastest?.let { "${flagForCountryCode(it.code)} ${it.name} · ${it.bestRttMs} ms" }
                        ?: "Automatic: the country that was fastest in the last ping.",
                    selected = selection is MasqueExitSelection.Fastest,
                    onClick = { enginesViewModel.selectMasqueExit(MasqueExitSelection.Fastest) },
                )
                Text(text = "Countries", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = L4Text)
                if (countries.isEmpty() && !pinging) {
                    Text(
                        text = "No gateways measured yet — tap Ping every country, or add a gateway below in Advanced.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                }
                for (country in countries) {
                    MasqueExitRow(
                        title = "${flagForCountryCode(country.code)} ${country.name}",
                        subtitle = "${country.serverCount} servers · " +
                            if (country.reachable) {
                                "${country.bestRttMs} ms" + (country.speedKbps?.let { " · ${it.toInt()} KB/s" } ?: "")
                            } else {
                                "not tested yet"
                            },
                        selected = selection is MasqueExitSelection.Country &&
                            (selection as MasqueExitSelection.Country).code == country.code,
                        onClick = { enginesViewModel.selectMasqueExit(MasqueExitSelection.Country(country.code)) },
                    )
                }
                Text(
                    text = "Live MASQUE tunnel needs a QUIC core (HTTP/3 CONNECT-UDP) that this build does not include — so there is no connect button here yet, and nothing pretends to be connected. Gateway discovery, ping, fastest, and the exit choice above are real and are stored for when that core lands. Countries shown are geolocated gateways from the pool (cached winner, your endpoints, and one documented public Cloudflare edge), never an assumed list.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                TextButton(onClick = { showAdvanced = !showAdvanced }) {
                    Text(if (showAdvanced) "Hide advanced" else "Advanced", color = L4Green)
                }
                if (showAdvanced) {
                    OutlinedTextField(value = manual, onValueChange = { manual = it }, label = { Text("Gateway endpoint (host or host:port)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    TextButton(onClick = {
                        if (manual.isNotBlank()) {
                            enginesViewModel.setMasqueManualEndpoint(manual)
                            enginesViewModel.pingMasqueCountries()
                            manual = ""
                        }
                    }) { Text("Add gateway and ping", color = L4Green) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun MasqueExitRow(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = L4Text)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = L4TextDim)
        }
        if (selected) {
            Text(text = "✓", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = L4GreenDark)
        }
        TextButton(onClick = onClick) { Text(if (selected) "Selected" else "Select", color = L4Green) }
    }
}

@Composable
private fun PsiphonSheet(
    enginesViewModel: EnginesViewModel,
    onDismiss: () -> Unit,
) {
    val summary by enginesViewModel.psiphonSummary.collectAsStateWithLifecycle()
    val busy by enginesViewModel.psiphonBusy.collectAsStateWithLifecycle()
    val error by enginesViewModel.psiphonError.collectAsStateWithLifecycle()
    val regionPings by enginesViewModel.psiphonRegionPings.collectAsStateWithLifecycle()
    val regionPinging by enginesViewModel.psiphonRegionPinging.collectAsStateWithLifecycle()
    // Zero input: fetch the public list as soon as the sheet opens.
    LaunchedEffect(Unit) {
        if (summary == null && !busy) enginesViewModel.fetchPsiphonList()
    }
    // Ping one server per region as soon as a list exists.
    LaunchedEffect(summary) {
        if (summary != null) enginesViewModel.probePsiphonRegions()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Psiphon", color = L4Text) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                Text(
                    text = "Real servers from the public Psiphon server list, grouped by region, each with a measured ping. No account needed.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                if (error != null) Text(text = error ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Button(
                    onClick = { enginesViewModel.fetchPsiphonList() },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text(if (busy) "Downloading…" else "Refresh server list") }
                summary?.let { s ->
                    Text(
                        text = "List: ${s.bytesDownloaded} bytes · ${s.entryCount ?: 0} servers" +
                            (s.regions.takeIf { it.isNotEmpty() }?.let { " · ${it.size} regions" } ?: ""),
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                    if (s.regionServers.isEmpty()) {
                        Text(
                            text = "No regions parsed from this list — tap Refresh; if it repeats, the list format has changed.",
                            style = MaterialTheme.typography.bodySmall,
                            color = L4TextDim,
                        )
                    }
                    for (rs in s.regionServers) {
                        val ping = regionPings[rs.code]
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${flagForCountryCode(rs.code)} ${countryNameForCode(rs.code)}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = L4Text,
                                )
                                Text(
                                    text = "${rs.ips.size} sampled servers · " +
                                        when {
                                            ping == null && regionPinging -> "pinging…"
                                            ping == null -> "not tested yet"
                                            ping.reachable -> "${ping.rttMs} ms"
                                            else -> "unreachable"
                                        },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = L4TextDim,
                                )
                            }
                        }
                    }
                    if (s.regionServers.isNotEmpty() && regionPinging) {
                        Text(text = "Pinging regions…", style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                    }
                } ?: run {
                    if (!busy && error == null) {
                        Text(text = "Fetching the server list…", style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                    }
                }
                Text(
                    text = "A live Psiphon tunnel needs the official Go Psiphon core, which is not in this build — so there is no connect button here, and nothing pretends to be connected. The servers and pings above are real.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
