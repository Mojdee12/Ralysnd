package com.kunk.singbox.engines

import android.content.Context
import com.tencent.mmkv.MMKV

/**
 * Local, real connection report for WARP² (the reference screen's
 * "Connection report" row). Counts only actual attempts made from
 * this app — never a sample number. The count is the number of
 * times the user tapped Connect WARP²; the last outcome is the
 * real result of the most recent attempt.
 */
data class Warp2Report(
    val attempts: Int,
    val lastOutcome: String?,
    val lastAtMs: Long,
)

class ConnectionReport(context: Context) {
    private val kv = MMKV.mmkvWithID("ralysnd_conn_report", MMKV.SINGLE_PROCESS_MODE)

    fun warp2Report(): Warp2Report = Warp2Report(
        attempts = kv.decodeInt("warp2_attempts", 0),
        lastOutcome = kv.decodeString("warp2_last_outcome", "")?.takeIf { it.isNotBlank() },
        lastAtMs = kv.decodeLong("warp2_last_at", 0L),
    )

    fun recordWarp2Attempt(success: Boolean, error: String? = null) {
        kv.encode("warp2_attempts", kv.decodeInt("warp2_attempts", 0) + 1)
        kv.encode("warp2_last_outcome", if (success) "Connected" else (error ?: "Failed"))
        kv.encode("warp2_last_at", System.currentTimeMillis())
    }
}
