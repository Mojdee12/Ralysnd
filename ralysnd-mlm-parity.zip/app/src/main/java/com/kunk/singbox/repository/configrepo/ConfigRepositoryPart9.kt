@file:Suppress("UnusedImports", "TooManyFunctions", "LongMethod", "LargeClass", "Indentation", "InvalidPackageDeclaration", "MaxLineLength", "LoopWithTooManyJumpStatements", "CognitiveComplexMethod", "ComplexCondition", "CyclomaticComplexMethod", "EmptyCatchBlock", "NestedBlockDepth", "ReturnCount", "SwallowedException", "TooGenericExceptionThrown", "UnusedParameter", "UnusedPrivateProperty", "VariableNaming", "NoUnusedImports", "MayBeCons")

package com.kunk.singbox.repository

import android.content.Intent
import android.util.Log
import com.kunk.singbox.R
import com.kunk.singbox.ipc.SingBoxRemote
import com.kunk.singbox.ipc.VpnStateStore
import com.kunk.singbox.model.*
import com.kunk.singbox.repository.config.NodeLinkExporter
import com.kunk.singbox.service.ProxyOnlyService
import com.kunk.singbox.service.SingBoxService
import com.kunk.singbox.service.root.RootTransparentForegroundService
import com.kunk.singbox.service.manager.VpnStopInitiator
import java.io.File
import java.util.UUID
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

internal suspend fun ConfigRepository.getActiveConfig(): SingBoxConfig? = withContext(Dispatchers.IO) {
    val id = _activeProfileId.value ?: return@withContext null
    loadConfig(id)
}

internal fun ConfigRepository.getConfig(profileId: String): SingBoxConfig? {
    return loadConfig(profileId)
}

internal suspend fun ConfigRepository.readProfileConfigContent(profileId: String): Result<String> = withContext(Dispatchers.IO) {
    runCatching {
        require(_profiles.value.any { it.id == profileId }) { "Profile not found" }

        val configFile = File(configDir, "$profileId.json")
        if (configFile.exists()) {
            return@runCatching configFile.readText(Charsets.UTF_8)
        }

        val config = loadConfig(profileId) ?: throw IllegalStateException("Config not found")
        gson.toJson(config)
    }
}

internal suspend fun ConfigRepository.updateProfileConfigContent(profileId: String, content: String): Result<ProfileUi> =
    withContext(Dispatchers.IO) {
        runCatching {
            require(content.isNotBlank()) { context.getString(R.string.profiles_content_empty) }

            val existingProfile = _profiles.value.find { it.id == profileId }
                ?: throw IllegalArgumentException("Profile not found")
            val parsedConfig = gson.fromJson(content, SingBoxConfig::class.java)
                ?: throw IllegalArgumentException(context.getString(R.string.profiles_parse_failed))
            val deduplicatedConfig = deduplicateTags(parsedConfig)
            val nodes = extractNodesFromConfig(deduplicatedConfig, profileId, {})
            require(nodes.isNotEmpty()) { context.getString(R.string.profiles_parse_failed) }

            writeConfigFileOrThrow(profileId, deduplicatedConfig)
            cacheConfig(profileId, deduplicatedConfig)
            profileNodes[profileId] = nodes
            updateAllNodesAndGroups()
            if (_activeProfileId.value == profileId) {
                applyActiveProfileNodes(profileId, nodes)
            }

            val updatedProfile = existingProfile.copy(lastUpdated = System.currentTimeMillis())
            _profiles.update { list ->
                list.map { profile ->
                    if (profile.id == profileId) updatedProfile else profile
                }
            }
            saveProfiles()

            updatedProfile
        }
    }

internal fun ConfigRepository.resolveDnsStrategy(strategy: DnsStrategy, mode: IpVersionMode): String {
    return mode.resolveDnsStrategy(strategy)
}

/**
 * 直连 DNS 策略：双栈 + AUTO 时强制 ipv4_only。
 * prefer_ipv4 仍会返回 AAAA，无公网 IPv6 时 geosite-cn 直连会 network unreachable。
 * 已保存为 AUTO 的旧配置也会走此路径。
 */
internal fun ConfigRepository.resolveDirectDnsStrategy(strategy: DnsStrategy, mode: IpVersionMode): String {
    return ConfigRepository.resolveDirectDnsStrategy(strategy, mode)
}

internal fun ConfigRepository.logOutboundServerAddressStrategy(
    scope: String,
    strategy: DnsStrategy,
    ipVersionMode: IpVersionMode,
    resolvedStrategy: String
) {
    val message = ConfigRepository.buildOutboundServerAddressStrategyLog(
        scope = scope,
        strategy = strategy,
        ipVersionMode = ipVersionMode,
        resolvedStrategy = resolvedStrategy
    )
    Log.i(ConfigRepository.TAG, message)
    LogRepository.getInstance().addLog(message)
}

internal suspend fun ConfigRepository.getOutboundByNodeId(nodeId: String): Outbound? = withContext(Dispatchers.IO) {
    val node = _nodes.value.find { it.id == nodeId } ?: return@withContext null
    val config = loadConfig(node.sourceProfileId) ?: return@withContext null
    config.outbounds?.find { it.tag == node.name }
}

internal fun ConfigRepository.getNodeById(nodeId: String): NodeUi? {
    _nodes.value.find { it.id == nodeId }?.let { return it }
    for ((_, nodes) in profileNodes) {
        nodes.find { it.id == nodeId }?.let { return it }
    }
    _allNodes.value.find { it.id == nodeId }?.let { return it }

    return null
}

@Suppress("ReturnCount")
internal fun ConfigRepository.getNodeByName(nodeName: String): NodeUi? {
    _nodes.value.find { it.name == nodeName }?.let { return it }
    for ((_, nodes) in profileNodes) {
        nodes.find { it.name == nodeName }?.let { return it }
    }
    _allNodes.value.find { it.name == nodeName }?.let { return it }

    return null
}

internal fun ConfigRepository.createNode(
    outbound: Outbound,
    targetProfileId: String? = null,
    newProfileName: String? = null) {
    var createdProfileId: String? = null
    try {
        val profileId: String
        val existingConfig: SingBoxConfig?
        var targetProfile: ProfileUi? = null
        val finalProfileName: String

        when {
            targetProfileId != null -> {
                targetProfile = _profiles.value.find { it.id == targetProfileId }
                if (targetProfile != null) {
                    profileId = targetProfileId
                    existingConfig = loadConfig(profileId)
                    finalProfileName = targetProfile.name
                } else {
                    profileId = UUID.randomUUID().toString()
                    existingConfig = null
                    finalProfileName = "Manual"
                    createdProfileId = profileId
                }
            }
            newProfileName != null -> {
                profileId = UUID.randomUUID().toString()
                existingConfig = null
                finalProfileName = newProfileName
                createdProfileId = profileId
            }
            else -> {
                val manualProfileName = "Manual"
                targetProfile = _profiles.value.find { it.name == manualProfileName && it.type == ProfileType.Imported }
                if (targetProfile != null) {
                    profileId = targetProfile.id
                    existingConfig = loadConfig(profileId)
                } else {
                    profileId = UUID.randomUUID().toString()
                    existingConfig = null
                    createdProfileId = profileId
                }
                finalProfileName = manualProfileName
            }
        }
        val newOutbounds = mutableListOf<Outbound>()
        existingConfig?.outbounds?.let { existing ->
            newOutbounds.addAll(existing.filter { it.type !in listOf("direct", "block", "dns") })
        }
        var finalTag = outbound.tag
        var counter = 1
        while (newOutbounds.any { it.tag == finalTag }) {
            finalTag = "${outbound.tag}_$counter"
            counter++
        }
        val finalOutbound = if (finalTag != outbound.tag) outbound.copy(tag = finalTag) else outbound
        newOutbounds.add(finalOutbound)
        if (newOutbounds.none { it.tag == "direct" }) {
            newOutbounds.add(Outbound(type = "direct", tag = "direct"))
        }
        val newConfig = deduplicateTags(
            ConfigRepository.buildConfigWithOutboundsPreservingProfileSettings(existingConfig, newOutbounds)
        )

        writeConfigFileOrThrow(profileId, newConfig)

        cacheConfig(profileId, newConfig)

        if (targetProfile == null) {
            targetProfile = ProfileUi(
                id = profileId,
                name = finalProfileName,
                type = ProfileType.Imported,
                url = null,
                lastUpdated = System.currentTimeMillis(),
                enabled = true,
                updateStatus = UpdateStatus.Idle
            )
            _profiles.update { it + targetProfile }
        } else {
            _profiles.update { list ->
                list.map { if (it.id == profileId) it.copy(lastUpdated = System.currentTimeMillis()) else it }
            }
        }

        scope.launch {
            val nodes = extractNodesFromConfig(newConfig, profileId)
            profileNodes[profileId] = nodes
            val addedNode = nodes.find { it.name == finalTag }
            if (ConfigRepository.shouldActivateCreatedNode(_activeProfileId.value)) {
                _activeProfileId.value = profileId
                applyActiveProfileNodes(profileId, nodes, addedNode?.id)
            } else if (_activeProfileId.value == profileId) {
                applyActiveProfileNodes(profileId, nodes)
            }
            updateAllNodesAndGroups()

            saveProfiles()
            Log.i(ConfigRepository.TAG, "Created node: $finalTag in profile $profileId")
        }
    } catch (e: Exception) {
        createdProfileId?.let { rollbackTransientProfileFile(it) }
        Log.e(ConfigRepository.TAG, "Failed to create node", e)
    }
}

internal suspend fun ConfigRepository.deleteNode(nodeId: String) = withContext(Dispatchers.IO) {
    val node = getNodeById(nodeId) ?: return@withContext
    val profileId = node.sourceProfileId
    val config = loadConfig(profileId) ?: return@withContext
    val newConfig = removeOutboundFromConfig(config, node.name)
    val allNodesSnapshot = _allNodes.value.takeIf { it.isNotEmpty() } ?: loadAllNodesSnapshot()
    val remainingNodes = allNodesSnapshot.filter { it.id != node.id }
    val deletedNodeReferences = buildSet {
        add("${node.sourceProfileId}::${node.name}")
        if (remainingNodes.none { it.name == node.name }) add(node.name)
    }
    val runtimeTags = NodeProtectionStore.runtimeMappings()
        .filterValues { reference -> reference.nodeId == node.id }
        .keys
    try {
        writeConfigFileOrThrow(profileId, newConfig)
        cacheConfig(profileId, newConfig)
        check(
            settingsRepository.removeDeletedRoutingReferences(
                deletedNodeIds = setOf(node.id),
                deletedNodeReferences = deletedNodeReferences
            )
        ) { "Failed to remove routing references for deleted node ${node.name}" }
    } catch (error: Exception) {
        runCatching {
            writeConfigFileOrThrow(profileId, config)
            cacheConfig(profileId, config)
        }.onFailure(error::addSuppressed)
        throw error
    }
    removeNodeLatencies(listOf(nodeId))
    nodeAutoSelectionMmkv.removeValueForKey(nodeId)
    NodeProtectionStore.removeNode(nodeId)
    if (runtimeTags.isNotEmpty()) lastTagToNodeName = lastTagToNodeName - runtimeTags

    val immediateNodes = (profileNodes[profileId]
        ?: allNodesSnapshot.filter { it.sourceProfileId == profileId })
        .filter { it.id != nodeId }
    applyDeletedNodeSnapshot(profileId, nodeId, immediateNodes)
    val newNodes = extractNodesFromConfig(newConfig, profileId)
    applyDeletedNodeSnapshot(profileId, nodeId, newNodes)
    saveProfiles()
    reloadRuntimeAfterDestructiveMutation("node_deleted")
}

internal suspend fun ConfigRepository.removeNodeLatencies(nodeIds: Collection<String>) {
    val distinctNodeIds = nodeIds.distinct()
    if (distinctNodeIds.isEmpty()) return

    distinctNodeIds.forEach(savedNodeLatencies::remove)
    try {
        nodeLatencyDao.deleteByNodeIds(distinctNodeIds)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Log.w(ConfigRepository.TAG, "Failed to delete persisted node latencies", e)
    }
}

internal fun ConfigRepository.migrateNodeSelectionState(
    profileId: String,
    oldNodeId: String,
    newNodeId: String,
    newNodeName: String
) {
    if (getProfileLastSelectedNode(profileId) == oldNodeId) {
        saveProfileNodeMemory(profileId, newNodeId)
    }
    if (_activeNodeId.value == oldNodeId) {
        _activeNodeId.value = newNodeId
    }
    if (VpnStateStore.getSelectedNodeId() == oldNodeId) {
        VpnStateStore.setSelectedNode(profileId, newNodeId)
        VpnStateStore.setSelectedNodeLabel(newNodeName)
    }
}

internal suspend fun ConfigRepository.migrateNodeLatency(oldNodeId: String, newNodeId: String) {
    if (oldNodeId == newNodeId) return
    val latency = savedNodeLatencies.remove(oldNodeId) ?: return
    savedNodeLatencies[newNodeId] = latency
    runCatching {
        nodeLatencyDao.upsert(newNodeId, latency.latencyMs, latency.testedAt)
        nodeLatencyDao.deleteByNodeIds(listOf(oldNodeId))
    }.onFailure { error ->
        Log.w(ConfigRepository.TAG, "Failed to migrate persisted node latency", error)
    }
}

internal fun ConfigRepository.applyDeletedNodeSnapshot(profileId: String, deletedNodeId: String, nodes: List<NodeUi>) {
    profileNodes[profileId] = nodes
    updateAllNodesAndGroups()
    val fallbackNode = nodes.minByOrNull(NodeUi::id)
    if (getProfileLastSelectedNode(profileId) == deletedNodeId) {
        if (fallbackNode == null) {
            profileLastSelectedNode.remove(profileId)
            profileNodeMemoryMmkv.removeValueForKey(profileId)
        } else {
            saveProfileNodeMemory(profileId, fallbackNode.id)
        }
    }
    if (_activeProfileId.value != profileId) return

    _nodes.value = nodes
    if (_activeNodeId.value == deletedNodeId) {
        _activeNodeId.value = fallbackNode?.id
    }
    val selectedName = nodes.firstOrNull { it.id == _activeNodeId.value }?.name
    persistMainProcessSelection(profileId, _activeNodeId.value, selectedName)
}

internal suspend fun ConfigRepository.addSingleNode(
    link: String,
    targetProfileId: String? = null,
    newProfileName: String? = null): Result<NodeUi> = withContext(Dispatchers.IO) {
    var createdProfileId: String? = null
    try {
        val outbound = parseNodeLink(link.trim())
            ?: return@withContext Result.failure(Exception("Failed to parse node link"))

        val profileId: String
        val existingConfig: SingBoxConfig?
        var isNewProfile = false

        when {
            targetProfileId != null -> {
                val profile = _profiles.value.find { it.id == targetProfileId }
                if (profile == null) {
                    return@withContext Result.failure(Exception("Profile not found"))
                }
                profileId = targetProfileId
                existingConfig = loadConfig(profileId)
            }
            newProfileName != null -> {
                profileId = UUID.randomUUID().toString()
                existingConfig = null
                isNewProfile = true
                createdProfileId = profileId
            }
            else -> {
                val manualProfileName = "Manual"
                val manualProfile = _profiles.value.find { it.name == manualProfileName && it.type == ProfileType.Imported }
                if (manualProfile != null) {
                    profileId = manualProfile.id
                    existingConfig = loadConfig(profileId)
                } else {
                    profileId = UUID.randomUUID().toString()
                    existingConfig = null
                    isNewProfile = true
                    createdProfileId = profileId
                }
            }
        }

        val newOutbounds = mutableListOf<Outbound>()
        existingConfig?.outbounds?.let { existing ->
            newOutbounds.addAll(existing.filter { it.type !in listOf("direct", "block", "dns") })
        }

        var finalTag = outbound.tag
        var counter = 1
        while (newOutbounds.any { it.tag == finalTag }) {
            finalTag = "${outbound.tag}_$counter"
            counter++
        }
        val finalOutbound = if (finalTag != outbound.tag) outbound.copy(tag = finalTag) else outbound
        newOutbounds.add(finalOutbound)

        if (newOutbounds.none { it.tag == "direct" }) {
            newOutbounds.add(Outbound(type = "direct", tag = "direct"))
        }
        val newConfig = deduplicateTags(
            ConfigRepository.buildConfigWithOutboundsPreservingProfileSettings(existingConfig, newOutbounds)
        )

        writeConfigFileOrThrow(profileId, newConfig)

        cacheConfig(profileId, newConfig)
        val nodes = extractNodesFromConfig(newConfig, profileId)
        profileNodes[profileId] = nodes

        if (isNewProfile || existingConfig == null) {
            val profileName = newProfileName ?: "Manual"
            val newProfile = ProfileUi(
                id = profileId,
                name = profileName,
                type = ProfileType.Imported,
                url = null,
                lastUpdated = System.currentTimeMillis(),
                enabled = true,
                updateStatus = UpdateStatus.Idle
            )
            _profiles.update { it + newProfile }
        } else {
            _profiles.update { list ->
                list.map { if (it.id == profileId) it.copy(lastUpdated = System.currentTimeMillis()) else it }
            }
        }

        val addedNode = nodes.find { it.name == finalTag }
        if (ConfigRepository.shouldActivateCreatedNode(_activeProfileId.value)) {
            _activeProfileId.value = profileId
            applyActiveProfileNodes(profileId, nodes, addedNode?.id)
        } else if (_activeProfileId.value == profileId) {
            applyActiveProfileNodes(profileId, nodes)
        }
        updateAllNodesAndGroups()

        saveProfiles()

        Log.i(ConfigRepository.TAG, "Added single node: $finalTag to profile $profileId")

        Result.success(addedNode ?: nodes.last())
    } catch (e: Exception) {
        createdProfileId?.let { rollbackTransientProfileFile(it) }
        Log.e(ConfigRepository.TAG, "Failed to add single node", e)
        Result.failure(Exception(context.getString(R.string.nodes_add_failed) + ": ${e.message}"))
    }
}

/**
 * WARP² (WARP-in-WARP) as a real, one-tap chain — NOT a manual JSON
 * import. Adds TWO WireGuard outbounds to one profile:
 *  - outer: the registered WARP identity (tag "WARP2-outer"), and
 *  - inner: the user's own WireGuard server (tag "WARP²") with
 *    detour = "WARP2-outer" and MTU 1220 (double encapsulation).
 *
 * How it connects: the caller selects the returned inner node
 * (ConfigRepository.setActiveNodeWithResult) and starts the service
 * through the normal Dashboard path. At runtime,
 * buildRunOutbounds keeps both outbounds, the PROXY selector's
 * default becomes the inner tag, and buildRunEndpoints converts
 * both WireGuard outbounds to endpoints preserving detour, so
 * sing-box dials the inner server THROUGH the outer WARP
 * endpoint. No new VpnService, no profile-JSON import, no copy
 * step. Normal single-node connects are untouched: this only
 * adds outbounds; it never rewrites existing ones.
 *
 * Returns the inner [NodeUi] on success; the caller must select
 * it and start the service — this function alone does not
 * connect anything, so no fake connected state can exist.
 */
internal suspend fun ConfigRepository.addWarp2Chain(
    warpLink: String,
    innerHost: String,
    innerPort: Int,
    innerPublicKey: String,
    innerPrivateKeyBase64: String,
    targetProfileId: String? = null
): Result<NodeUi> = withContext(Dispatchers.IO) {
    var createdProfileId: String? = null
    try {
        val outerParsed = parseNodeLink(warpLink.trim())
            ?: return@withContext Result.failure(Exception("Failed to parse WARP link"))
        val innerLink = "wireguard://$innerPrivateKeyBase64@$innerHost:$innerPort" +
            "?public_key=$innerPublicKey&local_address=172.16.0.3%2F32" +
            "&mtu=1220&persistent_keepalive_interval=25#WARP2-inner"
        val innerParsed = parseNodeLink(innerLink)
            ?: return@withContext Result.failure(Exception("Failed to parse inner WireGuard link"))

        val profileId: String
        val existingConfig: SingBoxConfig?
        var isNewProfile = false
        when {
            targetProfileId != null -> {
                val profile = _profiles.value.find { it.id == targetProfileId }
                    ?: return@withContext Result.failure(Exception("Profile not found"))
                profileId = targetProfileId
                existingConfig = loadConfig(profileId)
            }
            else -> {
                val manualProfileName = "Manual"
                val manualProfile = _profiles.value.find { it.name == manualProfileName && it.type == ProfileType.Imported }
                if (manualProfile != null) {
                    profileId = manualProfile.id
                    existingConfig = loadConfig(profileId)
                } else {
                    profileId = UUID.randomUUID().toString()
                    existingConfig = null
                    isNewProfile = true
                    createdProfileId = profileId
                }
            }
        }

        val newOutbounds = mutableListOf<Outbound>()
        existingConfig?.outbounds?.let { existing ->
            newOutbounds.addAll(existing.filter { it.type !in listOf("direct", "block", "dns") })
        }
        fun uniqueTag(base: String): String {
            var tag = base
            var counter = 1
            while (newOutbounds.any { it.tag == tag }) {
                tag = "${base}_$counter"
                counter++
            }
            return tag
        }
        val outerTag = uniqueTag("WARP2-outer")
        val outerOutbound = outerParsed.copy(tag = outerTag)
        newOutbounds.add(outerOutbound)
        val innerTag = uniqueTag("WARP²")
        val innerOutbound = innerParsed.copy(tag = innerTag, detour = outerTag, mtu = 1220)
        newOutbounds.add(innerOutbound)

        if (newOutbounds.none { it.tag == "direct" }) {
            newOutbounds.add(Outbound(type = "direct", tag = "direct"))
        }
        val newConfig = deduplicateTags(
            ConfigRepository.buildConfigWithOutboundsPreservingProfileSettings(existingConfig, newOutbounds)
        )

        writeConfigFileOrThrow(profileId, newConfig)
        cacheConfig(profileId, newConfig)
        val nodes = extractNodesFromConfig(newConfig, profileId)
        profileNodes[profileId] = nodes

        if (isNewProfile || existingConfig == null) {
            val profileName = "Manual"
            val newProfile = ProfileUi(
                id = profileId,
                name = profileName,
                type = ProfileType.Imported,
                url = null,
                lastUpdated = System.currentTimeMillis(),
                enabled = true,
                updateStatus = UpdateStatus.Idle
            )
            _profiles.update { it + newProfile }
        } else {
            _profiles.update { list ->
                list.map { if (it.id == profileId) it.copy(lastUpdated = System.currentTimeMillis()) else it }
            }
        }
        if (_activeProfileId.value == profileId) {
            applyActiveProfileNodes(profileId, nodes)
        }
        updateAllNodesAndGroups()
        saveProfiles()

        val innerNode = nodes.find { it.name == innerTag }
        Log.i(ConfigRepository.TAG, "Added WARP² chain: inner=$innerTag detour=$outerTag to profile $profileId")
        Result.success(innerNode ?: nodes.last())
    } catch (e: Exception) {
        createdProfileId?.let { rollbackTransientProfileFile(it) }
        Log.e(ConfigRepository.TAG, "Failed to add WARP² chain", e)
        Result.failure(Exception(context.getString(R.string.nodes_add_failed) + ": ${e.message}"))
    }
}

/**
 * WARP² chain built from one of the user's own WireGuard nodes —
 * the no-typing main path. The node's own outbound is cloned
 * (same server, keys, and settings), retagged, given detour to a
 * fresh outer WARP outbound and MTU 1220, and written back with
 * the same profile-write path as [addWarp2Chain]. Only genuine
 * WireGuard nodes qualify; anything else fails plainly. WireGuard
 * may be stored as an endpoint in newer sing-box configs, so the
 * lookup searches the normalised outbounds as well as the raw
 * ones, exactly like node extraction does.
 */
internal suspend fun ConfigRepository.addWarp2ChainFromNode(
    nodeId: String,
    warpLink: String,
): Result<NodeUi> = withContext(Dispatchers.IO) {
    try {
        val node = getNodeById(nodeId)
            ?: return@withContext Result.failure(Exception("Node not found"))
        if (node.protocol != "wireguard") {
            return@withContext Result.failure(
                Exception("Only a WireGuard node can be the inner WARP² server (this node is ${node.protocol})"),
            )
        }
        val profileId = node.sourceProfileId
        val rawConfig = loadConfig(profileId)
            ?: return@withContext Result.failure(Exception("Profile config not found"))
        val normalised = ConfigRepository.normalizeWireGuardEndpointsForInternalUse(rawConfig)
        val innerSource = normalised.outbounds?.find { it.tag == node.name }
            ?: rawConfig.outbounds?.find { it.tag == node.name }
            ?: return@withContext Result.failure(Exception("WireGuard outbound not found for this node"))
        val outerParsed = parseNodeLink(warpLink.trim())
            ?: return@withContext Result.failure(Exception("Failed to parse WARP link"))

        val newOutbounds = mutableListOf<Outbound>()
        rawConfig.outbounds?.let { existing ->
            newOutbounds.addAll(existing.filter { it.type !in listOf("direct", "block", "dns") })
        }
        fun uniqueTag(base: String): String {
            var tag = base
            var counter = 1
            while (newOutbounds.any { it.tag == tag }) {
                tag = "${base}_$counter"
                counter++
            }
            return tag
        }
        val outerTag = uniqueTag("WARP2-outer")
        newOutbounds.add(outerParsed.copy(tag = outerTag))
        val innerTag = uniqueTag("WARP²")
        newOutbounds.add(innerSource.copy(tag = innerTag, detour = outerTag, mtu = 1220))

        if (newOutbounds.none { it.tag == "direct" }) {
            newOutbounds.add(Outbound(type = "direct", tag = "direct"))
        }
        val newConfig = deduplicateTags(
            ConfigRepository.buildConfigWithOutboundsPreservingProfileSettings(rawConfig, newOutbounds),
        )
        writeConfigFileOrThrow(profileId, newConfig)
        cacheConfig(profileId, newConfig)
        val nodes = extractNodesFromConfig(newConfig, profileId)
        profileNodes[profileId] = nodes
        _profiles.update { list ->
            list.map { if (it.id == profileId) it.copy(lastUpdated = System.currentTimeMillis()) else it }
        }
        if (_activeProfileId.value == profileId) {
            applyActiveProfileNodes(profileId, nodes)
        }
        updateAllNodesAndGroups()
        saveProfiles()
        val innerNode = nodes.find { it.name == innerTag }
        Log.i(ConfigRepository.TAG, "Added WARP² chain from node ${node.name}: inner=$innerTag detour=$outerTag")
        Result.success(innerNode ?: nodes.last())
    } catch (e: Exception) {
        Log.e(ConfigRepository.TAG, "Failed to add WARP² chain from node", e)
        Result.failure(Exception(context.getString(R.string.nodes_add_failed) + ": ${e.message}"))
    }
}

internal suspend fun ConfigRepository.updateNode(
    nodeId: String,
    newOutbound: Outbound,
    autoSelectionEligible: Boolean = isNodeAutoSelectionEligible(nodeId),
    meteredProtected: Boolean = isNodeMeteredProtected(nodeId)
) = withContext(Dispatchers.IO) {
    val node = getNodeById(nodeId) ?: return@withContext
    val profileId = node.sourceProfileId
    val config = loadConfig(profileId) ?: return@withContext
    val allNodesSnapshot = _allNodes.value.takeIf { it.isNotEmpty() } ?: loadAllNodesSnapshot()
    val effectiveAutoSelectionEligible = autoSelectionEligible && !meteredProtected
    val mutation = persistUpdatedNodeConfig(
        node = node,
        config = config,
        newOutbound = newOutbound,
        autoSelectionEligible = effectiveAutoSelectionEligible,
        meteredProtected = meteredProtected,
        allNodesSnapshot = allNodesSnapshot
    )
    val refreshedNodes = refreshNodesAfterNodeMutation(
        profileId = profileId,
        oldNodeId = nodeId,
        newTag = mutation.finalTag,
        newConfig = mutation.config
    )
    applyNodeAutoSelectionEligibilityChange(
        profileId = profileId,
        previousEligibility = mutation.previousEligibility,
        autoSelectionEligible = effectiveAutoSelectionEligible,
        previousProtection = mutation.previousProtection,
        meteredProtected = meteredProtected,
        refreshedNodes = refreshedNodes,
        forceReload = mutation.config != config
    )
}

internal data class PersistedNodeMutation(
    val config: SingBoxConfig,
    val finalTag: String,
    val previousEligibility: Boolean,
    val previousProtection: Boolean
)

@Suppress("LongParameterList")
internal suspend fun ConfigRepository.persistUpdatedNodeConfig(
    node: NodeUi,
    config: SingBoxConfig,
    newOutbound: Outbound,
    autoSelectionEligible: Boolean,
    meteredProtected: Boolean,
    allNodesSnapshot: List<NodeUi>
): PersistedNodeMutation {
    val profileId = node.sourceProfileId
    val previousEligibility = isNodeAutoSelectionEligible(node.id)
    val previousProtection = isNodeMeteredProtected(node.id)
    val previousAuthorization = NodeProtectionStore.manuallyAuthorizedNodeId()
    require(
        config.outbounds.orEmpty().any { it.tag == node.name } ||
            config.proxies.orEmpty().any { it.tag == node.name }
    ) { "Outbound not found: ${node.name}" }
    val (newConfig, finalTag) = replaceOutboundInConfig(config, node.name, newOutbound)
    val updatedNodeId = ConfigRepository.stableNodeId(profileId, finalTag)
    val oldQualifiedReference = "$profileId::${node.name}"
    val newQualifiedReference = "$profileId::$finalTag"
    val oldBareNameIsUnique = allNodesSnapshot.count { it.name == node.name } == 1
    val newBareNameIsUnique = allNodesSnapshot.none { it.id != node.id && it.name == finalTag }
    val oldRuntimeTags = NodeProtectionStore.runtimeMappings()
        .filterValues { reference -> reference.nodeId == node.id }
        .keys
    var settingsMigrated = false
    var protectionMigrated = false
    try {
        writeConfigFileOrThrow(profileId, newConfig)
        cacheConfig(profileId, newConfig)
        if (updatedNodeId != node.id) {
            check(
                settingsRepository.migrateNodeRoutingReferences(
                    oldNodeId = node.id,
                    newNodeId = updatedNodeId,
                    oldQualifiedReference = oldQualifiedReference,
                    newQualifiedReference = newQualifiedReference,
                    oldBareReference = node.name,
                    newBareReference = finalTag,
                    oldBareNameIsUnique = oldBareNameIsUnique,
                    newBareNameIsUnique = newBareNameIsUnique,
                    notify = false
                )
            ) { "Failed to migrate routing references for ${node.name}" }
            settingsMigrated = true
        }
        check(saveNodeAutoSelectionEligibility(updatedNodeId, autoSelectionEligible)) {
            "Failed to persist automatic selection eligibility for ${node.name}"
        }
        if (updatedNodeId != node.id) {
            protectionMigrated = true
            NodeProtectionStore.migrateNode(node.id, updatedNodeId, finalTag)
        }
        check(NodeProtectionStore.setProtected(updatedNodeId, meteredProtected)) {
            "Failed to persist metered protection for ${node.name}"
        }
        NodeProtectionStore.authorizeManualNode(
            authorizationAfterProtectionUpdate(
                previousAuthorizedNodeId = previousAuthorization,
                oldNodeId = node.id,
                updatedNodeId = updatedNodeId,
                wasProtected = previousProtection,
                isProtected = meteredProtected
            )
        )
    } catch (e: Exception) {
        runCatching {
            writeConfigFileOrThrow(profileId, config)
            cacheConfig(profileId, config)
        }.onFailure(e::addSuppressed)
        if (settingsMigrated) {
            runCatching {
                settingsRepository.migrateNodeRoutingReferences(
                    oldNodeId = updatedNodeId,
                    newNodeId = node.id,
                    oldQualifiedReference = newQualifiedReference,
                    newQualifiedReference = oldQualifiedReference,
                    oldBareReference = finalTag,
                    newBareReference = node.name,
                    oldBareNameIsUnique = newBareNameIsUnique,
                    newBareNameIsUnique = oldBareNameIsUnique,
                    notify = false
                )
            }.onFailure(e::addSuppressed)
        }
        if (protectionMigrated) {
            runCatching { NodeProtectionStore.migrateNode(updatedNodeId, node.id, node.name) }
                .onFailure(e::addSuppressed)
        }
        saveNodeAutoSelectionEligibility(node.id, previousEligibility)
        if (updatedNodeId != node.id) {
            nodeAutoSelectionMmkv.removeValueForKey(updatedNodeId)
        }
        NodeProtectionStore.setProtected(node.id, previousProtection)
        if (updatedNodeId != node.id) NodeProtectionStore.removeNode(updatedNodeId)
        NodeProtectionStore.authorizeManualNode(previousAuthorization)
        throw e
    }
    if (updatedNodeId != node.id) {
        nodeAutoSelectionMmkv.removeValueForKey(node.id)
        migrateNodeSelectionState(profileId, node.id, updatedNodeId, finalTag)
        migrateNodeLatency(node.id, updatedNodeId)
        if (oldRuntimeTags.isNotEmpty()) {
            lastTagToNodeName = lastTagToNodeName.mapValues { (runtimeTag, nodeName) ->
                if (runtimeTag in oldRuntimeTags) finalTag else nodeName
            }
        }
    }
    return PersistedNodeMutation(newConfig, finalTag, previousEligibility, previousProtection)
}

@Suppress("LongParameterList", "CognitiveComplexMethod")
internal suspend fun ConfigRepository.applyNodeAutoSelectionEligibilityChange(
    profileId: String,
    previousEligibility: Boolean,
    autoSelectionEligible: Boolean,
    previousProtection: Boolean,
    meteredProtected: Boolean,
    refreshedNodes: List<NodeUi>,
    forceReload: Boolean = false
) {
    val protectionEnabled = !previousProtection && meteredProtected
    disableProfileAutoSelectionWithoutCandidates(profileId, autoSelectionEligible, refreshedNodes)
    if (protectionEnabled) {
        // 先清空旧配置建立的连接，再生成不含计费节点的新运行配置。
        resetRuntimeConnectionsForMeteredProtection()
        if (leaveNewlyProtectedActiveNode(refreshedNodes)) return
    }
    val settingsChanged = forceReload || previousEligibility != autoSelectionEligible ||
        previousProtection != meteredProtected
    if (!settingsChanged || !shouldReloadNodeSettingsChange()) return

    val generationResult = generateConfigFile()
    if (generationResult == null) {
        if (protectionEnabled) stopRuntimeForMeteredProtection()
        error(lastConfigGenerationError ?: "Failed to generate config after changing node policy")
    }
    try {
        requestFullRuntimeConfigReload(generationResult)
        lastRunOutboundTags = generationResult.outboundTags
        lastRunProfileId = _activeProfileId.value
    } catch (error: Exception) {
        if (protectionEnabled) stopRuntimeForMeteredProtection()
        throw error
    }
}

internal fun ConfigRepository.disableProfileAutoSelectionWithoutCandidates(
    profileId: String,
    autoSelectionEligible: Boolean,
    refreshedNodes: List<NodeUi>
) {
    if (autoSelectionEligible || refreshedNodes.any { it.autoSelectionEligible }) return
    if (!saveProfileAutoSelection(profileId, false)) {
        Log.e(ConfigRepository.TAG, "Failed to disable automatic selection for empty candidate set")
    }
}

internal suspend fun ConfigRepository.leaveNewlyProtectedActiveNode(refreshedNodes: List<NodeUi>): Boolean {
    val activeNode = refreshedNodes.firstOrNull { it.id == _activeNodeId.value }
    if (activeNode?.meteredProtected != true) return false

    val fallbackNode = refreshedNodes.firstOrNull { !it.meteredProtected }
    if (fallbackNode == null) {
        stopRuntimeForMeteredProtection()
        return true
    }
    val result = setActiveNodeWithResult(fallbackNode.id)
    if (result is ConfigRepository.NodeSwitchResult.Failed) {
        stopRuntimeForMeteredProtection()
        error("Failed to leave newly protected node: ${result.reason}")
    }
    return true
}

internal fun ConfigRepository.resetRuntimeConnectionsForMeteredProtection() {
    val intent = when (VpnStateStore.getMode()) {
        VpnStateStore.CoreMode.PROXY -> Intent(context, ProxyOnlyService::class.java).apply {
            action = ProxyOnlyService.ACTION_RESET_CONNECTIONS
        }
        VpnStateStore.CoreMode.VPN -> Intent(context, SingBoxService::class.java).apply {
            action = SingBoxService.ACTION_RESET_CONNECTIONS
        }
        VpnStateStore.CoreMode.ROOT -> Intent(context, RootTransparentForegroundService::class.java).apply {
            action = RootTransparentForegroundService.ACTION_RESET_CONNECTIONS
        }
        VpnStateStore.CoreMode.NONE -> return
    }
    context.startService(intent)
}

internal fun ConfigRepository.stopRuntimeForMeteredProtection() {
    stopRuntimeAfterConfigMutation(
        initiator = VpnStopInitiator.METERED_PROTECTION,
        logMessage = "WARN [METERED_GUARD] stopped runtime because protected-node paths could not be purged safely"
    )
}

internal suspend fun ConfigRepository.reloadRuntimeAfterDestructiveMutation(reason: String) {
    if (!shouldReloadNodeSettingsChange()) return
    resetRuntimeConnectionsForMeteredProtection()
    val generation = generateConfigFile()
    if (generation == null) {
        stopRuntimeAfterConfigMutation(
            initiator = VpnStopInitiator.MODE_SWITCH,
            logMessage = "ERROR [CFG] stopped runtime after $reason because no safe config could be generated"
        )
        if (_profiles.value.isEmpty()) return
        error(lastConfigGenerationError ?: "Failed to generate config after $reason")
    }
    try {
        requestFullRuntimeConfigReload(generation)
        lastRunOutboundTags = generation.outboundTags
        lastRunProfileId = _activeProfileId.value
    } catch (error: Exception) {
        stopRuntimeAfterConfigMutation(
            initiator = VpnStopInitiator.MODE_SWITCH,
            logMessage = "ERROR [CFG] stopped runtime after $reason because reload failed"
        )
        throw error
    }
}

internal fun ConfigRepository.stopRuntimeAfterConfigMutation(
    initiator: VpnStopInitiator,
    logMessage: String
) {
    val intent = when (VpnStateStore.getMode()) {
        VpnStateStore.CoreMode.PROXY -> Intent(context, ProxyOnlyService::class.java).apply {
            action = ProxyOnlyService.ACTION_STOP
            putExtra(SingBoxService.EXTRA_STOP_INITIATOR, initiator.wireValue)
        }
        VpnStateStore.CoreMode.VPN -> Intent(context, SingBoxService::class.java).apply {
            action = SingBoxService.ACTION_STOP
            putExtra(SingBoxService.EXTRA_STOP_INITIATOR, initiator.wireValue)
        }
        VpnStateStore.CoreMode.ROOT -> Intent(context, RootTransparentForegroundService::class.java).apply {
            action = RootTransparentForegroundService.ACTION_STOP
            putExtra(SingBoxService.EXTRA_STOP_INITIATOR, initiator.wireValue)
        }
        VpnStateStore.CoreMode.NONE -> return
    }
    context.startService(intent)
    LogRepository.getInstance().addAlwaysLog(logMessage)
}

internal fun ConfigRepository.filterVpnCapturedPackages(settings: AppSettings, packageNames: List<String>): List<String> {
    if (!ConfigRepository.shouldFilterCapturedPackages(settings)) {
        return packageNames.map(String::trim).filter(String::isNotBlank).distinct()
    }
    val policy = PerAppVpnPolicy.from(settings)
    val selectedPackages = when (policy.mode) {
        VpnAppMode.ALL -> emptySet()
        VpnAppMode.ALLOWLIST -> policy.allowlist
        VpnAppMode.BLOCKLIST -> policy.blocklist
    }
    val selectedUids = selectedPackages.mapNotNullTo(mutableSetOf()) { packageName ->
        runCatching { context.packageManager.getApplicationInfo(packageName, 0).uid }.getOrNull()
    }
    return packageNames.asSequence()
        .map(String::trim)
        .filter(String::isNotBlank)
        .filterNot { it == context.packageName }
        .filter { packageName ->
            val uid = runCatching {
                context.packageManager.getApplicationInfo(packageName, 0).uid
            }.getOrNull()
            when (policy.mode) {
                VpnAppMode.ALL -> true
                VpnAppMode.ALLOWLIST -> packageName in policy.allowlist || uid in selectedUids
                VpnAppMode.BLOCKLIST -> packageName !in policy.blocklist && uid !in selectedUids
            }
        }
        .distinct()
        .toList()
}

internal fun ConfigRepository.shouldReloadNodeSettingsChange(): Boolean {
    // 运行配置可能通过应用分流或 detour 引用其他配置中的节点。
    if (SingBoxRemote.isRunning.value || SingBoxRemote.isStarting.value) return true
    return VpnStateStore.getActive()
}

internal suspend fun ConfigRepository.refreshNodesAfterNodeMutation(
    profileId: String,
    oldNodeId: String,
    newTag: String,
    newConfig: SingBoxConfig
): List<NodeUi> {
    val oldNodes = profileNodes[profileId] ?: _nodes.value
    val latencyById = oldNodes.associate { it.id to it.latencyMs }
    val updatedNodeId = ConfigRepository.stableNodeId(profileId, newTag)
    val originalLatency = oldNodes.find { it.id == oldNodeId }?.latencyMs
    val newNodes = extractNodesFromConfig(newConfig, profileId)
    val mergedNodes = mergeMutatedNodeLatencies(
        newNodes = newNodes,
        latencyById = latencyById,
        updatedNodeId = updatedNodeId,
        originalLatency = originalLatency
    )
    profileNodes[profileId] = mergedNodes
    updateAllNodesAndGroups()
    applyMutatedActiveNode(profileId, oldNodeId, newTag, mergedNodes)
    saveProfiles()
    return mergedNodes
}

internal fun ConfigRepository.mergeMutatedNodeLatencies(
    newNodes: List<NodeUi>,
    latencyById: Map<String, Long?>,
    updatedNodeId: String,
    originalLatency: Long?
): List<NodeUi> {
    return newNodes.map { nodeItem ->
        val storedLatency = latencyById[nodeItem.id]
            ?: if (nodeItem.id == updatedNodeId) originalLatency else null
        if (storedLatency != null) nodeItem.copy(latencyMs = storedLatency) else nodeItem
    }
}

internal fun ConfigRepository.applyMutatedActiveNode(
    profileId: String,
    oldNodeId: String,
    newTag: String,
    mergedNodes: List<NodeUi>
) {
    if (_activeProfileId.value != profileId) return

    _nodes.value = mergedNodes
    if (_activeNodeId.value != oldNodeId) return

    val newNode = mergedNodes.find { it.name == newTag }
    if (newNode != null) {
        _activeNodeId.value = newNode.id
    }
}

internal suspend fun ConfigRepository.exportNode(nodeId: String): String? = withContext(Dispatchers.IO) {
    val node = _nodes.value.find { it.id == nodeId } ?: run {
        Log.e(ConfigRepository.TAG, "exportNode: Node not found in UI list: $nodeId")
        return@withContext null
    }

    val config = loadConfig(node.sourceProfileId) ?: run {
        Log.e(ConfigRepository.TAG, "exportNode: Config not found for profile: ${node.sourceProfileId}")
        return@withContext null
    }

    val outbound = config.outbounds?.find { it.tag == node.name } ?: run {
        Log.e(ConfigRepository.TAG, "exportNode: Outbound not found in config with tag: ${node.name}")
        return@withContext null
    }

    NodeLinkExporter.export(outbound, gson)
}

internal fun ConfigRepository.deduplicateTags(config: SingBoxConfig): SingBoxConfig {
    ConfigRepository.findUnsupportedAndroidCapability(config)?.let { message ->
        throw IllegalArgumentException(message)
    }
    val normalizedConfig = ConfigRepository.normalizeWireGuardEndpointsForInternalUse(config)
    val outbounds = normalizedConfig.outbounds
    if (outbounds == null) return normalizedConfig
    val seenTags = mutableSetOf<String>()

    val newOutbounds = outbounds.map { outbound ->
        var tag = outbound.tag
        if (tag.isBlank()) {
            tag = "unnamed"
        }

        var newTag = tag
        var counter = 1
        while (seenTags.contains(newTag)) {
            newTag = "${tag}_$counter"
            counter++
        }

        seenTags.add(newTag)

        if (newTag != outbound.tag) {
            outbound.copy(tag = newTag)
        } else {
            outbound
        }
    }

    return normalizedConfig.copy(outbounds = newOutbounds)
}

internal fun ConfigRepository.findAvailablePort(startPort: Int): Int {
    for (port in startPort until startPort + 100) {
        try {
            java.net.ServerSocket(port).use {
                return port
            }
        } catch (_: Exception) {
        }
    }
    return startPort
}

internal fun ConfigRepository.cleanup() {
    scope.cancel()
    ConfigRepository.nodeIdCache.clear()
    configCache.clear()
    configCacheAccessTimes.clear()
    profileNodes.clear()
    savedNodeLatencies.clear()
    inFlightLatencyTests.clear()
    Log.i(ConfigRepository.TAG, "ConfigRepository cleanup completed")
}

internal fun ConfigRepository.isIpAddress(address: String?): Boolean {
    return ConfigRepository.isIpAddressValue(address)
}
