package com.kunk.singbox.engines

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kunk.singbox.repository.ConfigRepository
import com.kunk.singbox.repository.addWarp2Chain
import com.kunk.singbox.repository.addWarp2ChainFromNode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/**
 * ViewModel for the new engines (WARP, WARP², MASQUE, Psiphon) and
 * their scanners. All state here is measured or user-supplied:
 * no invented gateways, servers, latencies, or quotas.
 *
 * Single-VpnService rule is preserved by construction: none of
 * these engines starts its own VpnService. WARP/WARP² produce
 * sing-box nodes/profiles that run through the existing sing-box
 * service; MASQUE/Psiphon do not connect at all until their cores
 * land (see MasqueEngine / PsiphonEngine notes).
 */
class EnginesViewModel(application: Application) : AndroidViewModel(application) {
    private val context: Context
        get() = getApplication<Application>().applicationContext

    private val warpStore by lazy { WarpIdentityStore(context) }
    private val masqueEngine by lazy { MasqueEngine(context) }
    private val psiphonEngine by lazy { PsiphonEngine(context) }
    private val connReport by lazy { ConnectionReport(context) }

    // ---- WARP ----
    private val _warpIdentity = MutableStateFlow<WarpIdentity?>(null)
    val warpIdentity: StateFlow<WarpIdentity?> = _warpIdentity.asStateFlow()
    private val _warpBusy = MutableStateFlow(false)
    val warpBusy: StateFlow<Boolean> = _warpBusy.asStateFlow()
    private val _warpError = MutableStateFlow<String?>(null)
    val warpError: StateFlow<String?> = _warpError.asStateFlow()
    /** Fresh wireguard:// link for the registered WARP identity, if any. */
    private val _warpLink = MutableStateFlow<String?>(null)
    val warpLink: StateFlow<String?> = _warpLink.asStateFlow()

    // ---- MASQUE scan ----
    private val _masqueResults = MutableStateFlow<List<ScanResult>>(emptyList())
    val masqueResults: StateFlow<List<ScanResult>> = _masqueResults.asStateFlow()
    private val _masqueScanning = MutableStateFlow(false)
    val masqueScanning: StateFlow<Boolean> = _masqueScanning.asStateFlow()
    val masqueWinner: String?
        get() = masqueEngine.cachedWinner

    // ---- MASQUE exit country (reference screen parity) ----
    private val _masqueCountries = MutableStateFlow<List<MasqueExitCountry>>(emptyList())
    val masqueCountries: StateFlow<List<MasqueExitCountry>> = _masqueCountries.asStateFlow()
    private val _masquePinging = MutableStateFlow(false)
    val masquePinging: StateFlow<Boolean> = _masquePinging.asStateFlow()
    private val _masqueExitMode = MutableStateFlow(masqueEngine.exitMode)
    val masqueExitMode: StateFlow<MasqueExitMode> = _masqueExitMode.asStateFlow()
    private val _masqueSelection = MutableStateFlow(masqueEngine.exitSelection)
    val masqueSelection: StateFlow<MasqueExitSelection> = _masqueSelection.asStateFlow()
    val masqueFastest: MasqueExitCountry?
        get() = masqueEngine.fastestCountry(_masqueCountries.value)

    // ---- WARP² one-tap connect ----
    private val _warp2Busy = MutableStateFlow(false)
    val warp2Busy: StateFlow<Boolean> = _warp2Busy.asStateFlow()
    private val _warp2Error = MutableStateFlow<String?>(null)
    val warp2Error: StateFlow<String?> = _warp2Error.asStateFlow()
    /** Inner node id of the most recently built WARP² chain, if any. */
    private val _warp2NodeId = MutableStateFlow<String?>(null)
    val warp2NodeId: StateFlow<String?> = _warp2NodeId.asStateFlow()

    // ---- WARP² scan ----
    private val _warp2Results = MutableStateFlow<List<ScanResult>>(emptyList())
    val warp2Results: StateFlow<List<ScanResult>> = _warp2Results.asStateFlow()
    private val _warp2Scanning = MutableStateFlow(false)
    val warp2Scanning: StateFlow<Boolean> = _warp2Scanning.asStateFlow()

    // ---- WARP² worker relay + connection report ----
    private val _warp2WorkerRelay = MutableStateFlow(warpStore.workerRelayEnabled)
    val warp2WorkerRelay: StateFlow<Boolean> = _warp2WorkerRelay.asStateFlow()
    private val _warp2WorkerRelayUrl = MutableStateFlow(warpStore.workerRelayUrl)
    val warp2WorkerRelayUrl: StateFlow<String> = _warp2WorkerRelayUrl.asStateFlow()
    private val _warp2Report = MutableStateFlow(connReport.warp2Report())
    val warp2Report: StateFlow<Warp2Report> = _warp2Report.asStateFlow()

    // ---- Psiphon ----
    private val _psiphonSummary = MutableStateFlow<PsiphonListSummary?>(null)
    val psiphonSummary: StateFlow<PsiphonListSummary?> = _psiphonSummary.asStateFlow()
    private val _psiphonBusy = MutableStateFlow(false)
    val psiphonBusy: StateFlow<Boolean> = _psiphonBusy.asStateFlow()
    private val _psiphonError = MutableStateFlow<String?>(null)
    val psiphonError: StateFlow<String?> = _psiphonError.asStateFlow()
    private val _psiphonProbeResults = MutableStateFlow<List<ScanResult>>(emptyList())
    val psiphonProbeResults: StateFlow<List<ScanResult>> = _psiphonProbeResults.asStateFlow()
    /** Per-region ping results, keyed by region code. */
    private val _psiphonRegionPings = MutableStateFlow<Map<String, ScanResult>>(emptyMap())
    val psiphonRegionPings: StateFlow<Map<String, ScanResult>> = _psiphonRegionPings.asStateFlow()
    private val _psiphonRegionPinging = MutableStateFlow(false)
    val psiphonRegionPinging: StateFlow<Boolean> = _psiphonRegionPinging.asStateFlow()

    init {
        _warpIdentity.value = warpStore.load()
        _warpIdentity.value?.let { _warpLink.value = WarpClient.buildWireGuardLink(it) }
        _psiphonSummary.value = psiphonEngine.cachedSummary()
    }

    /** Registers a fresh WARP identity and publishes its node link. */
    fun registerWarp() {
        if (_warpBusy.value) return
        viewModelScope.launch {
            _warpBusy.value = true
            _warpError.value = null
            try {
                val keyPair = WarpClient.generateKeyPair()
                val identity = WarpClient.register(keyPair)
                warpStore.save(identity)
                _warpIdentity.value = identity
                _warpLink.value = WarpClient.buildWireGuardLink(identity)
            } catch (e: Exception) {
                _warpError.value = e.message ?: "WARP registration failed"
            } finally {
                _warpBusy.value = false
            }
        }
    }

    fun clearWarpError() {
        _warpError.value = null
    }

    /** Scans MASQUE candidates live; caches the fastest reachable winner. */
    fun scanMasque(input: String) {
        val targets = EngineScanner.parseTargets(input)
        if (targets.isEmpty() || _masqueScanning.value) return
        viewModelScope.launch {
            _masqueScanning.value = true
            _masqueResults.value = emptyList()
            try {
                val collected = mutableListOf<ScanResult>()
                EngineScanner.scan(targets).collect { result ->
                    collected.add(result)
                    _masqueResults.value = EngineScanner.fastestFirst(collected)
                }
                collected.firstOrNull { it.reachable }?.let { winner ->
                    masqueEngine.setManualEndpoint(winner.target.label)
                }
            } finally {
                _masqueScanning.value = false
            }
        }
    }

    fun setMasqueManualEndpoint(endpoint: String) {
        masqueEngine.setManualEndpoint(endpoint)
        masqueEngine.addCandidate(endpoint)
    }

    /** "Ping every country": real probes over the gateway pool, grouped by country. */
    fun pingMasqueCountries() {
        if (_masquePinging.value) return
        viewModelScope.launch {
            _masquePinging.value = true
            try {
                _masqueCountries.value = masqueEngine.pingExitCountries()
            } catch (_: Exception) {
                // Keep the previous list; the sheet shows the empty state, never fake rows.
            } finally {
                _masquePinging.value = false
            }
        }
    }

    fun setMasqueExitMode(mode: MasqueExitMode) {
        masqueEngine.exitMode = mode
        _masqueExitMode.value = mode
    }

    fun selectMasqueExit(selection: MasqueExitSelection) {
        masqueEngine.exitSelection = selection
        _masqueSelection.value = selection
    }

    /**
     * Scans WARP² inner candidates: TCP reachability of each inner
     * host plus the outer WARP edge RTT (engage host). A TCP probe
     * cannot prove a WireGuard handshake — the UI labels it as
     * reachability only, and the winner is cached as a candidate,
     * not as a proven tunnel.
     */
    fun scanWarp2(input: String) {
        val targets = EngineScanner.parseTargets(input, defaultPort = 51820)
        if (targets.isEmpty() || _warp2Scanning.value) return
        viewModelScope.launch {
            _warp2Scanning.value = true
            _warp2Results.value = emptyList()
            try {
                val collected = mutableListOf<ScanResult>()
                EngineScanner.scan(targets).collect { result ->
                    collected.add(result)
                    _warp2Results.value = EngineScanner.fastestFirst(collected)
                }
            } finally {
                _warp2Scanning.value = false
            }
        }
    }

    /** Fetches the public Psiphon server list and caches its summary. */
    fun fetchPsiphonList() {
        if (_psiphonBusy.value) return
        viewModelScope.launch {
            _psiphonBusy.value = true
            _psiphonError.value = null
            try {
                _psiphonSummary.value = psiphonEngine.fetchServerList()
            } catch (e: Exception) {
                _psiphonError.value = e.message ?: "Psiphon list download failed"
            } finally {
                _psiphonBusy.value = false
            }
        }
    }

    /** Probes a sample of servers from the fetched Psiphon list (TCP 443). */
    fun probePsiphonSample() {
        val ips = _psiphonSummary.value?.sampleIps.orEmpty()
        if (ips.isEmpty()) return
        viewModelScope.launch {
            _psiphonProbeResults.value = emptyList()
            val collected = mutableListOf<ScanResult>()
            EngineScanner.scan(ips.map { ScanTarget(it, it, 443) }).collect { result ->
                collected.add(result)
                _psiphonProbeResults.value = EngineScanner.fastestFirst(collected)
            }
        }
    }

    /** Pings one server per Psiphon region, so each region row shows a real ping. */
    fun probePsiphonRegions() {
        val regions = _psiphonSummary.value?.regionServers.orEmpty()
            .filter { it.ips.isNotEmpty() }
        if (regions.isEmpty() || _psiphonRegionPinging.value) return
        viewModelScope.launch {
            _psiphonRegionPinging.value = true
            _psiphonRegionPings.value = emptyMap()
            try {
                val targets = regions.map { rs -> ScanTarget(rs.code, rs.ips.first(), 443) }
                EngineScanner.scan(targets).collect { result ->
                    _psiphonRegionPings.value = _psiphonRegionPings.value + (result.target.label to result)
                }
            } finally {
                _psiphonRegionPinging.value = false
            }
        }
    }

    /**
     * One-tap WARP² connect, fully automatic — no manual JSON import.
     * (a) Ensures a WARP identity exists, registering one through
     * the existing WarpClient path when none is stored. (b) Builds
     * the two-outbound chain in the profile store via
     * ConfigRepository.addWarp2Chain (outer WARP + inner WireGuard
     * with detour, MTU 1220). (c) Hands the inner node id to
     * [onNodeReady]; the caller selects it and starts the service
     * through the normal Dashboard path, so connected status is
     * the real sing-box state, never a faked one. Disconnect is
     * the normal Dashboard stop — no separate teardown exists
     * because no separate service exists.
     */
    fun connectWarp2(
        innerHost: String,
        innerPort: Int,
        innerPublicKey: String,
        innerPrivateKeyBase64: String,
        onNodeReady: (String) -> Unit,
    ) {
        if (_warp2Busy.value) return
        viewModelScope.launch {
            _warp2Busy.value = true
            _warp2Error.value = null
            try {
                var identity = _warpIdentity.value
                if (identity == null) {
                    val keyPair = WarpClient.generateKeyPair()
                    identity = WarpClient.register(keyPair)
                    warpStore.save(identity)
                    _warpIdentity.value = identity
                    _warpLink.value = WarpClient.buildWireGuardLink(identity)
                }
                val link = WarpClient.buildWireGuardLink(identity)
                val repository = ConfigRepository.getInstance(context)
                val result = repository.addWarp2Chain(
                    warpLink = link,
                    innerHost = innerHost,
                    innerPort = innerPort,
                    innerPublicKey = innerPublicKey,
                    innerPrivateKeyBase64 = innerPrivateKeyBase64,
                )
                result.onSuccess { node ->
                    _warp2NodeId.value = node.id
                    connReport.recordWarp2Attempt(true)
                    _warp2Report.value = connReport.warp2Report()
                    onNodeReady(node.id)
                }.onFailure { error ->
                    _warp2Error.value = error.message ?: "WARP² setup failed"
                    connReport.recordWarp2Attempt(false, _warp2Error.value)
                    _warp2Report.value = connReport.warp2Report()
                }
            } catch (e: Exception) {
                _warp2Error.value = e.message ?: "WARP² setup failed"
            } finally {
                _warp2Busy.value = false
            }
        }
    }

    fun clearWarp2Error() {
        _warp2Error.value = null
    }

    fun setWarp2WorkerRelay(enabled: Boolean) {
        warpStore.workerRelayEnabled = enabled
        _warp2WorkerRelay.value = enabled
    }

    fun setWarp2WorkerRelayUrl(url: String) {
        warpStore.workerRelayUrl = url.trim()
        _warp2WorkerRelayUrl.value = warpStore.workerRelayUrl
    }

    /**
     * One-tap WARP² from one of the user's own WireGuard nodes —
     * the new main path. No host, port, or key is typed: the node
     * already holds them, the WARP identity is auto-registered or
     * reused, and the chain is built from the node's own outbound
     * (detour to the outer WARP endpoint, MTU 1220). The worker
     * relay toggle only matters when direct registration is
     * filtered; with it on and no relay URL set, this fails
     * plainly instead of pretending a relay exists.
     */
    fun connectWarp2FromNode(nodeId: String, onNodeReady: (String) -> Unit) {
        if (_warp2Busy.value) return
        if (_warp2WorkerRelay.value && _warp2WorkerRelayUrl.value.isBlank()) {
            _warp2Error.value = "Worker relay is on but no worker URL is set — turn it off or add your worker URL in Advanced."
            return
        }
        viewModelScope.launch {
            _warp2Busy.value = true
            _warp2Error.value = null
            try {
                var identity = _warpIdentity.value
                if (identity == null) {
                    val keyPair = WarpClient.generateKeyPair()
                    identity = WarpClient.register(keyPair)
                    warpStore.save(identity)
                    _warpIdentity.value = identity
                    _warpLink.value = WarpClient.buildWireGuardLink(identity)
                }
                val link = WarpClient.buildWireGuardLink(identity)
                val repository = ConfigRepository.getInstance(context)
                val result = repository.addWarp2ChainFromNode(nodeId, link)
                result.onSuccess { node ->
                    _warp2NodeId.value = node.id
                    connReport.recordWarp2Attempt(true)
                    _warp2Report.value = connReport.warp2Report()
                    onNodeReady(node.id)
                }.onFailure { error ->
                    _warp2Error.value = error.message ?: "WARP² setup failed"
                    connReport.recordWarp2Attempt(false, _warp2Error.value)
                    _warp2Report.value = connReport.warp2Report()
                }
            } catch (e: Exception) {
                _warp2Error.value = e.message ?: "WARP² setup failed"
                connReport.recordWarp2Attempt(false, _warp2Error.value)
                _warp2Report.value = connReport.warp2Report()
            } finally {
                _warp2Busy.value = false
            }
        }
    }
}
