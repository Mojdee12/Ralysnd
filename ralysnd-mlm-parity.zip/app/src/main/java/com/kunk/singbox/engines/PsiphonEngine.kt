package com.kunk.singbox.engines

import android.content.Context
import com.tencent.mmkv.MMKV
import java.io.ByteArrayInputStream
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import java.util.zip.InflaterInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

/**
 * Psiphon engine — server-list fetch, region extraction, and bench
 * scaffolding. Fresh code, no other app's Psiphon code vendored.
 *
 * Diagnosis of the old "no servers at all" bug (fixed here):
 * the public list file is named server_list_compressed because
 * Psiphon's own tooling compresses it with ZLIB (see the upstream
 * common package: Compress/Decompress are zlib, not gzip). The old
 * code only recognised the gzip magic (0x1f 0x8b) and otherwise
 * treated the raw compressed bytes as text, so the ipAddress/region
 * regexes matched nothing and the sheet showed zero servers while
 * still reporting "List: N bytes". The fix tries gzip, then zlib,
 * then raw text, in that order, and reports a real parse failure
 * instead of a silent empty list when all three yield nothing.
 *
 * A second old bug: entryCount was the size of the capped 20-IP
 * sample, not the list size. It is now the total ipAddress match
 * count; the sample stays capped at 20.
 *
 * What is NOT here, stated plainly: a live Psiphon tunnel. That
 * needs the official Psiphon client library (Go, via its Android
 * PsiphonTunnel JNI wrapper) built into this app — a gomobile/JNI
 * integration that cannot be verified without a real Gradle build
 * and a Go toolchain, and would be irresponsible to half-wire
 * statically. Until that binding lands, this screen shows the real
 * list + regions + measured probes and refuses to claim a
 * connection.
 */
data class PsiphonRegionServers(
    /** ISO country code from the list, e.g. "US". */
    val code: String,
    /** Sampled server IPs for this region (at most 8). */
    val ips: List<String>,
) {
    /** Total servers for this region in the fetched list. */
    val totalCount: Int
        get() = ips.size
}

data class PsiphonListSummary(
    val bytesDownloaded: Int,
    /** Total server entries parsed from the list, null when unparsed. */
    val entryCount: Int?,
    val regions: List<String>,
    val fetchedAtMs: Long,
    /** Sampled server IPs extracted from the list (at most 20). */
    val sampleIps: List<String>,
    /** Per-region server samples, for the region rows. */
    val regionServers: List<PsiphonRegionServers> = emptyList(),
)

class PsiphonEngine(context: Context) {
    private val kv = MMKV.mmkvWithID("ralysnd_psiphon", MMKV.SINGLE_PROCESS_MODE)

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    companion object {
        /** Public Psiphon server list (public URL, no key material). */
        const val PUBLIC_SERVER_LIST_URL =
            "https://s3.amazonaws.com/psiphon/web/iohq-waa4-q4dt/server_list_compressed"
        private val IP_REGEX = Regex("\"ipAddress\"\\s*:\\s*\"([0-9.]+)\"")
        private val REGION_REGEX = Regex("\"region\"\\s*:\\s*\"([A-Z]{2})\"")
        /** Pairs ipAddress with the region that follows it in the same entry. */
        private val ENTRY_REGEX =
            Regex("\"ipAddress\"\\s*:\\s*\"([0-9.]+)\"[^}]{0,400}?\"region\"\\s*:\\s*\"([A-Z]{2})\"")
    }

    fun cachedSummary(): PsiphonListSummary? {
        val bytes = kv.decodeInt("bytes", 0)
        if (bytes <= 0) return null
        val regions = kv.decodeString("regions", "")
            ?.split(",")
            ?.filter { it.isNotBlank() }
            .orEmpty()
        val regionServers = kv.decodeString("region_servers", "")
            ?.split(";")
            ?.mapNotNull { part ->
                val code = part.substringBefore(":", "")
                val ips = part.substringAfter(":", "")
                    .split(",")
                    .filter { it.isNotBlank() }
                if (code.isBlank()) null else PsiphonRegionServers(code, ips)
            }
            .orEmpty()
        return PsiphonListSummary(
            bytesDownloaded = bytes,
            entryCount = kv.decodeInt("entries", -1).takeIf { it >= 0 },
            regions = regions,
            fetchedAtMs = kv.decodeLong("fetched_at", 0L),
            sampleIps = kv.decodeString("sample_ips", "")
                ?.split(",")
                ?.filter { it.isNotBlank() }
                .orEmpty(),
            regionServers = regionServers,
        )
    }

    /** Downloads the public list and returns a parsed summary. */
    suspend fun fetchServerList(): PsiphonListSummary = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(PUBLIC_SERVER_LIST_URL).build()
        val raw = http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Psiphon server list failed: HTTP ${response.code}")
            }
            response.body?.bytes() ?: ByteArray(0)
        }
        if (raw.isEmpty()) {
            throw IllegalStateException("Psiphon server list was empty")
        }
        val text = decompressIfNeeded(raw)
        val allIps = IP_REGEX.findAll(text).map { it.groupValues[1] }.distinct().toList()
        if (allIps.isEmpty()) {
            throw IllegalStateException(
                "Psiphon server list parsed to 0 servers — the list format may have changed",
            )
        }
        val ips = allIps.take(20)
        val regions = REGION_REGEX.findAll(text).map { it.groupValues[1] }.distinct().sorted().toList()
        val byRegion = mutableMapOf<String, MutableList<String>>()
        ENTRY_REGEX.findAll(text).forEach { match ->
            val ip = match.groupValues[1]
            val region = match.groupValues[2]
            val list = byRegion.getOrPut(region) { mutableListOf() }
            if (list.size < 8 && ip !in list) list.add(ip)
        }
        // Regions whose entries did not match the paired regex still
        // get a row when at least one sample IP exists for them via
        // the plain region list; their probe uses the global sample.
        val regionServers = regions.map { code ->
            PsiphonRegionServers(code, byRegion[code].orEmpty())
        }
        kv.encode("bytes", raw.size)
        kv.encode("entries", allIps.size)
        kv.encode("regions", regions.joinToString(","))
        kv.encode("sample_ips", ips.joinToString(","))
        kv.encode(
            "region_servers",
            regionServers.joinToString(";") { rs -> rs.code + ":" + rs.ips.joinToString(",") },
        )
        kv.encode("fetched_at", System.currentTimeMillis())
        PsiphonListSummary(
            bytesDownloaded = raw.size,
            entryCount = allIps.size,
            regions = regions,
            fetchedAtMs = System.currentTimeMillis(),
            sampleIps = ips,
            regionServers = regionServers,
        )
    }

    /**
     * The list is zlib-compressed by Psiphon's own tooling; some
     * mirrors serve gzip. Try gzip first (magic 0x1f 0x8b), then
     * zlib (Inflater), then raw text — never silently return
     * compressed bytes as if they were text.
     */
    private fun decompressIfNeeded(raw: ByteArray): String {
        if (raw.size >= 2 && raw[0] == 0x1f.toByte() && raw[1] == 0x8b.toByte()) {
            runCatching {
                GZIPInputStream(ByteArrayInputStream(raw)).readBytes().toString(Charsets.UTF_8)
            }.onSuccess { return it }
        }
        runCatching {
            InflaterInputStream(ByteArrayInputStream(raw)).readBytes().toString(Charsets.UTF_8)
        }.onSuccess { return it }
        return raw.toString(Charsets.UTF_8)
    }
}
