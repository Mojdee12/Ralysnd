package com.ralysnd.tv.data

/**
 * One stream source of a channel. A channel can carry several sources
 * (servers): the player tries them in order and the Sources sheet lets
 * the user pick one. Each source may carry its own HTTP headers
 * (Referer / Origin / User-Agent, …) — some hosts 403 without them.
 * All values come from the bundled channels.json; nothing host-specific
 * is hard-coded in the app.
 */
data class ChannelSource(
    val url: String,
    val title: String = "",
    val headers: Map<String, String> = emptyMap(),
)

/**
 * One channel from the bundled channels.json. Keys: id, name, logo,
 * categories, urls, sources, needsVpn.
 *
 * `sources` is the full model (url + optional title + optional headers).
 * `urls` is kept as a flat list for compatibility: it is derived from
 * `sources`, and channels.json files without a `sources` array still
 * parse (one source per url, no headers) — see [ChannelRepository].
 */
data class Channel(
    val id: String,
    val name: String,
    val logo: String,
    val categories: List<String>,
    val sources: List<ChannelSource>,
    /** True when the source data flags this channel as needing a VPN
     *  to play. Only the channels explicitly flagged there carry this;
     *  nothing is inferred. */
    val needsVpn: Boolean = false,
) {
    /** Every stream URL of this channel, in failover order. */
    val urls: List<String> get() = sources.map { it.url }
    /** Primary stream URL, or null when the channel has no stream at all. */
    val primaryUrl: String? get() = sources.firstOrNull()?.url
    /** Headers of the primary source (empty when the channel has none). */
    val headers: Map<String, String> get() = sources.firstOrNull()?.headers ?: emptyMap()
    /** True when this channel is live-streamable right now. */
    val isPlayable: Boolean get() = sources.isNotEmpty()
}
