package com.kunk.singbox.engines

import com.kunk.singbox.utils.TcpPing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

/**
 * mlm's core idea, reimplemented fresh: measure candidates on the
 * REAL line before connecting, stream each result live as it
 * arrives, and order fastest-first. Every value here is a measured
 * TCP connect time (or -1 / unreachable on failure) — nothing is
 * invented, estimated, or simulated.
 */
data class ScanTarget(val label: String, val host: String, val port: Int)

data class ScanResult(
    val target: ScanTarget,
    /** Measured ms, or null when unreachable. */
    val rttMs: Long?,
    val reachable: Boolean,
)

object EngineScanner {
    /**
     * Probes all [targets] concurrently and emits each [ScanResult]
     * as soon as its probe finishes (live results). Callers sort
     * fastest-first themselves from the emitted stream; [sorted]
     * is a convenience for the final list.
     */
    fun scan(targets: List<ScanTarget>): Flow<ScanResult> = flow {
        // Each probe sends its result to a channel as soon as it
        // finishes, so the collector (UI) receives results LIVE in
        // completion order, not only after the slowest probe.
        val channel = kotlinx.coroutines.channels.Channel<ScanResult>(targets.size)
        val jobs = targets.map { target ->
            async {
                val rtt = TcpPing.connect(target.host, target.port, timeout = 3000)
                channel.send(ScanResult(target, rttMs = rtt.takeIf { it >= 0 }, reachable = rtt >= 0))
            }
        }
        repeat(targets.size) { emit(channel.receive()) }
        jobs.awaitAll()
        channel.close()
    }.flowOn(Dispatchers.IO)

    /** Fastest-first ordering for a finished result list. */
    fun fastestFirst(results: List<ScanResult>): List<ScanResult> =
        results.sortedWith(
            compareBy<ScanResult> { !it.reachable }
                .thenBy { it.rttMs ?: Long.MAX_VALUE },
        )

    fun parseTargets(input: String, defaultPort: Int = 443): List<ScanTarget> {
        return input.split(",", "\n").map { it.trim() }.filter { it.isNotBlank() }.map { raw ->
            val (host, port) = MasqueEngine.parseHostPort(raw)
            ScanTarget(label = raw, host = host, port = if (raw.contains(":")) port else defaultPort)
        }
    }
}
