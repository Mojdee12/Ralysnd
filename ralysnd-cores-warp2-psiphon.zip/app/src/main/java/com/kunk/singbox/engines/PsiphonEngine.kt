package com.kunk.singbox.engines

import android.content.Context
import com.tencent.mmkv.MMKV
import java.io.ByteArrayInputStream
import java.util.concurrent.TimeUnit
import java.util.zip.GZIPInputStream
import java.util.zip.InflaterInputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * Psiphon engine — server-list fetch, region extraction, and bench
 * scaffolding. Fresh code, no other app's Psiphon code vendored.
 *
 * ROOT CAUSE of the old "no servers at all" bug, proven from the
 * official upstream source (psiphon/common/protocol/serverEntry.go):
 * a remote server list is NOT plain JSON. Each line is a
 * HEX-ENCODED string: hex("IP port secret cert {JSON}"). The core
 * decodes it with hex.DecodeString, splits the decoded text on
 * spaces into 5 fields, and JSON-parses field 5 — which is where
 * "ipAddress" and "region" live. The old code ran its
 * "ipAddress"/"region" regexes over the raw (hex) text, so it
 * could never match anything: download 373,549 bytes, zero
 * regions, every time. The earlier zlib fix was real but
 * insufficient on its own — after zlib decompression the text is
 * still hex, not JSON. This version decodes exactly like the core
 * does: decompress, unwrap the signed-package JSON envelope when
 * present, hex-decode each line, JSON-parse the 5th field.
 *
 * The signed-package envelope: the core's remote lists are
 * AuthenticatedDataPackages (psiphon/common/authPackage.go) —
 * zlib-compressed JSON {"data": "<hex lines>", ...}. The "data"
 * payload is used for region display only; the core itself
 * verifies the signature when it connects, so display here does
 * not need the public key. The file written for the core contains
 * the hex lines (the format Psi.startTunneling expects as embedded
 * entries), never the envelope JSON.
 *
 * A second old bug, also fixed: entryCount was the size of the
 * capped 20-IP sample, not the list size. It is now the total
 * distinct-IP count; the sample stays capped at 20.
 *
 * STALE-APK NOTE: the screenshot showing "Fetch server list" /
 * "Probe sampled servers" buttons is the OLD sheet. The current
 * sheet (EngineSheets.kt, PsiphonSheet) has no such buttons: it
 * auto-fetches on open and renders flag + name + ping rows. If a
 * device still shows the old buttons, it is running an older APK,
 * not this code — install the new build.
 *
 * Live tunnel: see PsiphonTunnelBridge + EngineVpnService. The
 * official Go core is wired through its Android PsiphonTunnel
 * wrapper; the one remaining owner step is Psiphon-issued
 * PropagationChannelId/SponsorId (the core rejects empty values),
 * and any rejection is shown verbatim instead of faked.
 */
data class PsiphonRegionServers(
    /** ISO country code from the list, e.g. "US". */
    val code: String,
    /** Sampled server IPs for this region (at most 8). */
    val ips: List<String>,
) {
    /** Total servers for this region in the fetched list. */
    val totalCount: Int
        get() = ips.size
}

/** Parse diagnostics, shown in the sheet when a list parses to zero. */
data class PsiphonParseDiagnostics(
    /** "authenticated-package", "hex-lines", "json-lines", or "unknown". */
    val format: String,
    val decompressedBytes: Int,
    val totalLines: Int,
    val hexDecodedLines: Int,
    val jsonParsedLines: Int,
    val matchedEntries: Int,
    val skippedLines: Int,
) {
    override fun toString(): String =
        "format=$format, decompressed=$decompressedBytes bytes, lines=$totalLines, " +
            "hex-decoded=$hexDecodedLines, json-parsed=$jsonParsedLines, " +
            "matched=$matchedEntries, skipped=$skippedLines"
}

data class PsiphonListSummary(
    val bytesDownloaded: Int,
    /** Total server entries parsed from the list, null when unparsed. */
    val entryCount: Int?,
    val regions: List<String>,
    val fetchedAtMs: Long,
    /** Sampled server IPs extracted from the list (at most 20). */
    val sampleIps: List<String>,
    /** Per-region server samples, for the region rows. */
    val regionServers: List<PsiphonRegionServers> = emptyList(),
    /** Parse diagnostics for the last successful fetch (null for cached). */
    val diagnostics: PsiphonParseDiagnostics? = null,
)

class PsiphonEngine(private val context: Context) {
    private val kv = MMKV.mmkvWithID("ralysnd_psiphon", MMKV.SINGLE_PROCESS_MODE)

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    companion object {
        /** Public Psiphon server list (public URL, no key material). */
        const val PUBLIC_SERVER_LIST_URL =
            "https://s3.amazonaws.com/psiphon/web/iohq-waa4-q4dt/server_list_compressed"

        /**
         * The only fetch source. Psiphon publishes its remote lists
         * per propagation channel (signed); there is no generic
         * public mirror list to fall back to, and inventing mirror
         * URLs would be guessing. On failure the sheet shows the
         * real error + Retry, and keeps showing the last cached
         * list when one exists.
         */
        val SERVER_LIST_URLS = listOf(PUBLIC_SERVER_LIST_URL)

        private val IP_LIKE = Regex("^[0-9.]+$")
        private val REGION_LIKE = Regex("^[A-Z]{2}$")
        private val HEX_LIKE = Regex("^[0-9a-fA-F]+$")

        /** Hex-decodes a line; null when it is not even-length hex. */
        fun hexDecodeLine(line: String): String? {
            if (line.length < 2 || line.length % 2 != 0 || !HEX_LIKE.matches(line)) return null
            return try {
                val out = ByteArray(line.length / 2)
                for (i in out.indices) {
                    out[i] = line.substring(i * 2, i * 2 + 2).toInt(16).toByte()
                }
                out.toString(Charsets.UTF_8)
            } catch (_: Exception) {
                null
            }
        }

        /**
         * Parses decompressed list text exactly like the core's
         * DecodeServerEntryList: split into lines, hex-decode each
         * line, skip the 4-field legacy prefix, JSON-parse the rest.
         * Lines that are already plain JSON are parsed directly
         * (defensive fallback). Returns the entries, the hex lines
         * to hand to the core, and full diagnostics.
         */
        fun parseServerListText(text: String): ParsedPsiphonList {
            // Authenticated-package envelope? {"data": "<hex lines>", ...}
            var linesText = text
            var format = "hex-lines"
            val trimmed = text.trimStart()
            if (trimmed.startsWith("{")) {
                runCatching {
                    val data = JSONObject(trimmed).optString("data", "")
                    if (data.isNotBlank()) {
                        linesText = data
                        format = "authenticated-package"
                    } else {
                        format = "json-lines"
                    }
                }.onFailure {
                    format = "unknown"
                }
            }
            val entries = mutableListOf<Pair<String, String>>()
            val coreLines = mutableListOf<String>()
            var totalLines = 0
            var hexDecoded = 0
            var jsonParsed = 0
            var skipped = 0
            for (rawLine in linesText.split("\n")) {
                val line = rawLine.trim()
                if (line.isEmpty()) continue
                totalLines++
                val jsonText: String?
                val coreLine: String?
                if (line.startsWith("{")) {
                    // Defensive fallback: already plain JSON.
                    jsonText = line
                    coreLine = hexEncodeEntry(line)
                } else {
                    val decoded = hexDecodeLine(line)
                    if (decoded == null) {
                        skipped++
                        continue
                    }
                    hexDecoded++
                    // Core rule: SplitN(decoded, " ", 5); JSON is field 5.
                    val fields = decoded.split(" ", limit = 5)
                    jsonText = if (fields.size == 5) fields[4] else null
                    coreLine = line
                }
                if (jsonText == null || !jsonText.trimStart().startsWith("{")) {
                    skipped++
                    continue
                }
                val obj = runCatching { JSONObject(jsonText) }.getOrNull()
                if (obj == null) {
                    skipped++
                    continue
                }
                jsonParsed++
                val ip = obj.optString("ipAddress", "")
                val region = obj.optString("region", "")
                if (!IP_LIKE.matches(ip) || !REGION_LIKE.matches(region)) {
                    skipped++
                    continue
                }
                entries.add(ip to region)
                if (coreLine != null) coreLines.add(coreLine)
            }
            return ParsedPsiphonList(
                entries = entries,
                coreLines = coreLines,
                diagnostics = PsiphonParseDiagnostics(
                    format = format,
                    decompressedBytes = text.toByteArray(Charsets.UTF_8).size,
                    totalLines = totalLines,
                    hexDecodedLines = hexDecoded,
                    jsonParsedLines = jsonParsed,
                    matchedEntries = entries.size,
                    skippedLines = skipped,
                ),
            )
        }

        /** Encodes a plain-JSON entry the way the core expects it. */
        private fun hexEncodeEntry(json: String): String {
            val plain = "0 0 0 0 $json"
            return plain.toByteArray(Charsets.UTF_8).joinToString("") { "%02x".format(it) }
        }
    }

    /** Result of [parseServerListText]. */
    data class ParsedPsiphonList(
        val entries: List<Pair<String, String>>,
        /** Hex lines to write for the tunnel core. */
        val coreLines: List<String>,
        val diagnostics: PsiphonParseDiagnostics,
    )

    fun cachedSummary(): PsiphonListSummary? {
        val bytes = kv.decodeInt("bytes", 0)
        if (bytes <= 0) return null
        val regions = kv.decodeString("regions", "")
            ?.split(",")
            ?.filter { it.isNotBlank() }
            .orEmpty()
        val regionServers = kv.decodeString("region_servers", "")
            ?.split(";")
            ?.mapNotNull { part ->
                val code = part.substringBefore(":", "")
                val ips = part.substringAfter(":", "")
                    .split(",")
                    .filter { it.isNotBlank() }
                if (code.isBlank()) null else PsiphonRegionServers(code, ips)
            }
            .orEmpty()
        return PsiphonListSummary(
            bytesDownloaded = bytes,
            entryCount = kv.decodeInt("entries", -1).takeIf { it >= 0 },
            regions = regions,
            fetchedAtMs = kv.decodeLong("fetched_at", 0L),
            sampleIps = kv.decodeString("sample_ips", "")
                ?.split(",")
                ?.filter { it.isNotBlank() }
                .orEmpty(),
            regionServers = regionServers,
            diagnostics = null,
        )
    }

    /** Downloads the public list and returns a parsed summary. */
    suspend fun fetchServerList(): PsiphonListSummary = withContext(Dispatchers.IO) {
        val request = Request.Builder().url(PUBLIC_SERVER_LIST_URL).build()
        val raw = http.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException(
                    "Psiphon server list failed: HTTP ${response.code} from $PUBLIC_SERVER_LIST_URL",
                )
            }
            response.body?.bytes() ?: ByteArray(0)
        }
        if (raw.isEmpty()) {
            throw IllegalStateException("Psiphon server list was empty ($PUBLIC_SERVER_LIST_URL)")
        }
        val text = decompressIfNeeded(raw)
        val parsed = parseServerListText(text)
        val allIps = parsed.entries.map { it.first }.distinct()
        if (allIps.isEmpty()) {
            throw IllegalStateException(
                "Psiphon server list parsed to 0 servers from $PUBLIC_SERVER_LIST_URL " +
                    "(${parsed.diagnostics}). The list format may have changed — tap Retry.",
            )
        }
        val ips = allIps.take(20)
        val byRegion = mutableMapOf<String, MutableList<String>>()
        parsed.entries.forEach { (ip, region) ->
            val list = byRegion.getOrPut(region) { mutableListOf() }
            if (list.size < 8 && ip !in list) list.add(ip)
        }
        val regions = byRegion.keys.sorted()
        val regionServers = regions.map { code ->
            PsiphonRegionServers(code, byRegion[code].orEmpty())
        }
        kv.encode("bytes", raw.size)
        kv.encode("entries", allIps.size)
        kv.encode("regions", regions.joinToString(","))
        kv.encode("sample_ips", ips.joinToString(","))
        kv.encode(
            "region_servers",
            regionServers.joinToString(";") { rs -> rs.code + ":" + rs.ips.joinToString(",") },
        )
        kv.encode("fetched_at", System.currentTimeMillis())
        // The tunnel core consumes these exact hex lines as its
        // embedded server entries (see PsiphonTunnelBridge): keep a
        // file copy next to the summary so connect never needs a
        // re-download. Never write the envelope JSON here — the
        // core decodes hex lines, not JSON.
        runCatching {
            java.io.File(context.filesDir, "psiphon_server_list.json")
                .writeText(parsed.coreLines.joinToString("\n"))
        }
        PsiphonListSummary(
            bytesDownloaded = raw.size,
            entryCount = allIps.size,
            regions = regions,
            fetchedAtMs = System.currentTimeMillis(),
            sampleIps = ips,
            regionServers = regionServers,
            diagnostics = parsed.diagnostics,
        )
    }

    /**
     * The list is zlib-compressed by Psiphon's own tooling; some
     * mirrors serve gzip. Try gzip first (magic 0x1f 0x8b), then
     * zlib (Inflater), then raw text — never silently return
     * compressed bytes as if they were text.
     */
    private fun decompressIfNeeded(raw: ByteArray): String {
        if (raw.size >= 2 && raw[0] == 0x1f.toByte() && raw[1] == 0x8b.toByte()) {
            runCatching {
                GZIPInputStream(ByteArrayInputStream(raw)).readBytes().toString(Charsets.UTF_8)
            }.onSuccess { return it }
        }
        runCatching {
            InflaterInputStream(ByteArrayInputStream(raw)).readBytes().toString(Charsets.UTF_8)
        }.onSuccess { return it }
        return raw.toString(Charsets.UTF_8)
    }
}
