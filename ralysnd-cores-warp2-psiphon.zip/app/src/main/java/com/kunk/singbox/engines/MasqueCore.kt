package com.kunk.singbox.engines

/**
 * JNI wrapper for the native MASQUE core (Rust, quiche-based) that
 * lives in app/src/main/rust/masque-core and is built on the build
 * server with cargo-ndk into app/src/main/jniLibs/<abi>/
 * libmasque_core.so. The .so is NOT in git: if it is missing, the
 * library simply fails to load and every start attempt reports
 * that plainly — nothing pretends to be connected.
 *
 * What the core does (see the Rust source for the full contract):
 * it runs a local SOCKS5 server on 127.0.0.1:[socksPort] and, for
 * each SOCKS5 connection, opens an HTTP/3 CONNECT (TCP) or
 * CONNECT-UDP (UDP, RFC 9298) stream to the MASQUE gateway, then
 * relays bytes/datagrams between the local socket and that
 * stream. The app's existing hev-socks5-tunnel points at the
 * local SOCKS5 port, exactly like the Foxy tunnel does for its
 * own local proxy — no new VPN-service plumbing was invented.
 *
 * TLS verification note: when the gateway is a hostname, the core
 * verifies the certificate against that name. When it is an IP
 * literal (like the documented WARP anycast edge), there is no
 * hostname to verify against, so the core dials with verification
 * off for that case only — the same trade-off sing-box makes for
 * IP endpoints with allowInsecure. Hostname gateways are always
 * verified.
 *
 * Gateway compatibility note: this is a generic CONNECT-UDP
 * client. A gateway that speaks CONNECT-IP (RFC 9484, e.g. the
 * WARP MASQUE edge, which authenticates as a WARP client) will
 * reject CONNECT-UDP requests, and that rejection is surfaced as
 * the connect error — it is not papered over. A generic
 * CONNECT-UDP gateway (cached winner or user-added endpoint) is
 * what this core connects to today.
 */
object MasqueCore {
    /** True only when libmasque_core.so actually loaded. */
    val isAvailable: Boolean = runCatching {
        System.loadLibrary("masque_core")
        true
    }.getOrDefault(false)

    private external fun nativeStart(
        gatewayHost: String,
        gatewayPort: Int,
        serverName: String,
        socksPort: Int,
    ): Int

    private external fun nativeStop()

    private external fun nativeIsRunning(): Boolean

    /**
     * Starts the core. [serverName] is "" when the gateway is an
     * IP literal (see the file note). Returns success only when
     * the native side reports 0; any other code is a real error.
     */
    fun start(
        gatewayHost: String,
        gatewayPort: Int,
        serverName: String,
        socksPort: Int,
    ): Result<Unit> {
        if (!isAvailable) {
            return Result.failure(
                IllegalStateException("MASQUE core library (libmasque_core.so) is not installed in this build"),
            )
        }
        val rc = runCatching {
            nativeStart(gatewayHost, gatewayPort, serverName, socksPort)
        }.getOrElse { e ->
            return Result.failure(e)
        }
        return if (rc == 0) {
            Result.success(Unit)
        } else {
            Result.failure(IllegalStateException("MASQUE core failed to start (code $rc)"))
        }
    }

    fun isRunning(): Boolean =
        isAvailable && runCatching { nativeIsRunning() }.getOrDefault(false)

    fun stop() {
        if (isAvailable) runCatching { nativeStop() }
    }
}
