package com.kunk.singbox.engines

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import com.kunk.singbox.foxy.vpn.FoxyVpnService
import com.kunk.singbox.foxy.vpn.tun.HevSocks5Tunnel
import com.kunk.singbox.foxy.vpn.tun.HevSocks5TunnelConfig
import com.kunk.singbox.service.SingBoxService
import java.io.File
import java.net.ServerSocket
import java.net.Socket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** UI-visible state of the engine VPN service. Never faked: an
 *  Error state carries the core's real message, and Connected is
 *  only published after the TUN interface and hev tunnel are up. */
sealed interface EngineVpnState {
    data object Disconnected : EngineVpnState
    data class Connecting(val engine: String) : EngineVpnState
    data class Connected(val engine: String, val detail: String) : EngineVpnState
    data class Error(val engine: String, val message: String) : EngineVpnState
}

/**
 * One shared VpnService for the MASQUE and Psiphon cores.
 *
 * Traffic flow (both engines, same shape as the Foxy tunnel):
 *   app traffic -> TUN -> hev-socks5-tunnel -> local SOCKS5
 *   (127.0.0.1:[socksPort]) -> core -> gateway / Psiphon server
 *   -> internet.
 * The MASQUE core itself IS the local SOCKS5 server (Rust); the
 * Psiphon core runs its own local SOCKS proxy and reports its
 * port via onListeningSocksProxyPort.
 *
 * Single-VpnService rule: before starting, this service stops
 * Foxy and sing-box explicitly. Android additionally allows only
 * one active VPN. The app's own package is disallowed from the
 * TUN (like Foxy does) so the cores' own outbound sockets bypass
 * the tunnel instead of looping back into it.
 */
class EngineVpnService : VpnService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var connectJob: Job? = null
    private var monitorJob: Job? = null
    private var tunFd: ParcelFileDescriptor? = null
    private var currentEngine: String? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> {
                teardown()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                if (connectJob != null || _state.value !is EngineVpnState.Disconnected) {
                    return START_STICKY
                }
                val mode = intent?.getStringExtra(EXTRA_MODE) ?: return START_NOT_STICKY
                val gateway = intent.getStringExtra(EXTRA_GATEWAY)
                val region = intent.getStringExtra(EXTRA_REGION)
                enterForeground(mode)
                connectJob = scope.launch { connect(mode, gateway, region) }
                return START_STICKY
            }
        }
    }

    override fun onDestroy() {
        teardown()
        scope.cancel()
        super.onDestroy()
    }

    private fun enterForeground(mode: String) {
        val channelId = "ralysnd_engine_vpn"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            if (manager?.getNotificationChannel(channelId) == null) {
                manager?.createNotificationChannel(
                    NotificationChannel(
                        channelId,
                        "Ralysnd engine VPN",
                        NotificationManager.IMPORTANCE_LOW,
                    ),
                )
            }
        }
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Ralysnd")
            .setContentText(if (mode == MODE_MASQUE) "MASQUE connecting…" else "Psiphon connecting…")
            .setOngoing(true)
            .build()
        startForeground(1, notification)
    }

    private suspend fun connect(mode: String, gateway: String?, region: String?) {
        val engine = if (mode == MODE_MASQUE) "MASQUE" else "Psiphon"
        currentEngine = engine
        _state.value = EngineVpnState.Connecting(engine)
        // Single-VpnService rule: stop the other two first.
        runCatching { FoxyVpnService.stop(applicationContext) }
        runCatching {
            applicationContext.startService(
                Intent(applicationContext, SingBoxService::class.java)
                    .setAction(SingBoxService.ACTION_STOP),
            )
        }
        val socksPort: Int = try {
            if (mode == MODE_MASQUE) {
                val (host, gwPort) = MasqueEngine.parseHostPort(gateway ?: MasqueEngine.DOCUMENTED_MASQUE_EDGE)
                val localPort = freePort()
                val serverName = if (IP_LIKE.matches(host)) "" else host
                MasqueCore.start(host, gwPort, serverName, localPort)
                    .getOrElse { throw IllegalStateException(it.message ?: "MASQUE core failed to start") }
                waitForLocalProxy(localPort, 15_000)
                    ?: throw IllegalStateException("MASQUE core did not open its local proxy")
                localPort
            } else {
                val entries = runCatching {
                    File(applicationContext.filesDir, "psiphon_server_list.json").readText()
                }.getOrDefault("")
                PsiphonTunnelBridge.start(applicationContext, region, entries)
                waitForPsiphonProxy()
            }
        } catch (e: Exception) {
            Log.e(TAG, "engine $engine failed to start", e)
            _state.value = EngineVpnState.Error(engine, e.message ?: e.javaClass.simpleName)
            teardownCores()
            stopSelf()
            connectJob = null
            return
        }
        try {
            val tun = Builder()
                .setSession("Ralysnd $engine")
                .addAddress(HevSocks5TunnelConfig.TUN_ADDRESS, 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer(HevSocks5TunnelConfig.MAPDNS_ADDRESS)
                .setMtu(HevSocks5TunnelConfig.TUN_MTU)
                .setBlocking(true)
                .apply {
                    runCatching { addDisallowedApplication(packageName) }
                }
                .establish()
                ?: throw IllegalStateException("Could not establish the VPN interface (permission revoked?)")
            tunFd = tun
            val configPath = HevSocks5TunnelConfig.write(applicationContext, socksPort)
            if (!HevSocks5Tunnel.start(configPath, tun.fd)) {
                throw IllegalStateException("Failed to start the local tunnel (hev-socks5-tunnel)")
            }
            val detail = if (mode == MODE_MASQUE) {
                "via $gateway"
            } else {
                "SOCKS :$socksPort" + (region?.takeIf { it.isNotBlank() }?.let { " · $it" } ?: "")
            }
            _state.value = EngineVpnState.Connected(engine, detail)
            monitorJob = scope.launch { monitor(mode, engine) }
        } catch (e: Exception) {
            Log.e(TAG, "engine $engine TUN/tunnel failed", e)
            _state.value = EngineVpnState.Error(engine, e.message ?: e.javaClass.simpleName)
            teardown()
            stopSelf()
            connectJob = null
        }
    }

    private suspend fun monitor(mode: String, engine: String) {
        while (true) {
            delay(2_000)
            if (mode == MODE_MASQUE) {
                if (!MasqueCore.isRunning()) {
                    _state.value = EngineVpnState.Error(engine, "MASQUE core stopped unexpectedly")
                    teardown()
                    stopSelf()
                    return
                }
            } else {
                PsiphonTunnelBridge.lastError?.let { error ->
                    _state.value = EngineVpnState.Error(engine, error)
                    teardown()
                    stopSelf()
                    return
                }
                if (PsiphonTunnelBridge.connected) {
                    val region = PsiphonTunnelBridge.connectedRegion
                    val current = _state.value
                    if (current is EngineVpnState.Connected && region != null &&
                        !current.detail.contains(region)
                    ) {
                        _state.value = current.copy(detail = current.detail + " · connected: $region")
                    }
                }
            }
        }
    }

    /** Waits until something accepts TCP on the local SOCKS port. */
    private suspend fun waitForLocalProxy(port: Int, timeoutMs: Long): Int? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (!MasqueCore.isRunning()) return null
            val ok = runCatching {
                Socket().use { socket ->
                    socket.connect(java.net.InetSocketAddress("127.0.0.1", port), 300)
                }
                true
            }.getOrDefault(false)
            if (ok) return port
            delay(500)
        }
        return null
    }

    /** Waits for the Psiphon core to report its SOCKS port or an error. */
    private suspend fun waitForPsiphonProxy(): Int {
        val deadline = System.currentTimeMillis() + 60_000
        while (System.currentTimeMillis() < deadline) {
            PsiphonTunnelBridge.lastError?.let { throw IllegalStateException(it) }
            val port = PsiphonTunnelBridge.socksPort
            if (port != 0) return port
            delay(500)
        }
        throw IllegalStateException("Psiphon core did not open its local proxy in 60s")
    }

    private fun teardownCores() {
        runCatching { MasqueCore.stop() }
        runCatching { PsiphonTunnelBridge.stop() }
    }

    private fun teardown() {
        monitorJob?.cancel()
        monitorJob = null
        connectJob?.cancel()
        connectJob = null
        runCatching { HevSocks5Tunnel.stop() }
        teardownCores()
        runCatching { tunFd?.close() }
        tunFd = null
        currentEngine = null
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
        if (_state.value !is EngineVpnState.Disconnected) {
            _state.value = EngineVpnState.Disconnected
        }
    }

    private fun freePort(): Int = ServerSocket(0).use { it.localPort }

    companion object {
        private const val TAG = "EngineVpnService"
        private val IP_LIKE = Regex("^[0-9.]+$")

        const val ACTION_CONNECT = "com.kunk.singbox.engines.action.CONNECT"
        const val ACTION_DISCONNECT = "com.kunk.singbox.engines.action.DISCONNECT"
        const val MODE_MASQUE = "masque"
        const val MODE_PSIPHON = "psiphon"
        private const val EXTRA_MODE = "mode"
        private const val EXTRA_GATEWAY = "gateway"
        private const val EXTRA_REGION = "region"

        private val _state = MutableStateFlow<EngineVpnState>(EngineVpnState.Disconnected)
        val state: StateFlow<EngineVpnState> = _state.asStateFlow()

        fun startMasque(context: Context, gateway: String) {
            val intent = Intent(context, EngineVpnService::class.java).apply {
                action = ACTION_CONNECT
                putExtra(EXTRA_MODE, MODE_MASQUE)
                putExtra(EXTRA_GATEWAY, gateway)
            }
            start(context, intent)
        }

        fun startPsiphon(context: Context, region: String?) {
            val intent = Intent(context, EngineVpnService::class.java).apply {
                action = ACTION_CONNECT
                putExtra(EXTRA_MODE, MODE_PSIPHON)
                putExtra(EXTRA_REGION, region)
            }
            start(context, intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, EngineVpnService::class.java).apply {
                action = ACTION_DISCONNECT
            }
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }

        private fun start(context: Context, intent: Intent) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
