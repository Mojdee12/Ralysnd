package com.kunk.singbox.engines

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import ca.psiphon.PsiphonTunnel
import org.json.JSONObject

/**
 * Kotlin bridge to the official Psiphon tunnel core (Go, via its
 * Android PsiphonTunnel JNI wrapper — classes from ca.psiphon.aar,
 * built on the build server from github.com/Psiphon-Labs/
 * psiphon-tunnel-core via MobileLibrary/Android/make.bash).
 *
 * Verified API surface (read from the upstream PsiphonTunnel.java):
 * - PsiphonTunnel.newPsiphonTunnel(HostService): singleton, stops
 *   any previous instance.
 * - HostService requires getContext() and getPsiphonConfig(); all
 *   other callbacks have defaults. The wrapper fills in
 *   DataRootDirectory, ClientPlatform and ClientAPILevel itself.
 * - tunnel.setVpnMode(true) before startTunneling(...); the core
 *   then runs a local SOCKS proxy and the app runs tun2socks to it
 *   (the same pattern as the official client's VPN mode).
 * - tunnel.startTunneling(embeddedServerEntries): embedded entries
 *   are the HEX-ENCODED server-entry lines this app already
 *   downloads and decodes (see PsiphonEngine, which writes exactly
 *   those lines to psiphon_server_list.json). The core splits them
 *   on newlines and hex-decodes each one (DecodeServerEntryList /
 *   DecodeServerEntryFields); passing JSON here would fail to
 *   decode. "" is allowed by the wrapper (restartPsiphon passes
 *   "") but then the core has no entries and reports its own error.
 * - The local SOCKS port is chosen by the core (0 = system picks)
 *   and reported via onListeningSocksProxyPort; callers must wait
 *   for it — there is no setter (setLocalSocksProxyPort is private).
 * - start/stop must never be called from inside a HostService
 *   callback (deadlock): this bridge calls them only from the
 *   EngineVpnService worker thread.
 *
 * GPL-3.0 NOTICE: the Psiphon tunnel core is GPL-licensed. This
 * bridge is fine for the user's personal use, but a public release
 * of the combined app carries GPL implications (the combined work
 * must be offered under GPL terms). Nothing here hides that.
 *
 * CREDENTIALS GAP, STATED PLAINLY: the core validates its config
 * and rejects it when PropagationChannelId or SponsorId is empty
 * ("propagation channel ID is missing from the configuration
 * file", psiphon/config.go). Those identifiers are issued by the
 * Psiphon Network to a distributing client — they cannot be
 * invented, and copying another client's identifiers would be
 * impersonation, so this bridge ships them EMPTY on purpose. A
 * start attempt therefore surfaces the core's real validation
 * error until the app owner supplies Psiphon-issued values in
 * PSIPHON_CHANNEL_ID / PSIPHON_SPONSOR_ID below. No fake
 * connected state is ever produced: if the core rejects the
 * config, the sheet shows its exact error.
 */
object PsiphonTunnelBridge {
    private const val TAG = "PsiphonTunnelBridge"

    /**
     * Owner-issued Psiphon Network identifiers. EMPTY until the app
     * owner obtains them from Psiphon Inc. — see the file note.
     * Do NOT fill these with another client's values.
     */
    const val PSIPHON_CHANNEL_ID = ""
    const val PSIPHON_SPONSOR_ID = ""

    @Volatile var socksPort: Int = 0
        private set

    @Volatile var connected: Boolean = false
        private set

    @Volatile var connectedRegion: String? = null
        private set

    @Volatile var lastError: String? = null
        private set

    @Volatile private var tunnel: PsiphonTunnel? = null

    private inner class Host(
        private val context: Context,
        private val configJson: String,
    ) : PsiphonTunnel.HostService {
        override fun getContext(): Context = context

        override fun getPsiphonConfig(): String = configJson

        override fun onListeningSocksProxyPort(port: Int) {
            socksPort = port
            Log.i(TAG, "Psiphon local SOCKS proxy listening on $port")
        }

        override fun onConnecting() {
            connected = false
        }

        override fun onConnected() {
            connected = true
            Log.i(TAG, "Psiphon tunnel connected")
        }

        override fun onConnectedServerRegion(region: String) {
            connectedRegion = region
        }

        override fun onDiagnosticMessage(message: String) {
            Log.d(TAG, message)
        }
    }

    /** Builds the config JSON the core validates. Never invents IDs. */
    fun buildConfig(context: Context, egressRegion: String?): String {
        val version = runCatching {
            @Suppress("DEPRECATION")
            context.packageManager.getPackageInfo(context.packageName, 0).versionName
        }.getOrNull() ?: "1.0"
        return JSONObject().apply {
            put("PropagationChannelId", PSIPHON_CHANNEL_ID)
            put("SponsorId", PSIPHON_SPONSOR_ID)
            put("ClientVersion", version)
            put("EgressRegion", egressRegion ?: "")
            put("EmitBytesTransferred", false)
        }.toString()
    }

    /**
     * Starts the core. Throws nothing: failures are recorded in
     * [lastError] (startTunneling throws on the worker thread) and
     * surfaced by the caller. Returns immediately; connection
     * progress arrives via the Host callbacks.
     */
    @Synchronized
    fun start(context: Context, egressRegion: String?, embeddedServerEntries: String) {
        lastError = null
        socksPort = 0
        connected = false
        connectedRegion = null
        val configJson = buildConfig(context, egressRegion)
        val host = Host(context.applicationContext, configJson)
        val newTunnel = PsiphonTunnel.newPsiphonTunnel(host)
        tunnel = newTunnel
        newTunnel.setVpnMode(true)
        Thread(
            {
                try {
                    newTunnel.startTunneling(embeddedServerEntries)
                } catch (e: Exception) {
                    lastError = "Psiphon core: ${e.message ?: e.javaClass.simpleName}"
                    Log.e(TAG, "startTunneling failed", e)
                }
            },
            "psiphon-start",
        ).start()
    }

    /** Stops the core on a worker thread (never from a callback). */
    fun stop() {
        val current = tunnel
        tunnel = null
        socksPort = 0
        connected = false
        connectedRegion = null
        if (current == null) return
        Thread(
            {
                runCatching { current.stop() }
                    .onFailure { Log.w(TAG, "Psiphon stop failed", it) }
            },
            "psiphon-stop",
        ).start()
    }
}
