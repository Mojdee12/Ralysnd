package com.kunk.singbox.ui.screens

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kunk.singbox.engines.ENGINE_GRID
import com.kunk.singbox.engines.EngineId
import com.kunk.singbox.engines.EngineVpnState
import com.kunk.singbox.engines.EnginesViewModel
import com.kunk.singbox.engines.MasqueExitMode
import com.kunk.singbox.engines.MasqueExitSelection
import com.kunk.singbox.ui.navigation.Screen
import java.util.Locale
import com.kunk.singbox.ui.theme.L4EngineTile
import com.kunk.singbox.ui.theme.L4Green
import com.kunk.singbox.ui.theme.L4GreenDark
import com.kunk.singbox.ui.theme.L4Surface
import com.kunk.singbox.ui.theme.L4SurfaceAlt
import com.kunk.singbox.ui.theme.L4PastelAmber
import com.kunk.singbox.ui.theme.L4PastelCyan
import com.kunk.singbox.ui.theme.L4PastelRose
import com.kunk.singbox.ui.theme.L4PastelSlate
import com.kunk.singbox.ui.theme.L4PastelViolet
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim

/**
 * Home engine grid (mlm-style, sample-4 light tiles) + per-engine
 * sheets. Only wanted engines appear here — no rejected engine has
 * a tile, placeholder, or reserved space. Plain WARP is NOT a
 * user-facing engine anymore: the grid is MASQUE, WARP², Psiphon,
 * WireGuard, FENIX, in that order. The WARP identity and
 * registration code still exist underneath because WARP² needs
 * them as its outer layer — but the user never sees a plain-WARP
 * tile, sheet, or label.
 *
 * Wiring (honest):
 * - WireGuard -> Nodes screen (existing nodes).
 * - FENIX -> FENIX tab (existing Foxy tunnel).
 * - WARP² -> NO country list, NO node-picking, NO manual fields:
 *   a per-country WARP² exit needs a per-country inner-server
 *   fleet, and no legitimate built-in fleet exists (WARP itself
 *   offers no exit-country choice; the only known per-country
 *   list is another app's proprietary data and must not be
 *   copied). The sheet states this blocker plainly and offers
 *   the one honest zero-input action: single-layer WARP
 *   (Cloudflare-chosen exit, explicitly labelled NOT WARP²).
 *   The two-layer chain builder stays in the repository, unused
 *   by any UI, until a legitimate fleet exists.
 * - MASQUE -> exit-country screen: IPv6 NAT64 / IPv4 proxy
 *   toggle, Ping every country over the gateway pool grouped by
 *   geolocated country, Fastest, Direct, and a live Connect
 *   button through the native QUIC core. A CONNECT-IP-only
 *   gateway (like the WARP edge) rejects CONNECT-UDP; its exact
 *   error is shown, never a fake connected state.
 * - Psiphon -> clean country list like the FENIX tab: opens and
 *   auto-fetches the public server list (hex-line decoding, like
 *   the core), rows are flag + name + real ping below the name,
 *   tap a region to egress from it, Connect through the official
 *   Go core. No Fetch button as the main interaction: only a
 *   small Retry on genuine failure. The core still needs
 *   Psiphon-issued channel/sponsor values; its exact error is
 *   shown until the owner supplies them.
 */
@Composable
fun EngineGridSection(
    onNavigate: (String) -> Unit,
    onAddNode: (String) -> Unit,
    onOpenScanner: () -> Unit,
    enginesViewModel: EnginesViewModel = viewModel(),
    /** Called with a node id when a WARP action is ready; the caller selects it and starts the service. */
    onConnectNode: (String) -> Unit = {},
) {
    var sheet by remember { mutableStateOf<EngineId?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Engines", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = L4Text)
            TextButton(onClick = onOpenScanner) { Text("Scanner", color = L4Green) }
        }
        for (row in ENGINE_GRID.chunked(2)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (engine in row) {
                    L4EngineTile(
                        title = engine.title,
                        subtitle = engine.statusNote,
                        pastel = when (engine.id) {
                            EngineId.MASQUE -> L4PastelCyan
                            EngineId.WARP2 -> L4PastelAmber
                            EngineId.PSIPHON -> L4PastelRose
                            EngineId.WIREGUARD -> L4PastelSlate
                            EngineId.FENIX -> L4PastelViolet
                        },
                        badge = engine.badge,
                        enabled = true,
                        onClick = {
                            when (engine.id) {
                                EngineId.WIREGUARD -> onNavigate(Screen.Nodes.route)
                                EngineId.FENIX -> onNavigate(Screen.Fenix.route)
                                else -> sheet = engine.id
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (row.size == 1) Spacer(modifier = Modifier.weight(1f))
            }
        }
    }

    when (sheet) {
        EngineId.WARP2 -> Warp2Sheet(enginesViewModel = enginesViewModel, onConnectNode = onConnectNode, onDismiss = { sheet = null })
        EngineId.MASQUE -> MasqueSheet(enginesViewModel = enginesViewModel, onDismiss = { sheet = null })
        EngineId.PSIPHON -> PsiphonSheet(enginesViewModel = enginesViewModel, onDismiss = { sheet = null })
        else -> Unit
    }
}


/** Flag emoji for an ISO country code, computed from regional indicators — no hard-coded flag list. */
private fun flagForCountryCode(code: String): String {
    val upper = code.uppercase()
    if (upper.length != 2 || !upper.all { it in 'A'..'Z' }) return "🌍"
    return upper.map { char -> String(Character.toChars(0x1F1E6 + (char - 'A'))) }.joinToString("")
}

private fun countryNameForCode(code: String): String {
    return Locale("", code).displayCountry.takeIf { it.isNotBlank() } ?: code
}

@Composable
private fun Warp2Sheet(
    enginesViewModel: EnginesViewModel,
    onConnectNode: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val identity by enginesViewModel.warpIdentity.collectAsStateWithLifecycle()
    val busy by enginesViewModel.warp2Busy.collectAsStateWithLifecycle()
    val error by enginesViewModel.warp2Error.collectAsStateWithLifecycle()
    val relay by enginesViewModel.warp2WorkerRelay.collectAsStateWithLifecycle()
    val relayUrl by enginesViewModel.warp2WorkerRelayUrl.collectAsStateWithLifecycle()
    val report by enginesViewModel.warp2Report.collectAsStateWithLifecycle()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("WARP in WARP", color = L4Text) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                Text(
                    text = "A WireGuard tunnel carried inside a WARP tunnel — two layers instead of one. It is slower to establish, and the reason to reach for it is a network that blocks either layer on its own.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                Text(
                    text = "Country exits — not available in this app",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = L4Text,
                )
                Text(
                    text = "A WARP² country list needs an inner server in each country, and this app has no built-in fleet: Cloudflare's WARP itself offers no exit-country choice (it routes to the nearest data center and chooses the egress), and the only per-country exit list known to exist belongs to another app and cannot be copied. So no country list is shown here — a list with no real exits behind it would be fake. Picking one of your own servers or typing server details is not offered either: that is not the country-list model, and it will not be disguised as one. A real country list becomes possible only with a per-country inner-server fleet, which is infrastructure this app does not have.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                Text(
                    text = "What works now — one tap, no typing",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = L4Text,
                )
                Text(
                    text = "Single-layer WARP: your WARP identity is registered automatically if you do not have one yet, one WARP node is added, and the tunnel starts through the Dashboard like any other connection. This is NOT WARP² — one Cloudflare layer, Cloudflare-chosen exit, no country choice. After the first tap, reconnect from Nodes or the Dashboard.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                if (identity == null) {
                    Text(
                        text = "No WARP identity stored yet — one will be registered automatically when you connect.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                }
                if (error != null) Text(text = error ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Button(
                    onClick = {
                        enginesViewModel.connectWarpSingleLayer { nodeId ->
                            onConnectNode(nodeId)
                            onDismiss()
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text(if (busy) "Connecting…" else "Connect WARP (single layer)") }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Make identity through worker",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4Text,
                        modifier = Modifier.weight(1f),
                    )
                    Switch(checked = relay, onCheckedChange = { enginesViewModel.setWarp2WorkerRelay(it) })
                }
                Text(
                    text = "Off by default. Only turn this on once if making an identity is filtered on your network.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                if (relay) {
                    OutlinedTextField(
                        value = relayUrl,
                        onValueChange = { enginesViewModel.setWarp2WorkerRelayUrl(it) },
                        label = { Text("Your worker relay URL") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                    )
                    if (relayUrl.isBlank()) {
                        Text(
                            text = "No relay is built into this app — with this on and no URL set, connecting will stop and say so.",
                            style = MaterialTheme.typography.bodySmall,
                            color = L4TextDim,
                        )
                    }
                }
                Text(
                    text = "Connection report: ${report.attempts} attempts" +
                        (report.lastOutcome?.let { " · last: $it" } ?: ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun MasqueSheet(
    enginesViewModel: EnginesViewModel,
    onDismiss: () -> Unit,
) {
    val countries by enginesViewModel.masqueCountries.collectAsStateWithLifecycle()
    val pinging by enginesViewModel.masquePinging.collectAsStateWithLifecycle()
    val masqueError by enginesViewModel.masqueError.collectAsStateWithLifecycle()
    val mode by enginesViewModel.masqueExitMode.collectAsStateWithLifecycle()
    val selection by enginesViewModel.masqueSelection.collectAsStateWithLifecycle()
    val fastest = enginesViewModel.masqueFastest
    val engineState by enginesViewModel.engineVpnState.collectAsStateWithLifecycle()
    var manual by remember { mutableStateOf("") }
    var showAdvanced by remember { mutableStateOf(false) }
    var pendingConnect by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingConnect) {
            enginesViewModel.connectMasque()
        }
        pendingConnect = false
    }
    // Zero input: ping the gateway pool as soon as the sheet opens.
    LaunchedEffect(Unit) {
        if (countries.isEmpty()) enginesViewModel.pingMasqueCountries()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("MASQUE — Exit country", color = L4Text) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { enginesViewModel.setMasqueExitMode(MasqueExitMode.IPV6_NAT64) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (mode == MasqueExitMode.IPV6_NAT64) L4Green else L4SurfaceAlt,
                            contentColor = if (mode == MasqueExitMode.IPV6_NAT64) L4Surface else L4Text,
                        ),
                    ) { Text("IPv6 · NAT64 gateway") }
                    Button(
                        onClick = { enginesViewModel.setMasqueExitMode(MasqueExitMode.IPV4_PROXY) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (mode == MasqueExitMode.IPV4_PROXY) L4Green else L4SurfaceAlt,
                            contentColor = if (mode == MasqueExitMode.IPV4_PROXY) L4Surface else L4Text,
                        ),
                    ) { Text("IPv4 · proxy") }
                }
                Button(
                    onClick = { enginesViewModel.pingMasqueCountries() },
                    enabled = !pinging,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text(if (pinging) "Pinging…" else "Ping every country") }
                if (masqueError != null) Text(text = masqueError ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Text(
                    text = "A short real connection to each gateway: ping, speed where measurable, and whether it works.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                when (val state = engineState) {
                    is EngineVpnState.Connecting -> if (state.engine == "MASQUE") {
                        Text(text = "Connecting…", style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                    }
                    is EngineVpnState.Connected -> if (state.engine == "MASQUE") {
                        Text(text = "Connected: ${state.detail}", style = MaterialTheme.typography.bodySmall, color = L4Text)
                    }
                    is EngineVpnState.Error -> if (state.engine == "MASQUE") {
                        Text(text = state.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                    else -> Unit
                }
                Button(
                    onClick = {
                        val intent = enginesViewModel.vpnPermissionIntent()
                        if (intent != null) {
                            pendingConnect = true
                            permissionLauncher.launch(intent)
                        } else {
                            enginesViewModel.connectMasque()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text("Connect MASQUE") }
                if (engineState is EngineVpnState.Connected || engineState is EngineVpnState.Connecting) {
                    TextButton(onClick = { enginesViewModel.disconnectEngine() }) {
                        Text("Disconnect", color = MaterialTheme.colorScheme.error)
                    }
                }
                MasqueExitRow(
                    title = "Direct connection",
                    subtitle = "No country change, and the fastest route. Filtered sites open without a MASQUE exit.",
                    selected = selection is MasqueExitSelection.Direct,
                    onClick = { enginesViewModel.selectMasqueExit(MasqueExitSelection.Direct) },
                )
                MasqueExitRow(
                    title = "Fastest country",
                    subtitle = fastest?.let { "${flagForCountryCode(it.code)} ${it.name} · ${it.bestRttMs} ms" }
                        ?: "Automatic: the country that was fastest in the last ping.",
                    selected = selection is MasqueExitSelection.Fastest,
                    onClick = { enginesViewModel.selectMasqueExit(MasqueExitSelection.Fastest) },
                )
                Text(text = "Countries", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = L4Text)
                if (countries.isEmpty() && !pinging) {
                    Text(
                        text = "No gateways measured yet — tap Ping every country, or add a gateway below in Advanced.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                }
                for (country in countries) {
                    MasqueExitRow(
                        title = "${flagForCountryCode(country.code)} ${country.name}",
                        subtitle = "${country.serverCount} servers · " +
                            if (country.reachable) {
                                "${country.bestRttMs} ms" + (country.speedKbps?.let { " · ${it.toInt()} KB/s" } ?: "")
                            } else {
                                // Rows only exist after a ping run, so a
                                // non-reachable row was tested and failed.
                                "unreachable"
                            },
                        selected = selection is MasqueExitSelection.Country &&
                            (selection as MasqueExitSelection.Country).code == country.code,
                        onClick = { enginesViewModel.selectMasqueExit(MasqueExitSelection.Country(country.code)) },
                    )
                }
                Text(
                    text = "Connect runs the native MASQUE core (QUIC + HTTP/3 CONNECT-UDP) to the selected gateway and routes the device through it. A gateway that only speaks CONNECT-IP (like the WARP edge, which authenticates as a WARP client) rejects the request — its exact error is shown above, never a fake connected state. Countries shown are geolocated gateways from the pool (cached winner, your endpoints, and one documented public Cloudflare edge), never an assumed list.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                TextButton(onClick = { showAdvanced = !showAdvanced }) {
                    Text(if (showAdvanced) "Hide advanced" else "Advanced", color = L4Green)
                }
                if (showAdvanced) {
                    OutlinedTextField(value = manual, onValueChange = { manual = it }, label = { Text("Gateway endpoint (host or host:port)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    TextButton(onClick = {
                        if (manual.isNotBlank()) {
                            enginesViewModel.setMasqueManualEndpoint(manual)
                            enginesViewModel.pingMasqueCountries()
                            manual = ""
                        }
                    }) { Text("Add gateway and ping", color = L4Green) }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun MasqueExitRow(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold), color = L4Text)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = L4TextDim)
        }
        if (selected) {
            Text(text = "✓", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = L4GreenDark)
        }
        TextButton(onClick = onClick) { Text(if (selected) "Selected" else "Select", color = L4Green) }
    }
}

@Composable
private fun PsiphonSheet(
    enginesViewModel: EnginesViewModel,
    onDismiss: () -> Unit,
) {
    val summary by enginesViewModel.psiphonSummary.collectAsStateWithLifecycle()
    val busy by enginesViewModel.psiphonBusy.collectAsStateWithLifecycle()
    val error by enginesViewModel.psiphonError.collectAsStateWithLifecycle()
    val regionPings by enginesViewModel.psiphonRegionPings.collectAsStateWithLifecycle()
    val regionPinging by enginesViewModel.psiphonRegionPinging.collectAsStateWithLifecycle()
    val selectedRegion by enginesViewModel.psiphonSelectedRegion.collectAsStateWithLifecycle()
    val engineState by enginesViewModel.engineVpnState.collectAsStateWithLifecycle()
    var pendingConnect by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingConnect) {
            enginesViewModel.connectPsiphon()
        }
        pendingConnect = false
    }
    // FENIX-clean: countries load automatically when the sheet
    // opens — no Fetch button, no byte-count screen, no extra step.
    LaunchedEffect(Unit) {
        if (summary == null && !busy) enginesViewModel.fetchPsiphonList()
    }
    // Ping one server per region as soon as a list exists.
    LaunchedEffect(summary) {
        if (summary != null) enginesViewModel.probePsiphonRegions()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Psiphon", color = L4Text) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState()),
            ) {
                // Loading state: plain text, no buttons.
                if (summary == null && busy) {
                    Text(text = "Loading countries…", style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                }
                // Genuine failure only: plain error + small Retry.
                // When a cached list exists it keeps showing below.
                if (error != null) {
                    Text(text = error ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { enginesViewModel.fetchPsiphonList() }) {
                        Text("Retry", color = L4Green)
                    }
                    if (summary != null) {
                        Text(
                            text = "Showing the last fetched list until the refresh succeeds.",
                            style = MaterialTheme.typography.bodySmall,
                            color = L4TextDim,
                        )
                    }
                }
                when (val state = engineState) {
                    is EngineVpnState.Connecting -> if (state.engine == "Psiphon") {
                        Text(text = "Connecting…", style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                    }
                    is EngineVpnState.Connected -> if (state.engine == "Psiphon") {
                        Text(text = "Connected: ${state.detail}", style = MaterialTheme.typography.bodySmall, color = L4Text)
                    }
                    is EngineVpnState.Error -> if (state.engine == "Psiphon") {
                        Text(text = state.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                    }
                    else -> Unit
                }
                Button(
                    onClick = {
                        val intent = enginesViewModel.vpnPermissionIntent()
                        if (intent != null) {
                            pendingConnect = true
                            permissionLauncher.launch(intent)
                        } else {
                            enginesViewModel.connectPsiphon()
                        }
                    },
                    enabled = summary != null,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text("Connect Psiphon" + (selectedRegion?.let { " · $it" } ?: " · Best server")) }
                if (engineState is EngineVpnState.Connected || engineState is EngineVpnState.Connecting) {
                    TextButton(onClick = { enginesViewModel.disconnectEngine() }) {
                        Text("Disconnect", color = MaterialTheme.colorScheme.error)
                    }
                }
                summary?.let { s ->
                    if (s.regionServers.isEmpty()) {
                        // Reachable only from a stale cache (fresh
                        // fetches throw on zero regions). Still
                        // offer the small Retry, never a blank list.
                        Text(
                            text = "No regions in this list.",
                            style = MaterialTheme.typography.bodySmall,
                            color = L4TextDim,
                        )
                        TextButton(onClick = { enginesViewModel.fetchPsiphonList() }) {
                            Text("Retry", color = L4Green)
                        }
                    }
                    for (rs in s.regionServers) {
                        val ping = regionPings[rs.code]
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth().clickable {
                                enginesViewModel.selectPsiphonRegion(rs.code)
                            },
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "${flagForCountryCode(rs.code)} ${countryNameForCode(rs.code)}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                    color = L4Text,
                                )
                                Text(
                                    text = when {
                                        ping == null && regionPinging -> "pinging…"
                                        ping == null -> "not tested yet"
                                        ping.reachable -> "${ping.rttMs} ms"
                                        else -> "unreachable"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = L4TextDim,
                                )
                            }
                            if (selectedRegion == rs.code) {
                                Text(text = "✓", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold), color = L4GreenDark)
                            }
                        }
                    }
                    if (s.regionServers.isNotEmpty() && regionPinging) {
                        Text(text = "Pinging regions…", style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                    }
                } ?: run {
                    if (!busy && error == null) {
                        Text(text = "Fetching the server list…", style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                    }
                }
                Text(
                    text = "Countries load automatically when you open this sheet; tap a country to egress from it, or leave Best server for the fastest one. Connect runs the official Psiphon core and routes the device through it. The core requires Psiphon-issued channel/sponsor values — until the app owner supplies them, the core's exact error is shown above, never a fake connected state. The servers and pings above are real.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
