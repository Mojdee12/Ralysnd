package com.kunk.singbox.ui.screens

import android.text.format.Formatter
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import com.kunk.singbox.ipc.SingBoxRemote
import com.kunk.singbox.model.ConnectionState
import com.kunk.singbox.model.PingDisplayText
import com.kunk.singbox.model.RoutingMode
import com.kunk.singbox.ui.navigation.Screen as AppScreen
import com.kunk.singbox.viewmodel.DashboardViewModel
import com.kunk.singbox.viewmodel.SettingsViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kunk.singbox.ui.components.ConfirmDialog
import com.kunk.singbox.ui.components.InfoCard
import com.kunk.singbox.ui.components.StandardCard
import com.kunk.singbox.ui.components.ModeChip
import com.kunk.singbox.ui.components.SingleSelectDialog
import com.kunk.singbox.ui.components.StatusChip
import com.kunk.singbox.ui.components.AppNotificationManager
import com.kunk.singbox.ui.components.rememberLocalNetworkPermissionRequest
import com.kunk.singbox.ui.theme.Neutral500
import com.kunk.singbox.ui.theme.L4Background
import com.kunk.singbox.ui.theme.L4CenterConnectButton
import com.kunk.singbox.ui.theme.L4GlassCard
import com.kunk.singbox.ui.theme.L4Green
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim
import com.kunk.singbox.R
import com.kunk.singbox.utils.LocalNetworkPermission
import com.kunk.singbox.viewmodel.NodesViewModel
import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.kunk.singbox.ui.theme.liquidGlassIconButtonPanel
import com.kunk.singbox.ui.theme.liquidGlassMutedContentColor
import com.kunk.singbox.ui.theme.liquidGlassStrongContentColor
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collectLatest

@Composable
@Suppress("LongMethod", "CyclomaticComplexMethod", "CognitiveComplexMethod", "FunctionNaming")
fun DashboardScreen(
    navController: NavController,
    viewModel: DashboardViewModel = viewModel(),
    settingsViewModel: SettingsViewModel = viewModel(),
    nodesViewModel: NodesViewModel = viewModel(),
    enginesViewModel: com.kunk.singbox.engines.EnginesViewModel = viewModel(),
    bottomContentPadding: Dp = 0.dp
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val dataPlaneReadiness by viewModel.dataPlaneReadiness.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val activeProfileId by viewModel.activeProfileId.collectAsStateWithLifecycle()
    val activeNodeId by viewModel.activeNodeId.collectAsStateWithLifecycle()
    val isAutoSelectionEnabled by viewModel.isAutoSelectionEnabled.collectAsStateWithLifecycle()
    val activeNodeLatency by viewModel.activeNodeLatency.collectAsStateWithLifecycle()
    val isPingTesting by viewModel.isPingTesting.collectAsStateWithLifecycle()
    val nodes by viewModel.nodes.collectAsStateWithLifecycle()
    val settings by settingsViewModel.settings.collectAsStateWithLifecycle()
    val runtimeNodeLabel by SingBoxRemote.activeLabel.collectAsStateWithLifecycle()

    val nodesForSelector by nodesViewModel.nodes.collectAsStateWithLifecycle()
    val rawNodesForSelector by nodesViewModel.rawNodes.collectAsStateWithLifecycle()
    val testingNodeIds by nodesViewModel.testingNodeIds.collectAsStateWithLifecycle()

    val activeProfileName by remember {
        derivedStateOf {
            profiles.find { it.id == activeProfileId }?.name
        }
    }

    // 连接态优先显示运行态标签，避免自动切换后主页仍显示手选旧节点
    val activeNodeName by remember(activeNodeId, nodes, connectionState, runtimeNodeLabel) {
        derivedStateOf {
            viewModel.getActiveNodeName()
        }
    }
    val autoSelectionSubtitle = when {
        !isAutoSelectionEnabled -> stringResource(R.string.nodes_auto_selection_disabled)
        runtimeNodeLabel.isNotBlank() -> stringResource(R.string.nodes_auto_selection_current, runtimeNodeLabel)
        connectionState == ConnectionState.Connecting -> stringResource(R.string.nodes_auto_selection_selecting)
        else -> stringResource(R.string.nodes_auto_selection_unavailable)
    }
    val displayedNodeName = if (isAutoSelectionEnabled) {
        stringResource(
            R.string.nodes_auto_selection_label,
            activeNodeName ?: stringResource(R.string.nodes_auto_selection_selecting)
        )
    } else {
        activeNodeName
    }

    var showModeDialog by remember { mutableStateOf(false) }
    val currentMode = stringResource(settings.routingMode.displayNameRes)
    var showUpdateDialog by remember { mutableStateOf(false) }
    var showTestDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showNodeDialog by remember { mutableStateOf(false) }
    var lastConnectionState by remember { mutableStateOf<ConnectionState?>(null) }

    val vpnPermissionNeeded by viewModel.vpnPermissionNeeded.collectAsStateWithLifecycle()
    val requestLocalNetworkPermission = rememberLocalNetworkPermissionRequest()

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        viewModel.onVpnPermissionResult(result.resultCode == Activity.RESULT_OK)
    }

    LaunchedEffect(vpnPermissionNeeded) {
        if (vpnPermissionNeeded) {
            val prepareIntent = VpnService.prepare(context)
            if (prepareIntent != null) {
                vpnPermissionLauncher.launch(prepareIntent)
            } else {
                viewModel.onVpnPermissionResult(true)
            }
        }
    }

    LaunchedEffect(connectionState) {
        lastConnectionState = connectionState
    }

    LaunchedEffect(viewModel) {
        viewModel.toastEvents.collectLatest { message ->
            AppNotificationManager.showMessage(context, message)
        }
    }

    if (showModeDialog) {
        val options = RoutingMode.entries.map { stringResource(it.displayNameRes) }
        SingleSelectDialog(
            title = stringResource(R.string.dashboard_routing_mode),
            options = options,
            selectedIndex = RoutingMode.entries.indexOf(settings.routingMode).coerceAtLeast(0),
            onSelect = { index ->
                val selectedMode = RoutingMode.entries[index]
                scope.launch {
                    settingsViewModel.setRoutingModeAndWait(
                        selectedMode,
                        notifyRestartRequired = false
                    )
                    if (connectionState == ConnectionState.Connected || connectionState == ConnectionState.Connecting) {
                        viewModel.restartVpn()
                    }
                }
                showModeDialog = false
            },
            onDismiss = { showModeDialog = false }
        )
    }

    if (showUpdateDialog) {
        ConfirmDialog(
            title = stringResource(R.string.dashboard_update_subscription),
            message = stringResource(R.string.dashboard_update_subscription_confirm),
            confirmText = stringResource(R.string.common_update),
            onConfirm = {
                viewModel.updateAllSubscriptions()
                showUpdateDialog = false
            },
            onDismiss = { showUpdateDialog = false }
        )
    }

    if (showTestDialog) {
        ConfirmDialog(
            title = stringResource(R.string.dashboard_latency_test),
            message = stringResource(R.string.dashboard_latency_test_confirm),
            confirmText = stringResource(R.string.dashboard_start_test),
            onConfirm = {
                viewModel.testAllNodesLatency()
                showTestDialog = false
            },
            onDismiss = { showTestDialog = false }
        )
    }

    if (showProfileDialog) {
        val options = profiles.map { it.name }
        SingleSelectDialog(
            title = stringResource(R.string.dashboard_select_profile),
            options = options,
            selectedIndex = profiles.indexOfFirst { it.id == activeProfileId }.let { idx ->
                when {
                    options.isEmpty() -> -1
                    idx >= 0 -> idx
                    else -> 0
                }
            },
            onSelect = { index ->
                profiles.getOrNull(index)?.id?.let { viewModel.setActiveProfile(it) }
                showProfileDialog = false
            },
            onDismiss = { showProfileDialog = false }
        )
    }

    if (showNodeDialog) {
        NodePickerPage(
            title = stringResource(R.string.dashboard_select_node),
            profiles = profiles,
            allNodes = rawNodesForSelector,
            displayedNodes = nodesForSelector,
            selectedNodeId = activeNodeId,
            isAutoSelectionEnabled = isAutoSelectionEnabled,
            autoSelectionSubtitle = autoSelectionSubtitle,
            testingNodeIds = testingNodeIds,
            onSelectAuto = viewModel::enableAutoSelection,
            onSelectNode = { node ->
                viewModel.setActiveNode(node.id)
            },
            onDismiss = { showNodeDialog = false }
        )
    }

    // Helper to format bytes
    fun formatBytes(bytes: Long): String = Formatter.formatFileSize(context, bytes)

    val statusBarPadding = WindowInsets.statusBars.asPaddingValues()

    // CENTER-CONNECT (approved mockups): the dashboard is explicitly
    // navy, not whatever the Scaffold surface happens to be. The previous
    // v2 build relied on the theme surface and kept the old layout
    // structure (chips, corner button, stats), which is why the user
    // still saw the old main page. This layout is unmistakably the
    // mockup: headline, CENTER connect button, stats, then My Configs.
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(L4Background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(top = statusBarPadding.calculateTopPadding())
                .padding(24.dp)
                .padding(bottom = bottomContentPadding),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // 1. Status Bar (Chips)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // App Logo & Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    // v2: text badge, not a picture (no profile/app photos in v2 UI).
                    androidx.compose.foundation.layout.Box(
                        modifier = Modifier
                            .size(40.dp)
                            .padding(end = 12.dp)
                            .background(
                                com.kunk.singbox.ui.theme.L4Surface,
                                androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                            )
                            .border(
                                1.dp,
                                com.kunk.singbox.ui.theme.L4Green,
                                androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "R",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold
                            ),
                            color = com.kunk.singbox.ui.theme.L4Green
                        )
                    }
                    Text(
                        text = "Ralysnd",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                            letterSpacing = 1.sp
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    // RALYSND PROFESSIONAL MOCKUP v3: clean white wordmark
                    // with a small emerald "Protected" indicator at the far
                    // right while connected — no accent bar underneath.
                    if (connectionState == ConnectionState.Connected) {
                        Spacer(modifier = Modifier.weight(1f))
                        Text(
                            text = "• Protected",
                            style = MaterialTheme.typography.labelLarge,
                            color = com.kunk.singbox.ui.theme.L4Green
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val safetyStatusLabel = when {
                        dataPlaneReadiness.status == com.kunk.singbox.ipc.DataPlaneStatus.BLOCKING &&
                            connectionState == ConnectionState.Connecting ->
                            stringResource(R.string.dashboard_status_protecting)
                        dataPlaneReadiness.status == com.kunk.singbox.ipc.DataPlaneStatus.RECOVERING &&
                            connectionState == ConnectionState.Connecting ->
                            stringResource(R.string.dashboard_status_recovering)
                        dataPlaneReadiness.status == com.kunk.singbox.ipc.DataPlaneStatus.FAILED_BLOCKED &&
                            connectionState == ConnectionState.Error ->
                            stringResource(R.string.dashboard_status_blocked)
                        dataPlaneReadiness.status == com.kunk.singbox.ipc.DataPlaneStatus.FAILED_UNPROTECTED &&
                            connectionState == ConnectionState.Error ->
                            stringResource(R.string.connection_idle)
                        else -> stringResource(connectionState.displayNameRes)
                    }
                    StatusChip(
                        label = safetyStatusLabel,
                        isActive = connectionState == ConnectionState.Connected
                    )

                    val indicatorColor = when (connectionState) {
                        ConnectionState.Connected -> com.kunk.singbox.ui.theme.L4Green // v2 cyan
                        ConnectionState.Error -> Color(0xFFF44336) // Red
                        else -> liquidGlassMutedContentColor(Neutral500)
                    }

                    ModeChip(
                        mode = currentMode,
                        indicatorColor = indicatorColor
                    ) { showModeDialog = true }
                }

                val browserExcluded = connectionState == ConnectionState.Connected &&
                    dataPlaneReadiness.routingScope.contains("browser=excluded")
                val failedUnprotected =
                    connectionState == ConnectionState.Error &&
                        dataPlaneReadiness.status == com.kunk.singbox.ipc.DataPlaneStatus.FAILED_UNPROTECTED
                val protectionWarning = when {
                    browserExcluded ->
                        stringResource(R.string.vpn_browser_not_covered)
                    failedUnprotected -> stringResource(R.string.vpn_status_failed_unprotected)
                    else -> null
                }
                if (protectionWarning != null) {
                    Text(
                        text = protectionWarning,
                        style = MaterialTheme.typography.labelMedium,
                        color = if (browserExcluded || failedUnprotected) {
                            MaterialTheme.colorScheme.error
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                runCatching { context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) }
                            }
                    )
                }

                val noProfileMsg = stringResource(R.string.dashboard_no_profiles_available)
                val noNodeMsg = stringResource(R.string.dashboard_no_nodes_available)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start
                ) {
                    StatusChip(
                        label = activeProfileName ?: stringResource(R.string.dashboard_no_profile_selected),
                        onClick = {
                            if (profiles.isNotEmpty()) {
                                showProfileDialog = true
                            } else {
                                AppNotificationManager.showMessage(context, noProfileMsg)
                            }
                        }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    StatusChip(
                        label = displayedNodeName ?: stringResource(R.string.dashboard_no_node_selected),
                        onClick = {
                            if (nodes.isNotEmpty()) {
                                showNodeDialog = true
                            } else {
                                AppNotificationManager.showMessage(context, noNodeMsg)
                            }
                        }
                    )
                }
            }

            // CENTER-CONNECT: the large circular button sits in the
            // CENTER of the screen (approved mockups), never at a corner.
            // Same toggle logic + local-network permission gate as before.
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                val isRunning = connectionState == ConnectionState.Connected ||
                    connectionState == ConnectionState.Connecting
                val toggleConnection = { viewModel.toggleConnection() }
                L4CenterConnectButton(
                    isRunning = isRunning,
                    onClick = {
                        if (!isRunning && LocalNetworkPermission.requiresLocalNetworkAccess(settings)) {
                            requestLocalNetworkPermission(toggleConnection)
                        } else {
                            toggleConnection()
                        }
                    }
                )
            }
            // Selected config, named under the center button.
            if (displayedNodeName != null) {
                Text(
                    text = displayedNodeName,
                    style = MaterialTheme.typography.bodyMedium,
                    color = L4TextDim
                )
            }

            // HOME ENGINE GRID (mlm-style, sample-4 light tiles):
            // only wanted engines — MASQUE, WARP², Psiphon, WireGuard,
            // FENIX. Plain WARP is not a user-facing engine anymore.
            // WireGuard/FENIX wire to their real flows; MASQUE/Psiphon
            // open their real setup sheets; WARP² has no country list
            // (no legitimate built-in fleet — see EnginesViewModel)
            // and offers one-tap single-layer WARP instead, which
            // live-switches the running tunnel when one is up, or
            // starts it when idle — so the Dashboard center button
            // then shows the real state.
            EngineGridSection(
                onNavigate = { route -> navController.navigate(route) },
                onAddNode = { link -> nodesViewModel.addNode(link) },
                onOpenScanner = { navController.navigate(com.kunk.singbox.ui.navigation.Screen.Scanner.route) },
                enginesViewModel = enginesViewModel,
                onConnectNode = { nodeId ->
                    viewModel.setActiveNode(nodeId)
                    if (connectionState == ConnectionState.Idle || connectionState == ConnectionState.Error) {
                        viewModel.toggleConnection()
                    }
                },
            )

            // SCANNER (home section): ping all nodes with the real
            // latency test and show fastest-first. Values come from
            // the nodes' measured latencies only — unmeasured nodes
            // show "—", never an invented number.
            if (nodes.isNotEmpty()) {
                L4GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Scanner",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                ),
                                color = L4Text
                            )
                            androidx.compose.material3.TextButton(
                                onClick = { viewModel.testAllNodesLatency() }
                            ) {
                                Text(text = "Ping all", color = L4Green)
                            }
                        }
                        val fastestNodes = remember(nodes) {
                            nodes.sortedWith(
                                compareBy<com.kunk.singbox.model.NodeUi> { it.latencyMs == null }
                                    .thenBy { it.latencyMs ?: Long.MAX_VALUE }
                            ).take(5)
                        }
                        for (node in fastestNodes) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.setActiveNode(node.id) },
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = node.displayName,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                                    ),
                                    color = L4Text,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = node.latencyMs?.let { "${it}ms" } ?: "—",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                    ),
                                    color = L4Green
                                )
                            }
                        }
                        androidx.compose.material3.TextButton(
                            onClick = { navController.navigate(com.kunk.singbox.ui.navigation.Screen.Scanner.route) }
                        ) {
                            Text(text = "Open full scanner (MASQUE / WARP² / Psiphon)", color = L4Green)
                        }
                    }
                }
            }

            // 3. Stats & Quick Actions
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Always show InfoCard but with placeholder data when not connected
                val isConnected = connectionState == ConnectionState.Connected

                val displayPing = activeNodeLatency

                val isPingLoading = isConnected && isPingTesting

                val timeoutMsg = stringResource(R.string.common_timeout)
                val unavailableMsg = stringResource(R.string.common_unavailable)
                val ipv6OnlyMsg = stringResource(R.string.common_ipv6_only)
                val pingText = PingDisplayText.resolve(
                    isConnected = isConnected,
                    displayPing = displayPing,
                    timeoutText = timeoutMsg,
                    unavailableText = unavailableMsg,
                    ipv6OnlyText = ipv6OnlyMsg
                )
                InfoCard(
                    uploadSpeed = if (isConnected) "${formatBytes(stats.uploadSpeed)}/s" else "-/s",
                    downloadSpeed = if (isConnected) "${formatBytes(stats.downloadSpeed)}/s" else "-/s",
                    ping = pingText,
                    isPingLoading = isPingLoading,
                    onPingClick = if (isConnected) {
                        { viewModel.retestCurrentNodePing() }
                    } else {
                        null
                    }
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Quick Actions Card
                StandardCard(modifier = Modifier.fillMaxWidth(), border = null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp, horizontal = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        QuickActionButton(
                            Icons.Rounded.Refresh,
                            stringResource(R.string.dashboard_update_subscription)
                        ) {
                            showUpdateDialog = true
                        }
                        QuickActionButton(
                            Icons.Rounded.Bolt,
                            stringResource(R.string.dashboard_latency_test)
                        ) {
                            showTestDialog = true
                        }
                        QuickActionButton(
                            Icons.Rounded.Terminal,
                            stringResource(R.string.dashboard_logs)
                        ) {
                            navController.navigate(AppScreen.Logs.route)
                        }
                        QuickActionButton(
                            Icons.Rounded.BugReport,
                            stringResource(R.string.dashboard_diagnostics)
                        ) {
                            navController.navigate(AppScreen.Diagnostics.route)
                        }
                    }
                }

                // My Configs (approved mockups): the user's configs, each
                // row showing name / protocol / latency, with the remaining
                // volume BELOW the row when its subscription reports one.
                // Volume source: the config's own subscription profile
                // (totalTraffic - usedTraffic, only when totalTraffic > 0).
                // A config whose profile reports no total gets NO volume
                // line at all — never a fake number. Active config first,
                // then up to four others, tapping a row selects it.
                if (nodes.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "My Configs",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                        ),
                        color = L4Text,
                        modifier = Modifier.fillMaxWidth()
                    )
                    val orderedConfigs = remember(nodes, activeNodeId) {
                        val active = nodes.find { it.id == activeNodeId }
                        (listOfNotNull(active) + nodes.filter { it.id != activeNodeId }).take(5)
                    }
                    androidx.compose.foundation.layout.Column(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        for (config in orderedConfigs) {
                            val configProfile = profiles.find { it.id == config.sourceProfileId }
                            val remainingBytes = configProfile?.let { profile ->
                                if (profile.totalTraffic > 0) {
                                    (profile.totalTraffic - profile.usedTraffic).coerceAtLeast(0L)
                                } else {
                                    null
                                }
                            }
                            L4GlassCard(
                                selected = config.id == activeNodeId,
                                onClick = { viewModel.setActiveNode(config.id) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                androidx.compose.foundation.layout.Column(
                                    modifier = Modifier.padding(14.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = config.displayName,
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                            ),
                                            color = L4Text,
                                            modifier = Modifier.weight(1f, fill = false)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = config.protocolDisplay,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = L4TextDim
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = when (val lat = config.latencyMs) {
                                                null -> "---"
                                                else -> "${lat}ms"
                                            },
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                            ),
                                            color = com.kunk.singbox.ui.theme.L4Green
                                        )
                                    }
                                    // Volume BELOW the row, only when real.
                                    if (remainingBytes != null) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "Remaining: ${formatBytes(remainingBytes)}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                                            ),
                                            color = com.kunk.singbox.ui.theme.L4Amber
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    }
}

@Composable
fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            modifier = Modifier.liquidGlassIconButtonPanel(),
            onClick = onClick
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.onBackground
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = liquidGlassStrongContentColor(MaterialTheme.colorScheme.onSurfaceVariant)
        )
    }
}
