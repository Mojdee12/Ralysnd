// MASQUE core: a generic HTTP/3 CONNECT-UDP / CONNECT client
// (Cloudflare quiche) with a local SOCKS5 server, exposed to
// Kotlin via JNI (see engines/MasqueCore.kt).
//
// Traffic flow:
//   hev-socks5-tunnel -> SOCKS5 (this core, 127.0.0.1:socksPort)
//     -> QUIC thread -> HTTP/3 stream to the MASQUE gateway
//        (CONNECT for TCP, CONNECT-UDP + datagrams for UDP)
//     -> destination.
//
// Design notes (read before changing this file):
// - One thread owns the quiche Connection (it is not Sync); all
//   other threads talk to it through an mpsc command channel.
// - SOCKS5 TCP connections get one thread for reading the client
//   socket and one for writing back QUIC events for that stream.
// - UDP uses one CONNECT-UDP stream per (client, destination)
//   pair, with one writer thread per stream.
// - This is a GENERIC CONNECT-UDP client (RFC 9298). A gateway
//   that only speaks CONNECT-IP (RFC 9484, e.g. the WARP MASQUE
//   edge, which authenticates as a WARP client) rejects the
//   CONNECT-UDP request; that rejection is reported to Kotlin
//   as a stream failure, never faked as success.
// - TLS: hostname gateways are verified against their name. An
//   IP-literal gateway has no name to verify against, so Kotlin
//   passes "" as server_name and verification is off for that
//   case only (same trade-off as allowInsecure for IP endpoints).

#![allow(non_snake_case)]

use jni::objects::{JObject, JString};
use jni::sys::{jboolean, jint};
use jni::JNIEnv;
use quiche::h3::{self, Header};
use std::collections::HashMap;
use std::io::{Read, Write};
use std::net::{SocketAddr, TcpListener, TcpStream, UdpSocket};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Mutex, OnceLock};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

const MAX_DATAGRAM: usize = 65535;
const OUT_BUF_LEN: usize = 1350;

#[derive(Debug)]
enum QuicCmd {
    OpenUdp { target: String, tx: Sender<QuicEvent> },
    UdpData { stream: u64, data: Vec<u8> },
    CloseUdp { stream: u64 },
    OpenTcp { target: String, tx: Sender<QuicEvent> },
    TcpData { stream: u64, data: Vec<u8>, fin: bool },
    CloseTcp { stream: u64 },
    Shutdown,
}

#[derive(Debug)]
enum QuicEvent {
    UdpOpened { stream: u64 },
    UdpDatagram { stream: u64, data: Vec<u8> },
    UdpClosed { stream: u64 },
    TcpOpened { stream: u64 },
    TcpData { stream: u64, data: Vec<u8> },
    TcpClosed { stream: u64 },
    TcpFailed { stream: u64, reason: String },
    Fatal(String),
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum StreamKind {
    Tcp,
    Udp,
}

struct Shared {
    stop: Arc<AtomicBool>,
    cmd_tx: Sender<QuicCmd>,
}

static CORE: OnceLock<Mutex<Option<Shared>>> = OnceLock::new();
static SCID_COUNTER: AtomicU64 = AtomicU64::new(1);

fn core_lock() -> &'static Mutex<Option<Shared>> {
    CORE.get_or_init(|| Mutex::new(None))
}

fn random_scid() -> [u8; 16] {
    let mut out = [0u8; 16];
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(0);
    let counter = SCID_COUNTER.fetch_add(1, Ordering::Relaxed);
    out[..8].copy_from_slice(&nanos.to_be_bytes());
    out[8..].copy_from_slice(&counter.to_be_bytes());
    out
}

// ---------------------------------------------------------------- QUIC thread

struct QuicState {
    sock: UdpSocket,
    peer: SocketAddr,
    conn: quiche::Connection,
    h3: h3::Connection,
    gateway_authority: String,
    kinds: HashMap<u64, StreamKind>,
    senders: HashMap<u64, Sender<QuicEvent>>,
}

impl QuicState {
    fn flush(&mut self) {
        let mut out = [0u8; OUT_BUF_LEN];
        loop {
            match self.conn.send(&mut out) {
                Ok((written, info)) => {
                    if written == 0 {
                        break;
                    }
                    let _ = self.sock.send_to(&out[..written], info.to);
                }
                Err(quiche::Error::Done) => break,
                Err(_) => break,
            }
        }
    }

    fn fail_all(&mut self, reason: &str) {
        for (_, tx) in self.senders.drain() {
            let _ = tx.send(QuicEvent::Fatal(reason.to_string()));
        }
        self.kinds.clear();
    }

    fn handle_cmd(&mut self, cmd: QuicCmd) -> bool {
        match cmd {
            QuicCmd::Shutdown => return false,
            QuicCmd::OpenUdp { target, tx } => {
                let headers = [
                    Header::new(b":method", b"CONNECT"),
                    Header::new(b":protocol", b"connect-udp"),
                    Header::new(b":scheme", b"https"),
                    Header::new(b":authority", self.gateway_authority.as_bytes()),
                    Header::new(b":path", target.as_bytes()),
                ];
                match self.h3.send_request(&mut self.conn, &headers, false) {
                    Ok(stream) => {
                        self.kinds.insert(stream, StreamKind::Udp);
                        self.senders.insert(stream, tx);
                    }
                    Err(e) => {
                        let _ = tx.send(QuicEvent::UdpClosed { stream: 0 });
                        let _ = e;
                    }
                }
            }
            QuicCmd::UdpData { stream, data } => {
                if self.kinds.get(&stream) == Some(&StreamKind::Udp) {
                    if self.h3.send_dgram(&mut self.conn, stream, &data).is_err() {
                        self.senders.remove(&stream);
                        self.kinds.remove(&stream);
                    }
                }
            }
            QuicCmd::CloseUdp { stream } => {
                let _ = self.conn.stream_shutdown(stream, quiche::Shutdown::Write, 0);
                self.senders.remove(&stream);
                self.kinds.remove(&stream);
            }
            QuicCmd::OpenTcp { target, tx } => {
                let headers = [
                    Header::new(b":method", b"CONNECT"),
                    Header::new(b":authority", target.as_bytes()),
                ];
                match self.h3.send_request(&mut self.conn, &headers, false) {
                    Ok(stream) => {
                        self.kinds.insert(stream, StreamKind::Tcp);
                        self.senders.insert(stream, tx);
                    }
                    Err(_) => {
                        let _ = tx.send(QuicEvent::TcpFailed {
                            stream: 0,
                            reason: "failed to open CONNECT stream".to_string(),
                        });
                    }
                }
            }
            QuicCmd::TcpData { stream, data, fin } => {
                if self.kinds.get(&stream) == Some(&StreamKind::Tcp) {
                    if self.h3.send_body(&mut self.conn, stream, &data, fin).is_err() {
                        self.senders.remove(&stream);
                        self.kinds.remove(&stream);
                    }
                }
            }
            QuicCmd::CloseTcp { stream } => {
                let _ = self.conn.stream_shutdown(stream, quiche::Shutdown::Write, 0);
                self.senders.remove(&stream);
                self.kinds.remove(&stream);
            }
        }
        true
    }

    fn drain_h3_events(&mut self) {
        loop {
            let polled = self.h3.poll(&mut self.conn);
            let (stream, event) = match polled {
                Ok(pair) => pair,
                Err(quiche::Error::Done) => break,
                Err(_) => break,
            };
            let kind = self.kinds.get(&stream).copied();
            match event {
                h3::Event::Headers { list, .. } => {
                    let status = list.iter().find(|h| h.name() == b":status").map(|h| h.value().to_vec());
                    let ok = status.as_deref() == Some(b"200".as_slice());
                    match kind {
                        Some(StreamKind::Tcp) => {
                            if ok {
                                if let Some(tx) = self.senders.get(&stream) {
                                    let _ = tx.send(QuicEvent::TcpOpened { stream });
                                }
                            } else if let Some(tx) = self.senders.remove(&stream) {
                                self.kinds.remove(&stream);
                                let _ = tx.send(QuicEvent::TcpFailed {
                                    stream,
                                    reason: format!(
                                        "CONNECT rejected: {}",
                                        status
                                            .map(|s| String::from_utf8_lossy(&s).into_owned())
                                            .unwrap_or_else(|| "?".to_string())
                                    ),
                                });
                            }
                        }
                        Some(StreamKind::Udp) => {
                            if ok {
                                if let Some(tx) = self.senders.get(&stream) {
                                    let _ = tx.send(QuicEvent::UdpOpened { stream });
                                }
                            } else if let Some(tx) = self.senders.remove(&stream) {
                                self.kinds.remove(&stream);
                                let _ = tx.send(QuicEvent::UdpClosed { stream });
                            }
                        }
                        None => {}
                    }
                }
                h3::Event::Data => {
                    if kind == Some(StreamKind::Tcp) {
                        // Data bytes are read below via recv_body in the
                        // event-drain loop of the caller; see drain_body.
                        let _ = stream;
                    }
                }
                h3::Event::Finished => {
                    if let Some(tx) = self.senders.remove(&stream) {
                        let _ = match kind {
                            Some(StreamKind::Tcp) => tx.send(QuicEvent::TcpClosed { stream }),
                            _ => tx.send(QuicEvent::UdpClosed { stream }),
                        };
                    }
                    self.kinds.remove(&stream);
                }
                h3::Event::Reset(_) => {
                    if let Some(tx) = self.senders.remove(&stream) {
                        let _ = match kind {
                            Some(StreamKind::Tcp) => tx.send(QuicEvent::TcpClosed { stream }),
                            _ => tx.send(QuicEvent::UdpClosed { stream }),
                        };
                    }
                    self.kinds.remove(&stream);
                }
                _ => {}
            }
            // Body bytes for TCP streams arrive as Data events; quiche
            // exposes them through recv_body, drained here.
            if kind == Some(StreamKind::Tcp) {
                let mut buf = [0u8; 16384];
                loop {
                    match self.h3.recv_body(&mut self.conn, stream, &mut buf) {
                        Ok((read, _)) => {
                            if read == 0 {
                                break;
                            }
                            if let Some(tx) = self.senders.get(&stream) {
                                let _ = tx.send(QuicEvent::TcpData {
                                    stream,
                                    data: buf[..read].to_vec(),
                                });
                            }
                        }
                        Err(_) => break,
                    }
                }
            }
        }
        // HTTP/3 datagrams (CONNECT-UDP payloads).
        loop {
            match self.h3.recv_dgram(&mut self.conn) {
                Ok((stream, data)) => {
                    if let Some(tx) = self.senders.get(&stream) {
                        let _ = tx.send(QuicEvent::UdpDatagram { stream, data });
                    }
                }
                Err(_) => break,
            }
        }
    }
}

fn quic_thread(
    sock: UdpSocket,
    peer: SocketAddr,
    server_name: Option<String>,
    gateway_authority: String,
    cmd_rx: Receiver<QuicCmd>,
) {
    let mut config = match quiche::Config::new(quiche::PROTOCOL_VERSION) {
        Ok(c) => c,
        Err(_) => return,
    };
    config.set_application_protos(&[b"h3"]);
    config.verify_peer(server_name.is_some());
    config.set_max_idle_timeout(30_000);
    config.set_initial_max_data(10_000_000);
    config.set_initial_max_stream_data_bidi_local(1_000_000);
    config.set_initial_max_stream_data_bidi_remote(1_000_000);
    config.set_initial_max_streams_bidi(100);
    config.set_initial_max_streams_uni(100);
    config.set_max_recv_udp_payload_size(1350);
    config.set_max_send_udp_payload_size(1350);
    config.enable_h3_datagram(true);

    let scid = quiche::ConnectionId::from_ref(&random_scid());
    let local = match sock.local_addr() {
        Ok(a) => a,
        Err(_) => return,
    };
    let mut conn = match quiche::connect(
        server_name.as_deref(),
        &scid,
        local,
        peer,
        &mut config,
    ) {
        Ok(c) => c,
        Err(_) => return,
    };
    let h3_config = match h3::Config::new() {
        Ok(c) => c,
        Err(_) => return,
    };
    let h3 = match h3::Connection::new(&mut conn, &h3_config) {
        Ok(c) => c,
        Err(_) => return,
    };
    let _ = sock.set_read_timeout(Some(Duration::from_millis(20)));
    let mut state = QuicState {
        sock,
        peer,
        conn,
        h3,
        gateway_authority,
        kinds: HashMap::new(),
        senders: HashMap::new(),
    };
    state.flush();
    let mut buf = [0u8; 65535];
    loop {
        // Drain pending commands without blocking.
        loop {
            match cmd_rx.try_recv() {
                Ok(cmd) => {
                    if !state.handle_cmd(cmd) {
                        return;
                    }
                }
                Err(_) => break,
            }
        }
        // Read one UDP packet (timeout keeps the loop responsive).
        match state.sock.recv_from(&mut buf) {
            Ok((len, from)) => {
                let info = quiche::RecvInfo { to: state.peer, from };
                if state.conn.recv(&mut buf[..len], info).is_ok() {
                    state.drain_h3_events();
                }
            }
            Err(_) => {}
        }
        if state.conn.is_closed() {
            state.fail_all("QUIC connection closed");
            return;
        }
        state.flush();
    }
}

// ---------------------------------------------------------------- SOCKS5 server

fn parse_socks_addr(buf: &[u8], off: usize) -> Option<(String, usize)> {
    if buf.len() < off + 1 {
        return None;
    }
    match buf[off] {
        1 => {
            if buf.len() < off + 7 {
                return None;
            }
            let ip = format!("{}.{}.{}.{}", buf[off + 1], buf[off + 2], buf[off + 3], buf[off + 4]);
            let port = ((buf[off + 5] as u16) << 8) | buf[off + 6] as u16;
            Some((format!("{}:{}", ip, port), off + 7))
        }
        3 => {
            if buf.len() < off + 2 {
                return None;
            }
            let len = buf[off + 1] as usize;
            if buf.len() < off + 2 + len + 2 {
                return None;
            }
            let host = String::from_utf8_lossy(&buf[off + 2..off + 2 + len]).into_owned();
            let port = ((buf[off + 2 + len] as u16) << 8) | buf[off + 3 + len] as u16;
            Some((format!("{}:{}", host, port), off + 2 + len + 2))
        }
        4 => {
            if buf.len() < off + 19 {
                return None;
            }
            let mut parts = Vec::new();
            for i in 0..8 {
                let v = ((buf[off + 1 + i * 2] as u16) << 8) | buf[off + 2 + i * 2] as u16;
                parts.push(format!("{:x}", v));
            }
            let port = ((buf[off + 17] as u16) << 8) | buf[off + 18] as u16;
            Some((format!("[{}]:{}", parts.join(":"), port), off + 19))
        }
        _ => None,
    }
}

fn socks_tcp_client(mut stream: TcpStream, shared: Arc<Shared>, socks_port: u16) {
    let _ = stream.set_read_timeout(Some(Duration::from_secs(30)));
    let _ = stream.set_write_timeout(Some(Duration::from_secs(30)));
    // Greeting: VER, NMETHODS, METHODS...
    let mut head = [0u8; 2];
    if stream.read_exact(&mut head).is_err() || head[0] != 5 {
        return;
    }
    let nmethods = head[1] as usize;
    let mut methods = vec![0u8; nmethods];
    if stream.read_exact(&mut methods).is_err() {
        return;
    }
    if stream.write_all(&[5, 0]).is_err() {
        return;
    }
    // Request: VER, CMD, RSV, ATYP, DST, PORT.
    let mut req = [0u8; 4];
    if stream.read_exact(&mut req).is_err() || req[0] != 5 {
        return;
    }
    let cmd = req[1];
    let mut rest = [0u8; 260];
    // Read enough to parse the address: peek by reading the address
    // field manually (ATYP byte already consumed as req[3]).
    let atyp = req[3];
    let addr_len = match atyp {
        1 => 6,
        3 => {
            let mut lb = [0u8; 1];
            if stream.read_exact(&mut lb).is_err() {
                return;
            }
            // Reconstruct: domain length byte + domain + port.
            let dlen = lb[0] as usize;
            let mut domain = vec![0u8; dlen + 2];
            if stream.read_exact(&mut domain).is_err() {
                return;
            }
            let host = String::from_utf8_lossy(&domain[..dlen]).into_owned();
            let port = ((domain[dlen] as u16) << 8) | domain[dlen + 1] as u16;
            return handle_socks_request(stream, shared, socks_port, cmd, format!("{}:{}", host, port));
        }
        4 => 18,
        _ => return,
    };
    if stream.read_exact(&mut rest[..addr_len]).is_err() {
        return;
    }
    let mut fake = vec![0u8; 1 + addr_len];
    fake[0] = atyp;
    fake[1..].copy_from_slice(&rest[..addr_len]);
    let (target, _) = match parse_socks_addr(&fake, 0) {
        Some(v) => v,
        None => return,
    };
    handle_socks_request(stream, shared, socks_port, cmd, target);
}

fn handle_socks_request(
    mut stream: TcpStream,
    shared: Arc<Shared>,
    socks_port: u16,
    cmd: u8,
    target: String,
) {
    match cmd {
        1 => {
            // CONNECT: the handler thread owns the whole relay. It
            // opens the H3 CONNECT stream, learns the stream id
            // from the TcpOpened event itself, replies to the
            // client, then spawns a writer thread (which receives
            // ONLY this stream's events, because the QUIC thread
            // routes events per-stream) and reads the client socket
            // itself. No id ever has to cross threads indirectly.
            let (tx, rx) = channel::<QuicEvent>();
            if shared.cmd_tx.send(QuicCmd::OpenTcp { target, tx }).is_err() {
                return;
            }
            let stream_id = loop {
                match rx.recv_timeout(Duration::from_secs(20)) {
                    Ok(QuicEvent::TcpOpened { stream }) => break stream,
                    Ok(QuicEvent::TcpFailed { .. }) | Ok(QuicEvent::Fatal(_)) => {
                        let _ = stream.write_all(&[5, 5, 0, 1, 0, 0, 0, 0, 0, 0]);
                        return;
                    }
                    Ok(_) => continue,
                    Err(_) => {
                        let _ = stream.write_all(&[5, 5, 0, 1, 0, 0, 0, 0, 0, 0]);
                        return;
                    }
                }
            };
            if stream.write_all(&[5, 0, 0, 1, 127, 0, 0, 1, 0, 0]).is_err() {
                return;
            }
            let stop = shared.stop.clone();
            match stream.try_clone() {
                Ok(writer_stream) => {
                    thread::spawn(move || {
                        let mut writer_stream = writer_stream;
                        while !stop.load(Ordering::Relaxed) {
                            match rx.recv_timeout(Duration::from_millis(200)) {
                                Ok(QuicEvent::TcpData { data, .. }) => {
                                    if writer_stream.write_all(&data).is_err() {
                                        break;
                                    }
                                }
                                Ok(QuicEvent::TcpClosed { .. })
                                | Ok(QuicEvent::Fatal(_)) => break,
                                Ok(_) => {}
                                Err(_) => {}
                            }
                        }
                        let _ = writer_stream.shutdown(std::net::Shutdown::Both);
                    });
                }
                Err(_) => return,
            }
            let cmd_tx = shared.cmd_tx.clone();
            let mut buf = [0u8; 16384];
            loop {
                if shared.stop.load(Ordering::Relaxed) {
                    break;
                }
                match stream.read(&mut buf) {
                    Ok(0) => break,
                    Ok(n) => {
                        if cmd_tx
                            .send(QuicCmd::TcpData {
                                stream: stream_id,
                                data: buf[..n].to_vec(),
                                fin: false,
                            })
                            .is_err()
                        {
                            break;
                        }
                    }
                    Err(_) => break,
                }
            }
            let _ = cmd_tx.send(QuicCmd::TcpData {
                stream: stream_id,
                data: Vec::new(),
                fin: true,
            });
            let _ = cmd_tx.send(QuicCmd::CloseTcp { stream: stream_id });
        }
        3 => {
            // UDP ASSOCIATE: reply with our UDP relay address and
            // hold the TCP connection open (per RFC 1928, the
            // association lives while this TCP connection lives).
            let reply = [
                5, 0, 0, 1, 127, 0, 0, 1,
                (socks_port >> 8) as u8, (socks_port & 0xff) as u8,
            ];
            if stream.write_all(&reply).is_err() {
                return;
            }
            let mut sink = [0u8; 512];
            while !shared.stop.load(Ordering::Relaxed) {
                match stream.read(&mut sink) {
                    Ok(0) | Err(_) => break,
                    Ok(_) => {}
                }
            }
        }
        _ => {
            let _ = stream.write_all(&[5, 7, 0, 1, 0, 0, 0, 0, 0, 0]);
        }
    }
}

fn socks_server(shared: Arc<Shared>, socks_port: u16) {
    let listener = match TcpListener::bind(("127.0.0.1", socks_port)) {
        Ok(l) => l,
        Err(_) => return,
    };
    let _ = listener.set_nonblocking(true);
    let udp_sock = match UdpSocket::bind(("127.0.0.1", socks_port)) {
        Ok(s) => s,
        Err(_) => return,
    };
    let _ = udp_sock.set_read_timeout(Some(Duration::from_millis(100)));
    let udp_shared = shared.clone();
    let udp_arc = Arc::new(udp_sock);
    thread::spawn(move || {
        udp_relay_loop(udp_arc, udp_shared);
    });
    while !shared.stop.load(Ordering::Relaxed) {
        match listener.accept() {
            Ok((stream, _)) => {
                let s = shared.clone();
                let port = socks_port;
                thread::spawn(move || socks_tcp_client(stream, s, port));
            }
            Err(_) => {
                std::thread::sleep(Duration::from_millis(20));
            }
        }
    }
}

fn udp_relay_loop(sock: Arc<UdpSocket>, shared: Arc<Shared>) {
    // Registry: (client addr, destination) -> CONNECT-UDP stream.
    // The writer thread for a stream inserts the id when the QUIC
    // thread confirms UdpOpened, and removes it on close. Packets
    // arriving while a stream is still opening are dropped (UDP
    // clients retry); this is the only lossy corner, and it is
    // deliberate — buffering unbounded datagrams would be worse.
    type UdpKey = (SocketAddr, String);
    let registry: Arc<Mutex<HashMap<UdpKey, u64>>> = Arc::new(Mutex::new(HashMap::new()));
    let pending: Arc<Mutex<std::collections::HashSet<UdpKey>>> =
        Arc::new(Mutex::new(std::collections::HashSet::new()));
    let mut buf = [0u8; MAX_DATAGRAM];
    while !shared.stop.load(Ordering::Relaxed) {
        let (len, src) = match sock.recv_from(&mut buf) {
            Ok(v) => v,
            Err(_) => continue,
        };
        if len < 4 || buf[0] != 0 || buf[2] != 0 {
            continue;
        }
        // Keep the raw address field bytes so replies can reuse
        // them verbatim (covers IPv4, domain, and IPv6 forms).
        let addr_field_len = match parse_socks_addr(&buf, 3) {
            Some((_, end)) => end - 3,
            None => continue,
        };
        let (dst, _) = match parse_socks_addr(&buf, 3) {
            Some(v) => v,
            None => continue,
        };
        let payload = buf[3 + addr_field_len..len].to_vec();
        let addr_bytes = buf[3..3 + addr_field_len].to_vec();
        let key: UdpKey = (src, dst.clone());
        let stream_id = {
            let guard = registry.lock().unwrap_or_else(|e| e.into_inner());
            guard.get(&key).copied()
        };
        if let Some(stream) = stream_id {
            let _ = shared.cmd_tx.send(QuicCmd::UdpData {
                stream,
                data: payload,
            });
            continue;
        }
        {
            let mut guard = pending.lock().unwrap_or_else(|e| e.into_inner());
            if guard.contains(&key) {
                continue;
            }
            guard.insert(key.clone());
        }
        let (tx, rx) = channel::<QuicEvent>();
        if shared
            .cmd_tx
            .send(QuicCmd::OpenUdp { target: dst, tx })
            .is_err()
        {
            let mut guard = pending.lock().unwrap_or_else(|e| e.into_inner());
            guard.remove(&key);
            continue;
        }
        let writer_sock = sock.clone();
        let writer_registry = registry.clone();
        let writer_pending = pending.clone();
        let writer_stop = shared.stop.clone();
        thread::spawn(move || {
            let mut my_stream: Option<u64> = None;
            while !writer_stop.load(Ordering::Relaxed) {
                match rx.recv_timeout(Duration::from_millis(200)) {
                    Ok(QuicEvent::UdpOpened { stream }) => {
                        my_stream = Some(stream);
                        let mut guard = writer_registry
                            .lock()
                            .unwrap_or_else(|e| e.into_inner());
                        guard.insert(key.clone(), stream);
                    }
                    Ok(QuicEvent::UdpDatagram { data, .. }) => {
                        if my_stream.is_none() {
                            continue;
                        }
                        let mut reply = vec![0u8, 0, 0];
                        reply.extend_from_slice(&addr_bytes);
                        reply.extend_from_slice(&data);
                        let _ = writer_sock.send_to(&reply, src);
                    }
                    Ok(QuicEvent::UdpClosed { .. }) | Ok(QuicEvent::Fatal(_)) => break,
                    Ok(_) => {}
                    Err(_) => {}
                }
            }
            if let Some(stream) = my_stream {
                let mut guard = writer_registry
                    .lock()
                    .unwrap_or_else(|e| e.into_inner());
                if guard.get(&key).copied() == Some(stream) {
                    guard.remove(&key);
                }
            }
            let mut guard = writer_pending.lock().unwrap_or_else(|e| e.into_inner());
            guard.remove(&key);
        });
    }
}

// ---------------------------------------------------------------- JNI

#[no_mangle]
pub extern "system" fn Java_com_kunk_singbox_engines_MasqueCore_nativeStart(
    mut env: JNIEnv,
    _obj: JObject,
    gateway_host: JString,
    gateway_port: jint,
    server_name: JString,
    socks_port: jint,
) -> jint {
    let host: String = match env.get_string(&gateway_host) {
        Ok(s) => s.into(),
        Err(_) => return 2,
    };
    let sni: String = match env.get_string(&server_name) {
        Ok(s) => s.into(),
        Err(_) => return 2,
    };
    if host.is_empty() || gateway_port <= 0 || gateway_port > 65535 || socks_port <= 0 || socks_port > 65535 {
        return 2;
    }
    {
        let guard = core_lock().lock().unwrap_or_else(|e| e.into_inner());
        if guard.is_some() {
            return 1;
        }
    }
    let peer: SocketAddr = match (host.as_str(), gateway_port as u16)
        .to_socket_addrs()
    {
        Ok(mut it) => match it.next() {
            Some(a) => a,
            None => return 3,
        },
        Err(_) => return 3,
    };
    let sock = match UdpSocket::bind("0.0.0.0:0") {
        Ok(s) => s,
        Err(_) => return 3,
    };
    if sock.connect(peer).is_err() {
        return 3;
    }
    let gateway_authority = format!("{}:{}", host, gateway_port);
    let server_name_opt = if sni.is_empty() { None } else { Some(sni) };
    let (cmd_tx, cmd_rx) = channel::<QuicCmd>();
    let stop = Arc::new(AtomicBool::new(false));
    let shared = Arc::new(Shared {
        stop: stop.clone(),
        cmd_tx: cmd_tx.clone(),
    });
    let quic_sock = match sock.try_clone() {
        Ok(s) => s,
        Err(_) => return 3,
    };
    thread::spawn(move || {
        quic_thread(quic_sock, peer, server_name_opt, gateway_authority, cmd_rx);
    });
    let socks_shared = shared.clone();
    thread::spawn(move || {
        socks_server(socks_shared, socks_port as u16);
    });
    {
        let mut guard = core_lock().lock().unwrap_or_else(|e| e.into_inner());
        *guard = Some(Shared {
            stop,
            cmd_tx,
        });
    }
    0
}

#[no_mangle]
pub extern "system" fn Java_com_kunk_singbox_engines_MasqueCore_nativeStop(
    _env: JNIEnv,
    _obj: JObject,
) {
    let mut guard = core_lock().lock().unwrap_or_else(|e| e.into_inner());
    if let Some(shared) = guard.take() {
        shared.stop.store(true, Ordering::Relaxed);
        let _ = shared.cmd_tx.send(QuicCmd::Shutdown);
    }
}

#[no_mangle]
pub extern "system" fn Java_com_kunk_singbox_engines_MasqueCore_nativeIsRunning(
    _env: JNIEnv,
    _obj: JObject,
) -> jboolean {
    let guard = core_lock().lock().unwrap_or_else(|e| e.into_inner());
    match guard.as_ref() {
        Some(shared) => !shared.stop.load(Ordering::Relaxed) as jboolean,
        None => 0 as jboolean,
    }
}
