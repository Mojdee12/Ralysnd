# Credits & licensing — Ralysnd (FENIX rebuild)

> This file ships with the public release. It is the attribution record
> for the whole app after the FENIX rebuild. Read it together with the
> root `LICENSE` file (GNU GPL-3.0).

## Distribution license (the whole app)

**Ralysnd is distributed under the GNU General Public License v3.0
(GPL-3.0).** The full license text is in the root `LICENSE` file.

This is a consequence of the FENIX rebuild: FENIX now embeds code
derived from a GPL-3.0 project (below). Under GPL-3.0 §5(c), the entire
distributed work — including the parts that were previously MIT — must
be licensed under GPL-3.0 as a whole, and the full corresponding source
must be published with every public release (GPL-3.0 §6(d): object code
offered from a network place must offer equivalent access to the
corresponding source from the same place at no further charge).

- The app is released publicly under the name **Ralysnd**.
- The full source of the released app is published with the release.
  A release that ships an APK without its corresponding source does
  NOT satisfy this file's promise — do not publish one.
- The previous root `LICENSE` (MIT, "SingBox for Android Contributors",
  2024, covering the KunBox base) is superseded by GPL-3.0 for the
  distributed app. MIT-licensed parts MAY be included in a GPL work;
  this file preserves their notices below, but the combined app's
  license is GPL-3.0.

## Original project credited (FENIX engine)

- **firefox-vpn-client** by **armanlife** — https://github.com/armanlife/firefox-vpn-client
- License: **GPL-3.0** (project root `LICENSE`).
- What was used: the Go core (FxA sign-in, Guardian pass, server list,
  control-plane stack with DoH resolution, gvisor TUN + H2/H3 CONNECT
  tunnel) as the FENIX engine, integrated into Ralysnd as a gomobile
  `.aar` and driven over the core's loopback dashboard API.
- Attribution note (from the mapping pass): the upstream project carries
  no `NOTICE` file and no per-file copyright headers — attribution lives
  at the project level, which is what this section does. The upstream
  project name and author are preserved here and in the release notes.
- Separate-license assets inside the upstream repo (NOT the project
  license, NOT shipped as code): flag icons under MIT (Panayiotis
  Lipiridis) and the Vazirmatn font under the SIL Open Font License.
  If either asset is shipped in Ralysnd, its own license file ships with it.

## MIT parts still in the app (included in the GPL whole)

- **KunBox / sing-box for Android base** (MIT) — the Configs tab,
  sing-box core (libbox), and the surrounding app shell derive from the
  KunBox open-source client. Original MIT notice preserved from the
  previous root `LICENSE` (Copyright (c) 2024 SingBox for Android
  Contributors). MIT permits inclusion in a GPL work; the combined app
  remains GPL-3.0.
- **FoxyVPN** (MIT, Vauth) — the OLD FENIX implementation derived from
  FoxyVPN. That code is DELETED in the rebuild; its `FOXY-LICENSE.txt`
  is therefore not a live attribution for the shipped app and must not
  be left implying Foxy code still ships. (Kept in release history only.)

## What the builder name means

"Ralysnd" on the release is the distributor/builder name for this
build. It does not replace the upstream credit above: the upstream
project is credited as the engine's origin, and Ralysnd is credited as
the app that integrates it. Both names appear in the release notes.
