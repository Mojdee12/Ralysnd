package com.kunk.singbox.service

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.content.ContextCompat
import com.kunk.singbox.aidl.ISingBoxService
import com.kunk.singbox.aidl.ISingBoxServiceCallback
import com.kunk.singbox.R
import com.kunk.singbox.ipc.DataPlaneStatus
import com.kunk.singbox.ipc.StateGenerationGate
import com.kunk.singbox.ipc.DataPlaneReadinessSnapshot
import com.kunk.singbox.ipc.VpnStateStore
import com.kunk.singbox.ipc.SingBoxIpcService
import com.kunk.singbox.ipc.toRuntimeStateSnapshot
import com.kunk.singbox.manager.VpnServiceManager
import com.kunk.singbox.repository.*
import com.kunk.singbox.ui.components.AppNotificationManager
import com.kunk.singbox.repository.SettingsRepository
import com.kunk.singbox.model.TrafficCaptureMode
import com.kunk.singbox.service.root.RootServicePrewarmer
import com.kunk.singbox.service.root.RootTransparentForegroundService
import com.kunk.singbox.service.manager.ServiceStateHolder
import com.kunk.singbox.service.manager.VpnStopInitiator
import com.kunk.singbox.service.notification.VpnNotificationManager
import com.kunk.singbox.utils.LocaleHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class VpnTileService : TileService() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrapFromCache(newBase))
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var bindTimeoutJob: Job? = null
    @Volatile private var lastServiceState: ServiceState = ServiceState.STOPPED
    @Volatile private var lastServiceLabel: String = ""
    @Volatile private var lastReadiness = com.kunk.singbox.ipc.DataPlaneReadinessSnapshot.stopped()
    private var serviceBound = false
    private var bindRequested = false
    private var tapPending = false
    private var tileReceiverRegistered = false

    @Volatile private var isStartingSequence = false
    @Volatile private var startSequenceId: Long = 0L

    @Volatile private var remoteService: ISingBoxService? = null
    private val stateGenerationGate = StateGenerationGate()

    private val tileRefreshReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == ACTION_REFRESH_TILE) {
                updateTile()
                bindService()
            }
        }
    }

    private val remoteCallback = object : ISingBoxServiceCallback.Stub() {
        override fun onStateChanged(
            @Suppress("UNUSED_PARAMETER") state: Int,
            @Suppress("UNUSED_PARAMETER") activeLabel: String?,
            @Suppress("UNUSED_PARAMETER") lastError: String?,
            @Suppress("UNUSED_PARAMETER") manuallyStopped: Boolean,
            @Suppress("UNUSED_PARAMETER") generation: Long
        ) {
            serviceScope.launch(Dispatchers.Main) {
                val snapshot = runCatching {
                    remoteService?.stateSnapshot?.toRuntimeStateSnapshot()
                }.getOrNull() ?: return@launch
                if (!applyRemoteStateSnapshot(snapshot)) {
                    Log.w(TAG, "Ignored stale tile snapshot generation=${snapshot.generation}")
                    return@launch
                }
                updateTile()
            }
        }

        override fun onUrlTestNodeDelayResult(requestId: Long, delay: Int) = Unit
    }

    private fun applyRemoteStateSnapshot(snapshot: VpnStateStore.RuntimeStateSnapshot): Boolean {
        val mappedState = ServiceState.values().getOrNull(snapshot.stateOrdinal)
            ?: ServiceState.STOPPED
        return stateGenerationGate.tryCommit(snapshot.generation) {
            lastServiceState = mappedState
            lastServiceLabel = snapshot.activeLabel
            lastReadiness = snapshot.readiness
            if (shouldCompleteStartingSequence(mappedState)) {
                isStartingSequence = false
                startSequenceId = 0L
            }
        }
    }

    companion object {
        private const val TAG = "VpnTileService"
        const val ACTION_REFRESH_TILE = "com.kunk.singbox.REFRESH_TILE"
        private const val STOP_NOTIFICATION_CLEANUP_DELAY_MS = 250L
        private const val REQUEST_CODE_VPN_PERMISSION = 3001
        fun persistVpnState(isActive: Boolean) {
            VpnStateStore.setActive(isActive)
        }

        fun persistVpnPending(pending: String?) {
            val value = pending.orEmpty()
            VpnStateStore.setPending(value)
        }

        internal fun shouldCompleteStartingSequence(state: ServiceState): Boolean {
            return state == ServiceState.RUNNING ||
                state == ServiceState.STOPPING ||
                state == ServiceState.STOPPED
        }

        internal fun shouldClearStartingSequenceOnListen(
            isStartingSequence: Boolean,
            pending: String
        ): Boolean {
            return isStartingSequence && pending != "starting"
        }

        internal fun shouldClearUnavailablePending(
            pending: String,
            isStartingSequence: Boolean,
            serviceActuallyRunning: Boolean,
            hasVpnTransport: Boolean
        ): Boolean {
            if (serviceActuallyRunning || hasVpnTransport) return false

            return when (pending) {
                "starting" -> !isStartingSequence
                "stopping" -> true
                else -> false
            }
        }

        internal fun shouldClearUnavailablePersistedActive(
            pending: String,
            persistedActive: Boolean,
            serviceActuallyRunning: Boolean,
            hasVpnTransport: Boolean
        ): Boolean {
            if (serviceActuallyRunning || hasVpnTransport) return false
            if (pending == "starting") return false
            return persistedActive
        }

        internal fun shouldRequestVpnPermissionBeforeStart(
            isActive: Boolean,
            tunEnabled: Boolean,
            vpnPrepareRequired: Boolean
        ): Boolean {
            return !isActive && tunEnabled && vpnPrepareRequired
        }

        internal fun hasTileControlPlane(
            serviceBound: Boolean,
            readiness: DataPlaneReadinessSnapshot,
            nowElapsedMs: Long
        ): Boolean = serviceBound || readiness.isFresh(nowElapsedMs)

        internal fun resolveTileState(
            serviceState: ServiceState,
            readinessStatus: DataPlaneStatus,
            isStartingSequence: Boolean
        ): Int = when {
            readinessStatus == DataPlaneStatus.FAILED_BLOCKED -> Tile.STATE_UNAVAILABLE
            readinessStatus == DataPlaneStatus.FAILED_UNPROTECTED -> Tile.STATE_INACTIVE
            isStartingSequence || serviceState == ServiceState.STARTING -> Tile.STATE_ACTIVE
            serviceState == ServiceState.RUNNING -> Tile.STATE_ACTIVE
            else -> Tile.STATE_INACTIVE
        }
    }

    override fun onStartListening() {
        super.onStartListening()
        serviceScope.launch(Dispatchers.IO) {
            RootServicePrewarmer.prewarmIfIdle(this@VpnTileService)
        }
        clearStaleStartingSequenceOnListen()
        updateTile()
        registerTileRefreshReceiver()
        bindService()
    }

    private fun clearStaleStartingSequenceOnListen() {
        if (!shouldClearStartingSequenceOnListen(isStartingSequence, VpnStateStore.getPending())) return
        isStartingSequence = false
        startSequenceId = 0L
    }

    override fun onStopListening() {
        super.onStopListening()
        unregisterTileRefreshReceiver()
        unbindService()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_REFRESH_TILE) {
            updateTile()
            bindService()
        }
        return START_NOT_STICKY
    }

    override fun onClick() {
        super.onClick()
        if (isLocked) {
            unlockAndRun { handleClick() }
            return
        }
        handleClick()
    }

    private fun handleClick() {
        val tile = qsTile ?: return

        if (VpnStateStore.getPending() == "stopping" ||
            (lastServiceState == ServiceState.STOPPING && isCoreServiceAvailable())
        ) {
            Log.i(TAG, "Ignoring tile tap while VPN stop is in progress")
            return
        }

        val isActive = tile.state == Tile.STATE_ACTIVE

        if (isActive) {

            tile.state = Tile.STATE_INACTIVE
            tile.label = getString(R.string.connection_disconnecting)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = null
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to set tile subtitle", e)
            }
            tile.updateTile()

            executeStopVpn()
        } else {

            tile.state = Tile.STATE_ACTIVE
            tile.label = getString(R.string.connection_connecting)
            tile.updateTile()

            executeStartVpn()
        }
    }

    @SuppressLint("StartActivityAndCollapseDeprecated")
    private fun startActivityAndCollapseCompat(intent: Intent, requestCode: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val pendingIntent = PendingIntent.getActivity(
                this,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            startActivityAndCollapse(pendingIntent)
            return
        }

        @Suppress("DEPRECATION")
        startActivityAndCollapse(intent)
    }

    @Suppress("LongMethod", "CyclomaticComplexMethod", "CognitiveComplexMethod")
    private fun updateTile(activeLabelOverride: String? = null) {
        val runtimeSnapshot = VpnStateStore.getRuntimeStateSnapshot()
        applyRemoteStateSnapshot(runtimeSnapshot)
        var persistedActive = runtimeSnapshot.stateOrdinal == ServiceState.RUNNING.ordinal
        val pending = VpnStateStore.getPending()
        if (shouldClearStartingSequenceOnListen(isStartingSequence, pending)) {
            isStartingSequence = false
            startSequenceId = 0L
        }

        val isServiceDisconnected = !serviceBound || remoteService == null
        val isZombieCandidate = !isStartingSequence && isServiceDisconnected && pending.isEmpty()
        if (isZombieCandidate && reconcileStaleStateIfNeeded(runtimeSnapshot, persistedActive)) {
            persistedActive = false
        }
        val effectiveState = if (isStartingSequence) {
            ServiceState.STARTING
        } else if (!serviceBound || remoteService == null || pending.isNotEmpty()) {
            when (pending) {
                "starting" -> ServiceState.STARTING
                "stopping" -> ServiceState.STOPPING
                else -> if (persistedActive) ServiceState.RUNNING else ServiceState.STOPPED
            }
        } else {
            lastServiceState
        }

        val tile = qsTile ?: return

        tile.state = resolveTileState(effectiveState, lastReadiness.status, isStartingSequence)
        val activeLabel = if (effectiveState == ServiceState.RUNNING ||
            effectiveState == ServiceState.STARTING
        ) {
            activeLabelOverride?.takeIf { it.isNotBlank() }
                ?: lastServiceLabel.takeIf { it.isNotBlank() }
                ?: runCatching {
                    val repo = ConfigRepository.getInstance(applicationContext)
                    val nodeId = repo.activeNodeId.value
                    if (!nodeId.isNullOrBlank()) repo.getNodeById(nodeId)?.name else null
                }.getOrNull()
        } else {
            null
        }

        tile.label = when (effectiveState) {
            ServiceState.STARTING -> getString(R.string.connection_connecting)
            ServiceState.STOPPING -> getString(R.string.connection_disconnecting)
            ServiceState.RUNNING -> activeLabel ?: getString(R.string.app_name)
            ServiceState.STOPPED -> getString(R.string.app_name)
        }
        try {
            tile.icon = android.graphics.drawable.Icon.createWithResource(this, R.drawable.ic_qs_tile)
        } catch (_: Exception) {
        }
        tile.updateTile()
    }

    @Suppress("DEPRECATION")
    private fun hasSystemVpnTransport(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        return cm.allNetworks.any { network ->
            val caps = cm.getNetworkCapabilities(network) ?: return@any false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
        }
    }

    private fun isCoreServiceAvailable(): Boolean {
        return (serviceBound && remoteService != null) ||
            ProxyOnlyService.isRunning ||
            ProxyOnlyService.isStarting ||
            RootTransparentForegroundService.isRunning ||
            RootTransparentForegroundService.isStarting ||
            ServiceStateHolder.instance != null ||
            ServiceStateHolder.isRunning ||
            ServiceStateHolder.isStarting ||
            // FENIX rebuild: the Go-core service is a fourth transport.
            com.kunk.singbox.gocore.GoCoreVpnService.isRunning ||
            com.kunk.singbox.gocore.GoCoreVpnService.isStarting
    }

    private fun reconcileStaleStateIfNeeded(
        runtimeSnapshot: VpnStateStore.RuntimeStateSnapshot,
        persistedActive: Boolean
    ): Boolean {
        if (!persistedActive) return false
        val serviceActuallyRunning = isCoreServiceAvailable()
        val hasVpnTransport = hasSystemVpnTransport()
        if (!serviceActuallyRunning && !hasVpnTransport) {
            Log.w(TAG, "Detected stale active state in updateTile, reconciling to STOPPED")
            persistVpnState(false)
            persistVpnPending("")
            VpnStateStore.buildNextRuntimeStateSnapshot(runtimeSnapshot) {
                it.copy(
                    stateOrdinal = ServiceState.STOPPED.ordinal,
                    readiness = com.kunk.singbox.ipc.DataPlaneReadinessSnapshot.stopped("tile_zombie_reconcile")
                )
            }.also { VpnStateStore.persistRuntimeStateSnapshotBestEffort(it) }
            lastServiceState = ServiceState.STOPPED
            lastReadiness = com.kunk.singbox.ipc.DataPlaneReadinessSnapshot.stopped()
            return true
        }
        return false
    }

    private fun executeStopVpn() {
        isStartingSequence = false
        startSequenceId = 0L

        persistVpnPending("stopping")
        val stopRequestedAt = SystemClock.elapsedRealtime()

        serviceScope.launch(Dispatchers.IO) {
            try {
                VpnServiceManager.stopVpn(
                    this@VpnTileService,
                    VpnStopInitiator.QUICK_SETTINGS
                ).getOrThrow()

                withContext(Dispatchers.Main) {
                    updateTile()
                }

                delay(STOP_NOTIFICATION_CLEANUP_DELAY_MS)
                withContext(Dispatchers.Main) {
                    runCatching {
                        val nm = getSystemService(NotificationManager::class.java)

                        nm?.cancel(VpnNotificationManager.NOTIFICATION_ID)

                        nm?.cancel(11)
                        nm?.cancel(12)
                    }
                    Log.d(TAG, "executeStopVpn ui settle in ${SystemClock.elapsedRealtime() - stopRequestedAt}ms")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Stop service failed", e)

                handleStartFailure("Stop service failed: ${e.message}")
            }
        }
    }

    @Suppress("CognitiveComplexMethod", "LongMethod")
    private fun executeStartVpn() {

        startSequenceId = SystemClock.elapsedRealtimeNanos()
        isStartingSequence = true
        persistVpnPending("starting")

        serviceScope.launch(Dispatchers.IO) {
            try {
                val settings = SettingsRepository.getInstance(applicationContext).settings.first()

                val captureMode = settings.resolvedTrafficCaptureMode()
                if (captureMode == TrafficCaptureMode.VPN) {
                    val prepareIntent = VpnService.prepare(this@VpnTileService)
                    if (shouldRequestVpnPermissionBeforeStart(
                            isActive = false,
                            tunEnabled = true,
                            vpnPrepareRequired = prepareIntent != null
                        )
                    ) {

                        withContext(Dispatchers.Main) {
                            revertToInactive()
                            prepareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            runCatching {
                                startActivityAndCollapseCompat(prepareIntent, REQUEST_CODE_VPN_PERMISSION)
                            }
                        }
                        return@launch
                    }
                }

                val configRepository = ConfigRepository.getInstance(applicationContext)
                val configResult = configRepository.generateConfigFile(
                    selectedProfileId = VpnStateStore.getSelectedProfileId(),
                    selectedNodeId = VpnStateStore.getSelectedNodeId(),
                    candidateRequestId = VpnServiceManager.newCandidateRequestId(captureMode).orEmpty()
                )

                if (configResult != null) {
                    VpnServiceManager.startVpn(
                        context = this@VpnTileService,
                        mode = captureMode,
                        configPath = configResult.path,
                        requestId = configResult.requestId,
                        cleanCache = true,
                        pendingNodeName = configResult.activeNodeName
                    ).getOrThrow()
                    withContext(Dispatchers.Main) { bindService(force = true) }
                } else {
                    handleStartFailure(getString(R.string.dashboard_config_generation_failed))
                }
            } catch (e: Exception) {
                handleStartFailure("Start failed: ${e.message}")
            }
        }
    }

    private suspend fun handleStartFailure(reason: String) {
        startSequenceId = 0L
        isStartingSequence = false

        persistVpnPending("")
        persistVpnState(false)
        lastServiceState = ServiceState.STOPPED
        lastReadiness = com.kunk.singbox.ipc.DataPlaneReadinessSnapshot.stopped()

        withContext(Dispatchers.Main) {
            revertToInactive()
            AppNotificationManager.showMessage(
                context = this@VpnTileService,
                message = reason,
                duration = androidx.compose.material3.SnackbarDuration.Long
            )
        }
    }

    private fun revertToInactive() {
        val tile = qsTile ?: return
        tile.state = Tile.STATE_INACTIVE
        tile.label = getString(R.string.app_name)
        tile.updateTile()
    }

    private fun toggle() {
        // Redirect to new logic
        handleClick()
    }

    private fun bindService(force: Boolean = false) {
        if (serviceBound || bindRequested) return

        val persistedActive = VpnStateStore.getActive()
        val pending = VpnStateStore.getPending()

        val shouldTryBind = force || persistedActive || pending == "starting" || pending == "stopping" ||
            isCoreServiceAvailable()
        if (!shouldTryBind) return

        val intent = Intent(this, SingBoxIpcService::class.java)

        val ok = runCatching {
            bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)
        }.getOrDefault(false)
        bindRequested = ok

        scheduleBindTimeout()

        if (!ok && shouldClearUnavailableAfterBindFailure(
                pending = pending,
                persistedActive = persistedActive
            )
        ) {
            tapPending = false
            persistVpnState(false)
            persistVpnPending("")
            lastServiceState = ServiceState.STOPPED
            lastReadiness = com.kunk.singbox.ipc.DataPlaneReadinessSnapshot.stopped()
            updateTile()
        }
    }

    private fun scheduleBindTimeout() {
        bindTimeoutJob?.cancel()
        bindTimeoutJob = serviceScope.launch {
            delay(1200)
            if (serviceBound || remoteService != null) return@launch
            if (!bindRequested) return@launch

            val active = VpnStateStore.getActive()
            val pending = VpnStateStore.getPending()

            if (shouldClearUnavailableAfterBindFailure(pending, active)) {
                unbindService()
                tapPending = false
                persistVpnState(false)
                persistVpnPending("")
                lastServiceState = ServiceState.STOPPED
                lastReadiness = com.kunk.singbox.ipc.DataPlaneReadinessSnapshot.stopped()
                updateTile()
            }
        }
    }

    private fun shouldClearUnavailableAfterBindFailure(
        pending: String,
        persistedActive: Boolean
    ): Boolean {
        val hasVpnTransport = hasSystemVpnTransport()
        return shouldClearUnavailablePending(
            pending = pending,
            isStartingSequence = isStartingSequence,
            serviceActuallyRunning = false,
            hasVpnTransport = hasVpnTransport
        ) || shouldClearUnavailablePersistedActive(
            pending = pending,
            persistedActive = persistedActive,
            serviceActuallyRunning = false,
            hasVpnTransport = hasVpnTransport
        )
    }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = ISingBoxService.Stub.asInterface(service)
            remoteService = binder
            runCatching { binder.registerCallback(remoteCallback) }
            serviceBound = true
            bindRequested = true
            val snapshot = runCatching { binder.stateSnapshot.toRuntimeStateSnapshot() }
                .onFailure { error -> Log.w(TAG, "Failed to read initial tile state snapshot", error) }
                .getOrNull()
            if (snapshot != null && !applyRemoteStateSnapshot(snapshot)) {
                Log.w(TAG, "Ignored stale initial tile snapshot generation=${snapshot.generation}")
            }
            updateTile()
            if (tapPending) {
                tapPending = false
                toggle()
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            runCatching { remoteService?.unregisterCallback(remoteCallback) }
            remoteService = null
            serviceBound = false
            bindRequested = false
            updateTile()
        }
    }

    private fun unbindService() {
        if (!bindRequested) return
        bindTimeoutJob?.cancel()
        bindTimeoutJob = null
        runCatching { remoteService?.unregisterCallback(remoteCallback) }
        runCatching { unbindService(serviceConnection) }
        remoteService = null
        serviceBound = false
        bindRequested = false
    }

    private fun registerTileRefreshReceiver() {
        if (tileReceiverRegistered) return
        val filter = IntentFilter(ACTION_REFRESH_TILE)
        runCatching {
            ContextCompat.registerReceiver(this, tileRefreshReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            tileReceiverRegistered = true
        }.onFailure { error ->
            Log.w(TAG, "Failed to register tile refresh receiver", error)
        }
    }

    private fun unregisterTileRefreshReceiver() {
        if (!tileReceiverRegistered) return
        runCatching {
            unregisterReceiver(tileRefreshReceiver)
        }.onFailure { error ->
            Log.w(TAG, "Failed to unregister tile refresh receiver", error)
        }
        tileReceiverRegistered = false
    }

    override fun onDestroy() {
        unregisterTileRefreshReceiver()
        unbindService()
        serviceScope.cancel()
        super.onDestroy()
    }
}
