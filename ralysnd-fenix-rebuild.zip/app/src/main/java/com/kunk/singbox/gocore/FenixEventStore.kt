// New code written for the Ralysnd FENIX rebuild (Go-core integration).
// Package: com.kunk.singbox.gocore (new).
//
// PURPOSE: the always-visible FENIX event strip. The old FENIX diagnostics
// were invisible because they went to an in-memory logger nobody displayed
// and because the Logs screen hides everything unless debug logging is on.
// This store is file-backed and read directly by the FENIX tab, independent
// of the debug-logging setting. Lines are ALSO mirrored to LogRepository
// (via the onLog wiring in GoCoreViewModel) so they appear in Settings >
// Tools > Logs when debug logging is on. Neither store ever holds secrets.

package com.kunk.singbox.gocore

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Last-N-lines persisted event log for the FENIX tab.
 * Format matches the Logs screen filter: "INFO [FENIX] ..." / "ERROR [FENIX] ...".
 */
class FenixEventStore(context: Context) {

    private val file = File(context.filesDir, "fenix_events.log")
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    private val _lines = MutableStateFlow<List<String>>(emptyList())
    val lines: StateFlow<List<String>> = _lines.asStateFlow()

    @Synchronized
    fun append(level: String, message: String) {
        val line = "${timeFormat.format(Date())} $level [FENIX] $message"
        val current = (_lines.value + line).takeLast(MAX_LINES)
        _lines.value = current
        runCatching {
            // Rewrite is fine at this size (<= 200 short lines).
            file.writeText(current.joinToString("\n"), Charsets.UTF_8)
        }
    }

    @Synchronized
    fun load() {
        if (!file.exists()) {
            _lines.value = emptyList()
            return
        }
        _lines.value = runCatching {
            file.readLines(Charsets.UTF_8).takeLast(MAX_LINES)
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun clear() {
        _lines.value = emptyList()
        runCatching { file.delete() }
    }

    companion object {
        private const val MAX_LINES = 200
    }
}
