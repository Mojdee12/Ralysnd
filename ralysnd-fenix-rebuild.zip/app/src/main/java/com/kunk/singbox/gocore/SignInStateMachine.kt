// New code written for the Ralysnd FENIX rebuild (Go-core integration).
// Package: com.kunk.singbox.gocore (new; the old FENIX
// package is deleted).
//
// This machine drives ONE dashboard sign-in: start → poll → answer steps
// → done/failed. The Go core owns the whole FxA flow; Kotlin only drives
// its waiting steps. No direct FxA HTTP call exists in Kotlin anymore.
// Step names and error codes below are the daemon's published vocabulary
// (signInView.step / error_code) — factual API surface, not copied code.
//
// VISIBLE LOG (fixes the empty-log bug): every diagnostic line goes
// through [onLog], which the ViewModel wires to BOTH the file-backed
// LogRepository (so Settings > Tools > Logs shows it) AND the FENIX tab's
// always-visible event strip. Never: bodies, tokens, emails, passwords,
// codes, challenge payloads, account ids.

package com.kunk.singbox.gocore

import com.kunk.singbox.repository.LogRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** UI states for one sign-in attempt. Carries no secrets. */
sealed interface GoSignInUiState {
    data object Idle : GoSignInUiState
    data object Starting : GoSignInUiState

    /** Waiting for the user to answer a daemon step. */
    data class WaitingStep(val signInId: String, val step: GoSignInView) : GoSignInUiState

    /** Waiting with no user action needed (daemon working / email-link wait). */
    data class Waiting(val signInId: String, val hint: String) : GoSignInUiState

    data object Answering : GoSignInUiState
    data class Done(val accountId: String) : GoSignInUiState
    data class Failed(val category: SignInFailureCategory) : GoSignInUiState
    data object Cancelled : GoSignInUiState
}

enum class SignInFailureCategory {
    WRONG_CREDENTIALS, NO_ACCOUNT, NO_PASSWORD, CODE_INVALID, TOO_MANY_ATTEMPTS,
    BLOCKED, NETWORK, TIMEOUT, UNKNOWN,
}

/**
 * Drives one dashboard sign-in: start → poll → answer steps → done/failed.
 * Owns the poll Job; callers cancel via [cancel] (which also DELETEs server-side).
 * The password is used only for the start request object, then dropped —
 * it is never put in state, logs, or saved state.
 */
class SignInStateMachine(
    private val api: DashboardApiClient,
    private val scope: CoroutineScope,
    private val onEvent: (GoSignInUiState) -> Unit = {},
    private val onLog: (level: String, message: String) -> Unit = { level, message ->
        // Default bridge: the store the Logs screen reads (addAlwaysLog
        // persists even when debug logging is off).
        LogRepository.getInstance().addAlwaysLog("$level [FENIX] $message")
    },
) {
    private val _state = MutableStateFlow<GoSignInUiState>(GoSignInUiState.Idle)
    val state: StateFlow<GoSignInUiState> = _state.asStateFlow()

    private var pollJob: Job? = null
    private var currentSignInId: String? = null
    private var answerGate: CompletableDeferred<String>? = null

    private fun emit(next: GoSignInUiState) {
        _state.value = next
        onEvent(next)
    }

    private fun log(level: String, message: String) = onLog(level, message)

    /** Start a sign-in. Any in-flight attempt is cancelled first. */
    fun start(email: String, password: String) {
        cancel()
        emit(GoSignInUiState.Starting)
        log("INFO", "signin started")
        pollJob = scope.launch {
            try {
                val started = api.startSignIn(email, password)
                val id = started.id.ifBlank {
                    throw IllegalStateException("Dashboard returned no sign-in id")
                }
                currentSignInId = id
                pollLoop(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log("ERROR", "signin failed category=${classify(e)}")
                emit(GoSignInUiState.Failed(classify(e)))
            }
        }
    }

    private suspend fun pollLoop(id: String) {
        val deadlineMs = 5 * 60 * 1000L
        val startedAt = System.currentTimeMillis()
        var intervalMs = 1500L
        var pollCount = 0
        var consecutiveNetworkErrors = 0
        while (scope.isActive) {
            if (System.currentTimeMillis() - startedAt > deadlineMs) {
                log("ERROR", "signin failed category=TIMEOUT")
                runCatching { api.cancelSignIn(id) }
                emit(GoSignInUiState.Failed(SignInFailureCategory.TIMEOUT))
                return
            }
            try {
                val view = api.getSignIn(id)
                consecutiveNetworkErrors = 0
                log("INFO", "poll step=${view.step}")
                when {
                    view.step == GoSignInStep.DONE -> {
                        val accountId = view.accountId.orEmpty()
                        log("INFO", "signin done")
                        emit(GoSignInUiState.Done(accountId))
                        return
                    }
                    view.step == GoSignInStep.FAILED -> {
                        val category = classifyErrorCode(view.errorCode, view.error)
                        log("ERROR", "signin failed category=$category")
                        emit(GoSignInUiState.Failed(category))
                        return
                    }
                    view.step == GoSignInStep.CANCELLED -> {
                        log("INFO", "signin cancelled")
                        emit(GoSignInUiState.Cancelled)
                        emit(GoSignInUiState.Idle)
                        return
                    }
                    GoSignInStep.NEEDS_TYPED_ANSWER.contains(view.step) -> {
                        emit(GoSignInUiState.WaitingStep(id, view))
                        // Park until answer() completes the gate (or cancel/timeout).
                        val gate = CompletableDeferred<String>()
                        answerGate = gate
                        try {
                            gate.await()
                        } finally {
                            if (answerGate === gate) answerGate = null
                        }
                        if (!scope.isActive) return
                        // Loop continues: the next poll shows the new step.
                    }
                    else -> {
                        emit(GoSignInUiState.Waiting(id, view.step.ifBlank { "working" }))
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                consecutiveNetworkErrors++
                log("ERROR", "poll network error count=$consecutiveNetworkErrors")
                if (consecutiveNetworkErrors >= 3) {
                    emit(GoSignInUiState.Failed(SignInFailureCategory.NETWORK))
                    return
                }
            }
            pollCount++
            if (pollCount > 40) intervalMs = 3000L
            delay(intervalMs)
        }
    }

    /** Answer the currently waiting step, then resume polling. */
    fun answer(value: String) {
        val id = currentSignInId ?: return
        val waiting = _state.value as? GoSignInUiState.WaitingStep ?: return
        emit(GoSignInUiState.Answering)
        log("INFO", "step=${waiting.step.step} answered")
        // The parked poll loop is cancelled here; a fresh loop starts below.
        pollJob?.cancel()
        pollJob = scope.launch {
            try {
                api.answerSignIn(id, value)
                pollLoop(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log("ERROR", "answer failed category=${classify(e)}")
                emit(GoSignInUiState.Failed(classify(e)))
            }
        }
    }

    /** User cancel: DELETE server-side, stop polling, return to idle. */
    fun cancel() {
        pollJob?.cancel()
        pollJob = null
        answerGate?.cancel()
        answerGate = null
        val id = currentSignInId
        currentSignInId = null
        if (id != null) {
            log("INFO", "signin cancelled")
            scope.launch {
                runCatching { api.cancelSignIn(id) }
            }
        }
        if (_state.value !is GoSignInUiState.Idle) {
            emit(GoSignInUiState.Cancelled)
            emit(GoSignInUiState.Idle)
        }
    }

    private fun classify(e: Exception): SignInFailureCategory {
        val msg = (e.message ?: "").lowercase()
        return when {
            "401" in msg || "403" in msg -> SignInFailureCategory.WRONG_CREDENTIALS
            "timeout" in msg || "timed out" in msg -> SignInFailureCategory.TIMEOUT
            "unreachable" in msg || "unable to resolve" in msg || "connection" in msg ->
                SignInFailureCategory.NETWORK
            else -> SignInFailureCategory.UNKNOWN
        }
    }

    private fun classifyErrorCode(code: String?, message: String?): SignInFailureCategory {
        return when (code) {
            GoSignInErrorCode.NO_ACCOUNT -> SignInFailureCategory.NO_ACCOUNT
            GoSignInErrorCode.WRONG_PASSWORD -> SignInFailureCategory.WRONG_CREDENTIALS
            GoSignInErrorCode.NO_PASSWORD -> SignInFailureCategory.NO_PASSWORD
            GoSignInErrorCode.WRONG_CODE, GoSignInErrorCode.WRONG_TOTP ->
                SignInFailureCategory.CODE_INVALID
            GoSignInErrorCode.TOO_MANY_ATTEMPTS, GoSignInErrorCode.TOO_MANY_CODES ->
                SignInFailureCategory.TOO_MANY_ATTEMPTS
            GoSignInErrorCode.UNBLOCK_REJECTED -> SignInFailureCategory.BLOCKED
            GoSignInErrorCode.TIMED_OUT -> SignInFailureCategory.TIMEOUT
            GoSignInErrorCode.NETWORK -> SignInFailureCategory.NETWORK
            else -> classifyMessageFallback(message)
        }
    }

    private fun classifyMessageFallback(message: String?): SignInFailureCategory {
        val msg = (message ?: "").lowercase()
        return when {
            "password" in msg || "credential" in msg -> SignInFailureCategory.WRONG_CREDENTIALS
            "code" in msg || "expired" in msg -> SignInFailureCategory.CODE_INVALID
            "block" in msg -> SignInFailureCategory.BLOCKED
            else -> SignInFailureCategory.UNKNOWN
        }
    }
}
