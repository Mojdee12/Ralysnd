// New code written for the Ralysnd FENIX rebuild (Go-core integration).
// Package: com.kunk.singbox.gocore (new; the old FENIX
// package is deleted). The old FENIX ViewModel surface (signIn, connect,
// disconnect, ping all, fastest, select, refresh, signOut, remove, switch)
// is re-implemented here against the dashboard API with NEW names
// (GoCoreUiState / GoCoreViewModel) so a stale reference is a compile
// error, not a silent old-code path.
//
// No tokens, passwords, or codes are stored here. The password is passed
// straight to the sign-in machine's start call and dropped. Account
// emails are display data only (see GoCoreAccountStore); they are never
// logged.

package com.kunk.singbox.gocore

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kunk.singbox.ipc.VpnStateStore
import com.kunk.singbox.manager.VpnServiceManager
import com.kunk.singbox.repository.LogRepository
import com.kunk.singbox.service.manager.VpnStopInitiator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Connection state shown on the FENIX tab. */
enum class GoConnectionState {
    DISCONNECTED, CONNECTING, CONNECTED, RECONNECTING, ERROR,
}

/** Full UI state for the new FENIX tab. */
data class GoCoreUiState(
    val accounts: List<GoAccount> = emptyList(),
    val activeAccountId: String? = null,
    val activeAccountEmail: String = "",
    val locations: List<GoLocation> = emptyList(),
    val selectedCountry: String = "",
    val connectionState: GoConnectionState = GoConnectionState.DISCONNECTED,
    val exitCountry: String? = null,
    val speedDownBps: Long = 0L,
    val speedUpBps: Long = 0L,
    val signIn: GoSignInUiState = GoSignInUiState.Idle,
    val errorMessage: String? = null,
    val coreError: String? = null,
    val isRefreshing: Boolean = false,
    val isPinging: Boolean = false,
)

class GoCoreViewModel(application: Application) : AndroidViewModel(application) {

    private val app: Application = application
    private val endpoint = GoCoreEndpoint(goCoreDataDir(app))
    private val api = DashboardApiClient(endpoint)
    private val accountStore = GoCoreAccountStore.getInstance(app)

    val eventStore = FenixEventStore(app)

    private val _uiState = MutableStateFlow(GoCoreUiState())
    val uiState: StateFlow<GoCoreUiState> = _uiState.asStateFlow()

    /** Transport state from the service (authoritative for tunnel up/down). */
    val transportState: StateFlow<GoCoreTransportState> = GoCoreVpnService.transportState

    private val signInMachine = SignInStateMachine(
        api = api,
        scope = viewModelScope,
        onEvent = { signInState ->
            _uiState.value = _uiState.value.copy(signIn = signInState)
            if (signInState is GoSignInUiState.Done) {
                refreshAll()
            }
        },
        onLog = { level, message ->
            eventStore.append(level, message)
            LogRepository.getInstance().addAlwaysLog("$level [FENIX] $message")
        },
    )

    /** Sign-in state, for the sheet. */
    val signInState: StateFlow<GoSignInUiState> = signInMachine.state

    private var coreEnsured = false
    private var statusPollJob: Job? = null

    init {
        eventStore.load()
        viewModelScope.launch {
            // Reflect the service's tunnel state in the tab state.
            transportState.collect { transport ->
                val current = _uiState.value
                val derived = when {
                    transport.connected -> GoConnectionState.CONNECTED
                    transport.error != null -> GoConnectionState.ERROR
                    current.connectionState == GoConnectionState.CONNECTING -> {
                        GoConnectionState.CONNECTING
                    }
                    else -> GoConnectionState.DISCONNECTED
                }
                _uiState.value = current.copy(
                    connectionState = derived,
                    exitCountry = transport.exitCountry ?: current.exitCountry,
                )
                if (transport.connected) startStatusPolling() else stopStatusPolling()
            }
        }
        ensureCore()
    }

    private fun logEvent(level: String, message: String) {
        eventStore.append(level, message)
        LogRepository.getInstance().addAlwaysLog("$level [FENIX] $message")
    }

    /** Start the daemon (proxy off) so the dashboard API answers. Idempotent. */
    fun ensureCore() {
        if (coreEnsured) return
        coreEnsured = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (!GoCoreBinding.running()) {
                    GoCoreBinding.start(goCoreDataDir(app).absolutePath, false)
                        .getOrThrow()
                }
                // Start removes the old token file and writes a fresh one
                // once bound; wait briefly for it before the first call.
                endpoint.awaitToken(10_000L)
                    ?: throw IllegalStateException("Dashboard local token unavailable")
                refreshAll()
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        coreError = "FENIX core could not start",
                    )
                }
                logEvent("ERROR", "core start failed")
            }
        }
    }

    /** Refresh accounts, locations, and status from the daemon. */
    fun refreshAll() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val accountsResp = api.getAccounts()
                val accounts = accountsResp.accounts.sortedBy { it.position }
                val active = accounts.firstOrNull { it.active }
                if (active != null) {
                    accountStore.saveActive(active.email, active.id)
                } else if (accounts.isEmpty()) {
                    accountStore.clear()
                }
                val locationsResp = runCatching { api.getLocations() }.getOrNull()
                val statusResp = runCatching { api.getStatus() }.getOrNull()
                withContext(Dispatchers.Main) {
                    val current = _uiState.value
                    val mergedLocations = mergePings(
                        locationsResp?.locations ?: current.locations,
                        current.locations,
                    )
                    _uiState.value = current.copy(
                        accounts = accounts,
                        activeAccountId = active?.id,
                        activeAccountEmail = active?.email.orEmpty(),
                        locations = mergedLocations,
                        selectedCountry = statusResp?.proxy?.countryCode
                            ?.takeIf { it.isNotBlank() }
                            ?: current.selectedCountry,
                        exitCountry = statusResp?.exit?.countryCode
                            ?.takeIf { it.isNotBlank() }
                            ?: statusResp?.proxy?.countryCode
                                ?.takeIf { it.isNotBlank() }
                            ?: current.exitCountry,
                        speedDownBps = statusResp?.traffic?.downRate ?: 0L,
                        speedUpBps = statusResp?.traffic?.upRate ?: 0L,
                        isRefreshing = false,
                    )
                }
            } catch (e: Exception) {
                logEvent("ERROR", "refresh failed")
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(isRefreshing = false)
                }
            }
        }
    }

    /** Keep old ping measurements when a locations refresh has none. */
    private fun mergePings(
        fresh: List<GoLocation>,
        previous: List<GoLocation>,
    ): List<GoLocation> {
        if (fresh.isEmpty()) return previous
        val oldByCode = previous.associateBy { it.code }
        return fresh.map { loc ->
            val old = oldByCode[loc.code]
            if (loc.pingMs == null && old?.pingMs != null) loc.copy(pingMs = old.pingMs) else loc
        }
    }

    private fun startStatusPolling() {
        if (statusPollJob?.isActive == true) return
        statusPollJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(3_000L)
                runCatching {
                    val status = api.getStatus()
                    val active = status.activeAccount
                    withContext(Dispatchers.Main) {
                        val current = _uiState.value
                        _uiState.value = current.copy(
                            exitCountry = status.exit?.countryCode
                                ?.takeIf { it.isNotBlank() }
                                ?: status.proxy?.countryCode
                                    ?.takeIf { it.isNotBlank() }
                                ?: current.exitCountry,
                            speedDownBps = status.traffic?.downRate ?: 0L,
                            speedUpBps = status.traffic?.upRate ?: 0L,
                            activeAccountEmail = active?.email ?: current.activeAccountEmail,
                        )
                    }
                }
            }
        }
    }

    private fun stopStatusPolling() {
        statusPollJob?.cancel()
        statusPollJob = null
    }

    // ---- Sign-in (sheet) ----

    fun startSignIn(email: String, password: String) {
        ensureCore()
        signInMachine.start(email, password)
    }

    fun answerSignInStep(value: String) {
        signInMachine.answer(value)
    }

    fun cancelSignIn() {
        signInMachine.cancel()
    }

    // ---- Accounts ----

    fun switchAccount(accountId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { api.activateAccount(accountId) }
            refreshAll()
        }
    }

    fun refreshAccount() {
        val id = _uiState.value.activeAccountId ?: return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { api.refreshAccount(id) }
            refreshAll()
        }
    }

    fun removeAccount(accountId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val isActive = accountId == _uiState.value.activeAccountId
            if (isActive && _uiState.value.connectionState == GoConnectionState.CONNECTED) {
                disconnect()
            }
            runCatching { api.deleteAccount(accountId) }
            refreshAll()
        }
    }

    /** Sign out of the active account: stop the tunnel first, then remove it. */
    fun signOut() {
        val id = _uiState.value.activeAccountId ?: return
        removeAccount(id)
    }

    // ---- Locations ----

    fun selectCountry(countryCode: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { api.setLocation(countryCode) }
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(selectedCountry = countryCode)
            }
            refreshAll()
        }
    }

    fun pingAllCountries() {
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(isPinging = true)
            }
            try {
                val codes = _uiState.value.locations.map { it.code }
                val resp = api.pingLocations(codes)
                val pingByCode = resp.locations.associateBy { it.code }
                withContext(Dispatchers.Main) {
                    val current = _uiState.value
                    _uiState.value = current.copy(
                        locations = current.locations.map { loc ->
                            val ping = pingByCode[loc.code]
                            if (ping?.pingMs != null) loc.copy(pingMs = ping.pingMs) else loc
                        },
                        isPinging = false,
                    )
                }
            } catch (e: Exception) {
                logEvent("ERROR", "ping all failed")
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(isPinging = false)
                }
            }
        }
    }

    /** Lowest measured ping; ties broken by list order (documented). */
    fun fastestCountry(): GoLocation? {
        return _uiState.value.locations
            .filter { it.pingMs != null && it.pingMs > 0 }
            .minByOrNull { it.pingMs ?: Long.MAX_VALUE }
    }

    // ---- Connect / disconnect (mutual exclusion, both directions) ----

    /**
     * Connect FENIX. The caller (screen) must have obtained VPN permission
     * via VpnService.prepare first. Stops sing-box first (bounded 10 s),
     * then starts the Go-core service. Never starts over a live sing-box.
     */
    fun connectSelected() {
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(
                    connectionState = GoConnectionState.CONNECTING,
                    errorMessage = null,
                )
            }
            try {
                ensureCore()
                if (VpnStateStore.getMode() == VpnStateStore.CoreMode.VPN) {
                    VpnServiceManager.stopVpn(app, VpnStopInitiator.MODE_SWITCH)
                    val stopped = VpnServiceManager.awaitModeStopped(
                        VpnStateStore.CoreMode.VPN,
                        10_000L,
                    )
                    if (!stopped) {
                        throw IllegalStateException("sing-box did not stop in time")
                    }
                }
                VpnStateStore.setMode(VpnStateStore.CoreMode.GO_CORE)
                VpnStateStore.setPending("starting")
                app.startForegroundService(
                    Intent(app, GoCoreVpnService::class.java).apply {
                        action = GoCoreServiceActions.ACTION_START
                    },
                )
                logEvent("INFO", "connect requested")
            } catch (e: Exception) {
                VpnStateStore.setMode(VpnStateStore.CoreMode.NONE)
                VpnStateStore.setPending("")
                logEvent("ERROR", "connect failed")
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        connectionState = GoConnectionState.ERROR,
                        errorMessage = "Could not connect. Try again.",
                    )
                }
            }
        }
    }

    /** Disconnect FENIX (prompt stop; the service clears the owner record). */
    fun disconnectFenix() {
        viewModelScope.launch(Dispatchers.IO) {
            app.startService(
                Intent(app, GoCoreVpnService::class.java).apply {
                    action = GoCoreServiceActions.ACTION_STOP
                },
            )
            logEvent("INFO", "disconnect requested")
        }
    }

    override fun onCleared() {
        signInMachine.cancel()
        stopStatusPolling()
        // The daemon is NOT stopped here: GoCoreVpnService owns the daemon
        // lifecycle and stops it in onDestroy. Stopping it from the
        // ViewModel would kill the API while the tunnel still runs.
        super.onCleared()
    }
}
