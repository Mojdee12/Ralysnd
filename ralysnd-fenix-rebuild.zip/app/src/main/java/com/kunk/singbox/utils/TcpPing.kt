package com.kunk.singbox.utils

import java.net.InetSocketAddress
import java.net.Socket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * M39 ping-helper note (read before "unifying" the ping code): this
 * helper is the plain, dependency-free TCP probe used by diagnostics
 * probing. The old FENIX ping helper (the old FENIX ping helper, with VPN socket
 * protection so FENIX pings bypassed an active tunnel) was deleted with
 * the old FENIX implementation; FENIX ping is now POST /api/locations/ping
 * on the Go core. Contract differences are deliberate and documented:
 *
 * - TcpPing.connect: timeout ms total (default 3000), Long ms or -1.
 * - Old PingUtil.measureTcpLatencyMs: 1500 ms total, Int ms or null,
 *   with VPN socket protection. Same TCP-only caveat: a UDP-only server
 *   shows no ping here and must never be called "fastest" on a probe
 *   it did not answer.
 */
object TcpPing {
    /**
     * Performs a TCP ping to the specified host and port.
     *
     * @param host The hostname or IP address to ping.
     * @param port The port to connect to (default 80).
     * @param timeout Total timeout in milliseconds (default 3000ms).
     *   It bounds DNS resolution AND connect together: the old code
     *   passed [timeout] only to socket.connect, so a hung DNS lookup
     *   inside InetSocketAddress could spin forever (M11).
     * @return The latency in milliseconds, or -1 if the connection failed
     *   or the total timeout elapsed. TCP only — never a UDP ping.
     */
    suspend fun connect(host: String, port: Int = 80, timeout: Int = 3000): Long = withContext(Dispatchers.IO) {
        withTimeoutOrNull(timeout.toLong()) {
            val start = System.nanoTime()
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(host, port), timeout)
                }
                (System.nanoTime() - start) / 1_000_000L
            } catch (_: Exception) {
                -1L
            }
        } ?: -1L
    }
}
