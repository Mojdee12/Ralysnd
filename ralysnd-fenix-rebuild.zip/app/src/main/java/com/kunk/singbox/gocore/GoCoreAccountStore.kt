// New code written for the Ralysnd FENIX rebuild (Go-core integration).
// Package: com.kunk.singbox.gocore (new).
//
// PURPOSE: replace the old FENIX account registry as the account-email source for the
// Dashboard and Settings account tiles. The daemon itself persists accounts
// in its own data dir, but it only answers while running; the tiles must
// show the email even when the daemon is down. This store therefore keeps
// ONLY display data — the active account's email and id — written by
// GoCoreViewModel on every accounts refresh. It never holds tokens,
// passwords, codes, or any credential material.

package com.kunk.singbox.gocore

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class GoCoreAccountStore(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _activeEmail = MutableStateFlow(
        prefs.getString(KEY_ACTIVE_EMAIL, "").orEmpty(),
    )
    /** Active Firefox account email for the Dashboard/Settings tiles. */
    val activeEmail: StateFlow<String> = _activeEmail.asStateFlow()

    /** Persist the active account's display data (email + id only). */
    fun saveActive(email: String, accountId: String) {
        prefs.edit()
            .putString(KEY_ACTIVE_EMAIL, email)
            .putString(KEY_ACTIVE_ID, accountId)
            .apply()
        _activeEmail.value = email
    }

    /** Clear the stored display data (e.g. after the last account is removed). */
    fun clear() {
        prefs.edit()
            .remove(KEY_ACTIVE_EMAIL)
            .remove(KEY_ACTIVE_ID)
            .apply()
        _activeEmail.value = ""
    }

    fun loadActiveEmail(): String = _activeEmail.value

    companion object {
        private const val PREFS_NAME = "gocore_accounts"
        private const val KEY_ACTIVE_EMAIL = "active_email"
        private const val KEY_ACTIVE_ID = "active_id"

        @Volatile private var instance: GoCoreAccountStore? = null

        fun getInstance(context: Context): GoCoreAccountStore {
            return instance ?: synchronized(this) {
                instance ?: GoCoreAccountStore(context.applicationContext).also { instance = it }
            }
        }
    }
}
