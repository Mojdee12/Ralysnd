// New code written for the Ralysnd FENIX rebuild (Go-core integration).
// Package: com.kunk.singbox.gocore (new; the old FENIX
// package is deleted). JSON field names below follow the daemon's dashboard
// API as confirmed from the upstream service (signInView, accountView,
// locationView, LocationPing, CoreStatus shapes) — field names are factual
// API surface, not copied code. Parsing is lenient: unknown fields are
// ignored and every field has a safe default, so a daemon response that
// grows new fields cannot break the UI.
// No tokens, emails, passwords, or codes are stored in these classes;
// emails appear only as user-visible UI data, never in logs.

package com.kunk.singbox.gocore

import com.google.gson.annotations.SerializedName

/** One sign-in attempt, as polled from GET /api/signin/{id}. */
data class GoSignInView(
    @SerializedName("id") val id: String = "",
    @SerializedName("email") val email: String = "",
    // Step vocabulary: working, need_email_code, need_totp,
    // need_unblock_code, need_captcha, need_email_link, done, failed, cancelled.
    @SerializedName("step") val step: String = "",
    @SerializedName("message") val message: String = "",
    @SerializedName("error") val error: String? = null,
    @SerializedName("error_code") val errorCode: String? = null,
    @SerializedName("password_accepted") val passwordAccepted: Boolean = false,
    // CAPTCHA challenge payload (image data) when step == need_captcha.
    // Never logged, never persisted.
    @SerializedName("captcha") val captcha: String? = null,
    @SerializedName("account_id") val accountId: String? = null,
    @SerializedName("updated") val updated: String? = null,
)

/** Step types published by the daemon while a sign-in waits for input. */
object GoSignInStep {
    const val WORKING = "working"
    const val NEED_EMAIL_CODE = "need_email_code"
    const val NEED_TOTP = "need_totp"
    const val NEED_UNBLOCK_CODE = "need_unblock_code"
    const val NEED_CAPTCHA = "need_captcha"
    const val NEED_EMAIL_LINK = "need_email_link"
    const val DONE = "done"
    const val FAILED = "failed"
    const val CANCELLED = "cancelled"

    /** Steps that need a typed answer from the user (vs. waiting states). */
    val NEEDS_TYPED_ANSWER = setOf(NEED_EMAIL_CODE, NEED_TOTP, NEED_UNBLOCK_CODE, NEED_CAPTCHA)

    fun isTerminal(step: String): Boolean =
        step == DONE || step == FAILED || step == CANCELLED
}

/** Error codes published in GoSignInView.error_code. */
object GoSignInErrorCode {
    const val NO_ACCOUNT = "no_account"
    const val WRONG_PASSWORD = "wrong_password"
    const val NO_PASSWORD = "no_password"
    const val TOO_MANY_ATTEMPTS = "too_many_attempts"
    const val UNBLOCK_REJECTED = "unblock_code_rejected"
    const val WRONG_CODE = "wrong_code"
    const val WRONG_TOTP = "wrong_totp"
    const val TOO_MANY_CODES = "too_many_codes"
    const val TIMED_OUT = "timed_out"
    const val NETWORK = "network"
}

/** Guardian quota/usage for one account. */
data class GoUsage(
    @SerializedName("unlimited") val unlimited: Boolean = false,
    @SerializedName("limit_bytes") val limitBytes: Long = 0L,
    @SerializedName("remaining_bytes") val remainingBytes: Long = 0L,
    @SerializedName("reset_at") val resetAt: String? = null,
    @SerializedName("checked_at") val checkedAt: String? = null,
)

/** One Firefox account known to the daemon. */
data class GoAccount(
    @SerializedName("id") val id: String = "",
    @SerializedName("name") val name: String = "",
    // User-visible UI data; never logged.
    @SerializedName("email") val email: String = "",
    @SerializedName("position") val position: Int = 0,
    @SerializedName("enabled") val enabled: Boolean = true,
    @SerializedName("active") val active: Boolean = false,
    @SerializedName("status") val status: String = "",
    @SerializedName("reason") val reason: String = "",
    @SerializedName("reason_code") val reasonCode: String = "",
    @SerializedName("reason_detail") val reasonDetail: String = "",
    @SerializedName("retry_at") val retryAt: String? = null,
    @SerializedName("usage") val usage: GoUsage? = null,
    @SerializedName("used_percent") val usedPercent: Double = 0.0,
    @SerializedName("has_password") val hasPassword: Boolean = false,
)

/** GET /api/accounts response. */
data class GoAccountsResponse(
    @SerializedName("accounts") val accounts: List<GoAccount> = emptyList(),
    @SerializedName("switch_threshold_percent") val switchThresholdPercent: Double = 0.0,
)

/** One VPN exit location. */
data class GoLocation(
    @SerializedName("code") val code: String = "",
    @SerializedName("name") val name: String = "",
    @SerializedName("city") val city: String? = null,
    @SerializedName("server") val server: String = "",
    @SerializedName("recommended") val recommended: Boolean = false,
    // Ping in milliseconds; null/absent means unmeasured — never a fake number.
    @SerializedName("ping_ms") val pingMs: Long? = null,
    @SerializedName("ping_error") val pingError: String? = null,
)

/** GET /api/locations and POST /api/locations/ping responses. */
data class GoLocationsResponse(
    @SerializedName("locations") val locations: List<GoLocation> = emptyList(),
    @SerializedName("pinged_at") val pingedAt: String? = null,
    @SerializedName("firefox_version") val firefoxVersion: String? = null,
    @SerializedName("target") val target: String? = null,
)

/** Engine state inside GET /api/status. */
data class GoEngineState(
    @SerializedName("phase") val phase: String = "",
    @SerializedName("message") val message: String = "",
    @SerializedName("code") val code: String = "",
    @SerializedName("address") val address: String = "",
)

/** Proxy info inside GET /api/status. */
data class GoProxyInfo(
    @SerializedName("listen") val listen: String = "",
    @SerializedName("upstream") val upstream: String = "",
    @SerializedName("country_code") val countryCode: String = "",
    @SerializedName("country_name") val countryName: String = "",
    @SerializedName("city_name") val cityName: String = "",
    @SerializedName("selection_source") val selectionSource: String = "",
    @SerializedName("transport") val transport: String = "",
    @SerializedName("login_required") val loginRequired: Boolean = false,
)

/** Exit info inside GET /api/status. */
data class GoExitInfo(
    @SerializedName("ipv4") val ipv4: String = "",
    @SerializedName("ipv6") val ipv6: String = "",
    @SerializedName("country_code") val countryCode: String = "",
    @SerializedName("country_name") val countryName: String = "",
    @SerializedName("city") val city: String = "",
    @SerializedName("network") val network: String = "",
)

/** Traffic counters inside GET /api/status. */
data class GoTraffic(
    @SerializedName("up") val up: Long = 0L,
    @SerializedName("down") val down: Long = 0L,
    @SerializedName("direct_up") val directUp: Long = 0L,
    @SerializedName("direct_down") val directDown: Long = 0L,
    @SerializedName("up_rate") val upRate: Long = 0L,
    @SerializedName("down_rate") val downRate: Long = 0L,
)

/** GET /api/status response (only the fields the UI reads). */
data class GoStatus(
    @SerializedName("state") val state: GoEngineState? = null,
    @SerializedName("proxy") val proxy: GoProxyInfo? = null,
    @SerializedName("active_account") val activeAccount: GoAccount? = null,
    @SerializedName("exit") val exit: GoExitInfo? = null,
    @SerializedName("traffic") val traffic: GoTraffic? = null,
)

/** Generic daemon error body. Only the message is surfaced; bodies are never logged. */
data class GoApiErrorBody(
    @SerializedName("error") val message: String? = null,
)

/** Exception for a failed dashboard call (route + status only, never a body). */
class GoApiException(val route: String, val statusCode: Int, message: String) :
    Exception("$route failed: HTTP $statusCode ($message)")
