package com.v2ray.ang.ui.compose

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Ralysnd shared design components (visual redesign v2): one signature
 * element per screen, yellow only for primary actions and the active state,
 * neutrals dominate, spacing on the 4/8/12/16/20/24/32/40/48 scale, rows
 * 56-72dp, primary buttons 48dp, touch targets >= 48dp.
 *
 * Colors come from the app theme (bg #121212, surface #1E1E1E,
 * primary/secondary #FFD60A, onPrimary black, connected green kept) so no
 * component hardcodes a palette value.
 */

/** Small-caps dim section label above a card (e.g. "SECURITY", "NETWORK"). */
@Composable
fun RalysndSectionHeader(
    text: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = modifier.padding(start = 4.dp, bottom = 8.dp)
    )
}

/** Rounded neutral card (16dp corners) that groups one section of a screen. */
@Composable
fun RalysndCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(content = content)
    }
}

/**
 * A card with a section header, the standard container for the grouped
 * sections on Settings, the config editor, Subscriptions, Routing and About.
 * The card body pads its children 16dp with 12dp between them; rows that
 * need edge-to-edge dividers should use [RalysndCard] directly instead.
 */
@Composable
fun RalysndSectionCard(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(modifier = modifier) {
        RalysndSectionHeader(text = title)
        RalysndCard {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                content = content
            )
        }
    }
}

/** Full-width yellow primary button, 48dp high (e.g. SAVE, ADD RULE). */
@Composable
fun RalysndPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .fillMaxWidth()
            .height(48.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/**
 * Compact selectable filter chip. Yellow when selected, neutral otherwise.
 * Used for the Logs filters (40dp) and the editor protocol chips (48dp);
 * the 48dp rule applies to primary actions, chips follow the Material chip
 * size.
 */
@Composable
fun RalysndFilterChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 40.dp
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1
            )
        },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = MaterialTheme.colorScheme.primary,
            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
        ),
        modifier = modifier.height(height)
    )
}

/**
 * One routing-mode card (Global / Bypass / Custom). Selected card is yellow
 * with black text; unselected is neutral with an outline. Title + one-line
 * subtitle; the row of three shares the width equally.
 */
@Composable
fun RalysndModeCard(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        selected = selected,
        color = if (selected) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.surface,
        contentColor = if (selected) MaterialTheme.colorScheme.onPrimary
        else MaterialTheme.colorScheme.onSurface,
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .height(72.dp)
            .semantics { this.selected = selected; role = Role.RadioButton }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (subtitle.isNotEmpty()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (selected) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * Small colored level tag for a log line: INFO green, WARN yellow,
 * ERROR red, DEBUG/VERBOSE dim. The text is the parsed log level itself
 * (data, not UI copy), so it needs no string resource.
 */
@Composable
fun RalysndLevelTag(
    level: String,
    modifier: Modifier = Modifier
) {
    val (label, color) = when (level) {
        "E", "F" -> "ERROR" to MaterialTheme.colorScheme.error
        "W" -> "WARN" to MaterialTheme.colorScheme.primary
        "I" -> "INFO" to MaterialTheme.colorScheme.tertiary
        "D" -> "DEBUG" to MaterialTheme.colorScheme.onSurfaceVariant
        "V" -> "VERBOSE" to MaterialTheme.colorScheme.onSurfaceVariant
        else -> level to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(
        color = color.copy(alpha = 0.16f),
        shape = RoundedCornerShape(4.dp),
        modifier = modifier
    ) {
        Text(
            text = label,
            color = color,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
    }
}

/** Thin (4dp) yellow usage bar for subscription rows and the summary card. */
@Composable
fun RalysndUsageBar(
    progress: Float,
    modifier: Modifier = Modifier
) {
    LinearProgressIndicator(
        progress = { progress.coerceIn(0f, 1f) },
        color = MaterialTheme.colorScheme.primary,
        trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f),
        modifier = modifier
            .fillMaxWidth()
            .height(4.dp),
        drawStopIndicator = {}
    )
}

/**
 * Small removable chip for one routing-rule entry (domain, IP or app).
 * Tapping the chip opens the rule editor; the × removes just that entry.
 */
@Composable
fun RalysndRuleChip(
    label: String,
    onClick: () -> Unit,
    onRemove: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilterChip(
        selected = false,
        onClick = onClick,
        label = {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        trailingIcon = {
            IconButton(
                onClick = onRemove,
                modifier = Modifier.size(24.dp)
            ) {
                Text(
                    text = "×",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        modifier = modifier.height(40.dp)
    )
}
