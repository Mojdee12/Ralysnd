package com.kunk.singbox.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
// Note: Modifier.animateItem() needs no import here — it resolves via
// the LazyItemScope receiver inside items { }, same as ProfileNodesSection.
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Power
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.ui.draw.clip
import com.kunk.singbox.ui.theme.BentoAmber
import com.kunk.singbox.ui.theme.BentoInk
import com.kunk.singbox.ui.theme.BentoViolet
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.kunk.singbox.foxy.FoxyViewModel
import com.kunk.singbox.foxy.data.formatBytes
import com.kunk.singbox.foxy.data.model.ConnectionState as FoxyConnectionState
import com.kunk.singbox.foxy.data.model.emojiFlag
import com.kunk.singbox.model.ConnectionState
import com.kunk.singbox.ui.theme.BentoBlue
import com.kunk.singbox.ui.theme.BentoCoral
import com.kunk.singbox.ui.theme.BentoMint
import com.kunk.singbox.ui.theme.L4Amber
import com.kunk.singbox.ui.theme.L4Background
import com.kunk.singbox.ui.theme.L4CenterConnectButton
import com.kunk.singbox.ui.theme.L4CountryCard
import com.kunk.singbox.ui.theme.L4GlassCard
import com.kunk.singbox.ui.theme.L4Surface
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim
import com.kunk.singbox.ui.theme.PureWhite
import com.kunk.singbox.viewmodel.DashboardViewModel

/**
 * FENIX bottom-tab screen — v2 approved style, FoxyVPN's flow (MIT, Vauth).
 *
 * Bento mosaic layout (approved mockup): big FENIX title + RALYSND •
 * VPN subtitle, a coral Account tile (active account, email text only)
 * + mint Remaining Volume tile (aggregate volume text across all added
 * Firefox accounts — no circle, no ring, no arc, no percentage circle;
 * real Guardian data only; "Quota unavailable" when no account reports
 * one), a wide amber Countries tile with a vertical country list in a
 * white inner card (flag emoji + name + first city + ping-derived
 * quality band + ping right; tap to select; Lowest pill selects the
 * fastest measured country; Ping all measures all), a violet
 * Subscription tile + blue VLESS Clients tile (real profile
 * subscription / real VLESS config count — see the checklist notes in
 * the file), and a wide blue Connect tile at the bottom. Multi-account
 * switching/removal lives in a compact list shown only when more than
 * one account exists; the + button to add another account is retained.
 *
 * Connect is the wide blue Connect tile at the bottom — the old center
 * button and the old bottom-right floating button have been removed.
 * The tunnel itself is untouched:
 * FoxyVpnService (Netty H2 CONNECT with Bearer proxy pass to the Fastly
 * edge, local SOCKS5 proxy, hev-socks5-tunnel) using the ACTIVE
 * account's tokens. No credential is stored in source or logs.
 *
 * Footer credit (FoxyVPN MIT attribution): "FENIX engine based on
 * FoxyVPN (MIT) by Vauth".
 */
@Composable
fun FenixScreen(
    navController: NavController,
    viewModel: FoxyViewModel = viewModel(),
    dashboardViewModel: DashboardViewModel = viewModel(),
    // m4: shared bottom padding from AppNavigation (same value the
    // other top-level screens get) — replaces the hardcoded 96dp.
    bottomContentPadding: Dp = 0.dp,
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    // Auto-load countries on first open when signed in. Previously the
    // list loaded ONLY via the manual Refresh button, so a fresh install
    // (server-list cache wiped by uninstalling the previous build) showed
    // a permanently blank country panel until the button was found.
    LaunchedEffect(state.signedIn) {
        if (state.signedIn && state.countries.isEmpty() && !state.isLoading) {
            viewModel.refreshAccountAndCountries()
        }
    }
    val connectionState by dashboardViewModel.connectionState.collectAsStateWithLifecycle()
    val foxyState by viewModel.foxyState.collectAsStateWithLifecycle()
    val foxyLastError by viewModel.foxyLastError.collectAsStateWithLifecycle()
    var pendingFenixConnect by remember { mutableStateOf(false) }
    // M5: a denied VPN-permission dialog must say so — never
    // silently clear the pending connect.
    var vpnPermissionDenied by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingFenixConnect) {
            pendingFenixConnect = false
            vpnPermissionDenied = false
            viewModel.connectSelected(context, dashboardViewModel)
        } else {
            pendingFenixConnect = false
            vpnPermissionDenied = true
        }
    }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var twoFactorCode by remember { mutableStateOf("") }
    val foxyRunning = foxyState == FoxyConnectionState.CONNECTED ||
        foxyState == FoxyConnectionState.CONNECTING
    val isRunning = foxyRunning ||
        connectionState == ConnectionState.Connected ||
        connectionState == ConnectionState.Connecting
    // Read-only dashboard state for the bento tiles (subscription +
    // VLESS clients): the same flows DashboardScreen collects.
    val dashProfiles by dashboardViewModel.profiles.collectAsStateWithLifecycle()
    val dashNodes by dashboardViewModel.nodes.collectAsStateWithLifecycle()
    val dashActiveNodeId by dashboardViewModel.activeNodeId.collectAsStateWithLifecycle()
    val dashActiveProfileId by dashboardViewModel.activeProfileId.collectAsStateWithLifecycle()

    val onPowerClick: () -> Unit = {
        if (isRunning) {
            if (foxyRunning) {
                viewModel.disconnectFenix(context)
            } else {
                dashboardViewModel.toggleConnection()
            }
        } else {
            vpnPermissionDenied = false
            val prepareIntent = VpnService.prepare(context)
            if (prepareIntent != null) {
                pendingFenixConnect = true
                vpnPermissionLauncher.launch(prepareIntent)
            } else {
                viewModel.connectSelected(context, dashboardViewModel)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(L4Background),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
                .padding(bottom = bottomContentPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // BENTO REWORK header (approved mockup): big FENIX title +
            // RALYSND • VPN subtitle. The old descriptive subtitle is
            // replaced by the mockup's subtitle line.
            Text(
                text = "FENIX",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp,
                ),
                color = L4Text,
            )
            Text(
                text = "RALYSND • VPN",
                style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 1.sp),
                color = L4TextDim,
            )

            // Permission-denied note (conditional state, kept; wording
            // updated: the connect control is now the Connect tile's
            // pill, not a center button).
            if (vpnPermissionDenied) {
                Text(
                    text = "VPN permission was not granted — tap CONNECT again to retry.",
                    color = MaterialTheme.colorScheme.error,
                )
            }
            // M37: the local Foxy proxy has no authentication, so a
            // 0.0.0.0 bind must carry this warning wherever it applies.
            // (There is no dedicated bind-host picker UI in the app;
            // the bind value is read from FoxySettingsStore here.)
            if (runCatching {
                    com.kunk.singbox.foxy.data.FoxySettingsStore(context).isLanBind
                }.getOrDefault(false)
            ) {
                Text(
                    text = com.kunk.singbox.foxy.data.FoxySettingsStore.LAN_BIND_WARNING,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            // Login card: first sign-in, or adding another account.
            AnimatedVisibility(visible = !state.signedIn || state.addingAccount) {
                L4GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (state.addingAccount) "Add another Firefox account" else "Sign in with your Firefox account",
                            fontWeight = FontWeight.Bold,
                            color = L4Text,
                        )
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Firefox account email") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            // ui-ux-pro-max (Forms / Mobile Keyboards):
                            // appropriate keyboard per input type.
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        )
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        )
                        if (state.needsTwoFactor) {
                            OutlinedTextField(
                                value = twoFactorCode,
                                onValueChange = { twoFactorCode = it },
                                label = { Text("Confirmation code sent to your email") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            )
                            Button(
                                onClick = { viewModel.submitTwoFactorCode(twoFactorCode) },
                                enabled = !state.isLoading && twoFactorCode.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = BentoBlue, contentColor = PureWhite),
                            ) { Text("Verify code") }
                        } else {
                            Button(
                                onClick = { viewModel.signIn(email, password) },
                                enabled = !state.isLoading && email.isNotBlank() && password.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = BentoBlue, contentColor = PureWhite),
                            ) { Text(if (state.addingAccount) "Add account" else "Sign in") }
                        }
                        Row {
                            TextButton(
                                onClick = {
                                    context.startActivity(
                                        Intent(Intent.ACTION_VIEW, Uri.parse("https://accounts.firefox.com/signup")),
                                    )
                                },
                            ) { Text("Create a Firefox account", color = BentoBlue) }
                            if (state.addingAccount) {
                                TextButton(onClick = { viewModel.cancelAddingAccount() }) {
                                    Text("Cancel", color = L4TextDim)
                                }
                            }
                        }
                    }
                }
            }

            // Signed-in mosaic (the mockup depicts the signed-in state;
            // signed-out shows only the login card above, plus the
            // connect tile below when a tunnel is running — see below).
            if (state.signedIn) {
                // Aggregate volume text: same real Guardian sourcing as
                // before (totalQuotaRemaining / totalMaxBytes); exact
                // remaining shown whenever known, even without a max.
                val totalRemaining = state.totalQuotaRemaining
                val totalMax = state.totalMaxBytes
                val volumeTabText = when {
                    totalRemaining != null && totalMax != null ->
                        "${formatBytes(totalRemaining)} left of ${formatBytes(totalMax)}"
                    totalRemaining != null ->
                        "${formatBytes(totalRemaining)} left"
                    totalMax != null -> "of ${formatBytes(totalMax)}"
                    else -> "Quota unavailable"
                }

                // Row: coral Account tile + mint Volume tile.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    // Account tile: the ACTIVE account only (the old
                    // strip listed every account; switching lives in
                    // the multi-account list below, shown when >1).
                    val activeAccount = state.accounts.find { it.isActive }
                        ?: state.accounts.firstOrNull()
                    L4GlassCard(
                        modifier = Modifier.weight(1f),
                        tileColor = BentoCoral,
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Person,
                                contentDescription = null,
                                tint = PureWhite,
                                modifier = Modifier.size(24.dp),
                            )
                            Text(
                                text = "Account",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                ),
                                color = PureWhite,
                            )
                            Text(
                                text = "Firefox account",
                                style = MaterialTheme.typography.bodySmall,
                                color = PureWhite.copy(alpha = 0.85f),
                            )
                            Text(
                                text = activeAccount?.displayEmail?.ifBlank { "Firefox account" }
                                    ?: "Firefox account",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                ),
                                color = PureWhite,
                            )
                            val accountRemaining = activeAccount?.entitlement?.quotaRemaining
                            val accountMax = activeAccount?.entitlement?.maxBytes
                            Text(
                                text = when {
                                    accountRemaining != null ->
                                        "Quota remaining: ${formatBytes(accountRemaining)}"
                                    accountMax != null ->
                                        "Allowance: ${formatBytes(accountMax)}"
                                    else -> "Quota unavailable"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = PureWhite.copy(alpha = 0.85f),
                            )
                            Text(
                                text = "Active account",
                                style = MaterialTheme.typography.labelSmall,
                                color = PureWhite,
                            )
                            if (!foxyRunning && activeAccount != null) {
                                TextButton(onClick = { viewModel.removeAccount(activeAccount.id) }) {
                                    Text(text = "Remove", color = PureWhite)
                                }
                            }
                        }
                    }

                    // Mint Volume tile (the old full-width volume tab,
                    // restyled as the mockup's mint tile).
                    L4GlassCard(
                        modifier = Modifier.weight(1f),
                        tileColor = BentoMint,
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.BarChart,
                                contentDescription = null,
                                tint = L4Text,
                                modifier = Modifier.size(24.dp),
                            )
                            Text(
                                text = "Remaining Volume",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                ),
                                color = L4Text,
                            )
                            Text(
                                text = volumeTabText,
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                ),
                                color = L4Text,
                            )
                            if (totalRemaining != null && totalMax != null && totalMax > 0) {
                                val usedFraction =
                                    ((totalMax - totalRemaining).toFloat() / totalMax.toFloat())
                                        .coerceIn(0f, 1f)
                                LinearProgressIndicator(
                                    progress = { usedFraction },
                                    modifier = Modifier.fillMaxWidth(),
                                    color = L4Text,
                                    trackColor = PureWhite.copy(alpha = 0.6f),
                                )
                                Text(
                                    text = "${formatBytes(totalMax - totalRemaining)} used",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = L4TextDim,
                                )
                            }
                        }
                    }
                }
                // Silent-volume cause, shown plainly: when no volume is
                // known because the account sign-in itself is gone, say
                // so (refresh cannot fix that — only signing in again
                // can). No reset-date line: Guardian reports no reset
                // date, so the mockup's "Resets in 18 days" is omitted
                // rather than faked.
                state.quotaNote?.let {
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                }

                // Multi-account list: ONLY when more than one account
                // exists (tap to switch, Remove when not running) —
                // the single-account case is fully covered by the
                // coral tile above, exactly as in the mockup.
                if (state.accounts.size > 1) {
                    Text(text = "FENIX Accounts", fontWeight = FontWeight.Bold, color = L4Text)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (account in state.accounts) {
                            val accountLabel = account.displayEmail.ifBlank { "Firefox account" }
                            L4GlassCard(
                                selected = account.isActive,
                                onClick = { viewModel.switchAccount(account.id) },
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = accountLabel,
                                            fontWeight = FontWeight.SemiBold,
                                            color = L4Text,
                                        )
                                        if (account.isActive) {
                                            Text(
                                                text = "Active account",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = L4TextDim,
                                            )
                                        }
                                    }
                                    if (!foxyRunning) {
                                        TextButton(onClick = { viewModel.removeAccount(account.id) }) {
                                            Text(text = "Remove", color = BentoBlue)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Add-account button (unchanged control; the mockup has
                // no Add button, but multi-account adding has no other
                // entry point, so it is retained, not dropped).
                Button(
                    onClick = { viewModel.startAddingAccount() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BentoBlue, contentColor = PureWhite),
                ) { Text(text = "+ Add another Firefox account", fontWeight = FontWeight.Bold) }

                // Wide amber Countries tile (the old horizontal
                // carousel, restyled as the mockup's vertical list
                // inside a white inner card; same sorting by measured
                // ping, same select action; per-country volume lines
                // removed as redundant with the mint Volume tile, and
                // the "Selected: …" line removed as redundant with the
                // row highlight + the Connect tile below).
                L4GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    tileColor = BentoAmber,
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.LocationOn,
                                    contentDescription = null,
                                    tint = L4Text,
                                    modifier = Modifier.size(24.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Countries",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                    ),
                                    color = L4Text,
                                )
                            }
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                // Lowest pill: tappable -> select the
                                // fastest measured country (the old
                                // Fastest button's action, moved here).
                                val fastest = viewModel.fastestCountry()
                                val lowestPing = fastest?.let { state.pingMs[it.code] }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(999.dp))
                                        .background(PureWhite)
                                        .clickable(enabled = fastest != null) {
                                            fastest?.let { viewModel.selectCountry(it.code) }
                                        }
                                        .padding(horizontal = 10.dp, vertical = 4.dp),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Text(
                                        text = if (lowestPing != null) "Lowest ${lowestPing}ms" else "Lowest —",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                        ),
                                        color = BentoInk,
                                    )
                                }
                                TextButton(
                                    onClick = { viewModel.pingAllCountries() },
                                    enabled = !state.isPinging,
                                ) {
                                    Text(
                                        text = if (state.isPinging) "Pinging…" else "Ping all",
                                        color = BentoInk,
                                    )
                                }
                            }
                        }
                        if (state.pingMs.isEmpty()) {
                            Text(
                                text = "Fastest is disabled until Ping all measures a country.",
                                style = MaterialTheme.typography.bodySmall,
                                color = L4TextDim,
                            )
                        }
                        // M10: refresh/cache and per-account Guardian
                        // notes, shown plainly instead of silently
                        // serving stale data.
                        state.countriesNote?.let {
                            Text(text = it, style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                        }
                        if (state.guardianFailureCount > 0) {
                            Text(
                                text = "Guardian data unavailable for ${state.guardianFailureCount} account(s) — " +
                                    "their quota is absent, not zero.",
                                style = MaterialTheme.typography.bodySmall,
                                color = L4TextDim,
                            )
                        }
                        if (state.isLoading || state.isPinging || state.isConnecting) {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = BentoBlue)
                        }
                        // White inner list card with one row per
                        // country: flag + name + first city (when the
                        // server list reports one) + quality band
                        // DERIVED from the measured ping (Fast <80ms,
                        // Stable <200ms, else Moderate) + ping right.
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(PureWhite, RoundedCornerShape(16.dp))
                                .padding(8.dp),
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                val sorted = remember(state.countries, state.pingMs) {
                                    state.countries.sortedBy { country ->
                                        state.pingMs[country.code] ?: Int.MAX_VALUE
                                    }
                                }
                                if (sorted.isEmpty()) {
                                    Text(
                                        text = "No countries yet — tap Refresh below.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = L4TextDim,
                                        modifier = Modifier.padding(8.dp),
                                    )
                                } else {
                                    for (country in sorted) {
                                        val ping = state.pingMs[country.code]
                                        val isSelected = state.selected?.countryCode.equals(
                                            country.code,
                                            ignoreCase = true,
                                        )
                                        val quality = when {
                                            ping == null -> null
                                            ping < 80 -> "Fast"
                                            ping < 200 -> "Stable"
                                            else -> "Moderate"
                                        }
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .then(
                                                    if (isSelected) {
                                                        Modifier.border(
                                                            2.dp,
                                                            BentoBlue,
                                                            RoundedCornerShape(12.dp),
                                                        )
                                                    } else {
                                                        Modifier
                                                    },
                                                )
                                                .clickable { viewModel.selectCountry(country.code) }
                                                .padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Text(
                                                text = country.emojiFlag,
                                                style = MaterialTheme.typography.titleMedium,
                                            )
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = country.name,
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontWeight = FontWeight.SemiBold,
                                                    ),
                                                    color = L4Text,
                                                )
                                                val cityName = country.cities.firstOrNull()?.name
                                                val subLine = buildString {
                                                    if (cityName != null) append(cityName)
                                                    if (quality != null) {
                                                        if (cityName != null) append(" • ")
                                                        append(quality)
                                                    }
                                                }
                                                if (subLine.isNotEmpty()) {
                                                    Text(
                                                        text = subLine,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = L4TextDim,
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = when {
                                                    ping != null -> "$ping ms"
                                                    state.isPinging -> "pinging…"
                                                    else -> "—"
                                                },
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                ),
                                                color = BentoInk,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        // Refresh (retained control, tile footer).
                        TextButton(
                            onClick = { viewModel.refreshAccountAndCountries() },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(text = "Refresh accounts & countries", color = BentoInk)
                        }
                    }
                }

                // Row: violet Subscription tile + blue VLESS Clients tile.
                // The mockup's "Pro • Active / Renews / Upgrade Plan"
                // has no counterpart (no tier, no renewal date, no
                // upgrade flow) and the app has no device/client list
                // (the mockup's Pixel 8 / iPad / MacBook rows), so both
                // tiles show the closest real content: the active
                // sing-box profile's subscription, and the real VLESS
                // config count + active VLESS config (from the
                // dashboard flows this screen already reads).
                val dashActiveProfile = dashProfiles.find { it.id == dashActiveProfileId }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    L4GlassCard(
                        modifier = Modifier.weight(1f),
                        tileColor = BentoViolet,
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Star,
                                    contentDescription = null,
                                    tint = PureWhite,
                                    modifier = Modifier.size(24.dp),
                                )
                                Button(
                                    onClick = { dashboardViewModel.updateAllSubscriptions() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = PureWhite,
                                        contentColor = BentoInk,
                                    ),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                        horizontal = 12.dp,
                                        vertical = 4.dp,
                                    ),
                                ) {
                                    Text(
                                        text = "Update",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                        ),
                                    )
                                }
                            }
                            Text(
                                text = "Subscription",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                ),
                                color = PureWhite,
                            )
                            Text(
                                text = dashActiveProfile?.name ?: "No profile",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                ),
                                color = PureWhite,
                            )
                            val dashSubTotal = dashActiveProfile?.totalTraffic ?: 0L
                            if (dashSubTotal > 0) {
                                val dashSubRemaining =
                                    (dashSubTotal - (dashActiveProfile?.usedTraffic ?: 0L))
                                        .coerceAtLeast(0L)
                                Text(
                                    text = "Left: ${formatBytes(dashSubRemaining)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = PureWhite.copy(alpha = 0.85f),
                                )
                            } else {
                                Text(
                                    text = "No subscription data",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = PureWhite.copy(alpha = 0.85f),
                                )
                            }
                        }
                    }

                    val vlessNodes = remember(dashNodes) {
                        dashNodes.filter { it.protocol.lowercase().contains("vless") }
                    }
                    val vlessActive = vlessNodes.find { it.id == dashActiveNodeId }
                    L4GlassCard(
                        modifier = Modifier.weight(1f),
                        tileColor = BentoBlue,
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Link,
                                contentDescription = null,
                                tint = PureWhite,
                                modifier = Modifier.size(24.dp),
                            )
                            Text(
                                text = "VLESS Clients",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                ),
                                color = PureWhite,
                            )
                            Text(
                                text = "${vlessNodes.size} VLESS configs",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                ),
                                color = PureWhite,
                            )
                            Text(
                                text = vlessActive?.displayName ?: "No active VLESS config",
                                style = MaterialTheme.typography.bodySmall,
                                color = PureWhite.copy(alpha = 0.85f),
                            )
                        }
                    }
                }

                // Wide blue Connect tile (the old center button's
                // logic, moved into the tile: same onPowerClick,
                // same VPN-permission flow, same toggle).
                L4GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    tileColor = BentoBlue,
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(
                                            PureWhite,
                                            RoundedCornerShape(12.dp),
                                        ),
                                    contentAlignment = Alignment.Center,
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Power,
                                        contentDescription = null,
                                        tint = BentoBlue,
                                        modifier = Modifier.size(24.dp),
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = if (isRunning) "Disconnect" else "Connect",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                    ),
                                    color = PureWhite,
                                )
                            }
                            Button(
                                onClick = onPowerClick,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = PureWhite,
                                    contentColor = BentoInk,
                                ),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                    horizontal = 16.dp,
                                    vertical = 6.dp,
                                ),
                            ) {
                                Text(
                                    text = if (isRunning) "DISCONNECT" else "CONNECT",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                    ),
                                )
                            }
                        }
                        val connectLine = when (val sel = state.selected) {
                            null -> "Select a country to connect"
                            else -> buildString {
                                append("Auto — ${sel.countryName} selected")
                                state.pingMs[sel.countryCode]?.let { append(" • ${it}ms") }
                            }
                        }
                        Text(
                            text = connectLine,
                            style = MaterialTheme.typography.bodyMedium,
                            color = PureWhite,
                        )
                    }
                }
            }

            // Connect tile while signed out but a tunnel is running
            // (M21, kept): the running tunnel must be stoppable from
            // here even without a sign-in.
            if (!state.signedIn && isRunning) {
                L4GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    tileColor = BentoBlue,
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = "Disconnect",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                ),
                                color = PureWhite,
                            )
                            Button(
                                onClick = onPowerClick,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = PureWhite,
                                    contentColor = BentoInk,
                                ),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                    horizontal = 16.dp,
                                    vertical = 6.dp,
                                ),
                            ) {
                                Text(
                                    text = "DISCONNECT",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                    ),
                                )
                            }
                        }
                        Text(
                            text = "A tunnel is running — tap DISCONNECT to stop it.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = PureWhite,
                        )
                    }
                }
            }

            state.message?.let {
                Text(text = it, color = MaterialTheme.colorScheme.error)
            }
            // C6: when the Foxy service has stopped with an error (e.g.
            // bounded monitor failure), its verbatim last error is
            // visible here instead of a stale "connected" impression.
            if (foxyState == FoxyConnectionState.DISCONNECTED) {
                foxyLastError?.let {
                    Text(text = it, color = MaterialTheme.colorScheme.error)
                }
            }
            Text(
                text = "FENIX engine based on FoxyVPN (MIT) by Vauth",
                style = MaterialTheme.typography.bodySmall,
                color = L4TextDim,
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
        // No bottom-corner button: the blue Connect tile at the
        // bottom is the only connect control on this screen.
    }
}

