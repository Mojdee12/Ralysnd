package com.kunk.singbox.foxy.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class FastlyChallengeError(message: String) : Exception(message)

private const val TAG = "FastlyChallengeSolver"

private const val SOLVE_TIMEOUT_SECONDS = 60L

private const val MAX_POST_BACK_ROUNDS = 3

// Bounds how many times a solve on one host restarts from a fresh challenge page
// when Fastly re-challenges mid-solve (e.g. a 406 interstitial on a later step).
private const val MAX_SOLVE_RESTARTS = 2

// Visible to FxaAuthRepository so a retry after a solve can use the same
// User-Agent as the session that minted the clearance (fix 2). The solver's
// Chrome UA is deliberately NOT the API's MozillaVPN UA: a clearance minted
// under one UA may not be honored when the retry presents a different UA.
internal const val SOLVER_USER_AGENT =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"

/**
 * Outcome of one successful challenge solve, for diagnostics and for the
 * caller's clearance check. [host] is the exact host that was solved — never
 * a different host's clearance counted for this host.
 */
data class ChallengeSolveResult(
    val host: String,
    val cookiesInstalled: Int,
    val restarts: Int,
)

private const val POW_ALPHABET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"

private const val HTML_ACCEPT =
    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"

private val CHALLENGE_PREFIX_REGEX = Regex("/_fs-ch-[A-Za-z0-9]+")
private val INIT_CALL_REGEX = Regex("init\\((\\[[^\\]]*\\]),\\s*\"([^\"]+)\",\\s*\"([^\"]+)\"")

class FastlyChallengeSolver(private val cookieJar: SimpleCookieJar) {

    private class NoChallengePage : Exception()

    // Fastly served a fresh challenge interstitial in the middle of a solve
    // (e.g. a 406 on the script, PAT, or post-back step). The solve restarts
    // from a fresh challenge page instead of dying on that step.
    private class RestartSolve : Exception()

    // The one detector for "this body is a Fastly challenge interstitial",
    // shared by the page check and the mid-solve 406 checks.
    private fun looksLikeChallengePage(body: String): Boolean =
        body.contains("/_fs-ch-") && body.contains("Client Challenge")

    /**
     * Solves ONLY on the exact host whose request failed. There is deliberately
     * no fallback to another host: api.accounts.firefox.com serves a small
     * JSON, not a challenge page, so the old two-host loop always fell through
     * to accounts.firefox.com, solved there, and retried the API POST with a
     * foreign-host clearance that Fastly does not honor for the API host —
     * producing the literal "HTTP 406" after all 5 attempts. If [failingHost]
     * serves no challenge page, that fact is surfaced as an error instead of
     * silently retrying as if cleared.
     */
    suspend fun solveAndInstall(failingHost: String): ChallengeSolveResult = withContext(Dispatchers.IO) {
        val host = failingHost.trim().lowercase()
        val base = "https://$host"
        AppLogger.i(TAG, "solve start host=$host")
        try {
            val result = solveOnHost(base, cookieDomainFor(host))
            AppLogger.i(
                TAG,
                "solve complete host=${result.host} cookies=${result.cookiesInstalled} restarts=${result.restarts}",
            )
            result
        } catch (e: NoChallengePage) {
            AppLogger.w(TAG, "no challenge page on $host")
            throw FastlyChallengeError("no challenge served on $host; edge is hard-blocking this IP")
        } catch (e: FastlyChallengeError) {
            AppLogger.w(TAG, "solve failed host=$host: ${e.message}")
            throw e
        }
    }

    /**
     * The cookie domain a solve on [host] must install under, so the retried
     * request actually sends the clearance. The old code always installed
     * under "firefox.com", which SimpleCookieJar never sends to vpn.mozilla.org
     * — Guardian's 406 loop therefore solved the wrong hosts by construction.
     */
    private fun cookieDomainFor(host: String): String = when {
        host == "firefox.com" || host.endsWith(".firefox.com") -> "firefox.com"
        host == "mozilla.org" || host.endsWith(".mozilla.org") -> "mozilla.org"
        else -> host
    }

    private fun baseOrigin(prefixUrl: String): String {
        val idx = prefixUrl.indexOf("/_fs-ch-")
        return if (idx > 0) prefixUrl.substring(0, idx) else prefixUrl
    }

    private fun solvePow(base: String, targetHex: String): String? {
        val target = try {
            targetHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        } catch (e: Exception) {
            return null
        }
        if (target.size != 32) return null
        val digest = MessageDigest.getInstance("SHA-256")
        for (a in POW_ALPHABET) {
            for (b in POW_ALPHABET) {
                val suffix = "$a$b"
                val hash = digest.digest((base + suffix).toByteArray(Charsets.UTF_8))
                if (hash.contentEquals(target)) return suffix
            }
        }
        return null
    }

    private fun fetchText(
        client: OkHttpClient,
        url: String,
        accept: String = HTML_ACCEPT,
    ): String {
        val request = Request.Builder().url(url)
            .header("User-Agent", SOLVER_USER_AGENT)
            .header("Accept", accept)
            .build()
        client.newCall(request).execute().use { response ->
            // A Fastly challenge interstitial can itself be served with HTTP 406 for
            // flagged exit IPs. Let a 406 body through so the caller can check whether
            // it is a challenge page; any other non-2xx still throws as before.
            if (!response.isSuccessful && response.code != 406) throw FastlyChallengeError("GET $url returned HTTP ${response.code}")
            return response.body?.string().orEmpty()
        }
    }

    private fun fetchChallengePage(client: OkHttpClient, pageUrl: String): Pair<String, Boolean> {
        val body = fetchText(client, pageUrl)
        return body to looksLikeChallengePage(body)
    }

    private fun parseChallengeInit(script: String): Pair<JSONArray, String> {
        val matches = INIT_CALL_REGEX.findAll(script).toList()
        if (matches.isEmpty()) throw FastlyChallengeError("challenge init() call not found in script")
        val last = matches.last()
        val challenges = try {
            JSONArray(last.groupValues[1])
        } catch (e: Exception) {
            throw FastlyChallengeError("could not parse challenge list: ${e.message}")
        }
        if (challenges.length() == 0) throw FastlyChallengeError("empty challenge list")
        return challenges to last.groupValues[2]
    }

    private fun fetchPat(client: OkHttpClient, prefixUrl: String, token: String): String {
        val patUrl = "$prefixUrl/pat?token=${URLEncoder.encode(token, "UTF-8")}"
        val request = Request.Builder()
            .url(patUrl)
            .header("Accept", "text/plain")
            .header("Content-Type", "application/json")
            .header("User-Agent", SOLVER_USER_AGENT)
            .header("Origin", baseOrigin(prefixUrl))
            .post(ByteArray(0).toRequestBody(null))
            .build()
        client.newCall(request).execute().use { response ->
            if (response.code == 400 || response.code == 401) return ""
            if (response.code == 406) {
                // Fastly re-challenged mid-solve: restart from a fresh challenge page.
                // A 406 that is not a challenge page is a hard block: clear error, never silent.
                val bodyText = response.body?.string().orEmpty()
                if (looksLikeChallengePage(bodyText)) throw RestartSolve()
                throw FastlyChallengeError("PAT endpoint rejected the request; the exit IP appears blocked by Fastly")
            }
            if (!response.isSuccessful) throw FastlyChallengeError("PAT request returned HTTP ${response.code}")
            val json = try {
                JSONObject(response.body?.string().orEmpty())
            } catch (e: Exception) {
                throw FastlyChallengeError("could not parse PAT response: ${e.message}")
            }
            val auth = json.optString("auth", "")
            if (auth.isEmpty()) throw FastlyChallengeError("empty PAT auth token")
            return auth
        }
    }

    private fun clientMetricsAnswer(): JSONObject = JSONObject().apply {
        put("ty", "clientmetrics")
        put("webdriver", false)
        put(
            "bot_detection_result",
            JSONObject().apply {
                put("bot_detected", false)
                put("bot_kind", JSONObject.NULL)
            },
        )
        put(
            "browser_metrics",
            JSONObject().apply {
                put("client_data", "{}")
                put("error_trace", JSONObject.NULL)
            },
        )
        put("detector_results", JSONObject())
        put("v", 2)
    }

    private fun answerChallenge(client: OkHttpClient, prefixUrl: String, token: String, challenge: JSONObject): JSONObject {
        val data = challenge.optJSONObject("data") ?: JSONObject()
        return when (val type = challenge.optString("ty")) {
            "pow" -> {
                val base = data.optString("base", "")
                val answer = solvePow(base, data.optString("hash", ""))
                    ?: throw FastlyChallengeError("no proof-of-work solution found for base $base")
                JSONObject().apply {
                    put("ty", "pow")
                    put("base", base)
                    put("answer", answer)
                    put("hmac", data.optString("hmac", ""))
                    put("expires", data.optString("expires", ""))
                }
            }
            "pat" -> JSONObject().apply {
                put("ty", "pat")
                put("auth", fetchPat(client, prefixUrl, token))
            }
            "clientmetrics" -> clientMetricsAnswer()
            else -> throw FastlyChallengeError("unsupported Fastly challenge type '$type' (captcha cannot be solved automatically)")
        }
    }

    /**
     * Installs the solver session's cookies under [cookieDomain] and returns
     * how many were installed. Installing under the solve host's own domain
     * is what makes the retried request carry the clearance at all.
     */
    private fun installChallengeCookies(solverJar: SimpleCookieJar, cookieDomain: String): Int {
        val cookies = solverJar.snapshotAll()
        if (cookies.isEmpty()) throw FastlyChallengeError("challenge completed but no cookies were issued")
        for (cookie in cookies) {
            cookieJar.set(cookie.name, cookie.value, cookieDomain)
        }
        return cookies.size
    }

    private fun solveOnHost(base: String, cookieDomain: String): ChallengeSolveResult {
        var restarts = 0
        while (true) {
            try {
                val cookiesInstalled = solveOnHostOnce(base, cookieDomain)
                return ChallengeSolveResult(
                    host = base.removePrefix("https://"),
                    cookiesInstalled = cookiesInstalled,
                    restarts = restarts,
                )
            } catch (e: RestartSolve) {
                if (++restarts > MAX_SOLVE_RESTARTS) {
                    throw FastlyChallengeError("Fastly kept re-challenging this exit IP; the challenge could not complete")
                }
            }
        }
    }

    private fun solveOnHostOnce(base: String, cookieDomain: String): Int {
        val solverJar = SimpleCookieJar()
        val solver = ControlPlaneHttp.client.newBuilder()
            .cookieJar(solverJar)
            .connectTimeout(SOLVE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .readTimeout(SOLVE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .build()

        val pageUrl = "$base/"
        val (page, isChallenge) = fetchChallengePage(solver, pageUrl)
        if (!isChallenge) throw NoChallengePage()

        val prefixMatch = CHALLENGE_PREFIX_REGEX.find(page)
            ?: throw FastlyChallengeError("challenge asset prefix not found on $base")
        val prefixUrl = base + prefixMatch.value

        val script = fetchText(solver, "$prefixUrl/script.js?reload=true")
        // A 406 interstitial served for the script asset (fetchText already passes
        // 406 bodies through) fails parsing; if the body is a challenge page, the
        // solve restarts from a fresh challenge page instead of dying here.
        var (challenges, token) = try {
            parseChallengeInit(script)
        } catch (e: FastlyChallengeError) {
            if (looksLikeChallengePage(script)) throw RestartSolve()
            throw e
        }

        repeat(MAX_POST_BACK_ROUNDS) {
            val answers = JSONArray()
            for (i in 0 until challenges.length()) {
                answers.put(answerChallenge(solver, prefixUrl, token, challenges.getJSONObject(i)))
            }
            val postBody = JSONObject().apply {
                put("token", token)
                put("data", answers)
            }.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$prefixUrl/fst-post-back")
                .header("Content-Type", "application/json")
                .header("Accept", "application/json")
                .header("User-Agent", SOLVER_USER_AGENT)
                .header("Origin", baseOrigin(prefixUrl))
                .post(postBody)
                .build()
            solver.newCall(request).execute().use { response ->
                if (response.code == 406) {
                    // Fastly re-challenged mid-solve: restart from a fresh challenge page.
                    // A 406 that is not a challenge page is a hard block: clear error, never silent.
                    val bodyText = response.body?.string().orEmpty()
                    if (looksLikeChallengePage(bodyText)) throw RestartSolve()
                    throw FastlyChallengeError("challenge post-back was rejected; the exit IP appears blocked by Fastly")
                }
                if (!response.isSuccessful) throw FastlyChallengeError("challenge post-back returned HTTP ${response.code}")
                val body = JSONObject(response.body?.string().orEmpty())
                if (body.optString("status") == "success") {
                    val (_, stillChallenged) = fetchChallengePage(solver, pageUrl)
                    if (stillChallenged) throw FastlyChallengeError("challenge cookie not accepted on this exit IP")
                    return installChallengeCookies(solverJar, cookieDomain)
                }
                val nextChallenges = body.optJSONArray("ch")
                val nextToken = body.optString("tok", "")
                if (nextChallenges == null || nextChallenges.length() == 0 || nextToken.isEmpty()) {
                    throw FastlyChallengeError("unexpected post-back response: $body")
                }
                challenges = nextChallenges
                token = nextToken
            }
        }
        throw FastlyChallengeError("Fastly challenge did not complete within $MAX_POST_BACK_ROUNDS rounds")
    }
}
