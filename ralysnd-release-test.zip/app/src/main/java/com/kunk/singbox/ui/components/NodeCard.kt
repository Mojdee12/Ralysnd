package com.kunk.singbox.ui.components

import com.kunk.singbox.R
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.kunk.singbox.ui.theme.*
import com.kunk.singbox.ui.theme.L4Amber

private val NodeSelectedPulseBlue = BentoBlue
private val NodeDetourPulsePurple = L4Amber

@Composable
private fun Modifier.nodeOverflowMenuPanel(): Modifier {
    val shape = RoundedCornerShape(12.dp)
    return if (isLiquidGlassTheme()) {
        width(100.dp) // 交给 LiquidGlassDropdownMenu 去绘制玻璃面板，这里只控制宽度
    } else {
        background(MaterialTheme.colorScheme.surfaceVariant, shape)
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline,
                shape = shape
            )
            .width(100.dp)
    }
}

@Suppress("LongParameterList", "LongMethod", "CognitiveComplexMethod", "CyclomaticComplexMethod")
/**
 * Flag emoji derived from a node name's real country word, if the
 * name contains one. Returns null when no recognizable country is
 * present — never a guessed flag — and when the name already
 * carries an emoji flag. Short codes (uk/usa/uae) match on word
 * boundaries only, so they cannot false-positive inside other words.
 */
fun flagEmojiForNodeName(name: String): String? {
    if ('\uD83C' in name) return null
    val lower = name.lowercase()
    for ((matchers, flag) in COUNTRY_FLAG_MATCHERS) {
        for (matcher in matchers) {
            // Short keys match on word boundaries only (precompiled
            // once below — was: a fresh Regex per key, per name, per
            // composition); longer keys are plain substring matches.
            val matched = matcher.regex?.containsMatchIn(lower)
                ?: (matcher.key in lower)
            if (matched) return flag
        }
    }
    return null
}

// Short-key word-boundary regexes, precompiled once from
// COUNTRY_FLAG_KEYS (same patterns, same first-match order).
private data class FlagMatcher(val key: String, val regex: Regex?)

private val COUNTRY_FLAG_MATCHERS: List<Pair<List<FlagMatcher>, String>> by lazy {
    COUNTRY_FLAG_KEYS.map { (keys, flag) ->
        keys.map { key ->
            FlagMatcher(key, if (key.length <= 3) Regex("\\b$key\\b") else null)
        } to flag
    }
}

private val COUNTRY_FLAG_KEYS: List<Pair<List<String>, String>> = listOf(
    listOf("united kingdom", "britain", "england", "uk") to "\uD83C\uDDEC\uD83C\uDDE7",
    listOf("united states", "america", "usa") to "\uD83C\uDDFA\uD83C\uDDF8",
    listOf("netherlands", "holland", "dutch") to "\uD83C\uDDF3\uD83C\uDDF1",
    listOf("switzerland", "swiss") to "\uD83C\uDDE8\uD83C\uDDED",
    listOf("germany", "deutschland") to "\uD83C\uDDE9\uD83C\uDDEA",
    listOf("france", "french") to "\uD83C\uDDEB\uD83C\uDDF7",
    listOf("canada") to "\uD83C\uDDE8\uD83C\uDDE6",
    listOf("turkey", "türkiye", "turkiye") to "\uD83C\uDDF9\uD83C\uDDF7",
    listOf("sweden", "swedish") to "\uD83C\uDDF8\uD83C\uDDEA",
    listOf("japan", "japanese") to "\uD83C\uDDEF\uD83C\uDDF5",
    listOf("singapore") to "\uD83C\uDDF8\uD83C\uDDEC",
    listOf("iran", "persia") to "\uD83C\uDDEE\uD83C\uDDF7",
    listOf("russia", "russian") to "\uD83C\uDDF7\uD83C\uDDFA",
    listOf("ukraine", "ukrainian") to "\uD83C\uDDFA\uD83C\uDDE6",
    listOf("poland", "polish") to "\uD83C\uDDF5\uD83C\uDDF1",
    listOf("spain", "spanish") to "\uD83C\uDDEA\uD83C\uDDF8",
    listOf("italy", "italian") to "\uD83C\uDDEE\uD83C\uDDF9",
    listOf("finland", "finnish") to "\uD83C\uDDEB\uD83C\uDDEE",
    listOf("norway", "norwegian") to "\uD83C\uDDF3\uD83C\uDDF4",
    listOf("denmark", "danish") to "\uD83C\uDDE9\uD83C\uDDF0",
    listOf("austria", "austrian") to "\uD83C\uDDE6\uD83C\uDDF9",
    listOf("belgium", "belgian") to "\uD83C\uDDE7\uD83C\uDDEA",
    listOf("ireland", "irish") to "\uD83C\uDDEE\uD83C\uDDEA",
    listOf("portugal", "portuguese") to "\uD83C\uDDF5\uD83C\uDDF9",
    listOf("greece", "greek") to "\uD83C\uDDEC\uD83C\uDDF7",
    listOf("romania", "romanian") to "\uD83C\uDDF7\uD83C\uDDF4",
    listOf("czech", "czechia") to "\uD83C\uDDE8\uD83C\uDDFF",
    listOf("hungary", "hungarian") to "\uD83C\uDDED\uD83C\uDDFA",
    listOf("australia", "australian") to "\uD83C\uDDE6\uD83C\uDDFA",
    listOf("brazil", "brazilian") to "\uD83C\uDDE7\uD83C\uDDF7",
    listOf("india", "indian") to "\uD83C\uDDEE\uD83C\uDDF3",
    listOf("korea", "korean") to "\uD83C\uDDF0\uD83C\uDDF7",
    listOf("hong kong", "hongkong") to "\uD83C\uDDED\uD83C\uDDF0",
    listOf("taiwan") to "\uD83C\uDDF9\uD83C\uDDFC",
    listOf("emirates", "uae") to "\uD83C\uDDE6\uD83C\uDDEA",
    listOf("israel", "israeli") to "\uD83C\uDDEE\uD83C\uDDF1",
    listOf("egypt", "egyptian") to "\uD83C\uDDEA\uD83C\uDDEC",
    listOf("mexico", "mexican") to "\uD83C\uDDF2\uD83C\uDDFD",
    listOf("argentina", "argentine") to "\uD83C\uDDE6\uD83C\uDDF7",
    listOf("chile", "chilean") to "\uD83C\uDDE8\uD83C\uDDF1",
    listOf("colombia", "colombian") to "\uD83C\uDDE8\uD83C\uDDF4",
    listOf("peru", "peruvian") to "\uD83C\uDDF5\uD83C\uDDEA",
    listOf("latvia", "latvian") to "\uD83C\uDDF1\uD83C\uDDFB",
    listOf("lithuania", "lithuanian") to "\uD83C\uDDF1\uD83C\uDDF9",
    listOf("estonia", "estonian") to "\uD83C\uDDEA\uD83C\uDDEA",
    listOf("iceland") to "\uD83C\uDDEE\uD83C\uDDF8",
    listOf("croatia") to "\uD83C\uDDED\uD83C\uDDF7",
    listOf("serbia") to "\uD83C\uDDF7\uD83C\uDDF8",
    listOf("bulgaria") to "\uD83C\uDDE7\uD83C\uDDEC",
    listOf("slovakia") to "\uD83C\uDDF8\uD83C\uDDF0",
    listOf("slovenia") to "\uD83C\uDDF8\uD83C\uDDEE",
    listOf("moldova") to "\uD83C\uDDF2\uD83C\uDDE9",
    listOf("georgia") to "\uD83C\uDDEC\uD83C\uDDEA",
    listOf("armenia") to "\uD83C\uDDE6\uD83C\uDDF2",
    listOf("azerbaijan") to "\uD83C\uDDE6\uD83C\uDDFF",
    listOf("kazakhstan") to "\uD83C\uDDF0\uD83C\uDDFF",
    listOf("vietnam") to "\uD83C\uDDFB\uD83C\uDDF3",
    listOf("thailand") to "\uD83C\uDDF9\uD83C\uDDED",
    listOf("malaysia") to "\uD83C\uDDF2\uD83C\uDDFE",
    listOf("indonesia") to "\uD83C\uDDEE\uD83C\uDDE9",
    listOf("philippines") to "\uD83C\uDDF5\uD83C\uDDED",
    listOf("new zealand") to "\uD83C\uDDF3\uD83C\uDDFF",
    listOf("south africa") to "\uD83C\uDDFF\uD83C\uDDE6",
    listOf("nigeria") to "\uD83C\uDDF3\uD83C\uDDEC",
    listOf("kenya") to "\uD83C\uDDF0\uD83C\uDDEA",
    listOf("morocco") to "\uD83C\uDDF2\uD83C\uDDE6",
    listOf("algeria") to "\uD83C\uDDE9\uD83C\uDDFF",
    listOf("tunisia") to "\uD83C\uDDF9\uD83C\uDDF3",
)

@Composable
fun NodeCard(
    name: String,
    flag: String? = null,
    type: String,
    latency: Long? = null,
    isSelected: Boolean,
    hasDetour: Boolean = false,
    isSwitching: Boolean = false,
    isTesting: Boolean = false,
    trafficUsed: Long = 0,
    // CENTER-CONNECT (approved mockups): remaining volume for this
    // config's subscription, rendered BELOW the row. Null = the profile
    // reports no total traffic, so no volume line is shown at all —
    // never a fake number. Caller computes it from
    // (totalTraffic - usedTraffic) of the config's profile.
    volumeRemaining: Long? = null,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onExport: () -> Unit,
    onLatency: () -> Unit,
    onDelete: () -> Unit,
    showLatency: Boolean = true,
    showActions: Boolean = true,
    // BENTO: tile fill for the mockup's colored node rows. Default
    // keeps the old white card. When contentColor is set, all card
    // text uses it (the mockup's violet row has white text, the other
    // rows dark text); latency threshold colors are then replaced by
    // the content color so text stays readable on the fill.
    tileColor: Color = L4Surface,
    contentColor: Color? = null,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }
    val listInteractionSource = remember { MutableInteractionSource() }

    fun formatTraffic(bytes: Long): String {
        if (bytes <= 0) return ""
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var unitIndex = 0
        while (value >= 1024 && unitIndex < units.size - 1) {
            value /= 1024
            unitIndex++
        }
        return String.format(java.util.Locale.US, "%.1f %s", value, units[unitIndex])
    }

    // RALYSND MOCKUP 2026: dark glass server card, 16dp corners, emerald
    // border when selected. Name/type/latency/traffic are the caller's
    // real values; nothing here is sample data.
    val shape = RoundedCornerShape(24.dp)
    val useLiquidGlass = isLiquidGlassTheme()
    val borderColor = if (isSelected) BentoBlue else L4Outline
    val borderWidth = 1.dp
    val cardModifier = if (useLiquidGlass) {
        modifier
            .fillMaxWidth()
            .liquidGlassPanel(shape = shape, selected = isSelected, shadowElevation = 0.dp)
    } else {
        modifier
            .fillMaxWidth()
            .background(tileColor, shape)
            .border(borderWidth, borderColor, shape)
    }
    // BENTO: on a colored tile, text follows the tile's content color.
    val nameColor = contentColor ?: MaterialTheme.colorScheme.onSurface
    val subColor = contentColor?.copy(alpha = 0.85f)
        ?: MaterialTheme.colorScheme.onSurfaceVariant
    val menuTint = contentColor ?: MaterialTheme.colorScheme.onSurfaceVariant
    Box(
        modifier = cardModifier
            .semantics { selected = isSelected }
            .liquidGlassPressFeedback(
                interactionSource = listInteractionSource,
                label = "liquid_glass_node_card_scale",
                onClick = onClick
            )
            .padding(16.dp)
    ) {
        // CENTER-CONNECT: volume line sits BELOW the main row, so the
        // card content is a Column: main row first, volume below it.
        Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                SelectedPulseIndicator(
                    selected = isSelected,
                    hasDetour = hasDetour,
                    animationLabel = "node_list_selected",
                    isSwitching = isSwitching
                )

                Spacer(modifier = Modifier.width(16.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (flag != null) {
                            Text(
                                text = flag,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                        }
                        Text(
                            text = name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = nameColor,
                            maxLines = 1,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = type,
                            style = MaterialTheme.typography.labelSmall,
                            color = subColor
                        )

                        Spacer(modifier = Modifier.width(if (showLatency) 8.dp else 0.dp))

                        if (isTesting && showLatency) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(12.dp),
                                color = liquidGlassProgressColor(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                                ),
                                strokeWidth = 2.dp,
                                trackColor = liquidGlassProgressTrackColor(Color.Transparent)
                            )
                        } else {
                            val placeholderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            val latencyColor = remember(latency, contentColor, placeholderColor) {
                                if (contentColor != null) {
                                    contentColor
                                } else {
                                    when {
                                        latency == null -> placeholderColor
                                        latency < 0 -> Color.Red
                                        // M27: darkened to >= 4.5:1 on white cards
                                        // (old teal/green/orange were 2.2-2.8:1).
                                        latency <= 100 -> Color(0xFF0F766E) // Teal: <=100ms
                                        latency <= 200 -> Color(0xFF15803D) // Green: <=200ms
                                        latency <= 500 -> Color(0xFFC2410C) // Orange: <=500ms
                                        else -> Color.Red // Red: >500ms
                                    }
                                }
                            }
                            val timeoutText = stringResource(R.string.common_timeout)
                            val ipv6OnlyText = stringResource(R.string.common_ipv6_only)
                            val latencyText = remember(showLatency, latency, timeoutText, ipv6OnlyText) {
                                when {
                                    !showLatency -> ""
                                    latency == null -> "---"
                                    latency == com.kunk.singbox.model.PingResultCode.IPV6_ONLY -> ipv6OnlyText
                                    latency < 0 -> timeoutText
                                    else -> "${latency}ms"
                                }
                            }
                            val latencyWeight = if (latency == null) FontWeight.Normal else FontWeight.Bold

                            Text(
                                text = latencyText,
                                style = MaterialTheme.typography.labelSmall,
                                color = latencyColor,
                                fontWeight = latencyWeight
                            )
                        }
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = if (trafficUsed > 0 || showActions) Modifier.padding(start = 8.dp) else Modifier
            ) {
                if (trafficUsed > 0) {
                    Box(
                        modifier = Modifier
                            .background(
                                contentColor?.copy(alpha = 0.2f) ?: L4SurfaceAlt,
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = formatTraffic(trafficUsed),
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Medium,
                            color = contentColor ?: L4Amber
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                }

                Box(
                    modifier = Modifier
                        .wrapContentSize(Alignment.TopStart)
                        .then(if (showActions) Modifier else Modifier.size(0.dp))
                ) {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier
                            .size(32.dp)
                            .liquidGlassIconButtonPanel(shadowElevation = 3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.MoreVert,
                            contentDescription = "More",
                            tint = menuTint,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    MaterialTheme(
                        shapes = MaterialTheme.shapes.copy(extraSmall = RoundedCornerShape(12.dp))
                    ) {
                        LiquidGlassDropdownMenu(
                            expanded = showActions && showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.nodeOverflowMenuPanel()
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Box(
                                        modifier = Modifier.fillMaxWidth(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            stringResource(R.string.common_edit),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    showMenu = false
                                    onEdit()
                                },
                                colors = liquidGlassDropdownMenuItemColors()
                            )
                            DropdownMenuItem(
                                text = {
                                    Box(
                                        modifier = Modifier.fillMaxWidth(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            stringResource(R.string.common_export),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    showMenu = false
                                    onExport()
                                },
                                colors = liquidGlassDropdownMenuItemColors()
                            )
                            DropdownMenuItem(
                                text = {
                                    Box(
                                        modifier = Modifier.fillMaxWidth(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            stringResource(R.string.common_latency),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    showMenu = false
                                    onLatency()
                                },
                                colors = liquidGlassDropdownMenuItemColors()
                            )
                            DropdownMenuItem(
                                text = {
                                    Box(
                                        modifier = Modifier.fillMaxWidth(),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            stringResource(R.string.common_delete),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                },
                                onClick = {
                                    showMenu = false
                                    onDelete()
                                },
                                colors = liquidGlassDropdownMenuItemColors()
                            )
                        }
                    }
                }
            }
        }
        // Volume BELOW the row, only when the profile reports a total.
        if (volumeRemaining != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Remaining: ${formatTraffic(volumeRemaining)}",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = contentColor ?: L4Amber
            )
        }
        } // end Column wrapping the main row + volume line
    }
}

@Composable
private fun BreathingDot(animationLabel: String, color: Color) {
    val infiniteTransition = rememberInfiniteTransition(label = "${animationLabel}_pulse")
    val pulseProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "${animationLabel}_pulse_progress"
    )

    Box(
        modifier = Modifier.size(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .graphicsLayer {
                    val pulseScale = 0.75f + (pulseProgress * 0.5f)
                    scaleX = pulseScale
                    scaleY = pulseScale
                    alpha = 0.36f - (pulseProgress * 0.18f)
                }
                .background(color, CircleShape)
        )
        Box(
            modifier = Modifier
                .size(7.dp)
                .background(color, CircleShape)
        )
    }
}

@Composable
internal fun SelectedPulseIndicator(
    selected: Boolean,
    animationLabel: String,
    hasDetour: Boolean = false,
    isSwitching: Boolean = false,
    slotSize: Dp = 24.dp
) {
    val indicatorColor = if (hasDetour) NodeDetourPulsePurple else NodeSelectedPulseBlue
    Box(
        modifier = Modifier.size(slotSize),
        contentAlignment = Alignment.Center
    ) {
        if (isSwitching) {
            CircularProgressIndicator(
                modifier = Modifier.size(slotSize.coerceAtMost(16.dp)),
                color = NodeSelectedPulseBlue,
                strokeWidth = 2.dp
            )
        } else {
            AnimatedVisibility(
                visible = selected,
                enter = fadeIn(
                    animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing)
                ) + scaleIn(
                    initialScale = 0.55f,
                    animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing)
                ),
                exit = fadeOut(
                    animationSpec = tween(durationMillis = 160, easing = FastOutSlowInEasing)
                ) + scaleOut(
                    targetScale = 0.55f,
                    animationSpec = tween(durationMillis = 180, easing = FastOutSlowInEasing)
                )
            ) {
                BreathingDot(animationLabel = animationLabel, color = indicatorColor)
            }
        }
    }
}

@Suppress("LongParameterList", "LongMethod", "CognitiveComplexMethod")
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NodeGridCard(
    name: String,
    type: String,
    latency: Long? = null,
    isSelected: Boolean,
    hasDetour: Boolean = false,
    isSwitching: Boolean = false,
    isTesting: Boolean = false,
    onClick: () -> Unit,
    onEdit: () -> Unit,
    onExport: () -> Unit,
    onLatency: () -> Unit,
    onDelete: () -> Unit,
    showLatency: Boolean = true,
    showActions: Boolean = true,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }
    val gridInteractionSource = remember { MutableInteractionSource() }

    val shape = RoundedCornerShape(24.dp)
    val useLiquidGlass = isLiquidGlassTheme()
    val borderColor = if (isSelected) {
        BentoBlue
    } else {
        L4Outline
    }
    val borderWidth = 1.dp
    val cardModifier = if (useLiquidGlass) {
        modifier
            .fillMaxWidth()
            .height(84.dp)
            .liquidGlassPanel(
                shape = shape,
                selected = isSelected,
                shadowElevation = 0.dp
            )
    } else {
        modifier
            .fillMaxWidth()
            .height(84.dp)
            .background(L4Surface, shape)
            .border(borderWidth, borderColor, shape)
    }
    Box(
        modifier = cardModifier
            .semantics { selected = isSelected }
            .liquidGlassPressFeedback(
                interactionSource = gridInteractionSource,
                label = "liquid_glass_node_grid_card_scale",
                onLongClick = if (showActions) ({ showMenu = true }) else null,
                onClick = onClick
            )
            .padding(10.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // 名称与选中指示器独立占位，双列和三列下都不会互相覆盖。
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                SelectedPulseIndicator(
                    selected = isSelected,
                    animationLabel = "node_grid_selected",
                    hasDetour = hasDetour,
                    isSwitching = isSwitching,
                    slotSize = 16.dp
                )
            }

            // Protocol & Latency
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Protocol
                Text(
                    text = type,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Spacer(modifier = Modifier.width(if (showLatency) 4.dp else 0.dp))

                // Latency / Testing
                if (isTesting && showLatency) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(10.dp),
                        color = liquidGlassProgressColor(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                        ),
                        strokeWidth = 1.5.dp,
                        trackColor = liquidGlassProgressTrackColor(Color.Transparent)
                    )
                } else {
                    val placeholderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                    val latencyColor = remember(latency, placeholderColor) {
                        when {
                            latency == null -> placeholderColor
                            latency < 0 -> Color.Red
                            latency <= 100 -> Color(0xFF0F766E)
                            latency <= 200 -> Color(0xFF15803D)
                            latency <= 500 -> Color(0xFFC2410C)
                            else -> Color.Red
                        }
                    }
                    val timeoutText = stringResource(R.string.common_timeout)
                    val ipv6OnlyText = stringResource(R.string.common_ipv6_only)
                    val latencyText = remember(showLatency, latency, timeoutText, ipv6OnlyText) {
                        when {
                            !showLatency -> ""
                            latency == null -> "---"
                            latency == com.kunk.singbox.model.PingResultCode.IPV6_ONLY -> ipv6OnlyText
                            latency < 0 -> timeoutText
                            else -> "${latency}ms"
                        }
                    }
                    Text(
                        text = latencyText,
                        style = MaterialTheme.typography.labelSmall,
                        color = latencyColor,
                        fontWeight = if (latency == null) FontWeight.Normal else FontWeight.Bold,
                        maxLines = 1
                    )
                }
            }
        }

        if (showActions && showMenu) {
            MaterialTheme(
                shapes = MaterialTheme.shapes.copy(extraSmall = RoundedCornerShape(12.dp))
            ) {
                LiquidGlassDropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier.nodeOverflowMenuPanel()
                ) {
                    DropdownMenuItem(
                        text = {
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    stringResource(R.string.common_edit),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        onClick = {
                            showMenu = false
                            onEdit()
                        },
                        colors = liquidGlassDropdownMenuItemColors()
                    )
                    DropdownMenuItem(
                        text = {
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    stringResource(R.string.common_export),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        onClick = {
                            showMenu = false
                            onExport()
                        },
                        colors = liquidGlassDropdownMenuItemColors()
                    )
                    DropdownMenuItem(
                        text = {
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    stringResource(R.string.common_latency),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        onClick = {
                            showMenu = false
                            onLatency()
                        },
                        colors = liquidGlassDropdownMenuItemColors()
                    )
                    DropdownMenuItem(
                        text = {
                            Box(
                                modifier = Modifier.fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    stringResource(R.string.common_delete),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        onClick = {
                            showMenu = false
                            onDelete()
                        },
                        colors = liquidGlassDropdownMenuItemColors()
                    )
                }
            }
        }
    }
}
