package com.ralysnd.tv

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.data.ChannelRepository
import com.ralysnd.tv.data.SettingsStore
import com.ralysnd.tv.data.UserDataStore
import com.ralysnd.tv.ui.channels.ChannelsScreen
import com.ralysnd.tv.ui.favorites.FavoritesScreen
import com.ralysnd.tv.ui.home.HomeScreen
import com.ralysnd.tv.ui.player.PlayerScreen
import com.ralysnd.tv.ui.settings.SettingsScreen
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Navigation destinations. One activity, five screens, D-pad throughout. */
sealed interface Screen {
    data object Home : Screen
    data object Channels : Screen
    data object Favorites : Screen
    data class Player(val channelId: String) : Screen
    data object Settings : Screen
}

@Composable
fun RalysndTvApp() {
    val context = LocalContext.current
    // The bundled list is ~415 KB / 1,097 channels: parsed off the main
    // thread so startup does not block on it (N2).
    val repository by produceState<ChannelRepository?>(initialValue = null) {
        value = withContext(Dispatchers.IO) {
            runCatching { ChannelRepository.load(context) }
                .getOrElse { ChannelRepository(emptyList()) }
        }
    }
    val settings = remember { SettingsStore(context) }
    val userData = remember { UserDataStore(context) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

    // Back from anywhere returns to Home; back from Home exits (default).
    BackHandler(enabled = screen != Screen.Home) {
        screen = Screen.Home
    }

    val repo = repository
    if (repo == null) {
        // Still loading the channel list.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(RalysndTvColors.Background),
            contentAlignment = Alignment.Center,
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = RalysndTvColors.GreenPrimary)
                Spacer(Modifier.height(16.dp))
                Text(
                    text = "Loading channels…",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontFamily = RalysndFontFamily,
                )
            }
        }
        return
    }
    if (repo.all.isEmpty()) {
        // A load failure is shown, never a blank Home (N3).
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(RalysndTvColors.Background),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = "Couldn't load the channel list.",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
        }
        return
    }

    when (val current = screen) {
        Screen.Home -> HomeScreen(
            repository = repo,
            settings = settings,
            userData = userData,
            onPlay = { channel -> screen = Screen.Player(channel.id) },
            onOpenChannels = { screen = Screen.Channels },
            onOpenSettings = { screen = Screen.Settings },
            onOpenFavorites = { screen = Screen.Favorites },
        )
        Screen.Channels -> ChannelsScreen(
            repository = repo,
            userData = userData,
            onPlay = { channel -> screen = Screen.Player(channel.id) },
        )
        Screen.Favorites -> FavoritesScreen(
            repository = repo,
            settings = settings,
            userData = userData,
            onPlay = { channel -> screen = Screen.Player(channel.id) },
        )
        is Screen.Player -> {
            val channel: Channel? = repo.channelById(current.channelId)
            // Never write state during composition (N1): a missing
            // channel navigates home from an effect instead.
            LaunchedEffect(current.channelId) {
                if (channel == null) screen = Screen.Home
            }
            if (channel != null) {
                PlayerScreen(
                    channel = channel,
                    repository = repo,
                    settings = settings,
                    userData = userData,
                    onBack = { screen = Screen.Home },
                    onChannelSelected = { next -> screen = Screen.Player(next.id) },
                )
            }
        }
        Screen.Settings -> SettingsScreen(
            settings = settings,
            channelCount = repo.all.size,
        )
    }
}
