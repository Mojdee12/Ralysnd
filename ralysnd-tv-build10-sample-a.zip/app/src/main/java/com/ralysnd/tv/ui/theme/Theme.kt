package com.ralysnd.tv.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.ralysnd.tv.R
import androidx.compose.ui.unit.sp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle

/**
 * Ralysnd TV theme — the approved green-split / Sample A look: charcoal-
 * green background #101613, dark surfaces, white / muted-grey text, and
 * ONE accent only: brand green #00C853 (LIVE dot, focus ring, selected
 * item). This object is the single source of truth for colors; the
 * values here match res/values/colors.xml (window background).
 *
 * Font: the original app used Vazirmatn (SIL OFL 1.1, v33.003).
 * The four weights are bundled under res/font/ and wired below.
 */
object RalysndTvColors {
    val GreenPrimary = Color(0xFF00C853)
    val GreenBright = Color(0xFF22C55E)
    val GreenDark = Color(0xFF007A33)
    val LiveRed = Color(0xFFE53935)
    val Background = Color(0xFF101613)
    val Surface = Color(0xFF1C231F)
    val SurfaceElevated = Color(0xFF262E29)
    val Divider = Color(0xFF2A2F34)
    val PillGrey = Color(0xFF3A4440)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextMuted = Color(0xFF9DB3A8)
}

private val ColorScheme = darkColorScheme(
    primary = RalysndTvColors.GreenPrimary,
    secondary = RalysndTvColors.GreenPrimary,
    background = RalysndTvColors.Background,
    surface = RalysndTvColors.Surface,
    onBackground = RalysndTvColors.TextPrimary,
    onSurface = RalysndTvColors.TextPrimary,
)

private val AppTypography = Typography(
    displayLarge = TextStyle(fontSize = 48.sp, fontWeight = FontWeight.Bold),
    headlineLarge = TextStyle(fontSize = 36.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Normal),
    labelLarge = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    labelMedium = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium),
)

@Composable
fun RalysndTvTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ColorScheme,
        typography = AppTypography,
        content = content,
    )
}

/** Vazirmatn, bundled in res/font/ (Regular / Medium / SemiBold / Bold). */
val RalysndFontFamily: FontFamily = FontFamily(
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_medium, FontWeight.Medium),
    Font(R.font.vazirmatn_semibold, FontWeight.SemiBold),
    Font(R.font.vazirmatn_bold, FontWeight.Bold),
)
