package com.ralysnd.tv.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.data.ChannelRepository
import com.ralysnd.tv.data.SettingsStore
import com.ralysnd.tv.data.UserDataStore
import com.ralysnd.tv.ui.components.ChannelPosterCard
import com.ralysnd.tv.ui.components.DpadHint
import com.ralysnd.tv.ui.components.FocusableCard
import com.ralysnd.tv.ui.components.HeroOverlay
import com.ralysnd.tv.ui.components.MutedPreviewPlayer
import com.ralysnd.tv.ui.components.categoryLabel
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors
import kotlinx.coroutines.delay

/**
 * Home — Sample A (build 10): slim left nav rail (wordmark, Home +
 * categories with channel counts, Favorites, All Channels, Settings
 * pinned at the bottom), a top featured HERO = the live muted preview of
 * the selected channel (name + category + LIVE badge + green Watch button
 * + favorite toggle), and below it horizontal rails of 16:9 poster cards
 * — Recently Watched first, then one rail per category, derived from the
 * data itself. OK on a rail card selects it into the hero; OK on the hero
 * / Watch plays it. D-pad moves between nav, hero and rails; the focused
 * card gets the emerald border + a small pop. Initial focus is the hero
 * Watch button.
 *
 * Deliberately NO lookup field anywhere on this screen: the original
 * app has none and it was not approved for the rebuild. NO invented
 * data either: no viewer counts, no program names or synopses, no EPG —
 * a rail card shows only the channel's logo and name, which is real,
 * and the Recently Watched rail shows only channels actually watched
 * on this device.
 */
@Composable
fun HomeScreen(
    repository: ChannelRepository,
    settings: SettingsStore,
    userData: UserDataStore,
    onPlay: (Channel) -> Unit,
    onOpenChannels: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenFavorites: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // Nav categories, computed once: the bundled data never changes.
    val navCategories = remember(repository) { navCategoryOrder(repository) }
    val navCounts = remember(repository) {
        navCategories.associateWith { repository.channelsFor(it).size }
    }
    var navCategory by remember { mutableStateOf(ChannelRepository.CATEGORY_ALL) }

    val channelsForNav = remember(navCategory) {
        repository.channelsFor(navCategory).filter { it.isPlayable }
    }
    var selectedChannel by remember(navCategory) {
        mutableStateOf(channelsForNav.firstOrNull())
    }

    // The hero text follows the selection at once, but the preview video
    // only switches after 300ms with no further movement — scrolling fast
    // through rails must not thrash the player on a slow connection.
    var previewChannel by remember { mutableStateOf(selectedChannel) }
    LaunchedEffect(selectedChannel) {
        if (previewChannel != selectedChannel) {
            previewChannel = null
            delay(300)
            previewChannel = selectedChannel
        }
    }

    // Recently Watched (real watches on this device only) leads the
    // rails when viewing All and there is anything to show. Refreshed
    // on resume: returning from the player may have added a watch while
    // Home stayed composed (S9).
    fun loadRecentChannels() = userData.recentlyWatchedIds()
        .mapNotNull { repository.channelById(it) }
        .filter { it.isPlayable }
    var recentChannels by remember { mutableStateOf(loadRecentChannels()) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                recentChannels = loadRecentChannels()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val rails = remember(navCategory, recentChannels) {
        val base = railsFor(repository, navCategory)
        if (navCategory == ChannelRepository.CATEGORY_ALL && recentChannels.isNotEmpty()) {
            listOf(Rail("recent", "Recently Watched", recentChannels)) + base
        } else {
            base
        }
    }

    // Favorites, kept in state so the hero star updates at once on toggle.
    var favoriteIds by remember { mutableStateOf(userData.favoriteIds()) }

    // Initial focus: the hero Watch button (S4). D-pad spatial search
    // handles nav ↔ hero ↔ rails movement from there.
    val heroWatchRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        heroWatchRequester.requestFocus()
    }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(RalysndTvColors.Background)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        // ---- Left: slim nav rail ------------------------------------------
        // Categories scroll inside; Settings stays pinned at the bottom
        // (S6 — deliberate: the one destination that is always reachable).
        Column(
            modifier = Modifier
                .width(220.dp)
                .fillMaxSize()
                .clip(RoundedCornerShape(20.dp))
                .background(RalysndTvColors.Surface)
                .padding(16.dp),
        ) {
            Text(
                text = "Ralysnd ",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Text(
                text = "TV",
                color = RalysndTvColors.GreenPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "${repository.all.size} channels",
                color = RalysndTvColors.TextMuted,
                fontSize = 14.sp,
                fontFamily = RalysndFontFamily,
            )
            Spacer(Modifier.height(16.dp))
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(navCategories, key = { it }) { category ->
                    NavRailRow(
                        label = categoryLabel(category),
                        count = navCounts[category] ?: 0,
                        selected = category == navCategory,
                        onClick = { navCategory = category },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                item {
                    NavRailRow(
                        label = "All Channels",
                        count = null,
                        selected = false,
                        onClick = onOpenChannels,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                item {
                    NavRailRow(
                        label = "♥ Favorites",
                        count = favoriteIds.size,
                        selected = false,
                        onClick = onOpenFavorites,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            NavRailRow(
                label = "⚙ Settings",
                count = null,
                selected = false,
                onClick = onOpenSettings,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(10.dp))
            DpadHint(
                text = "OK to play • ← → rails",
                modifier = Modifier.fillMaxWidth(),
            )
        }

        // ---- Right: hero + rails -------------------------------------------
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxSize(),
        ) {
            // Hero: live muted preview of the selected channel, with the
            // shared bottom overlay (S5): LIVE + name + category +
            // favorite toggle + Watch.
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.44f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black),
            ) {
                // The preview player stays composed even while the
                // selection is debouncing (previewChannel null): the
                // single player instance survives and only its media
                // item swaps, instead of being released and recreated
                // on every rail scroll.
                MutedPreviewPlayer(
                    channel = previewChannel,
                    settings = settings,
                    modifier = Modifier.fillMaxSize(),
                )
                HeroOverlay(
                    channel = selectedChannel,
                    isFavorite = selectedChannel != null &&
                        selectedChannel.id in favoriteIds,
                    onToggleFavorite = {
                        selectedChannel?.let {
                            favoriteIds = userData.toggleFavorite(it.id)
                        }
                    },
                    onWatch = { selectedChannel?.let(onPlay) },
                    watchFocusRequester = heroWatchRequester,
                    modifier = Modifier.align(Alignment.BottomStart),
                )
            }

            Spacer(Modifier.height(18.dp))

            // Rails: one horizontal row of 16:9 poster cards per category.
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(18.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(rails, key = { it.key }) { rail ->
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = rail.label,
                                color = Color.White,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = RalysndFontFamily,
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = "• ${rail.channels.size}",
                                color = RalysndTvColors.TextMuted,
                                fontSize = 16.sp,
                                fontFamily = RalysndFontFamily,
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            items(rail.channels, key = { it.id }) { channel ->
                                ChannelPosterCard(
                                    channel = channel,
                                    selected = channel.id == selectedChannel?.id,
                                    onClick = { selectedChannel = channel },
                                    modifier = Modifier.width(260.dp),
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            DpadHint(
                text = "OK Watch • ☆ Favorite • ← → rails • Back to exit",
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

/** One rail: a category key, its display label, and its playable channels. */
private data class Rail(
    val key: String,
    val label: String,
    val channels: List<Channel>,
)

/** Rails for the current nav selection. "All" = one rail per category
 *  present in the data, in the repository's count order (S1) — no
 *  category is hidden. A chosen category = just its own rail. */
private fun railsFor(repository: ChannelRepository, navCategory: String): List<Rail> {
    val keys = if (navCategory == ChannelRepository.CATEGORY_ALL) {
        repository.categories.filter { it != ChannelRepository.CATEGORY_ALL }
    } else {
        listOf(navCategory)
    }
    return keys.mapNotNull { key ->
        val list = repository.channelsFor(key).filter { it.isPlayable }
        if (list.isEmpty()) null else Rail(key, categoryLabel(key), list)
    }
}

/** Nav order: the named categories first (only the ones that exist),
 *  then any other present categories in the repository's count order,
 *  so no channel is ever unreachable from Home. */
private fun navCategoryOrder(repository: ChannelRepository): List<String> {
    val preferred = listOf(
        "movies & series", "entertainment", "sports", "music",
        "documentary", "kids & teens", "national", "international",
        "news", "arabic", "turkish", "kurdish", "persiana",
        "gem tv networks", "regional", "telewebion",
    )
    val present = repository.categories.filter { it != ChannelRepository.CATEGORY_ALL }
    val ordered = preferred.filter { it in present } +
        present.filter { it !in preferred }
    return listOf(ChannelRepository.CATEGORY_ALL) + ordered
}

@Composable
private fun NavRailRow(
    label: String,
    count: Int?,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FocusableCard(
        onClick = onClick,
        modifier = modifier,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (selected) RalysndTvColors.GreenPrimary
                    else RalysndTvColors.Surface,
                    RoundedCornerShape(16.dp),
                )
                .padding(horizontal = 16.dp, vertical = 11.dp),
        ) {
            Text(
                text = label,
                color = if (selected) RalysndTvColors.Background
                else RalysndTvColors.TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = RalysndFontFamily,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (count != null) {
                Text(
                    text = "$count",
                    color = if (selected) RalysndTvColors.Background
                    else RalysndTvColors.TextMuted,
                    fontSize = 14.sp,
                    fontFamily = RalysndFontFamily,
                )
            }
        }
    }
}
