package com.ralysnd.tv.ui.player

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.data.ChannelRepository
import com.ralysnd.tv.data.SettingsStore
import com.ralysnd.tv.data.UserDataStore
import com.ralysnd.tv.player.PlayerFactory
import com.ralysnd.tv.ui.components.ChannelRow
import com.ralysnd.tv.ui.components.LiveBadge
import com.ralysnd.tv.ui.components.VpnBadge
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors
import kotlinx.coroutines.delay

/**
 * Full-screen player — the approved player mockup:
 * video on the left, "NEXT CHANNELS" panel on the right, bottom control bar
 * (pause, progress, time, subtitles, audio, volume), LIVE badge.
 *
 * Behaviour, matching the original app: play/pause, seek when the stream
 * allows it, subtitle + audio track pickers, and retry: on failure the
 * next URL of the same channel is tried before an error is shown
 * (channels carry up to 7 alternate streams, each with its own HTTP
 * headers — the player sends the source's headers with every request).
 * Live streams have no speed control: Media3 clamps live playback to
 * ~1x, so the speed button was removed rather than lie about it.
 *
 * Fast zapping (build 7): the player holds the whole current category as
 * one playlist, so jumping to the next/previous channel is a seek inside
 * the player instead of tearing it down and re-preparing a stream.
 * D-pad Up/Down zaps while the controls are hidden, CH+ / CH− zap any
 * time, and a brief overlay shows previous / current / next names.
 */
@Composable
fun PlayerScreen(
    channel: Channel,
    repository: ChannelRepository,
    settings: SettingsStore,
    userData: UserDataStore,
    onBack: () -> Unit,
    onChannelSelected: (Channel) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val player = remember { PlayerFactory.create(context, settings) }
    DisposableEffect(player) { onDispose { player.release() } }

    // Pause when the app goes to background (audio must not keep playing
    // with no UI); resume on return only if it was playing (P6).
    val lifecycleOwner = LocalLifecycleOwner.current
    var wasPlayingBeforePause by remember { mutableStateOf(false) }
    DisposableEffect(lifecycleOwner, player) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    wasPlayingBeforePause = player.isPlaying
                    player.pause()
                }
                Lifecycle.Event.ON_RESUME -> {
                    if (wasPlayingBeforePause) player.play()
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // --- Playlist zapping (build 7) --------------------------------------
    // `channel` is only the entry point; the live channel is whatever
    // playlist item the player is on, tracked via onMediaItemTransition.
    val playlist = remember(channel) {
        repository.channelsFor(
            channel.categories.firstOrNull() ?: ChannelRepository.CATEGORY_ALL,
        ).filter { it.isPlayable }
    }
    val startIndex = playlist.indexOfFirst { it.id == channel.id }.takeIf { it >= 0 } ?: 0
    var currentIndex by remember { mutableIntStateOf(startIndex) }
    val currentChannel: Channel = playlist.getOrElse(currentIndex) { channel }
    var urlIndex by remember { mutableIntStateOf(0) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    // Latest playlist for the player listener (created once): the listener
    // must see the current list, not the one from the first composition.
    val playlistState = rememberUpdatedState(playlist)

    // The NEXT CHANNELS panel shows the next items of the same playlist,
    // so every row is guaranteed to be a seek, never a screen rebuild.
    // distinctBy guards the small-category case: a category with fewer
    // than 8 channels would otherwise emit duplicate ids (P15).
    val panelChannels = remember(currentIndex, playlist) {
        if (playlist.size <= 1) emptyList()
        else (1..8).map { playlist[(currentIndex + it) % playlist.size] }
            .distinctBy { it.id }
    }

    // Brief zap feedback: previous / current / next names, ~2s. Derived
    // from the actual media-item transition (P13), never from the
    // requested target — a failed zap shows no stale name.
    var zapInfo by remember { mutableStateOf<ZapInfo?>(null) }
    LaunchedEffect(zapInfo) {
        if (zapInfo != null) {
            delay(2_000)
            zapInfo = null
        }
    }

    var isPlaying by remember { mutableStateOf(true) }
    var isBuffering by remember { mutableStateOf(false) }
    var controlsVisible by remember { mutableStateOf(true) }
    var interactionTick by remember { mutableIntStateOf(0) }
    var showNextPanel by remember { mutableStateOf(true) }
    var showSubtitlePicker by remember { mutableStateOf(false) }
    var showAudioPicker by remember { mutableStateOf(false) }
    var volume by remember { mutableFloatStateOf(1f) }

    // Focus restore (P10): the controls are conditionally composed, so
    // after the 5s auto-hide the focused control is disposed. When the
    // controls come back, focus returns to play/pause.
    val playPauseFocusRequester = remember { FocusRequester() }
    var controlsWereHidden by remember { mutableStateOf(false) }
    LaunchedEffect(controlsVisible) {
        if (controlsVisible && controlsWereHidden) {
            playPauseFocusRequester.requestFocus()
        }
        controlsWereHidden = !controlsVisible
    }

    // Favorites, kept in state so the control-bar star updates at once.
    var favoriteIds by remember { mutableStateOf(userData.favoriteIds()) }

    // Load the playlist once for the entry channel.
    LaunchedEffect(channel) {
        currentIndex = startIndex
        urlIndex = 0
        errorMessage = null
        if (playlist.isEmpty()) {
            errorMessage = "This channel has no stream."
        } else {
            // Record only playable channels (P14).
            userData.recordWatched(channel.id)
            player.setMediaItems(
                playlist.map { PlayerFactory.mediaItemFor(it.primaryUrl!!, it.headers) },
                startIndex,
                0L,
            )
            player.prepare()
            player.play()
        }
    }

    // Record every channel actually watched, including zaps inside the
    // playlist — this is what the Home "Recently Watched" rail shows.
    LaunchedEffect(currentIndex) {
        playlist.getOrNull(currentIndex)?.let { userData.recordWatched(it.id) }
    }

    // Player state -> UI state; transitions track the live channel;
    // failure -> next URL of the same channel (replace in place) -> error.
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onMediaItemTransition(
                mediaItem: MediaItem?,
                reason: Int,
            ) {
                val list = playlistState.value
                if (list.isNotEmpty()) {
                    currentIndex = player.currentMediaItemIndex
                        .coerceIn(0, list.lastIndex)
                }
                if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) {
                    // A real zap (or the first load) resets the retry index.
                    urlIndex = 0
                }
                // Zap feedback from the channel that is actually playing
                // now — never from the requested target (P13).
                if ((reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK ||
                        reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) &&
                    list.isNotEmpty()
                ) {
                    val idx = player.currentMediaItemIndex.coerceIn(0, list.lastIndex)
                    zapInfo = ZapInfo(
                        previous = list[(idx - 1 + list.size) % list.size].name,
                        current = list[idx].name,
                        next = list[(idx + 1) % list.size].name,
                    )
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                isPlaying = player.isPlaying
                isBuffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY) errorMessage = null
                if (state == Player.STATE_ENDED && settings.autoplayNextChannel) {
                    if (player.hasNextMediaItem()) player.seekToNextMediaItem()
                    else {
                        val list = playlistState.value
                        if (list.isNotEmpty()) {
                            val idx = player.currentMediaItemIndex.coerceIn(0, list.lastIndex)
                            onChannelSelected(list[(idx + 1) % list.size])
                        }
                    }
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlayerError(error: PlaybackException) {
                val list = playlistState.value
                if (list.isEmpty()) {
                    errorMessage = "No source available — all streams failed."
                    return
                }
                val index = player.currentMediaItemIndex.coerceIn(0, list.lastIndex)
                val current = list.getOrElse(index) { channel }
                if (urlIndex + 1 < current.sources.size) {
                    urlIndex += 1
                    // Failover: replace in place WITH the new source's
                    // headers, then prepare + play — after an error the
                    // player is STATE_IDLE and never starts without them (P1, P2).
                    player.replaceMediaItem(
                        index,
                        PlayerFactory.mediaItemFor(
                            current.sources[urlIndex].url,
                            current.sources[urlIndex].headers,
                        ),
                    )
                    player.prepare()
                    player.play()
                } else {
                    errorMessage = "No source available — all streams failed."
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    // Auto-hide the control bar 5s after the last interaction.
    LaunchedEffect(controlsVisible, interactionTick) {
        if (controlsVisible) {
            delay(5_000)
            controlsVisible = false
        }
    }

    fun poke() {
        controlsVisible = true
        interactionTick += 1
    }

    fun zap(delta: Int) {
        if (playlist.size <= 1) return
        if (delta > 0) {
            if (player.hasNextMediaItem()) player.seekToNextMediaItem()
            else player.seekTo(0, 0L) // wrap to the first channel
        } else {
            if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
            else player.seekTo(playlist.lastIndex, 0L) // wrap to the last channel
        }
        // Feedback comes from onMediaItemTransition (P13), not from here.
    }

    /** Jump to a channel in the playlist (NEXT CHANNELS panel); anything
     *  outside the playlist falls back to a fresh player screen. */
    fun jumpTo(target: Channel) {
        val index = playlist.indexOfFirst { it.id == target.id }
        if (index >= 0) {
            player.seekTo(index, 0L)
        } else {
            onChannelSelected(target)
        }
    }

    // Stable per-channel callbacks for the NEXT CHANNELS panel, so the
    // row lambdas are not recreated on every recomposition (P12).
    val jumpCallbacks = remember(panelChannels) {
        panelChannels.associate { target -> target.id to { jumpTo(target) } }
    }

    BackHandler { onBack() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            // Tap the video to bring the controls back (phone) / hide them.
            .pointerInput(controlsVisible) {
                detectTapGestures(
                    onTap = {
                        if (controlsVisible) controlsVisible = false else poke()
                    },
                )
            }
            .onPreviewKeyEvent { event ->
                if (event.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                // Remote CH+ / CH− (KEYCODE_CHANNEL_UP/DOWN) zap any time,
                // even with the controls up. Checked on the native key code
                // so this does not depend on Compose's Key constants.
                when (event.nativeKeyEvent.keyCode) {
                    android.view.KeyEvent.KEYCODE_CHANNEL_UP -> {
                        zap(+1)
                        return@onPreviewKeyEvent true
                    }
                    android.view.KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                        zap(-1)
                        return@onPreviewKeyEvent true
                    }
                }
                when (event.key) {
                    Key.DirectionCenter, Key.Enter -> {
                        poke()
                        false // let the focused control handle the click
                    }
                    Key.DirectionUp -> {
                        if (!controlsVisible) {
                            zap(+1)
                            true
                        } else {
                            poke()
                            false
                        }
                    }
                    Key.DirectionDown -> {
                        if (!controlsVisible) {
                            zap(-1)
                            true
                        } else {
                            poke()
                            false
                        }
                    }
                    else -> {
                        poke()
                        false
                    }
                }
            },
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    // Fill the screen (zoom): the video must be full-screen
                    // when a channel plays, not letterboxed by the panel.
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                }
            },
            modifier = Modifier.fillMaxSize(),
        )

        // ---- Top overlay: LIVE badge + channel name --------------------------
        if (controlsVisible) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(28.dp),
            ) {
                LiveBadge()
                Spacer(Modifier.width(14.dp))
                Text(
                    text = currentChannel.name,
                    color = Color.White,
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RalysndFontFamily,
                )
                if (currentChannel.needsVpn) {
                    Spacer(Modifier.width(12.dp))
                    VpnBadge()
                }
            }
        }

        // ---- Buffering indicator (P4): a spinner, not a black screen ---------
        if (isBuffering && errorMessage == null) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.align(Alignment.Center),
            ) {
                CircularProgressIndicator(color = RalysndTvColors.GreenPrimary)
                Spacer(Modifier.height(12.dp))
                Text(
                    text = "Loading…",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontFamily = RalysndFontFamily,
                )
            }
        }

        // ---- Zap overlay: prev / current / next, ~2s after a zap ------------
        zapInfo?.let { info ->
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 28.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(RalysndTvColors.Background.copy(alpha = 0.92f))
                    .padding(horizontal = 20.dp, vertical = 12.dp),
            ) {
                Text(
                    text = "‹ ${info.previous}",
                    color = RalysndTvColors.TextMuted,
                    fontSize = 18.sp,
                    fontFamily = RalysndFontFamily,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Spacer(Modifier.width(16.dp))
                LiveBadge()
                Spacer(Modifier.width(10.dp))
                Text(
                    text = info.current,
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RalysndFontFamily,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Spacer(Modifier.width(16.dp))
                Text(
                    text = "${info.next} ›",
                    color = RalysndTvColors.TextMuted,
                    fontSize = 18.sp,
                    fontFamily = RalysndFontFamily,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
            }
        }

        // ---- Right: NEXT CHANNELS panel (same green-split as home) -----------
        // Shown only while the controls are visible: 5s after the last
        // interaction both hide and the video is truly full-screen.
        if (controlsVisible && showNextPanel) {
            Column(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(420.dp)
                    .padding(20.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(RalysndTvColors.Background.copy(alpha = 0.92f))
                    .padding(16.dp),
            ) {
                Text(
                    text = "NEXT CHANNELS",
                    color = RalysndTvColors.GreenBright,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RalysndFontFamily,
                )
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f),
                ) {
                    items(panelChannels, key = { it.id }) { next ->
                        ChannelRow(
                            channel = next,
                            isPlaying = false,
                            onClick = jumpCallbacks[next.id] ?: { jumpTo(next) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "CH+ / CH− or ↑ ↓ to zap • OK to select",
                    color = RalysndTvColors.GreenBright,
                    fontSize = 14.sp,
                    fontFamily = RalysndFontFamily,
                )
            }
        }

        // ---- Error overlay ----------------------------------------------------
        errorMessage?.let { message ->
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(16.dp))
                    .background(RalysndTvColors.Surface)
                    .padding(24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = message,
                        color = Color.White,
                        fontSize = 20.sp,
                        fontFamily = RalysndFontFamily,
                    )
                    Spacer(Modifier.height(14.dp))
                    ControlButton(label = "Retry", onClick = {
                        urlIndex = 0
                        errorMessage = null
                        currentChannel.primaryUrl?.let {
                            player.replaceMediaItem(
                                currentIndex,
                                PlayerFactory.mediaItemFor(it, currentChannel.headers),
                            )
                            player.prepare()
                            player.play()
                        }
                    })
                }
            }
        }

        // ---- Bottom control bar ----------------------------------------------
        // Extracted (P12): the 500ms position clock lives inside the bar,
        // so only the bar recomposes twice a second — not the whole screen.
        if (controlsVisible) {
            PlayerControlBar(
                player = player,
                isPlaying = isPlaying,
                currentChannel = currentChannel,
                currentIndex = currentIndex,
                urlIndex = urlIndex,
                onUrlIndexChange = { urlIndex = it },
                onClearError = { errorMessage = null },
                favoriteIds = favoriteIds,
                onToggleFavorite = {
                    poke()
                    favoriteIds = userData.toggleFavorite(currentChannel.id)
                },
                volume = volume,
                onVolumeChange = { newVolume ->
                    volume = newVolume
                    player.volume = newVolume
                },
                showNextPanel = showNextPanel,
                onToggleNextPanel = {
                    poke()
                    showNextPanel = !showNextPanel
                },
                onShowSubtitles = {
                    poke()
                    showSubtitlePicker = true
                },
                onShowAudio = {
                    poke()
                    showAudioPicker = true
                },
                onPoke = ::poke,
                playPauseFocusRequester = playPauseFocusRequester,
                modifier = Modifier.align(Alignment.BottomCenter),
            )
        }
    }

    if (showSubtitlePicker) {
        TrackPickerDialog(
            title = "Subtitles",
            options = subtitleOptions(player),
            onDismiss = { showSubtitlePicker = false },
            onPick = { option ->
                showSubtitlePicker = false
                applyTextTrack(player, option)
            },
        )
    }
    if (showAudioPicker) {
        TrackPickerDialog(
            title = "Audio track",
            options = audioOptions(player),
            onDismiss = { showAudioPicker = false },
            onPick = { option ->
                showAudioPicker = false
                applyAudioTrack(player, option)
            },
        )
    }
}

/**
 * Bottom control bar, extracted from [PlayerScreen] so the 500ms position
 * clock recomposes only this subtree (P12). Owns its own position /
 * duration state; everything else comes from the parent.
 */
@Composable
private fun PlayerControlBar(
    player: ExoPlayer,
    isPlaying: Boolean,
    currentChannel: Channel,
    currentIndex: Int,
    urlIndex: Int,
    onUrlIndexChange: (Int) -> Unit,
    onClearError: () -> Unit,
    favoriteIds: List<String>,
    onToggleFavorite: () -> Unit,
    volume: Float,
    onVolumeChange: (Float) -> Unit,
    showNextPanel: Boolean,
    onToggleNextPanel: () -> Unit,
    onShowSubtitles: () -> Unit,
    onShowAudio: () -> Unit,
    onPoke: () -> Unit,
    playPauseFocusRequester: FocusRequester,
    modifier: Modifier = Modifier,
) {
    // Position clock: local to the bar, so the rest of the player screen
    // does not recompose twice a second.
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(C.TIME_UNSET) }
    LaunchedEffect(player) {
        while (true) {
            positionMs = player.currentPosition
            durationMs = player.duration
            delay(500)
        }
    }
    val seekable = durationMs > 0 && player.isCurrentMediaItemSeekable

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp, vertical = 20.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(RalysndTvColors.Background.copy(alpha = 0.92f))
            .padding(horizontal = 20.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ControlButton(
                label = if (isPlaying) "❚❚" else "▶",
                onClick = {
                    onPoke()
                    if (player.isPlaying) player.pause() else player.play()
                },
                focusRequester = playPauseFocusRequester,
            )
            Spacer(Modifier.width(12.dp))
            // Seek buttons only exist when the stream is seekable (P9):
            // on live streams they were visible but dead.
            if (seekable) {
                ControlButton(label = "−10s", onClick = {
                    onPoke()
                    player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0))
                })
                ControlButton(label = "+10s", onClick = {
                    onPoke()
                    player.seekTo(player.currentPosition + 10_000)
                })
                Spacer(Modifier.width(12.dp))
                Slider(
                    value = (positionMs.toFloat() / durationMs).coerceIn(0f, 1f),
                    onValueChange = { fraction ->
                        player.seekTo((durationMs * fraction).toLong())
                    },
                    colors = SliderDefaults.colors(
                        thumbColor = RalysndTvColors.GreenPrimary,
                        activeTrackColor = RalysndTvColors.GreenPrimary,
                        inactiveTrackColor = RalysndTvColors.PillGrey,
                    ),
                    modifier = Modifier.weight(1f),
                )
            } else {
                Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.width(12.dp))
            Text(
                text = formatTime(positionMs, durationMs),
                color = Color.White,
                fontSize = 18.sp,
                fontFamily = RalysndFontFamily,
            )
            Spacer(Modifier.width(12.dp))
            // Server switcher: only for channels with alternate streams.
            // Each tap moves to the next URL in place — replaceMediaItem
            // keeps the playlist and volume; the first URL stays
            // the default. The new source's headers go with it (P1).
            if (currentChannel.urls.size > 1) {
                ControlButton(
                    label = "Server ${urlIndex + 1}/${currentChannel.urls.size}",
                    onClick = {
                        onPoke()
                        val next = (urlIndex + 1) % currentChannel.urls.size
                        onUrlIndexChange(next)
                        onClearError()
                        player.replaceMediaItem(
                            currentIndex,
                            PlayerFactory.mediaItemFor(
                                currentChannel.urls[next],
                                currentChannel.sources.getOrNull(next)?.headers
                                    ?: emptyMap(),
                            ),
                        )
                        player.prepare()
                        player.play()
                    },
                )
            }
            ControlButton(label = "CC", onClick = onShowSubtitles)
            ControlButton(label = "♪", onClick = onShowAudio)
            // Favorite toggle for the channel now playing (Stitch
            // model): solid star when it is a favorite already.
            ControlButton(
                label = if (currentChannel.id in favoriteIds) "★" else "☆",
                onClick = onToggleFavorite,
            )
            ControlButton(label = "Vol−", onClick = {
                onPoke()
                onVolumeChange((volume - 0.1f).coerceIn(0f, 1f))
            })
            ControlButton(label = "Vol+", onClick = {
                onPoke()
                onVolumeChange((volume + 0.1f).coerceIn(0f, 1f))
            })
            ControlButton(
                label = if (showNextPanel) "Hide ◂" else "Next ▸",
                onClick = onToggleNextPanel,
            )
        }
    }
}

@Composable
private fun ControlButton(
    label: String,
    onClick: () -> Unit,
    focusRequester: FocusRequester? = null,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (focused) RalysndTvColors.GreenPrimary else RalysndTvColors.SurfaceElevated,
                RoundedCornerShape(12.dp),
            )
            .then(
                if (focusRequester != null) Modifier.focusRequester(focusRequester)
                else Modifier,
            )
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            color = if (focused) Color.Black else Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = RalysndFontFamily,
        )
    }
}

private data class TrackOption(
    val label: String,
    val group: Tracks.Group?,
    val trackIndex: Int,
)

/** Previous / current / next channel names shown briefly after a zap. */
private data class ZapInfo(
    val previous: String,
    val current: String,
    val next: String,
)

private fun audioOptions(player: ExoPlayer): List<TrackOption> {
    val out = ArrayList<TrackOption>()
    for (group in player.currentTracks.groups) {
        if (group.type != C.TRACK_TYPE_AUDIO) continue
        for (i in 0 until group.length) {
            val format = group.getTrackFormat(i)
            val label = format.label
                ?: format.language?.uppercase()
                ?: "Audio ${out.size + 1}"
            out += TrackOption(label, group, i)
        }
    }
    return out
}

private fun subtitleOptions(player: ExoPlayer): List<TrackOption> {
    val out = ArrayList<TrackOption>()
    out += TrackOption("Off", null, -1)
    for (group in player.currentTracks.groups) {
        if (group.type != C.TRACK_TYPE_TEXT) continue
        for (i in 0 until group.length) {
            val format = group.getTrackFormat(i)
            val label = format.label
                ?: format.language?.uppercase()
                ?: "Subtitles ${out.size}"
            out += TrackOption(label, group, i)
        }
    }
    return out
}

private fun applyAudioTrack(player: ExoPlayer, option: TrackOption) {
    val group = option.group ?: return
    val override = TrackSelectionOverride(group.mediaTrackGroup, option.trackIndex)
    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
        .setOverrideForType(override)
        .build()
}

private fun applyTextTrack(player: ExoPlayer, option: TrackOption) {
    val builder = player.trackSelectionParameters.buildUpon()
    if (option.group == null) {
        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
    } else {
        builder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(
                TrackSelectionOverride(option.group.mediaTrackGroup, option.trackIndex),
            )
    }
    player.trackSelectionParameters = builder.build()
}

@Composable
private fun TrackPickerDialog(
    title: String,
    options: List<TrackOption>,
    onDismiss: () -> Unit,
    onPick: (TrackOption) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = title,
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (options.isEmpty()) {
                    Text(
                        text = "No tracks available for this channel.",
                        color = RalysndTvColors.TextMuted,
                        fontSize = 17.sp,
                        fontFamily = RalysndFontFamily,
                    )
                }
                for (option in options) {
                    TrackOptionRow(option = option, onPick = onPick)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = RalysndTvColors.GreenPrimary)
            }
        },
        containerColor = RalysndTvColors.Surface,
    )
}

/** One track row: a visible focus state (green + border) so a D-pad user
 *  can see which subtitle/audio track is focused (P11). */
@Composable
private fun TrackOptionRow(option: TrackOption, onPick: (TrackOption) -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Text(
        text = option.label,
        color = if (focused) Color.Black else Color.White,
        fontSize = 18.sp,
        fontFamily = RalysndFontFamily,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(
                if (focused) RalysndTvColors.GreenPrimary
                else RalysndTvColors.SurfaceElevated,
            )
            .border(
                width = if (focused) 2.dp else 0.dp,
                color = if (focused) Color.White else Color.Transparent,
                RoundedCornerShape(10.dp),
            )
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onPick(option) }
            .padding(horizontal = 14.dp, vertical = 10.dp),
    )
}

private fun formatTime(positionMs: Long, durationMs: Long): String {
    fun part(ms: Long): String {
        val totalSeconds = (ms / 1000).coerceAtLeast(0)
        return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
    }
    return if (durationMs > 0) "${part(positionMs)} / ${part(durationMs)}"
    else "${part(positionMs)} • LIVE"
}
