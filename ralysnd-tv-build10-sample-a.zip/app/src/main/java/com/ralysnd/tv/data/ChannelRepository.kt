package com.ralysnd.tv.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Loads the bundled channels.json (assets/channels.json, 1,097 channels
 * from the user's own mytvsat dump) and groups channels by category.
 *
 * Categories are derived from the data itself, ordered by channel count
 * (largest first). Channels with no category are listed under
 * "general" so no channel is ever unreachable.
 */
class ChannelRepository(private val channels: List<Channel>) {

    val all: List<Channel> get() = channels

    /** Category keys in display order: "all" first, then by channel count. */
    val categories: List<String> by lazy {
        val counts = linkedMapOf<String, Int>()
        for (channel in channels) {
            for (category in channel.categories) {
                counts[category] = (counts[category] ?: 0) + 1
            }
        }
        listOf(CATEGORY_ALL) + counts.entries
            .sortedByDescending { it.value }
            .map { it.key }
    }

    /** Channels for one category key, or every channel for "all". Sorted A–Z. */
    fun channelsFor(category: String): List<Channel> {
        val filtered = if (category == CATEGORY_ALL) {
            channels
        } else {
            channels.filter { it.categories.contains(category) }
        }
        return filtered.sortedBy { it.name.lowercase() }
    }

    fun channelById(id: String): Channel? = channels.firstOrNull { it.id == id }

    companion object {
        const val CATEGORY_ALL = "all"

        /** Loads and parses the bundled channels.json from assets. */
        fun load(context: Context): ChannelRepository {
            val json = context.assets.open("channels.json")
                .bufferedReader()
                .use { it.readText() }
            return ChannelRepository(parseChannels(json))
        }

        /** Pure parse of a channels.json document. Kept separate so unit tests
         * can exercise it without Android assets. */
        fun parseChannels(json: String): List<Channel> {
            val array = JSONArray(json)
            val out = ArrayList<Channel>(array.length())
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val categories = obj.stringList("categories")
                    .ifEmpty { listOf("general") }
                out += Channel(
                    id = obj.optString("id"),
                    name = obj.optString("name"),
                    logo = obj.optString("logo"),
                    categories = categories,
                    sources = obj.sourceList(),
                    needsVpn = obj.optBoolean("needsVpn", false),
                )
            }
            return out
        }

        private fun JSONObject.stringList(key: String): List<String> {
            val arr: JSONArray = optJSONArray(key) ?: return emptyList()
            val out = ArrayList<String>(arr.length())
            for (i in 0 until arr.length()) {
                val value = arr.optString(i)
                if (value.isNotBlank()) out += value
            }
            return out
        }

        /** String-to-string map from a JSON object value, e.g. a source's
         *  `headers` (`{"Referer": "https://…", …}`). Blank values are
         *  skipped; a missing or malformed value yields an empty map. */
        private fun JSONObject.stringMap(key: String): Map<String, String> {
            val obj: JSONObject = optJSONObject(key) ?: return emptyMap()
            val out = linkedMapOf<String, String>()
            val names = obj.names() ?: return emptyMap()
            for (i in 0 until names.length()) {
                val name = names.optString(i)
                val value = obj.optString(name)
                if (name.isNotBlank() && value.isNotBlank()) out[name] = value
            }
            return out
        }

        /**
         * A channel's sources. When the `sources` array is present and
         * non-empty it wins (url + optional title + optional headers
         * object). Otherwise the flat `urls` list is used, one source
         * per url with no headers — so older channels.json files keep
         * parsing exactly as before.
         */
        private fun JSONObject.sourceList(): List<ChannelSource> {
            val arr: JSONArray = optJSONArray("sources")
            if (arr != null && arr.length() > 0) {
                val out = ArrayList<ChannelSource>(arr.length())
                for (i in 0 until arr.length()) {
                    val src = arr.optJSONObject(i) ?: continue
                    val url = src.optString("url")
                    if (url.isBlank()) continue
                    out += ChannelSource(
                        url = url,
                        title = src.optString("title"),
                        headers = src.stringMap("headers"),
                    )
                }
                if (out.isNotEmpty()) return out
            }
            return stringList("urls").map { ChannelSource(url = it) }
        }
    }
}
