package com.ralysnd.tv

import com.ralysnd.tv.data.ChannelRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

/**
 * Unit tests for the bundled-channels parsing. org.json needs Robolectric
 * on the JVM (the android.jar stubs throw), so these run under Robolectric.
 * The bundled asset itself is verified separately: python count = 1,097 channels / 1,272 URLs.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ChannelRepositoryTest {

    private val sampleJson = """
        [
          {"id": "a.ir", "name": "Alpha", "logo": "https://example.com/a.png",
           "categories": ["news"], "urls": ["https://example.com/a.m3u8"]},
          {"id": "b.ir", "name": "Beta", "logo": "",
           "categories": ["news", "sports"],
           "urls": ["https://example.com/b1.m3u8", "https://example.com/b2.m3u8"]},
          {"id": "c.ir", "name": "Gamma", "logo": "",
           "categories": [], "urls": []}
        ]
    """.trimIndent()

    @Test
    fun parsesAllChannels() {
        val repo = ChannelRepository(ChannelRepository.parseChannels(sampleJson))
        assertEquals(3, repo.all.size)
        assertEquals("Alpha", repo.all[0].name)
        assertEquals("https://example.com/a.m3u8", repo.all[0].primaryUrl)
        assertTrue(repo.all[0].isPlayable)
    }

    @Test
    fun multiUrlChannelKeepsAlternates() {
        val repo = ChannelRepository(ChannelRepository.parseChannels(sampleJson))
        val beta = repo.channelById("b.ir")!!
        assertEquals(2, beta.urls.size)
        assertEquals("https://example.com/b2.m3u8", beta.urls[1])
    }

    @Test
    fun uncategorisedChannelFallsUnderGeneral() {
        val repo = ChannelRepository(ChannelRepository.parseChannels(sampleJson))
        val gamma = repo.channelById("c.ir")!!
        assertEquals(listOf("general"), gamma.categories)
        assertTrue(repo.channelsFor("general").any { it.id == "c.ir" })
    }

    @Test
    fun categoriesAreOrderedByCount() {
        val repo = ChannelRepository(ChannelRepository.parseChannels(sampleJson))
        // news: 2 channels, sports: 1, general: 1 (Gamma). "all" is always first.
        assertEquals("all", repo.categories.first())
        assertEquals("news", repo.categories[1])
    }

    @Test
    fun sourcesWithHeadersParse() {
        val json = """
            [
              {"id": "h.ir", "name": "Headered", "logo": "",
               "categories": ["news"],
               "sources": [
                 {"url": "https://example.com/h1.m3u8", "title": "Server 1",
                  "headers": {"Referer": "https://example.com/"}},
                 {"url": "https://example.com/h2.m3u8", "title": "Server 2"}
               ],
               "urls": ["https://example.com/h1.m3u8", "https://example.com/h2.m3u8"]}
            ]
        """.trimIndent()
        val repo = ChannelRepository(ChannelRepository.parseChannels(json))
        val channel = repo.channelById("h.ir")!!
        // The sources array wins over the flat urls list.
        assertEquals(2, channel.sources.size)
        assertEquals("Server 1", channel.sources[0].title)
        assertEquals("https://example.com/", channel.sources[0].headers["Referer"])
        // The second source carries no headers.
        assertTrue(channel.sources[1].headers.isEmpty())
        // urls is derived from sources, in order.
        assertEquals(
            listOf("https://example.com/h1.m3u8", "https://example.com/h2.m3u8"),
            channel.urls,
        )
        // headers is the primary source's headers (what the player sends).
        assertEquals("https://example.com/", channel.headers["Referer"])
        assertEquals("https://example.com/h1.m3u8", channel.primaryUrl)
    }

    @Test
    fun urlsOnlyChannelGetsEmptyHeaders() {
        val repo = ChannelRepository(ChannelRepository.parseChannels(sampleJson))
        val alpha = repo.channelById("a.ir")!!
        assertEquals(1, alpha.sources.size)
        assertTrue(alpha.sources[0].headers.isEmpty())
        assertTrue(alpha.headers.isEmpty())
    }

    @Test
    fun vpnFlagDefaultsToFalseAndParsesWhenPresent() {
        val json = """
            [
              {"id": "v.ir", "name": "VpnOne", "logo": "",
               "categories": ["news"], "urls": ["https://example.com/v.m3u8"],
               "needsVpn": true},
              {"id": "n.ir", "name": "Normal", "logo": "",
               "categories": ["news"], "urls": ["https://example.com/n.m3u8"]}
            ]
        """.trimIndent()
        val repo = ChannelRepository(ChannelRepository.parseChannels(json))
        assertTrue(repo.channelById("v.ir")!!.needsVpn)
        assertTrue(!repo.channelById("n.ir")!!.needsVpn)
    }
}
