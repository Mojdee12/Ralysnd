package com.kunk.singbox.engines

/**
 * Home engine grid catalog — Ralysnd only.
 *
 * The grid contains ONLY the engines the user asked for plus the
 * flows that already work in this app. Engines the user explicitly
 * rejected are not listed here at all: no tile, no "coming soon"
 * placeholder, no empty space reserved for them.
 *
 * Status honesty rule: a tile may only claim READY when its connect
 * path is real in this build. SCAFFOLD means its setup / discovery /
 * server-list flow works but a live connect is not yet possible for
 * the reason stated in [EngineInfo.statusNote] — the UI must show that
 * note, never a fake successful connection.
 */
enum class EngineId { WIREGUARD, FENIX }

enum class EngineStatus { READY, SCAFFOLD }

data class EngineInfo(
    val id: EngineId,
    val title: String,
    val badge: String,
    val status: EngineStatus,
    /** Short honest status line shown under the tile. */
    val statusNote: String,
)

val ENGINE_GRID: List<EngineInfo> = listOf(
    EngineInfo(
        id = EngineId.WIREGUARD,
        title = "WireGuard",
        badge = "W",
        status = EngineStatus.READY,
        statusNote = "Your WireGuard nodes",
    ),
    EngineInfo(
        id = EngineId.FENIX,
        title = "FENIX",
        badge = "F",
        status = EngineStatus.READY,
        statusNote = "Firefox VPN tunnel",
    ),
)
