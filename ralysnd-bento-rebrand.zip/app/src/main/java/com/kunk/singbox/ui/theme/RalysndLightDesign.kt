package com.kunk.singbox.ui.theme

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * RALYSND LIGHT DESIGN — approved bento theme (FENIX sample 4, full
 * mosaic, 2026-10-28).
 *
 * Light grey background, dark ink text, white cards and colorful
 * rounded bento tiles (coral / mint / violet / blue / amber), blue
 * connect button, slim floating pill bottom nav (light version, in
 * AppNavBar).
 *
 * This file mirrors the v2 dark components' signatures (glass card,
 * center connect button, country card) so the main screens keep their
 * approved layout and only the palette changes. No sample data is
 * produced here; every card renders only real values its caller passes.
 * NO profile pictures / avatar images anywhere: countries are flag
 * emoji text + country-code text badge, accounts are email text only.
 */

/** Bento light palette (values mirror Color.kt's Bento* palette so
 * older L4* callers get the new look with no signature change). */
val L4Background = BentoBackground
val L4Surface = BentoSurface
val L4SurfaceAlt = BentoSurfaceAlt
val L4Outline = BentoOutline
// M27: darkened for >= 4.5:1 contrast on white cards (same hues,
// just darker). Old L4Green #16A34A was 3.3:1 and old L4Amber
// #D97706 was 3.2:1 on white — both below the 4.5:1 bar for normal
// text. New values: #15803D ~= 5.0:1, #B45309 ~= 4.8:1 on white.
// Button containers using these colors keep white/off-white text,
// which still reads on the darker fills.
val L4Green = Color(0xFF15803D)
val L4GreenDark = Color(0xFF15803D)
val L4GreenSoft = Color(0xFFDCFCE7)
val L4Amber = Color(0xFFB45309)
val L4Text = BentoInk
val L4TextDim = BentoInkDim

/** Bento tile backgrounds (light tints whose text stays dark ink). */
val L4PastelCyan = BentoTintBlue
val L4PastelAmber = BentoTintAmber
val L4PastelRose = BentoTintCoral
val L4PastelSlate = BentoSurfaceAlt
val L4PastelViolet = BentoTintViolet
val L4PastelOrange = BentoTintAmber

/** Light glass card: white surface, soft shadow, 24dp bento corners.
 * [tileColor] lets a caller paint a full bento tile (coral / mint /
 * violet / blue / amber) while keeping the same card behavior; the
 * default stays white, so existing callers are unchanged. Callers
 * that pass a saturated tile must also pass light text colors for
 * their own content — this card does not recolor its children. */
@Composable
fun L4GlassCard(
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null,
    tileColor: Color = L4Surface,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(24.dp)
    val borderColor = if (selected) BentoBlue else L4Outline
    val borderWidth = if (selected) 1.5.dp else 1.dp
    val clickModifier = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    Box(
        modifier = modifier
            .shadow(6.dp, shape)
            .clip(shape)
            .background(tileColor, shape)
            .border(borderWidth, borderColor, shape)
            .then(clickModifier)
            .animateContentSize(),
    ) {
        Column(modifier = Modifier.fillMaxWidth(), content = content)
    }
}

/** Light center connect button: 216dp circle, white disc, thin blue
 * bento ring (blue = connect, like the approved sample's blue connect
 * tile); the icon stays green while actually connected. */
@Composable
fun L4CenterConnectButton(
    isRunning: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "l4CenterConnectScale",
    )
    val label = if (isRunning) "DISCONNECT" else "CONNECT"
    val status = if (isRunning) "Connected" else "Not Connected"
    val iconColor = if (isRunning) L4Green else BentoBlue
    Column(
        modifier = modifier
            .semantics {
                contentDescription = label
                role = Role.Button
            }
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(216.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .shadow(12.dp, CircleShape)
                .clip(CircleShape)
                .background(L4Surface, CircleShape)
                .border(
                    width = 2.dp,
                    brush = Brush.sweepGradient(colors = listOf(BentoBlue, BentoViolet, BentoBlue)),
                    shape = CircleShape,
                ),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(modifier = Modifier.size(72.dp)) {
                val stroke = 7.dp.toPx()
                val radius = (size.minDimension - stroke) / 2f
                val center = Offset(size.width / 2f, size.height / 2f)
                drawArc(
                    color = iconColor,
                    startAngle = 300f,
                    sweepAngle = 300f,
                    useCenter = false,
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = Size(radius * 2f, radius * 2f),
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
                drawLine(
                    color = iconColor,
                    start = Offset(center.x, center.y - radius),
                    end = Offset(center.x, center.y - radius * 0.15f),
                    strokeWidth = stroke,
                    cap = StrokeCap.Round,
                )
            }
        }
        Spacer(modifier = Modifier.height(28.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Medium, letterSpacing = 6.sp),
            color = L4Text,
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = status,
            style = MaterialTheme.typography.bodyMedium,
            color = if (isRunning) L4GreenDark else L4TextDim,
        )
    }
}

/** Light country card: same layout as the dark one, light palette. */
@Composable
fun L4CountryCard(
    flag: String,
    countryCode: String,
    countryName: String,
    pingText: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    volumeText: String? = null,
    // M28: optional pill badge rendered under the ping line (e.g.
    // "UNVERIFIED" on an unverified country). Null = no badge; FENIX
    // callers pass nothing and are unchanged.
    badge: String? = null,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "l4CountryCardScale",
    )
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier = modifier
            .width(168.dp)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(6.dp, shape)
            .clip(shape)
            .background(L4Surface, shape)
            .border(if (selected) 1.5.dp else 1.dp, if (selected) BentoBlue else L4Outline, shape)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .animateContentSize(),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = flag, fontSize = 26.sp)
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(L4SurfaceAlt)
                        .border(1.dp, L4Outline, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = countryCode.uppercase(),
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                        color = BentoBlue,
                    )
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = countryName,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = L4Text,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = pingText,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = if (selected) BentoBlue else L4Amber,
            )
            Text(
                text = "ping",
                style = MaterialTheme.typography.labelSmall,
                color = L4TextDim,
            )
            // M28 badge: dark-amber pill, white text (>= 4.5:1 on
            // the darkened L4Amber fill).
            if (badge != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(L4Amber)
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        text = badge,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = L4Surface,
                    )
                }
            }
            if (volumeText != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = volumeText,
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                    color = L4Amber,
                )
            }
        }
    }
}

/** One pastel engine tile for the home grid (bento style). */
@Composable
fun L4EngineTile(
    title: String,
    subtitle: String,
    pastel: Color,
    badge: String,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(24.dp)
    val clickModifier = if (enabled) Modifier.clickable(onClick = onClick) else Modifier
    Box(
        modifier = modifier
            .shadow(if (enabled) 6.dp else 0.dp, shape)
            .clip(shape)
            .background(if (enabled) pastel else L4SurfaceAlt, shape)
            .border(1.dp, L4Outline, shape)
            .then(clickModifier)
            .padding(14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(L4Surface, CircleShape)
                    .border(1.dp, L4Outline, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = badge,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = L4Text,
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = L4Text,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = L4TextDim,
            )
        }
    }
}
