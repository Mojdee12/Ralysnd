package com.kunk.singbox.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kunk.singbox.engines.ENGINE_GRID
import com.kunk.singbox.engines.EngineId
import com.kunk.singbox.ui.navigation.Screen
import com.kunk.singbox.ui.theme.BentoTintAmber
import com.kunk.singbox.ui.theme.BentoTintViolet
import com.kunk.singbox.ui.theme.L4EngineTile
import com.kunk.singbox.ui.theme.L4Text

/**
 * Home engine grid (sample-4 light tiles). Only wanted engines
 * appear here — no rejected engine has a tile, placeholder, or
 * reserved space. The grid is WireGuard, FENIX, in that order.
 *
 * Wiring (honest):
 * - WireGuard -> Nodes screen (existing nodes).
 * - FENIX -> FENIX tab (existing Foxy tunnel).
 *
 * NOTE (2026-10-28 total purge): the exit-country sheet and the
 * scanner entry that used to live here were deleted outright
 * with their engine, service, and native core.
 */
@Composable
fun EngineGridSection(
    onNavigate: (String) -> Unit,
    onAddNode: (String) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Engines", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = L4Text)
        }
        for (row in ENGINE_GRID.chunked(2)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (engine in row) {
                    L4EngineTile(
                        title = engine.title,
                        subtitle = engine.statusNote,
                        pastel = when (engine.id) {
                            EngineId.WIREGUARD -> BentoTintAmber
                            EngineId.FENIX -> BentoTintViolet
                        },
                        badge = engine.badge,
                        enabled = true,
                        onClick = {
                            when (engine.id) {
                                EngineId.WIREGUARD -> onNavigate(Screen.Nodes.route)
                                EngineId.FENIX -> onNavigate(Screen.Fenix.route)
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (row.size == 1) Spacer(modifier = Modifier.weight(1f))
            }
        }
    }
}
