package com.kunk.singbox.engines

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel for the WARP identity registration that the Nodes path
 * still uses. All state here is measured or user-supplied: no
 * invented gateways, servers, latencies, or quotas.
 *
 * Single-VpnService rule is preserved by construction: WARP
 * produces sing-box nodes/profiles that run through the existing
 * sing-box service, so at most one VPN is ever active.
 *
 * NOTE (2026-10-28 total purge): the scanner and exit-country
 * engine paths that used to live here were deleted outright with
 * their screens, service, and native core. Nothing in this file
 * references them anymore.
 */
class EnginesViewModel(application: Application) : AndroidViewModel(application) {
    private val context: Context
        get() = getApplication<Application>().applicationContext

    private val warpStore by lazy { WarpIdentityStore(context) }

    // ---- WARP ----
    private val _warpIdentity = MutableStateFlow<WarpIdentity?>(null)
    val warpIdentity: StateFlow<WarpIdentity?> = _warpIdentity.asStateFlow()
    private val _warpBusy = MutableStateFlow(false)
    val warpBusy: StateFlow<Boolean> = _warpBusy.asStateFlow()
    private val _warpError = MutableStateFlow<String?>(null)
    val warpError: StateFlow<String?> = _warpError.asStateFlow()
    /** Fresh wireguard:// link for the registered WARP identity, if any. */
    private val _warpLink = MutableStateFlow<String?>(null)
    val warpLink: StateFlow<String?> = _warpLink.asStateFlow()

    init {
        _warpIdentity.value = warpStore.load()
        _warpIdentity.value?.let { _warpLink.value = WarpClient.buildWireGuardLink(it) }
    }

    /** Registers a fresh WARP identity and publishes its node link. */
    fun registerWarp() {
        if (_warpBusy.value) return
        viewModelScope.launch {
            _warpBusy.value = true
            _warpError.value = null
            try {
                val keyPair = WarpClient.generateKeyPair()
                val identity = WarpClient.register(keyPair)
                warpStore.save(identity)
                _warpIdentity.value = identity
                _warpLink.value = WarpClient.buildWireGuardLink(identity)
            } catch (e: Exception) {
                _warpError.value = e.message ?: "WARP registration failed"
            } finally {
                _warpBusy.value = false
            }
        }
    }

    fun clearWarpError() {
        _warpError.value = null
    }

}
