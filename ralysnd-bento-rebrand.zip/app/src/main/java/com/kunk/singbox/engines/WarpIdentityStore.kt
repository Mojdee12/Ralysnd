package com.kunk.singbox.engines

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.tencent.mmkv.MMKV

/**
 * Local persistence for the user's own Cloudflare WARP identity.
 *
 * The identity (account id, token, private key, public key) lives in
 * EncryptedSharedPreferences (MasterKey AES256_GCM, key encryption
 * AES256_SIV, value encryption AES256_GCM). It is NEVER logged and
 * never stored in plaintext. The WARP UI is removed, so this store
 * is dormant, but a dormant store must not ship a plaintext
 * private key.
 *
 * ONE-TIME MIGRATION from the old plaintext MMKV store ("ralysnd_warp"):
 * on first access, legacy keys are read once, written to the encrypted
 * store (only where it has nothing yet), and then the legacy keys are
 * deleted.
 */
data class WarpIdentity(
    val accountId: String,
    val token: String,
    val privateKeyBase64: String,
    val publicKeyBase64: String,
    val reserved: List<Int>,
    val registeredAtMs: Long,
)

class WarpIdentityStore(context: Context) {
    private val appContext = context.applicationContext

    private val prefs by lazy {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            appContext,
            "ralysnd_warp_enc",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    @Volatile
    private var migrationDone = false

    private fun migrateLegacyOnce() {
        if (migrationDone) return
        runCatching {
            val legacy = MMKV.mmkvWithID("ralysnd_warp", MMKV.SINGLE_PROCESS_MODE)
            val stringKeys = listOf(
                "account_id", "token", "private_key", "public_key", "reserved", "worker_relay_url",
            )
            for (name in stringKeys) {
                val legacyValue = legacy.decodeString(name, null)?.takeIf { it.isNotBlank() }
                if (legacyValue != null && !prefs.contains(name)) {
                    prefs.edit().putString(name, legacyValue).apply()
                }
                legacy.remove(name)
            }
            val legacyRegisteredAt = legacy.decodeLong("registered_at", 0L)
            if (legacyRegisteredAt != 0L && !prefs.contains("registered_at")) {
                prefs.edit().putLong("registered_at", legacyRegisteredAt).apply()
            }
            legacy.remove("registered_at")
            if (legacy.decodeBool("worker_relay_enabled", false) && !prefs.contains("worker_relay_enabled")) {
                prefs.edit().putBoolean("worker_relay_enabled", true).apply()
            }
            legacy.remove("worker_relay_enabled")
            migrationDone = true
        }
    }

    private fun encrypted(): android.content.SharedPreferences {
        migrateLegacyOnce()
        return prefs
    }

    fun load(): WarpIdentity? {
        val store = encrypted()
        val id = store.getString("account_id", "")?.takeIf { it.isNotBlank() } ?: return null
        val token = store.getString("token", "") ?: ""
        val priv = store.getString("private_key", "")?.takeIf { it.isNotBlank() } ?: return null
        val pub = store.getString("public_key", "")?.takeIf { it.isNotBlank() } ?: return null
        val reserved = store.getString("reserved", "")
            ?.split(",")
            ?.mapNotNull { it.trim().toIntOrNull() }
            .orEmpty()
        return WarpIdentity(
            accountId = id,
            token = token,
            privateKeyBase64 = priv,
            publicKeyBase64 = pub,
            reserved = reserved,
            registeredAtMs = store.getLong("registered_at", 0L),
        )
    }

    fun save(identity: WarpIdentity) {
        encrypted().edit()
            .putString("account_id", identity.accountId)
            .putString("token", identity.token)
            .putString("private_key", identity.privateKeyBase64)
            .putString("public_key", identity.publicKeyBase64)
            .putString("reserved", identity.reserved.joinToString(","))
            .putLong("registered_at", identity.registeredAtMs)
            .apply()
    }

    /**
     * "Make identity through worker" toggle (off by default).
     * Only for networks where direct identity registration is
     * filtered: when on, registration is attempted through the
     * user's own worker relay URL below. The app ships no relay
     * of its own — with the toggle on and no URL set, the sheet
     * says so plainly instead of pretending a relay exists.
     */
    var workerRelayEnabled: Boolean
        get() = encrypted().getBoolean("worker_relay_enabled", false)
        set(value) {
            encrypted().edit().putBoolean("worker_relay_enabled", value).apply()
        }

    var workerRelayUrl: String
        get() = encrypted().getString("worker_relay_url", "") ?: ""
        set(value) {
            encrypted().edit().putString("worker_relay_url", value).apply()
        }

    fun clear() {
        encrypted().edit().clear().apply()
        // Defensive: never leave a plaintext legacy key behind.
        runCatching {
            val legacy = MMKV.mmkvWithID("ralysnd_warp", MMKV.SINGLE_PROCESS_MODE)
            legacy.clearAll()
        }
    }
}
