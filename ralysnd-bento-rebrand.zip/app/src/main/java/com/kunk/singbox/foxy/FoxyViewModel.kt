package com.kunk.singbox.foxy

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kunk.singbox.foxy.data.FxaAuthRepository
import com.kunk.singbox.foxy.data.FoxyAccountRegistry
import com.kunk.singbox.foxy.data.GuardianClient
import com.kunk.singbox.foxy.data.ServerListClient
import com.kunk.singbox.foxy.data.TokenStore
import com.kunk.singbox.foxy.data.ProxyStateStore
import com.kunk.singbox.foxy.vpn.FoxyVpnService
import com.kunk.singbox.foxy.data.model.Entitlement
import com.kunk.singbox.foxy.data.model.ProxyCandidate
import com.kunk.singbox.foxy.data.model.VpnCountry
import com.kunk.singbox.foxy.vpn.PingUtil
import com.kunk.singbox.viewmodel.DashboardViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * FENIX (Foxy) ViewModel for Ralysnd — MULTI-ACCOUNT.
 *
 * Auth + server list + quota + ping are FoxyVPN's actual flow (MIT, Vauth):
 * Firefox-account email+password sign-in via FxaAuthRepository (PBKDF2 authPW,
 * FxA OAuth, client_id from FoxyVPN), Guardian proxy pass + account status
 * via GuardianClient, country list via Mozilla Remote Settings via
 * ServerListClient, TCP ping via PingUtil.
 *
 * MULTI-ACCOUNT: every Firefox account keeps its own tokens under
 * per-account [TokenStore] keys (see TokenStore + [FoxyAccountRegistry]);
 * the registry holds only account ids (emails) and the active id. The
 * aggregate volume shown in the UI is the SUM of each signed-in account's
 * Guardian quota (quotaRemaining where reported, else maxBytes); an
 * account whose API reports neither contributes nothing and is counted
 * in [FoxyUiState.accountsWithoutQuota] — its card says
 * "Quota unavailable", never a fake number. The pre-multi-account
 * sign-in is migrated as the first account (id "legacy" when its email
 * was never recorded) and is never deleted by migration.
 *
 * CONNECTION PATH — FULL FOXY TUNNEL (no HTTP-outbound fallback):
 * connectSelected() saves the chosen country candidate into ProxyStateStore
 * (the store FoxyVpnService.connect() reads), stops KunBox's sing-box VPN
 * if it is running (Android allows only one active VpnService), then starts
 * FoxyVpnService, which reads the ACTIVE account from the registry and
 * mints that account's Guardian proxy pass, opening a Netty HTTP/2 CONNECT
 * to the Fastly edge with `proxy-authorization: Bearer <pass>`.
 */

private const val KEY_PENDING_2FA_EMAIL = "pending_2fa_email"

/** One signed-in Firefox account, shown in the UI by EMAIL TEXT ONLY (never a photo). */
data class FoxyAccount(
    /** Registry id: normalised email, or "legacy" for the migrated account. */
    val id: String,
    /** Email text to display; empty when the migrated account's email was never recorded. */
    val displayEmail: String,
    val entitlement: Entitlement?,
    val isActive: Boolean,
)

data class FoxyUiState(
    val signedIn: Boolean = false,
    val needsTwoFactor: Boolean = false,
    val isLoading: Boolean = false,
    val isPinging: Boolean = false,
    val isConnecting: Boolean = false,
    /** Active account's entitlement (kept for callers that only need one account). */
    val entitlement: Entitlement? = null,
    val countries: List<VpnCountry> = emptyList(),
    val selected: ProxyCandidate? = null,
    val pingMs: Map<String, Int> = emptyMap(),
    val message: String? = null,
    /** All signed-in accounts (email text only). */
    val accounts: List<FoxyAccount> = emptyList(),
    /** Registry id of the active account (the one the tunnel uses). */
    val activeAccountId: String = "",
    /** Sum of quotaRemaining across accounts that report it; null if none report it. */
    val totalQuotaRemaining: Long? = null,
    /** Sum of maxBytes across accounts that report it; null if none report it. */
    val totalMaxBytes: Long? = null,
    /** Accounts whose API reported neither quotaRemaining nor maxBytes. */
    val accountsWithoutQuota: Int = 0,
    /** True while the login card is open to ADD another account (not replace). */
    val addingAccount: Boolean = false,
    /** Plain note when the country list fell back to the last fetched cache (M10). */
    val countriesNote: String? = null,
    /** Accounts whose Guardian fetch failed (their quota is absent, not zero) (M10). */
    val guardianFailureCount: Int = 0,
    /** Plain reason when no volume is known because the account sign-in
     * itself is gone (token missing) — refresh cannot fix that case. */
    val quotaNote: String? = null,
    /** True while an account switch/removal waits for the tunnel to stop (M7). */
    val accountChangePending: Boolean = false,
)

class FoxyViewModel(application: Application) : AndroidViewModel(application) {

    private val registry = FoxyAccountRegistry(application)
    private val guardian = GuardianClient()
    private val serverClient = ServerListClient(application)
    /** Live state of the Foxy tunnel service (for the FENIX tab's toggle). */
    val foxyState = FoxyVpnService.state

    /** Last error the Foxy service reported (e.g. bounded monitor failure, C6). */
    val foxyLastError = FoxyVpnService.lastError

    private val _uiState = MutableStateFlow(FoxyUiState())
    val uiState: StateFlow<FoxyUiState> = _uiState.asStateFlow()

    private var pendingEmail: String = ""
    private var pendingRepo: FxaAuthRepository? = null

    /**
     * Pending 2FA sign-in, persisted in plain prefs — EMAIL ONLY, never
     * a token (the session token itself lives in the encrypted
     * TokenStore of that account). Survives process death so a 2FA code
     * is validated against the pending account, never a different
     * current account (M7).
     */
    private val pending2faPrefs by lazy {
        getApplication<Application>().getSharedPreferences(
            "foxyvpn_pending_2fa", android.content.Context.MODE_PRIVATE,
        )
    }
    private fun persistedPendingEmail(): String =
        runCatching { pending2faPrefs.getString(KEY_PENDING_2FA_EMAIL, "") }.getOrDefault("") ?: ""
    private fun savePersistedPendingEmail(email: String) {
        runCatching { pending2faPrefs.edit().putString(KEY_PENDING_2FA_EMAIL, email).apply() }
    }
    private fun clearPersistedPendingEmail() {
        runCatching { pending2faPrefs.edit().remove(KEY_PENDING_2FA_EMAIL).apply() }
    }

    /** A switch/removal queued while the tunnel stops; applied only after DISCONNECTED (M7). */
    private var pendingAccountSwitch: String? = null
    private var pendingAccountRemoval: String? = null
    private var accountStopJob: Job? = null
    private var pingJob: Job? = null

    private fun foxyTunnelRunning(): Boolean =
        foxyState.value == com.kunk.singbox.foxy.data.model.ConnectionState.CONNECTED ||
            foxyState.value == com.kunk.singbox.foxy.data.model.ConnectionState.CONNECTING

    /**
     * Waits (bounded, 10 s) for the Foxy tunnel to reach DISCONNECTED,
     * then runs [afterStop]. Returns false when the tunnel did not stop
     * in time — the queued change is then dropped with a plain message
     * instead of wiping tokens under a live tunnel.
     */
    private fun waitForTunnelStop(afterStop: () -> Unit) {
        accountStopJob?.cancel()
        accountStopJob = viewModelScope.launch {
            val stopped = withTimeoutOrNull(10_000L) {
                foxyState.first { it == com.kunk.singbox.foxy.data.model.ConnectionState.DISCONNECTED }
            } != null
            if (stopped) {
                afterStop()
            } else {
                pendingAccountSwitch = null
                pendingAccountRemoval = null
                _uiState.update {
                    it.copy(
                        accountChangePending = false,
                        message = "The tunnel did not stop in time — " +
                            "disconnect it first, then try the account change again",
                    )
                }
            }
        }
    }

    private fun storeFor(accountId: String?): TokenStore {
        val id = accountId?.takeIf { it.isNotBlank() && it != FoxyAccountRegistry.LEGACY_ACCOUNT_ID }
        return TokenStore(getApplication(), id)
    }

    private fun repoFor(accountId: String?): FxaAuthRepository =
        FxaAuthRepository(storeFor(accountId))

    init {
        viewModelScope.launch {
            // Restore a 2FA sign-in interrupted by process death (M7):
            // the pending email + session token are persisted, so the
            // code field comes back for the SAME pending account.
            val restoredPending = persistedPendingEmail()
            if (restoredPending.isNotBlank()) {
                val hasPendingSession = runCatching {
                    repoFor(restoredPending).pendingSessionToken != null
                }.getOrDefault(false)
                if (hasPendingSession) {
                    pendingEmail = restoredPending
                    pendingRepo = repoFor(restoredPending)
                    _uiState.update { it.copy(needsTwoFactor = true) }
                } else {
                    clearPersistedPendingEmail()
                }
            }
            // Migrate the pre-multi-account sign-in as the first account.
            val legacyStore = TokenStore(getApplication())
            if (legacyStore.hasStoredSession()) {
                registry.migrateLegacyIfNeeded(legacyStore.loadEmail())
            }
            val accounts = registry.loadAccounts()
            if (accounts.isEmpty()) return@launch
            var active = registry.loadActive().takeIf { it.isNotBlank() } ?: accounts.first()
            if (active !in accounts) {
                active = accounts.first()
                registry.setActive(active)
            }
            // Restore each account's session; keep only accounts that still have one.
            val signedIn = accounts.filter { id ->
                runCatching { repoFor(id).restoreSession() }.getOrNull() ==
                    com.kunk.singbox.foxy.data.SessionStatus.ACTIVE
            }
            if (signedIn.isEmpty()) {
                _uiState.update { it.copy(signedIn = false) }
                return@launch
            }
            if (active !in signedIn) {
                active = signedIn.first()
                registry.setActive(active)
            }
            _uiState.update { it.copy(signedIn = true, activeAccountId = active) }
            refreshAccountAndCountries()
        }
    }

    /** Opens the login card in ADD mode (adds another account, never overwrites). */
    fun startAddingAccount() {
        _uiState.update { it.copy(addingAccount = true, needsTwoFactor = false, message = null) }
    }

    fun cancelAddingAccount() {
        _uiState.update { it.copy(addingAccount = false, needsTwoFactor = false) }
    }

    fun signIn(email: String, password: String) {
        val cleanEmail = FxaAuthRepository.normalizeEmail(email)
        val repo = repoFor(cleanEmail)
        pendingEmail = cleanEmail
        pendingRepo = repo
        savePersistedPendingEmail(cleanEmail)
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, message = null) }
            val result = repo.startLogin(cleanEmail, password)
            result.onSuccess { needsCode ->
                if (needsCode) {
                    _uiState.update { it.copy(isLoading = false, needsTwoFactor = true) }
                } else {
                    finishSignIn(cleanEmail, repo)
                }
            }.onFailure { e ->
                clearPersistedPendingEmail()
                _uiState.update { it.copy(isLoading = false, message = e.message ?: "Sign-in failed") }
            }
        }
    }

    fun submitTwoFactorCode(code: String) {
        // Resolve the pending account from PERSISTED state first: after
        // process death the in-memory pendingEmail is empty, and the
        // code must go to the pending account, never the current one.
        val email = persistedPendingEmail().takeIf { it.isNotBlank() }
            ?: pendingEmail
        if (email.isBlank()) {
            _uiState.update { it.copy(message = "No pending sign-in. Start sign-in again.") }
            return
        }
        val repo = repoFor(email)
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, message = null) }
            val result = repo.submitTwoFactorCode(code, expectedEmail = email)
            result.onSuccess {
                finishSignIn(email, repo)
            }.onFailure { e ->
                _uiState.update { it.copy(isLoading = false, message = e.message ?: "Verification failed") }
            }
        }
    }

    private suspend fun finishSignIn(email: String, repo: FxaAuthRepository) {
        runCatching { storeFor(email).saveEmail(email) }
        registry.addAccount(email)
        registry.setActive(email)
        pendingEmail = ""
        pendingRepo = null
        clearPersistedPendingEmail()
        _uiState.update {
            it.copy(isLoading = false, signedIn = true, needsTwoFactor = false, addingAccount = false, activeAccountId = email)
        }
        refreshAccountAndCountries()
    }

    /** Signs out AND removes the active account (legacy single-account behaviour). */
    fun signOut() {
        val active = _uiState.value.activeAccountId
        if (active.isNotBlank()) removeAccount(active) else _uiState.update { FoxyUiState() }
    }

    /**
     * Removes one account. If this account's tunnel is running, the
     * tunnel is stopped FIRST and its tokens are wiped only after the
     * service reports DISCONNECTED (M7) — never fire-and-forget under
     * a live tunnel or a token renewal in flight. A second change
     * while a stop is in flight is refused with a plain message.
     */
    fun removeAccount(accountId: String) {
        if (pendingAccountSwitch != null || pendingAccountRemoval != null) {
            _uiState.update {
                it.copy(message = "An account change is already waiting for the tunnel to stop — try again shortly")
            }
            return
        }
        val isActive = accountId == _uiState.value.activeAccountId
        if (isActive && foxyTunnelRunning()) {
            pendingAccountRemoval = accountId
            _uiState.update {
                it.copy(accountChangePending = true, message = "Stopping the tunnel before removing the account…")
            }
            FoxyVpnService.stop(getApplication())
            waitForTunnelStop {
                pendingAccountRemoval = null
                _uiState.update { it.copy(accountChangePending = false, message = null) }
                removeAccountNow(accountId)
            }
            return
        }
        removeAccountNow(accountId)
    }

    private fun removeAccountNow(accountId: String) {
        viewModelScope.launch {
            runCatching { storeFor(accountId).clear() }
            registry.removeAccount(accountId)
            val remaining = registry.loadAccounts()
            if (remaining.isEmpty()) {
                _uiState.update { FoxyUiState() }
            } else {
                _uiState.update { it.copy(activeAccountId = registry.loadActive()) }
                refreshAccountAndCountries()
            }
        }
    }

    /**
     * Switches the tunnel's account. While the tunnel is running, the
     * switch is QUEUED: the tunnel stops first and the switch applies
     * only after DISCONNECTED (M7). A switch while a stop is already
     * in flight is refused with a plain message, not silently queued
     * behind another change.
     */
    fun switchAccount(accountId: String) {
        if (pendingAccountSwitch != null || pendingAccountRemoval != null) {
            _uiState.update {
                it.copy(message = "An account change is already waiting for the tunnel to stop — try again shortly")
            }
            return
        }
        if (foxyTunnelRunning()) {
            pendingAccountSwitch = accountId
            _uiState.update {
                it.copy(accountChangePending = true, message = "Stopping the tunnel before switching accounts…")
            }
            FoxyVpnService.stop(getApplication())
            waitForTunnelStop {
                val target = pendingAccountSwitch
                pendingAccountSwitch = null
                _uiState.update { it.copy(accountChangePending = false, message = null) }
                if (target != null) switchAccountNow(target)
            }
            return
        }
        switchAccountNow(accountId)
    }

    private fun switchAccountNow(accountId: String) {
        registry.setActive(accountId)
        _uiState.update { it.copy(activeAccountId = accountId, message = null) }
        refreshAccountAndCountries()
    }

    fun refreshAccountAndCountries() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, message = null, countriesNote = null) }
            try {
                val ids = registry.loadAccounts()
                val active = registry.loadActive().takeIf { it.isNotBlank() } ?: ids.firstOrNull().orEmpty()
                // Per-account Guardian failures are COUNTED, not swallowed
                // by getOrNull (M10): a failed fetch means "no quota data
                // for this account", never a silent zero.
                var guardianFailures = 0
                var tokenMissing = false
                val accounts = ids.map { id ->
                    val token = runCatching { repoFor(id).currentAccessToken() }.getOrNull()
                    if (token == null) tokenMissing = true
                    val entitlement = if (token != null) {
                        runCatching {
                            guardian.fetchUserInfo(com.kunk.singbox.foxy.data.GUARDIAN_ENDPOINT_DEFAULT, token)
                        }.onFailure { guardianFailures++ }.getOrNull()
                    } else null
                    val email = runCatching { storeFor(id).loadEmail() }.getOrNull()
                    FoxyAccount(
                        id = id,
                        displayEmail = email?.takeIf { it.isNotBlank() }
                            ?: if (id != FoxyAccountRegistry.LEGACY_ACCOUNT_ID) id else "",
                        entitlement = entitlement,
                        isActive = id == active,
                    )
                }
                val remainingValues = accounts.mapNotNull { it.entitlement?.quotaRemaining }
                val maxValues = accounts.mapNotNull { it.entitlement?.maxBytes }
                val withoutQuota = accounts.count { it.entitlement?.quotaRemaining == null && it.entitlement?.maxBytes == null }
                // A failed refresh must SAY it fell back to cache (M10),
                // never silently serve a stale list as if it were fresh.
                var countriesNote: String? = null
                var countriesError: String? = null
                val countries = runCatching { serverClient.fetchCountries() }
                    .onFailure {
                        countriesError = it.message ?: it::class.simpleName
                        countriesNote = "Could not refresh — showing last fetched list"
                    }
                    .getOrElse { serverClient.loadCachedCountries() }
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        signedIn = accounts.isNotEmpty(),
                        accounts = accounts,
                        activeAccountId = active,
                        entitlement = accounts.firstOrNull { a -> a.isActive }?.entitlement,
                        totalQuotaRemaining = remainingValues.takeIf { list -> list.isNotEmpty() }?.sum(),
                        totalMaxBytes = maxValues.takeIf { list -> list.isNotEmpty() }?.sum(),
                        accountsWithoutQuota = withoutQuota,
                        countries = countries,
                        countriesNote = countriesNote,
                        // Never a silent blank list: when BOTH the remote
                        // fetch and the local cache fail, say the real
                        // error instead of the misleading "showing last
                        // fetched list" note over an empty list.
                        message = if (countries.isEmpty() && countriesError != null) {
                            "Could not load FENIX countries: $countriesError — " +
                                "check your connection, then tap Refresh"
                        } else {
                            null
                        },
                        guardianFailureCount = guardianFailures,
                        // Never a silent missing volume: when no account
                        // reports any volume because its sign-in token is
                        // gone, say so — a Refresh re-fetches live data,
                        // but only a fresh sign-in restores an expired one.
                        quotaNote = if (remainingValues.isEmpty() && maxValues.isEmpty() && tokenMissing) {
                            "Volume unavailable: the account sign-in has expired — " +
                                "sign in again, then Refresh shows the exact remaining volume."
                        } else {
                            null
                        },
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, message = e.message ?: "Failed to load FENIX data") }
            }
        }
    }

    fun selectCountry(countryCode: String) {
        val candidates = ServerListClient.candidatesForCountry(_uiState.value.countries, countryCode)
        val first = candidates.firstOrNull()
        if (first != null) {
            _uiState.update { it.copy(selected = first, message = null) }
        } else {
            _uiState.update { it.copy(message = "No available servers for that country") }
        }
    }

    /**
     * Ping all countries, publishing each result LIVE as it arrives (not
     * only at the end). Re-entry guarded (M10): a second tap while a
     * ping run is in flight is ignored, never a second overlapping
     * coroutine overwriting results.
     */
    fun pingAllCountries() {
        if (pingJob?.isActive == true || _uiState.value.isPinging) return
        pingJob = viewModelScope.launch {
            _uiState.update { it.copy(isPinging = true) }
            try {
                withContext(Dispatchers.IO) {
                    for (country in _uiState.value.countries) {
                        val candidate = ServerListClient.candidatesForCountry(
                            _uiState.value.countries, country.code,
                        ).firstOrNull() ?: continue
                        val ms = PingUtil.measureTcpLatencyMs(candidate.host, candidate.port)
                        if (ms != null) {
                            _uiState.update { it.copy(pingMs = it.pingMs + (country.code to ms)) }
                        }
                    }
                }
            } finally {
                _uiState.update { it.copy(isPinging = false) }
            }
        }
    }

    fun fastestCountry(): VpnCountry? {
        val pings = _uiState.value.pingMs
        if (pings.isEmpty()) return null
        val code = pings.minByOrNull { it.value }?.key ?: return null
        return _uiState.value.countries.firstOrNull { it.code.equals(code, ignoreCase = true) }
    }

    /**
     * Connect via the FULL Foxy tunnel. Caller (FenixScreen) must have
     * already ensured VpnService.prepare() is granted for this app (the
     * Dashboard permission flow grants it app-wide); this function only
     * starts the service. Steps: save the selected candidate where
     * FoxyVpnService.connect() reads it, stop sing-box if running, then
     * start FoxyVpnService. The service reads the ACTIVE account from
     * the registry, mints that account's Guardian proxy pass and dials
     * the Fastly edge with Bearer auth on an H2 CONNECT.
     */
    fun connectSelected(context: android.content.Context, dashboardViewModel: DashboardViewModel) {
        val selected = _uiState.value.selected
        if (selected == null) {
            _uiState.update { it.copy(message = "Pick a country first") }
            return
        }
        // Duplicate connect while CONNECTING must give feedback (m8),
        // not just a log line in the service: the tap visibly answers.
        if (foxyState.value == com.kunk.singbox.foxy.data.model.ConnectionState.CONNECTING) {
            _uiState.update { it.copy(message = "Already connecting… please wait") }
            return
        }
        if (foxyState.value == com.kunk.singbox.foxy.data.model.ConnectionState.CONNECTED) {
            _uiState.update { it.copy(message = "FENIX is already connected") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isConnecting = true, message = null) }
            try {
                val dashState = dashboardViewModel.connectionState.value
                if (dashState == com.kunk.singbox.model.ConnectionState.Connected ||
                    dashState == com.kunk.singbox.model.ConnectionState.Connecting
                ) {
                    dashboardViewModel.toggleConnection()
                    delay(700)
                }
                ProxyStateStore(context).save(selected)
                FoxyVpnService.start(context)
                _uiState.update {
                    it.copy(
                        isConnecting = false,
                        message = "FENIX connecting via the Foxy tunnel to ${selected.countryName}",
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isConnecting = false, message = e.message ?: "Connect failed") }
            }
        }
    }

    /** Disconnect the Foxy tunnel (does not touch sing-box). */
    fun disconnectFenix(context: android.content.Context) {
        FoxyVpnService.stop(context)
    }
}
