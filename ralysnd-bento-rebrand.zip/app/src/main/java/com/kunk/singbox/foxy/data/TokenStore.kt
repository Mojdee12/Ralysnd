package com.kunk.singbox.foxy.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.kunk.singbox.foxy.data.model.RuntimeAuth
import com.tencent.mmkv.MMKV

/**
 * FoxyVPN TokenStore, adapted for Ralysnd, with MULTI-ACCOUNT support.
 *
 * Tokens live in EncryptedSharedPreferences (MasterKey AES256_GCM, key
 * encryption AES256_SIV, value encryption AES256_GCM, via
 * androidx.security:security-crypto, already a dependency). They are
 * NEVER logged and never stored in plaintext.
 *
 * ONE-TIME MIGRATION from the old plaintext MMKV store ("foxyvpn_tokens"):
 * on first access, any legacy keys for this account are read once, written
 * to the encrypted store (only where the encrypted store has nothing yet),
 * and then the legacy keys are deleted. After migration the old MMKV keys
 * are gone, so a later read can never resurrect a plaintext token.
 *
 * MULTI-ACCOUNT KEYS: a TokenStore is now bound to one account id:
 * - accountId == null or "legacy" -> the ORIGINAL single-account keys, byte for
 *   byte ("access_token", "refresh_token", ...). This is the backward-compatible
 *   path: the account a user already signed in with keeps working untouched.
 * - any other accountId -> keys are prefixed "acct_<sanitised-id>_<key>", so
 *   each Firefox account's tokens live under its own keys in the same
 *   encrypted store and never overwrite each other. Sanitising lowercases
 *   the id and replaces every non [a-z0-9] character with '_', so an email
 *   maps to exactly one deterministic prefix.
 *
 * clear() removes ONLY this account's keys — it must never wipe the whole
 * store now that several accounts share it.
 */
class TokenStore(context: Context, accountId: String? = null) {

    private val appContext = context.applicationContext

    private val prefs by lazy {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            appContext,
            "foxyvpn_tokens_enc",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    private val prefix: String = when {
        accountId.isNullOrBlank() || accountId == LEGACY_ACCOUNT_ID -> ""
        else -> "acct_${sanitizeAccountId(accountId)}_"
    }

    private fun key(name: String): String = prefix + name

    @Volatile
    private var migrationDone = false

    /**
     * One-time legacy migration. Reads the old plaintext MMKV keys for
     * this account once, copies any value the encrypted store lacks,
     * then deletes the legacy keys. Runs at most once per instance and
     * never logs a token value.
     */
    private fun migrateLegacyOnce() {
        if (migrationDone) return
        runCatching {
            val legacy = MMKV.mmkvWithID("foxyvpn_tokens", MMKV.MULTI_PROCESS_MODE)
            val names = listOf(
                KEY_ACCESS_TOKEN, KEY_REFRESH_TOKEN, KEY_EMAIL, KEY_PENDING_SESSION_TOKEN,
                KEY_PENDING_EMAIL,
            )
            for (name in names) {
                val legacyValue = legacy.decodeString(key(name), null)?.takeIf { it.isNotBlank() }
                if (legacyValue != null && !prefs.contains(key(name))) {
                    prefs.edit().putString(key(name), legacyValue).apply()
                }
                legacy.remove(key(name))
            }
            val legacyExpires = legacy.decodeLong(key(KEY_EXPIRES_AT), 0L)
            if (legacyExpires != 0L && !prefs.contains(key(KEY_EXPIRES_AT))) {
                prefs.edit().putLong(key(KEY_EXPIRES_AT), legacyExpires).apply()
            }
            legacy.remove(key(KEY_EXPIRES_AT))
            // Only mark migration done after a full pass, so a failed
            // attempt (e.g. MMKV not yet initialised) retries later
            // instead of leaving plaintext keys behind forever.
            migrationDone = true
        }
    }

    private fun encrypted(): android.content.SharedPreferences {
        migrateLegacyOnce()
        return prefs
    }

    fun saveAuth(auth: RuntimeAuth) {
        val editor = encrypted().edit()
        editor.putString(key(KEY_ACCESS_TOKEN), auth.accessToken)
        if (auth.refreshToken != null) {
            editor.putString(key(KEY_REFRESH_TOKEN), auth.refreshToken)
        } else {
            editor.remove(key(KEY_REFRESH_TOKEN))
        }
        editor.putLong(key(KEY_EXPIRES_AT), auth.expiresAtEpochSeconds)
        editor.apply()
    }

    fun loadAuth(): RuntimeAuth? = runCatching {
        val store = encrypted()
        val access = store.getString(key(KEY_ACCESS_TOKEN), null)?.takeIf { it.isNotBlank() }
            ?: return@runCatching null
        val refresh = store.getString(key(KEY_REFRESH_TOKEN), null)?.takeIf { it.isNotBlank() }
        val expiresAt = store.getLong(key(KEY_EXPIRES_AT), 0L)
        RuntimeAuth(access, refresh, expiresAt)
    }.getOrNull()

    fun hasValidAccessToken(): Boolean {
        val auth = loadAuth() ?: return false
        if (auth.expiresAtEpochSeconds <= 0L) return false
        val nowSeconds = System.currentTimeMillis() / 1000
        return auth.expiresAtEpochSeconds - nowSeconds > CLOCK_SKEW_TOLERANCE_SECONDS
    }

    fun hasStoredSession(): Boolean = loadAuth() != null

    fun hasRefreshToken(): Boolean = loadAuth()?.refreshToken != null

    /** The email this account signed in with (saved at sign-in; absent for the migrated legacy account). */
    fun saveEmail(email: String) {
        encrypted().edit().putString(key(KEY_EMAIL), email).apply()
    }

    fun loadEmail(): String? =
        encrypted().getString(key(KEY_EMAIL), null)?.takeIf { it.isNotBlank() }

    var pendingSessionToken: String?
        get() = encrypted().getString(key(KEY_PENDING_SESSION_TOKEN), null)?.takeIf { it.isNotBlank() }
        set(value) {
            val editor = encrypted().edit()
            if (value != null) {
                editor.putString(key(KEY_PENDING_SESSION_TOKEN), value)
            } else {
                editor.remove(key(KEY_PENDING_SESSION_TOKEN))
            }
            editor.apply()
        }

    /**
     * Email of the sign-in currently awaiting a 2FA code, persisted so
     * the pending account survives process death. An email is not a
     * token, but it still lives in the encrypted store, never in plain
     * MMKV; it is cleared together with the pending session token.
     */
    var pendingEmail: String?
        get() = encrypted().getString(key(KEY_PENDING_EMAIL), null)?.takeIf { it.isNotBlank() }
        set(value) {
            val editor = encrypted().edit()
            if (value != null) {
                editor.putString(key(KEY_PENDING_EMAIL), value)
            } else {
                editor.remove(key(KEY_PENDING_EMAIL))
            }
            editor.apply()
        }

    /** Removes ONLY this account's keys, never other accounts' tokens. */
    fun clear() {
        val editor = encrypted().edit()
        editor.remove(key(KEY_ACCESS_TOKEN))
        editor.remove(key(KEY_REFRESH_TOKEN))
        editor.remove(key(KEY_EXPIRES_AT))
        editor.remove(key(KEY_PENDING_SESSION_TOKEN))
        editor.remove(key(KEY_EMAIL))
        editor.remove(key(KEY_PENDING_EMAIL))
        editor.apply()
        // Defensive: never leave a plaintext legacy key behind for this account.
        runCatching {
            val legacy = MMKV.mmkvWithID("foxyvpn_tokens", MMKV.MULTI_PROCESS_MODE)
            legacy.remove(key(KEY_ACCESS_TOKEN))
            legacy.remove(key(KEY_REFRESH_TOKEN))
            legacy.remove(key(KEY_EXPIRES_AT))
            legacy.remove(key(KEY_PENDING_SESSION_TOKEN))
            legacy.remove(key(KEY_EMAIL))
            legacy.remove(key(KEY_PENDING_EMAIL))
        }
    }

    companion object {
        const val LEGACY_ACCOUNT_ID = "legacy"
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_EXPIRES_AT = "expires_at"
        private const val KEY_PENDING_SESSION_TOKEN = "pending_session_token"
        private const val KEY_PENDING_EMAIL = "pending_email"
        private const val KEY_EMAIL = "email"
        private const val CLOCK_SKEW_TOLERANCE_SECONDS = 60L

        fun sanitizeAccountId(accountId: String): String =
            accountId.lowercase().map { if (it in 'a'..'z' || it in '0'..'9') it else '_' }.joinToString("")
    }
}
