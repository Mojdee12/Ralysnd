package com.kunk.singbox.foxy

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kunk.singbox.foxy.data.FxaAuthRepository
import com.kunk.singbox.foxy.data.FoxyAccountRegistry
import com.kunk.singbox.foxy.data.GuardianClient
import com.kunk.singbox.foxy.data.ServerListClient
import com.kunk.singbox.foxy.data.TokenStore
import com.kunk.singbox.foxy.data.ProxyStateStore
import com.kunk.singbox.foxy.vpn.FoxyVpnService
import com.kunk.singbox.foxy.data.model.Entitlement
import com.kunk.singbox.foxy.data.model.ProxyCandidate
import com.kunk.singbox.foxy.data.model.VpnCountry
import com.kunk.singbox.foxy.vpn.PingUtil
import com.kunk.singbox.viewmodel.DashboardViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * FENIX (Foxy) ViewModel for Ralysnd — MULTI-ACCOUNT.
 *
 * Auth + server list + quota + ping are FoxyVPN's actual flow (MIT, Vauth):
 * Firefox-account email+password sign-in via FxaAuthRepository (PBKDF2 authPW,
 * FxA OAuth, client_id from FoxyVPN), Guardian proxy pass + account status
 * via GuardianClient, country list via Mozilla Remote Settings via
 * ServerListClient, TCP ping via PingUtil.
 *
 * MULTI-ACCOUNT: every Firefox account keeps its own tokens under
 * per-account [TokenStore] keys (see TokenStore + [FoxyAccountRegistry]);
 * the registry holds only account ids (emails) and the active id. The
 * aggregate volume shown in the UI is the SUM of each signed-in account's
 * Guardian quota (quotaRemaining where reported, else maxBytes); an
 * account whose API reports neither contributes nothing and is counted
 * in [FoxyUiState.accountsWithoutQuota] — its card says
 * "Quota unavailable", never a fake number. The pre-multi-account
 * sign-in is migrated as the first account (id "legacy" when its email
 * was never recorded) and is never deleted by migration.
 *
 * CONNECTION PATH — FULL FOXY TUNNEL (no HTTP-outbound fallback):
 * connectSelected() saves the chosen country candidate into ProxyStateStore
 * (the store FoxyVpnService.connect() reads), stops KunBox's sing-box VPN
 * if it is running (Android allows only one active VpnService), then starts
 * FoxyVpnService, which reads the ACTIVE account from the registry and
 * mints that account's Guardian proxy pass, opening a Netty HTTP/2 CONNECT
 * to the Fastly edge with `proxy-authorization: Bearer <pass>`.
 */

/** One signed-in Firefox account, shown in the UI by EMAIL TEXT ONLY (never a photo). */
data class FoxyAccount(
    /** Registry id: normalised email, or "legacy" for the migrated account. */
    val id: String,
    /** Email text to display; empty when the migrated account's email was never recorded. */
    val displayEmail: String,
    val entitlement: Entitlement?,
    val isActive: Boolean,
)

data class FoxyUiState(
    val signedIn: Boolean = false,
    val needsTwoFactor: Boolean = false,
    val isLoading: Boolean = false,
    val isPinging: Boolean = false,
    val isConnecting: Boolean = false,
    /** Active account's entitlement (kept for callers that only need one account). */
    val entitlement: Entitlement? = null,
    val countries: List<VpnCountry> = emptyList(),
    val selected: ProxyCandidate? = null,
    val pingMs: Map<String, Int> = emptyMap(),
    val message: String? = null,
    /** All signed-in accounts (email text only). */
    val accounts: List<FoxyAccount> = emptyList(),
    /** Registry id of the active account (the one the tunnel uses). */
    val activeAccountId: String = "",
    /** Sum of quotaRemaining across accounts that report it; null if none report it. */
    val totalQuotaRemaining: Long? = null,
    /** Sum of maxBytes across accounts that report it; null if none report it. */
    val totalMaxBytes: Long? = null,
    /** Accounts whose API reported neither quotaRemaining nor maxBytes. */
    val accountsWithoutQuota: Int = 0,
    /** True while the login card is open to ADD another account (not replace). */
    val addingAccount: Boolean = false,
)

class FoxyViewModel(application: Application) : AndroidViewModel(application) {

    private val registry = FoxyAccountRegistry(application)
    private val guardian = GuardianClient()
    private val serverClient = ServerListClient(application)
    /** Live state of the Foxy tunnel service (for the FENIX tab's toggle). */
    val foxyState = FoxyVpnService.state

    private val _uiState = MutableStateFlow(FoxyUiState())
    val uiState: StateFlow<FoxyUiState> = _uiState.asStateFlow()

    private var pendingEmail: String = ""
    private var pendingRepo: FxaAuthRepository? = null

    private fun storeFor(accountId: String?): TokenStore {
        val id = accountId?.takeIf { it.isNotBlank() && it != FoxyAccountRegistry.LEGACY_ACCOUNT_ID }
        return TokenStore(getApplication(), id)
    }

    private fun repoFor(accountId: String?): FxaAuthRepository =
        FxaAuthRepository(storeFor(accountId))

    init {
        viewModelScope.launch {
            // Migrate the pre-multi-account sign-in as the first account.
            val legacyStore = TokenStore(getApplication())
            if (legacyStore.hasStoredSession()) {
                registry.migrateLegacyIfNeeded(legacyStore.loadEmail())
            }
            val accounts = registry.loadAccounts()
            if (accounts.isEmpty()) return@launch
            var active = registry.loadActive().takeIf { it.isNotBlank() } ?: accounts.first()
            if (active !in accounts) {
                active = accounts.first()
                registry.setActive(active)
            }
            // Restore each account's session; keep only accounts that still have one.
            val signedIn = accounts.filter { id ->
                runCatching { repoFor(id).restoreSession() }.getOrNull() ==
                    com.kunk.singbox.foxy.data.SessionStatus.ACTIVE
            }
            if (signedIn.isEmpty()) {
                _uiState.update { it.copy(signedIn = false) }
                return@launch
            }
            if (active !in signedIn) {
                active = signedIn.first()
                registry.setActive(active)
            }
            _uiState.update { it.copy(signedIn = true, activeAccountId = active) }
            refreshAccountAndCountries()
        }
    }

    /** Opens the login card in ADD mode (adds another account, never overwrites). */
    fun startAddingAccount() {
        _uiState.update { it.copy(addingAccount = true, needsTwoFactor = false, message = null) }
    }

    fun cancelAddingAccount() {
        _uiState.update { it.copy(addingAccount = false, needsTwoFactor = false) }
    }

    fun signIn(email: String, password: String) {
        val cleanEmail = FxaAuthRepository.normalizeEmail(email)
        val repo = repoFor(cleanEmail)
        pendingEmail = cleanEmail
        pendingRepo = repo
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, message = null) }
            val result = repo.startLogin(cleanEmail, password)
            result.onSuccess { needsCode ->
                if (needsCode) {
                    _uiState.update { it.copy(isLoading = false, needsTwoFactor = true) }
                } else {
                    finishSignIn(cleanEmail, repo)
                }
            }.onFailure { e ->
                _uiState.update { it.copy(isLoading = false, message = e.message ?: "Sign-in failed") }
            }
        }
    }

    fun submitTwoFactorCode(code: String) {
        val repo = pendingRepo ?: repoFor(pendingEmail)
        val email = pendingEmail
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, message = null) }
            val result = repo.submitTwoFactorCode(code)
            result.onSuccess {
                finishSignIn(email, repo)
            }.onFailure { e ->
                _uiState.update { it.copy(isLoading = false, message = e.message ?: "Verification failed") }
            }
        }
    }

    private suspend fun finishSignIn(email: String, repo: FxaAuthRepository) {
        runCatching { storeFor(email).saveEmail(email) }
        registry.addAccount(email)
        registry.setActive(email)
        pendingEmail = ""
        pendingRepo = null
        _uiState.update {
            it.copy(isLoading = false, signedIn = true, needsTwoFactor = false, addingAccount = false, activeAccountId = email)
        }
        refreshAccountAndCountries()
    }

    /** Signs out AND removes the active account (legacy single-account behaviour). */
    fun signOut() {
        val active = _uiState.value.activeAccountId
        if (active.isNotBlank()) removeAccount(active) else _uiState.update { FoxyUiState() }
    }

    /** Removes one account. Refused while the tunnel is running on it — stop it first via disconnect. */
    fun removeAccount(accountId: String) {
        viewModelScope.launch {
            val isActive = accountId == _uiState.value.activeAccountId
            if (isActive) {
                runCatching { FoxyVpnService.stop(getApplication()) }
            }
            runCatching { storeFor(accountId).clear() }
            registry.removeAccount(accountId)
            val remaining = registry.loadAccounts()
            if (remaining.isEmpty()) {
                _uiState.update { FoxyUiState() }
            } else {
                _uiState.update { it.copy(activeAccountId = registry.loadActive()) }
                refreshAccountAndCountries()
            }
        }
    }

    /** Switches the tunnel's account (takes effect on next connect; a running tunnel must be stopped first). */
    fun switchAccount(accountId: String) {
        registry.setActive(accountId)
        _uiState.update { it.copy(activeAccountId = accountId) }
        refreshAccountAndCountries()
    }

    fun refreshAccountAndCountries() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, message = null) }
            try {
                val ids = registry.loadAccounts()
                val active = registry.loadActive().takeIf { it.isNotBlank() } ?: ids.firstOrNull().orEmpty()
                val accounts = ids.map { id ->
                    val token = runCatching { repoFor(id).currentAccessToken() }.getOrNull()
                    val entitlement = if (token != null) {
                        runCatching {
                            guardian.fetchUserInfo(com.kunk.singbox.foxy.data.GUARDIAN_ENDPOINT_DEFAULT, token)
                        }.getOrNull()
                    } else null
                    val email = runCatching { storeFor(id).loadEmail() }.getOrNull()
                    FoxyAccount(
                        id = id,
                        displayEmail = email?.takeIf { it.isNotBlank() }
                            ?: if (id != FoxyAccountRegistry.LEGACY_ACCOUNT_ID) id else "",
                        entitlement = entitlement,
                        isActive = id == active,
                    )
                }
                val remainingValues = accounts.mapNotNull { it.entitlement?.quotaRemaining }
                val maxValues = accounts.mapNotNull { it.entitlement?.maxBytes }
                val withoutQuota = accounts.count { it.entitlement?.quotaRemaining == null && it.entitlement?.maxBytes == null }
                val countries = runCatching { serverClient.fetchCountries() }
                    .getOrElse { serverClient.loadCachedCountries() }
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        signedIn = accounts.isNotEmpty(),
                        accounts = accounts,
                        activeAccountId = active,
                        entitlement = accounts.firstOrNull { a -> a.isActive }?.entitlement,
                        totalQuotaRemaining = remainingValues.takeIf { list -> list.isNotEmpty() }?.sum(),
                        totalMaxBytes = maxValues.takeIf { list -> list.isNotEmpty() }?.sum(),
                        accountsWithoutQuota = withoutQuota,
                        countries = countries,
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoading = false, message = e.message ?: "Failed to load FENIX data") }
            }
        }
    }

    fun selectCountry(countryCode: String) {
        val candidates = ServerListClient.candidatesForCountry(_uiState.value.countries, countryCode)
        val first = candidates.firstOrNull()
        if (first != null) {
            _uiState.update { it.copy(selected = first, message = null) }
        } else {
            _uiState.update { it.copy(message = "No available servers for that country") }
        }
    }

    /** Ping all countries, publishing each result LIVE as it arrives (not only at the end). */
    fun pingAllCountries() {
        viewModelScope.launch {
            _uiState.update { it.copy(isPinging = true) }
            try {
                withContext(Dispatchers.IO) {
                    for (country in _uiState.value.countries) {
                        val candidate = ServerListClient.candidatesForCountry(
                            _uiState.value.countries, country.code,
                        ).firstOrNull() ?: continue
                        val ms = PingUtil.measureTcpLatencyMs(candidate.host, candidate.port)
                        if (ms != null) {
                            _uiState.update { it.copy(pingMs = it.pingMs + (country.code to ms)) }
                        }
                    }
                }
            } finally {
                _uiState.update { it.copy(isPinging = false) }
            }
        }
    }

    fun fastestCountry(): VpnCountry? {
        val pings = _uiState.value.pingMs
        if (pings.isEmpty()) return null
        val code = pings.minByOrNull { it.value }?.key ?: return null
        return _uiState.value.countries.firstOrNull { it.code.equals(code, ignoreCase = true) }
    }

    /**
     * Connect via the FULL Foxy tunnel. Caller (FenixScreen) must have
     * already ensured VpnService.prepare() is granted for this app (the
     * Dashboard permission flow grants it app-wide); this function only
     * starts the service. Steps: save the selected candidate where
     * FoxyVpnService.connect() reads it, stop sing-box if running, then
     * start FoxyVpnService. The service reads the ACTIVE account from
     * the registry, mints that account's Guardian proxy pass and dials
     * the Fastly edge with Bearer auth on an H2 CONNECT.
     */
    fun connectSelected(context: android.content.Context, dashboardViewModel: DashboardViewModel) {
        val selected = _uiState.value.selected
        if (selected == null) {
            _uiState.update { it.copy(message = "Pick a country first") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isConnecting = true, message = null) }
            try {
                val dashState = dashboardViewModel.connectionState.value
                if (dashState == com.kunk.singbox.model.ConnectionState.Connected ||
                    dashState == com.kunk.singbox.model.ConnectionState.Connecting
                ) {
                    dashboardViewModel.toggleConnection()
                    delay(700)
                }
                ProxyStateStore(context).save(selected)
                FoxyVpnService.start(context)
                _uiState.update {
                    it.copy(
                        isConnecting = false,
                        message = "FENIX connecting via the Foxy tunnel to ${selected.countryName}",
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isConnecting = false, message = e.message ?: "Connect failed") }
            }
        }
    }

    /** Disconnect the Foxy tunnel (does not touch sing-box). */
    fun disconnectFenix(context: android.content.Context) {
        FoxyVpnService.stop(context)
    }
}
