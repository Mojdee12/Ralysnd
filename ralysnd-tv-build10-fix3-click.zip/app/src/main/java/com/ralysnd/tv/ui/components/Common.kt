package com.ralysnd.tv.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.data.ChannelRepository
import com.ralysnd.tv.data.SettingsStore
import com.ralysnd.tv.player.PlayerFactory
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors

/**
 * Shared building blocks for the green-split style. Every screen uses these
 * so the look is identical everywhere: dark surface cards, emerald focus
 * border, red LIVE badge, logo + name channel rows.
 */

/**
 * One shared Coil loader for channel logos: disk cache (100 MB under the
 * app cache dir) + memory cache (25% of available memory), so a logo is
 * downloaded once and every later row/tile/rail reuses it instead of
 * re-fetching over a slow connection. Built lazily and cached per process.
 */
object LogoImageLoader {
    @Volatile
    private var instance: ImageLoader? = null

    fun get(context: android.content.Context): ImageLoader =
        instance ?: synchronized(this) {
            instance ?: ImageLoader.Builder(context)
                .memoryCache {
                    MemoryCache.Builder(context)
                        .maxSizePercent(0.25)
                        .build()
                }
                .diskCache {
                    DiskCache.Builder()
                        .directory(context.cacheDir.resolve("coil_logos"))
                        .maxSizeBytes(100L * 1024L * 1024L)
                        .build()
                }
                .respectCacheHeaders(false)
                .build()
                .also { instance = it }
        }
}

/** Red LIVE pill, as on the home preview and the focused channel row. */
@Composable
fun LiveBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(RalysndTvColors.LiveRed, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "● LIVE",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}

/** Small VPN pill: marks channels the source app flags as needing a VPN
 *  to play. Only the 13 explicitly flagged channels carry it — nothing
 *  is inferred. Shown on rows, tiles and in the player. */
@Composable
fun VpnBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .border(
                width = 1.dp,
                color = RalysndTvColors.GreenPrimary,
                RoundedCornerShape(8.dp),
            )
            .background(RalysndTvColors.SurfaceElevated, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "VPN",
            color = RalysndTvColors.GreenPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}

/** Channel logo: remote image when present, initial letter on a green tile when not.
 * 280 of the 1,097 channels ship without a logo, so the fallback is part of the design.
 * Logos that fail to load (e.g. blocked hosts) fall back to the letter tile too —
 * never a blank white box. Logos go through the shared cached loader, requested
 * at 192px (covers the largest 84dp tile) so a logo is fetched once, downsampled
 * once, and reused from cache everywhere it appears. */
@Composable
fun ChannelLogo(channel: Channel, modifier: Modifier = Modifier) {
    var loadFailed by remember(channel.logo) { mutableStateOf(false) }
    if (channel.logo.isNotBlank() && !loadFailed) {
        val context = LocalContext.current
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(channel.logo)
                .size(192)
                .memoryCachePolicy(CachePolicy.ENABLED)
                .diskCachePolicy(CachePolicy.ENABLED)
                .build(),
            imageLoader = LogoImageLoader.get(context),
            contentDescription = channel.name,
            contentScale = ContentScale.Fit,
            onError = { loadFailed = true },
            modifier = modifier
                .clip(RoundedCornerShape(8.dp))
                .background(RalysndTvColors.SurfaceElevated),
        )
    } else {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(8.dp))
                .background(RalysndTvColors.GreenDark),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = channel.name.firstOrNull()?.uppercase() ?: "•",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
        }
    }
}

/**
 * A D-pad focusable card. Focused state gets the emerald border + slight
 * surface lift used across all mockups; unfocused state is the plain dark card.
 * Focused cards also pop slightly (1.04x), as in the Stitch model — a small
 * scale so the focused card reads at 10 feet without moving its neighbours.
 */
@Composable
fun FocusableCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onFocus: () -> Unit = {},
    content: @Composable () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.04f else 1f,
        label = "focusPop",
    )
    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .border(
                BorderStroke(
                    width = if (focused) 3.dp else 1.dp,
                    color = if (focused) RalysndTvColors.GreenPrimary
                    else RalysndTvColors.SurfaceElevated,
                ),
                RoundedCornerShape(16.dp),
            )
            .background(
                if (focused) RalysndTvColors.SurfaceElevated
                else RalysndTvColors.Surface,
                RoundedCornerShape(16.dp),
            )
            .focusable(interactionSource = interactionSource)
            .onFocusChanged { if (it.isFocused) onFocus() }
            .clickable(interactionSource = interactionSource, indication = null) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

/** One channel row: logo + name (+ LIVE badge when it is the playing channel). */
@Composable
fun ChannelRow(
    channel: Channel,
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FocusableCard(
        onClick = onClick,
        modifier = modifier,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            ChannelLogo(channel, Modifier.size(48.dp))
            Spacer(Modifier.width(14.dp))
            Text(
                text = channel.name,
                color = RalysndTvColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = RalysndFontFamily,
                modifier = Modifier.weight(1f),
            )
            if (channel.needsVpn) {
                VpnBadge()
                Spacer(Modifier.width(8.dp))
            }
            if (isPlaying) LiveBadge()
        }
    }
}

/** Bottom D-pad hint bar, as on the home mockup. */
@Composable
fun DpadHint(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = RalysndTvColors.TextMuted,
        fontSize = 16.sp,
        fontFamily = RalysndFontFamily,
        textAlign = TextAlign.Center,
        modifier = modifier,
    )
}

/**
 * Muted live preview of a channel. A SINGLE player instance per screen:
 * switching the channel only swaps its media item, the player is never
 * recreated per selection. Released when the hosting screen leaves.
 * Shared by Home and Favorites (both show a live hero preview).
 * The hero is a wide banner, so the video zooms to fill it instead of
 * letterboxing.
 *
 * The channel's own HTTP headers go with the stream (P1): some hosts
 * 403 without their Referer. On error the next source of the same
 * channel is tried, like the full player (P7); when every source has
 * failed the player stops and the hero shows the channel's logo tile
 * instead of a black box. During the 300ms selection debounce the
 * preview is null and the player pauses, keeping its last frame instead
 * of playing the previous channel on.
 */
@Composable
fun MutedPreviewPlayer(
    channel: Channel?,
    settings: SettingsStore,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val player = remember {
        PlayerFactory.create(context, settings).apply { volume = 0f }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    // Latest channel for the error listener (created once).
    val channelState = rememberUpdatedState(channel)
    var urlIndex by remember { mutableIntStateOf(0) }
    var failed by remember { mutableStateOf(false) }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val current = channelState.value ?: return
                if (urlIndex + 1 < current.sources.size) {
                    urlIndex += 1
                    player.replaceMediaItem(
                        0,
                        PlayerFactory.mediaItemFor(
                            current.sources[urlIndex].url,
                            current.sources[urlIndex].headers,
                        ),
                    )
                    player.prepare()
                    player.play()
                } else {
                    player.stop()
                    failed = true
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(channel) {
        urlIndex = 0
        failed = false
        val current = channel
        if (current == null) {
            player.pause()
            return@LaunchedEffect
        }
        val url = current.primaryUrl ?: return@LaunchedEffect
        player.setMediaItem(PlayerFactory.mediaItemFor(url, current.headers))
        player.prepare()
        player.play()
    }
    if (failed && channel != null) {
        Box(
            modifier = modifier.background(Color.Black),
            contentAlignment = Alignment.Center,
        ) {
            ChannelLogo(channel, Modifier.size(180.dp))
        }
    } else {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                }
            },
            modifier = modifier,
        )
    }
}

/**
 * 16:9 poster card from the Stitch model: a wide logo area on top (the
 * channel logo, or the green letter tile when the channel has none) and
 * the channel name below. No poster art exists for real channels, so the
 * logo area is the logo itself — never an invented image. The selected
 * card (the hero's channel) also shows LIVE.
 */
@Composable
fun ChannelPosterCard(
    channel: Channel,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onFocus: () -> Unit = {},
) {
    FocusableCard(
        onClick = onClick,
        modifier = modifier,
        onFocus = onFocus,
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(RalysndTvColors.SurfaceElevated),
                contentAlignment = Alignment.Center,
            ) {
                ChannelLogo(channel, Modifier.fillMaxSize())
                if (selected) {
                    LiveBadge(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp),
                    )
                }
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
            ) {
                Text(
                    text = channel.name,
                    color = RalysndTvColors.TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = RalysndFontFamily,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                if (channel.needsVpn) {
                    Spacer(Modifier.width(8.dp))
                    VpnBadge()
                }
            }
        }
    }
}

/**
 * Pill toggle for favorites (hero and player): filled green with a solid
 * star when the channel is a favorite, dark with an outline star when not.
 * Disabled when there is no channel to favorite (S10).
 */
@Composable
fun FavoriteToggleButton(
    isFavorite: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = modifier
            .border(
                width = if (focused) 3.dp else 0.dp,
                color = if (focused) Color.White else Color.Transparent,
                RoundedCornerShape(24.dp),
            )
            .background(
                if (isFavorite) RalysndTvColors.GreenPrimary
                else RalysndTvColors.SurfaceElevated,
                RoundedCornerShape(24.dp),
            )
            .focusable(enabled, interactionSource)
            .clickable(enabled = enabled, interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 20.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = if (isFavorite) "★ Favorite" else "☆ Favorite",
            color = if (isFavorite) Color.Black else Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}

/**
 * Shared hero bottom strip (S5): LIVE badge + channel name + category +
 * favorite toggle + Watch button, over a frosted dark strip. Used by Home
 * and Favorites so the hero looks identical on both screens.
 */
@Composable
fun HeroOverlay(
    channel: Channel?,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    onWatch: () -> Unit,
    watchFocusRequester: FocusRequester? = null,
    modifier: Modifier = Modifier,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .background(RalysndTvColors.Background.copy(alpha = 0.78f))
            .padding(horizontal = 20.dp, vertical = 14.dp),
    ) {
        LiveBadge()
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = channel?.name ?: "",
                    color = Color.White,
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RalysndFontFamily,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (channel?.needsVpn == true) {
                    Spacer(Modifier.width(12.dp))
                    VpnBadge()
                }
            }
            Text(
                text = categoryLabel(
                    channel?.categories?.firstOrNull()
                        ?: ChannelRepository.CATEGORY_ALL,
                ),
                color = RalysndTvColors.TextMuted,
                fontSize = 16.sp,
                fontFamily = RalysndFontFamily,
            )
        }
        Spacer(Modifier.width(16.dp))
        FavoriteToggleButton(
            isFavorite = isFavorite,
            enabled = channel != null,
            onClick = onToggleFavorite,
        )
        Spacer(Modifier.width(12.dp))
        WatchButton(
            enabled = channel != null,
            onClick = onWatch,
            focusRequester = watchFocusRequester,
        )
    }
}

/** Green Watch pill, as on the home and favorites heroes. */
@Composable
fun WatchButton(
    enabled: Boolean,
    onClick: () -> Unit,
    focusRequester: FocusRequester? = null,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = modifier
            .border(
                width = if (focused) 3.dp else 0.dp,
                color = if (focused) Color.White else Color.Transparent,
                RoundedCornerShape(24.dp),
            )
            .background(RalysndTvColors.GreenPrimary, RoundedCornerShape(24.dp))
            .then(
                if (focusRequester != null) Modifier.focusRequester(focusRequester)
                else Modifier,
            )
            .focusable(enabled, interactionSource)
            .clickable(enabled = enabled, interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 24.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "▶ Watch",
            color = Color.Black,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}

/** Display names for category keys (L5/S7): proper title case, not just
 *  a capitalized first letter ("Movies & Series", not "Movies & series").
 *  Unknown keys fall back to a capitalized first letter. */
private val CATEGORY_DISPLAY_NAMES = mapOf(
    "all" to "All",
    "general" to "General",
    "movies & series" to "Movies & Series",
    "kids & teens" to "Kids & Teens",
    "gem tv networks" to "GEM TV Networks",
    "national" to "National",
    "international" to "International",
    "regional" to "Regional",
    "telewebion" to "Telewebion",
    "persiana" to "Persiana",
    "entertainment" to "Entertainment",
    "sports" to "Sports",
    "music" to "Music",
    "documentary" to "Documentary",
    "arabic" to "Arabic",
    "turkish" to "Turkish",
    "kurdish" to "Kurdish",
    "news" to "News",
)

/** Display label for a category key ("all" -> "All", "general" -> "General", ...). */
fun categoryLabel(category: String): String =
    CATEGORY_DISPLAY_NAMES[category] ?: category.replaceFirstChar { it.uppercase() }
