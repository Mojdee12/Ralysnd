package com.kunk.singbox.engines

import android.util.Base64
import java.security.KeyPairGenerator
import java.security.SecureRandom
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Fresh Cloudflare WARP client — written from the public WARP
 * registration API, NOT copied from any other app.
 *
 * Flow: generate an X25519 keypair on-device, register it with
 * Cloudflare's WARP API, persist the returned identity, and build a
 * standard sing-box `wireguard://` link that the app's existing node
 * path (NodesViewModel.addNode) can add and connect like any other
 * WireGuard node. No Cloudflare account of the user is needed: WARP
 * registration is anonymous (an install id + a fresh keypair).
 *
 * Public, documented constants used here:
 * - Registration endpoint: api.cloudflareclient.com, API version v0a2482.
 * - WARP edge endpoint: engage.cloudflareclient.com:2408.
 * - WARP server public key (published by Cloudflare's own clients):
 *   bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo=
 * - WARP local address: 172.16.0.2/32, MTU 1280.
 */
object WarpClient {
    private const val REGISTER_URL = "https://api.cloudflareclient.com/v0a2482/reg"
    const val WARP_ENDPOINT_HOST = "engage.cloudflareclient.com"
    const val WARP_ENDPOINT_PORT = 2408
    const val WARP_SERVER_PUBLIC_KEY = "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo="
    const val WARP_LOCAL_ADDRESS = "172.16.0.2/32"
    const val WARP_MTU = 1280

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    data class KeyPair(val privateKeyBase64: String, val publicKeyBase64: String)

    /**
     * Generates an X25519 keypair via the platform provider and
     * extracts the raw 32-byte keys (last 32 bytes of the PKCS#8 /
     * SubjectPublicKeyInfo encodings), base64-encoded as WireGuard
     * expects. Throws if the platform cannot generate X25519 keys —
     * callers must surface that error, never substitute a fake key.
     */
    fun generateKeyPair(): KeyPair {
        val generator = KeyPairGenerator.getInstance("X25519")
        generator.initialize(256, SecureRandom())
        val pair = generator.generateKeyPair()
        val privateRaw = pair.private.encoded.takeLast(32).toByteArray()
        val publicRaw = pair.public.encoded.takeLast(32).toByteArray()
        require(privateRaw.size == 32 && publicRaw.size == 32) {
            "Unexpected X25519 key encoding length"
        }
        return KeyPair(
            privateKeyBase64 = Base64.encodeToString(privateRaw, Base64.NO_WRAP),
            publicKeyBase64 = Base64.encodeToString(publicRaw, Base64.NO_WRAP),
        )
    }

    /** Registers [keyPair] with Cloudflare and returns the identity. */
    suspend fun register(keyPair: KeyPair): WarpIdentity = withContext(Dispatchers.IO) {
        val bodyJson = JSONObject().apply {
            put("install_id", UUID.randomUUID().toString())
            put("key", keyPair.publicKeyBase64)
            put("fcm_token", "")
            put("tos", "2026-01-01T00:00:00.000+00:00")
            put("model", "Android")
            put("locale", "en_US")
        }.toString()
        val request = Request.Builder()
            .url(REGISTER_URL)
            .post(bodyJson.toRequestBody("application/json".toMediaType()))
            .header("User-Agent", "okhttp/5.4.0")
            .build()
        val response = http.newCall(request).execute()
        response.use {
            val text = it.body?.string().orEmpty()
            if (!it.isSuccessful) {
                throw IllegalStateException("WARP registration failed: HTTP ${it.code}")
            }
            val json = JSONObject(text)
            val id = json.optString("id").takeIf { s -> s.isNotBlank() }
                ?: throw IllegalStateException("WARP registration returned no account id")
            val token = json.optString("token")
            val config = json.optJSONObject("config")
            val clientId = config?.optJSONObject("client_id")
            val reserved = mutableListOf<Int>()
            if (clientId != null) {
                // client_id is base64 of 3 reserved bytes.
                val decoded = runCatching {
                    Base64.decode(clientId.optString("bytes", ""), Base64.DEFAULT)
                }.getOrNull()
                if (decoded != null && decoded.size >= 3) {
                    reserved.addAll(decoded.take(3).map { b -> b.toInt() and 0xFF })
                }
            }
            WarpIdentity(
                accountId = id,
                token = token,
                privateKeyBase64 = keyPair.privateKeyBase64,
                publicKeyBase64 = keyPair.publicKeyBase64,
                reserved = reserved,
                registeredAtMs = System.currentTimeMillis(),
            )
        }
    }

    /**
     * Builds the sing-box `wireguard://` link for a registered WARP
     * identity, in the exact shape NodeLinkParser.parseWireGuardLink
     * accepts (private key as user-info, public_key / local_address /
     * mtu / reserved as query parameters, name as fragment).
     */
    fun buildWireGuardLink(identity: WarpIdentity): String {
        val params = StringBuilder()
        params.append("public_key=").append(WARP_SERVER_PUBLIC_KEY)
        params.append("&local_address=").append("172.16.0.2%2F32")
        params.append("&mtu=").append(WARP_MTU)
        params.append("&persistent_keepalive_interval=25")
        if (identity.reserved.isNotEmpty()) {
            params.append("&reserved=").append(identity.reserved.joinToString("%2C"))
        }
        return "wireguard://${identity.privateKeyBase64}@$WARP_ENDPOINT_HOST:$WARP_ENDPOINT_PORT" +
            "?$params#WARP"
    }

    /**
     * Builds a sing-box JSON profile for WARP² (WireGuard inside
     * WARP): a WARP endpoint plus an inner WireGuard endpoint whose
     * traffic detours through it, MTU 1220 (double encapsulation).
     * The JSON is offered to the user to import as a JSON profile —
     * the detour chain cannot be expressed as a single wireguard://
     * link, so it is NOT silently added as a plain node.
     */
    fun buildWarp2ProfileJson(
        warpIdentity: WarpIdentity,
        innerHost: String,
        innerPort: Int,
        innerPublicKey: String,
        innerPrivateKeyBase64: String,
    ): String {
        val reservedJson = warpIdentity.reserved.joinToString(",")
        return """
        {
          "endpoints": [
            {
              "type": "wireguard",
              "tag": "warp",
              "address": ["${WARP_LOCAL_ADDRESS}"],
              "private_key": "${warpIdentity.privateKeyBase64}",
              "peers": [
                {
                  "address": "$WARP_ENDPOINT_HOST",
                  "port": $WARP_ENDPOINT_PORT,
                  "public_key": "$WARP_SERVER_PUBLIC_KEY",
                  "allowed_ips": ["0.0.0.0/0", "::/0"],
                  "persistent_keepalive_interval": 25,
                  "reserved": [$reservedJson]
                }
              ],
              "mtu": $WARP_MTU
            },
            {
              "type": "wireguard",
              "tag": "warp2-inner",
              "detour": "warp",
              "address": ["172.16.0.3/32"],
              "private_key": "$innerPrivateKeyBase64",
              "peers": [
                {
                  "address": "$innerHost",
                  "port": $innerPort,
                  "public_key": "$innerPublicKey",
                  "allowed_ips": ["0.0.0.0/0", "::/0"],
                  "persistent_keepalive_interval": 25
                }
              ],
              "mtu": 1220
            }
          ],
          "route": { "final": "warp2-inner" }
        }
        """.trimIndent()
    }
}
