package com.kunk.singbox.engines

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

/**
 * ViewModel for the new engines (WARP, WARP², MASQUE, Psiphon) and
 * their scanners. All state here is measured or user-supplied:
 * no invented gateways, servers, latencies, or quotas.
 *
 * Single-VpnService rule is preserved by construction: none of
 * these engines starts its own VpnService. WARP/WARP² produce
 * sing-box nodes/profiles that run through the existing sing-box
 * service; MASQUE/Psiphon do not connect at all until their cores
 * land (see MasqueEngine / PsiphonEngine notes).
 */
class EnginesViewModel(application: Application) : AndroidViewModel(application) {
    private val context: Context
        get() = getApplication<Application>().applicationContext

    private val warpStore by lazy { WarpIdentityStore(context) }
    private val masqueEngine by lazy { MasqueEngine(context) }
    private val psiphonEngine by lazy { PsiphonEngine(context) }

    // ---- WARP ----
    private val _warpIdentity = MutableStateFlow<WarpIdentity?>(null)
    val warpIdentity: StateFlow<WarpIdentity?> = _warpIdentity.asStateFlow()
    private val _warpBusy = MutableStateFlow(false)
    val warpBusy: StateFlow<Boolean> = _warpBusy.asStateFlow()
    private val _warpError = MutableStateFlow<String?>(null)
    val warpError: StateFlow<String?> = _warpError.asStateFlow()
    /** Fresh wireguard:// link for the registered WARP identity, if any. */
    private val _warpLink = MutableStateFlow<String?>(null)
    val warpLink: StateFlow<String?> = _warpLink.asStateFlow()

    // ---- MASQUE scan ----
    private val _masqueResults = MutableStateFlow<List<ScanResult>>(emptyList())
    val masqueResults: StateFlow<List<ScanResult>> = _masqueResults.asStateFlow()
    private val _masqueScanning = MutableStateFlow(false)
    val masqueScanning: StateFlow<Boolean> = _masqueScanning.asStateFlow()
    val masqueWinner: String?
        get() = masqueEngine.cachedWinner

    // ---- WARP² scan ----
    private val _warp2Results = MutableStateFlow<List<ScanResult>>(emptyList())
    val warp2Results: StateFlow<List<ScanResult>> = _warp2Results.asStateFlow()
    private val _warp2Scanning = MutableStateFlow(false)
    val warp2Scanning: StateFlow<Boolean> = _warp2Scanning.asStateFlow()

    // ---- Psiphon ----
    private val _psiphonSummary = MutableStateFlow<PsiphonListSummary?>(null)
    val psiphonSummary: StateFlow<PsiphonListSummary?> = _psiphonSummary.asStateFlow()
    private val _psiphonBusy = MutableStateFlow(false)
    val psiphonBusy: StateFlow<Boolean> = _psiphonBusy.asStateFlow()
    private val _psiphonError = MutableStateFlow<String?>(null)
    val psiphonError: StateFlow<String?> = _psiphonError.asStateFlow()
    private val _psiphonProbeResults = MutableStateFlow<List<ScanResult>>(emptyList())
    val psiphonProbeResults: StateFlow<List<ScanResult>> = _psiphonProbeResults.asStateFlow()

    init {
        _warpIdentity.value = warpStore.load()
        _warpIdentity.value?.let { _warpLink.value = WarpClient.buildWireGuardLink(it) }
        _psiphonSummary.value = psiphonEngine.cachedSummary()
    }

    /** Registers a fresh WARP identity and publishes its node link. */
    fun registerWarp() {
        if (_warpBusy.value) return
        viewModelScope.launch {
            _warpBusy.value = true
            _warpError.value = null
            try {
                val keyPair = WarpClient.generateKeyPair()
                val identity = WarpClient.register(keyPair)
                warpStore.save(identity)
                _warpIdentity.value = identity
                _warpLink.value = WarpClient.buildWireGuardLink(identity)
            } catch (e: Exception) {
                _warpError.value = e.message ?: "WARP registration failed"
            } finally {
                _warpBusy.value = false
            }
        }
    }

    fun clearWarpError() {
        _warpError.value = null
    }

    /** Scans MASQUE candidates live; caches the fastest reachable winner. */
    fun scanMasque(input: String) {
        val targets = EngineScanner.parseTargets(input)
        if (targets.isEmpty() || _masqueScanning.value) return
        viewModelScope.launch {
            _masqueScanning.value = true
            _masqueResults.value = emptyList()
            try {
                val collected = mutableListOf<ScanResult>()
                EngineScanner.scan(targets).collect { result ->
                    collected.add(result)
                    _masqueResults.value = EngineScanner.fastestFirst(collected)
                }
                collected.firstOrNull { it.reachable }?.let { winner ->
                    masqueEngine.setManualEndpoint(winner.target.label)
                }
            } finally {
                _masqueScanning.value = false
            }
        }
    }

    fun setMasqueManualEndpoint(endpoint: String) {
        masqueEngine.setManualEndpoint(endpoint)
    }

    /**
     * Scans WARP² inner candidates: TCP reachability of each inner
     * host plus the outer WARP edge RTT (engage host). A TCP probe
     * cannot prove a WireGuard handshake — the UI labels it as
     * reachability only, and the winner is cached as a candidate,
     * not as a proven tunnel.
     */
    fun scanWarp2(input: String) {
        val targets = EngineScanner.parseTargets(input, defaultPort = 51820)
        if (targets.isEmpty() || _warp2Scanning.value) return
        viewModelScope.launch {
            _warp2Scanning.value = true
            _warp2Results.value = emptyList()
            try {
                val collected = mutableListOf<ScanResult>()
                EngineScanner.scan(targets).collect { result ->
                    collected.add(result)
                    _warp2Results.value = EngineScanner.fastestFirst(collected)
                }
            } finally {
                _warp2Scanning.value = false
            }
        }
    }

    /** Fetches the public Psiphon server list and caches its summary. */
    fun fetchPsiphonList() {
        if (_psiphonBusy.value) return
        viewModelScope.launch {
            _psiphonBusy.value = true
            _psiphonError.value = null
            try {
                _psiphonSummary.value = psiphonEngine.fetchServerList()
            } catch (e: Exception) {
                _psiphonError.value = e.message ?: "Psiphon list download failed"
            } finally {
                _psiphonBusy.value = false
            }
        }
    }

    /** Probes a sample of servers from the fetched Psiphon list (TCP 443). */
    fun probePsiphonSample() {
        val ips = _psiphonSummary.value?.sampleIps.orEmpty()
        if (ips.isEmpty()) return
        viewModelScope.launch {
            _psiphonProbeResults.value = emptyList()
            val collected = mutableListOf<ScanResult>()
            EngineScanner.scan(ips.map { ScanTarget(it, it, 443) }).collect { result ->
                collected.add(result)
                _psiphonProbeResults.value = EngineScanner.fastestFirst(collected)
            }
        }
    }

    /** WARP² detour profile JSON for the registered identity + inner server. */
    fun buildWarp2ProfileJson(
        innerHost: String,
        innerPort: Int,
        innerPublicKey: String,
        innerPrivateKeyBase64: String,
    ): String? {
        val identity = _warpIdentity.value ?: return null
        return WarpClient.buildWarp2ProfileJson(
            warpIdentity = identity,
            innerHost = innerHost,
            innerPort = innerPort,
            innerPublicKey = innerPublicKey,
            innerPrivateKeyBase64 = innerPrivateKeyBase64,
        )
    }
}
