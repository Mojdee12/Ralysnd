package com.kunk.singbox.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kunk.singbox.engines.ENGINE_GRID
import com.kunk.singbox.engines.EngineId
import com.kunk.singbox.engines.EnginesViewModel
import com.kunk.singbox.ui.navigation.Screen
import com.kunk.singbox.ui.theme.L4EngineTile
import com.kunk.singbox.ui.theme.L4Green
import com.kunk.singbox.ui.theme.L4PastelAmber
import com.kunk.singbox.ui.theme.L4PastelCyan
import com.kunk.singbox.ui.theme.L4PastelOrange
import com.kunk.singbox.ui.theme.L4PastelRose
import com.kunk.singbox.ui.theme.L4PastelSlate
import com.kunk.singbox.ui.theme.L4PastelViolet
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim

/**
 * Home engine grid (mlm-style, sample-4 light tiles) + per-engine
 * sheets. Only wanted engines appear here — no rejected engine has
 * a tile, placeholder, or reserved space.
 *
 * Wiring (honest):
 * - WireGuard -> Nodes screen (existing nodes).
 * - FENIX -> FENIX tab (existing Foxy tunnel).
 * - WARP -> register + add as a real sing-box WireGuard node.
 * - WARP² -> WARP identity + inner node (MTU 1220) + a copyable
 *   detour profile JSON (the detour chain itself is a manual JSON
 *   profile import, not a silent fake node).
 * - MASQUE -> gateway discovery + cached winner (live connect
 *   needs a QUIC core — stated in the sheet, no connect button).
 * - Psiphon -> public server list + regions + sample probes
 *   (live connect needs the official Go core — stated, no button).
 */
@Composable
fun EngineGridSection(
    onNavigate: (String) -> Unit,
    onAddNode: (String) -> Unit,
    onOpenScanner: () -> Unit,
    enginesViewModel: EnginesViewModel = viewModel(),
) {
    var sheet by remember { mutableStateOf<EngineId?>(null) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = "Engines", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = L4Text)
            TextButton(onClick = onOpenScanner) { Text("Scanner", color = L4Green) }
        }
        for (row in ENGINE_GRID.chunked(2)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (engine in row) {
                    L4EngineTile(
                        title = engine.title,
                        subtitle = engine.statusNote,
                        pastel = when (engine.id) {
                            EngineId.MASQUE -> L4PastelCyan
                            EngineId.WARP2 -> L4PastelAmber
                            EngineId.PSIPHON -> L4PastelRose
                            EngineId.WIREGUARD -> L4PastelSlate
                            EngineId.FENIX -> L4PastelViolet
                            EngineId.WARP -> L4PastelOrange
                        },
                        badge = engine.badge,
                        enabled = true,
                        onClick = {
                            when (engine.id) {
                                EngineId.WIREGUARD -> onNavigate(Screen.Nodes.route)
                                EngineId.FENIX -> onNavigate(Screen.Fenix.route)
                                else -> sheet = engine.id
                            }
                        },
                        modifier = Modifier.weight(1f),
                    )
                }
                if (row.size == 1) Spacer(modifier = Modifier.weight(1f))
            }
        }
    }

    when (sheet) {
        EngineId.WARP -> WarpSheet(enginesViewModel = enginesViewModel, onAddNode = onAddNode, onDismiss = { sheet = null })
        EngineId.WARP2 -> Warp2Sheet(enginesViewModel = enginesViewModel, onAddNode = onAddNode, onDismiss = { sheet = null })
        EngineId.MASQUE -> MasqueSheet(enginesViewModel = enginesViewModel, onDismiss = { sheet = null })
        EngineId.PSIPHON -> PsiphonSheet(enginesViewModel = enginesViewModel, onDismiss = { sheet = null })
        else -> Unit
    }
}

@Composable
private fun WarpSheet(
    enginesViewModel: EnginesViewModel,
    onAddNode: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val identity by enginesViewModel.warpIdentity.collectAsStateWithLifecycle()
    val busy by enginesViewModel.warpBusy.collectAsStateWithLifecycle()
    val error by enginesViewModel.warpError.collectAsStateWithLifecycle()
    val link by enginesViewModel.warpLink.collectAsStateWithLifecycle()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("WARP", color = L4Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (identity == null) {
                    Text(
                        text = "Register an anonymous WARP identity with Cloudflare, then add it as a WireGuard node (MTU 1280). No account needed.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                    if (error != null) Text(text = error ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    Button(
                        onClick = { enginesViewModel.registerWarp() },
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                    ) { Text(if (busy) "Registering…" else "Register WARP") }
                } else {
                    Text(
                        text = "Registered (id ${identity!!.accountId.take(8)}…). Add it as a node and connect it from the Dashboard like any WireGuard node.",
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                    Button(
                        onClick = { link?.let { onAddNode(it) }; onDismiss() },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                    ) { Text("Add WARP node") }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun Warp2Sheet(
    enginesViewModel: EnginesViewModel,
    onAddNode: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    val context = LocalContext.current
    val identity by enginesViewModel.warpIdentity.collectAsStateWithLifecycle()
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("51820") }
    var serverKey by remember { mutableStateOf("") }
    var privateKey by remember { mutableStateOf("") }
    var copied by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("WARP²", color = L4Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "WireGuard inside WARP (MTU 1220). Register WARP first, then enter YOUR inner server's details. The detour chain is a JSON profile — copy it and import it as a JSON profile; the button below only adds the inner node itself.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                if (identity == null) {
                    Text(text = "WARP is not registered yet — open the WARP tile first.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                } else {
                    OutlinedTextField(value = host, onValueChange = { host = it }, label = { Text("Inner server host") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = port, onValueChange = { port = it }, label = { Text("Inner server port") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = serverKey, onValueChange = { serverKey = it }, label = { Text("Inner server public key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = privateKey, onValueChange = { privateKey = it }, label = { Text("Your inner private key") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Button(
                        onClick = {
                            val p = port.toIntOrNull() ?: 51820
                            if (host.isNotBlank() && serverKey.isNotBlank() && privateKey.isNotBlank()) {
                                onAddNode("wireguard://$privateKey@$host:$p?public_key=$serverKey&local_address=172.16.0.3%2F32&mtu=1220&persistent_keepalive_interval=25#WARP2-inner")
                                onDismiss()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                    ) { Text("Add inner node (MTU 1220)") }
                    Button(
                        onClick = {
                            val p = port.toIntOrNull() ?: 51820
                            val json = if (host.isNotBlank() && serverKey.isNotBlank() && privateKey.isNotBlank()) {
                                enginesViewModel.buildWarp2ProfileJson(host, p, serverKey, privateKey)
                            } else {
                                null
                            }
                            if (json != null) {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("WARP2 profile", json))
                                copied = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                    ) { Text(if (copied) "Profile JSON copied" else "Copy detour profile JSON") }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun MasqueSheet(
    enginesViewModel: EnginesViewModel,
    onDismiss: () -> Unit,
) {
    val results by enginesViewModel.masqueResults.collectAsStateWithLifecycle()
    val scanning by enginesViewModel.masqueScanning.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    var manual by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("MASQUE", color = L4Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "HTTP/3 with HTTP/2 fallback, MTU 1304, TLS chrome/compat. Discovery below is real (measured TCP probes, fastest cached). A live MASQUE connect still needs a QUIC core — this sheet does not fake one.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                OutlinedTextField(value = input, onValueChange = { input = it }, label = { Text("Gateways, comma-separated") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Button(
                    onClick = { enginesViewModel.scanMasque(input) },
                    enabled = !scanning && input.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text(if (scanning) "Scanning…" else "Discover gateways") }
                for (result in results) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = result.target.label, style = MaterialTheme.typography.bodySmall, color = L4Text, modifier = Modifier.weight(1f, fill = false))
                        Text(text = if (result.reachable) "${result.rttMs} ms" else "unreachable", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = L4Text)
                    }
                }
                enginesViewModel.masqueWinner?.let { winner ->
                    Text(text = "Cached winner: $winner", style = MaterialTheme.typography.bodySmall, color = L4TextDim)
                }
                OutlinedTextField(value = manual, onValueChange = { manual = it }, label = { Text("Manual endpoint override") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                TextButton(onClick = { if (manual.isNotBlank()) enginesViewModel.setMasqueManualEndpoint(manual) }) { Text("Use manual endpoint") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun PsiphonSheet(
    enginesViewModel: EnginesViewModel,
    onDismiss: () -> Unit,
) {
    val summary by enginesViewModel.psiphonSummary.collectAsStateWithLifecycle()
    val busy by enginesViewModel.psiphonBusy.collectAsStateWithLifecycle()
    val error by enginesViewModel.psiphonError.collectAsStateWithLifecycle()
    val probes by enginesViewModel.psiphonProbeResults.collectAsStateWithLifecycle()
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Psiphon", color = L4Text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Public server list, regions, and sample probes. A live Psiphon tunnel needs the official Go core — this sheet does not fake a connection.",
                    style = MaterialTheme.typography.bodySmall,
                    color = L4TextDim,
                )
                if (error != null) Text(text = error ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Button(
                    onClick = { enginesViewModel.fetchPsiphonList() },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                ) { Text(if (busy) "Downloading…" else "Fetch server list") }
                summary?.let { s ->
                    Text(
                        text = "List: ${s.bytesDownloaded} bytes" +
                            (s.entryCount?.let { ", ~$it sampled IPs" } ?: "") +
                            (s.regions.takeIf { it.isNotEmpty() }?.let { ", regions: ${it.joinToString(", ")}" } ?: ""),
                        style = MaterialTheme.typography.bodySmall,
                        color = L4TextDim,
                    )
                    Button(
                        onClick = { enginesViewModel.probePsiphonSample() },
                        modifier = Modifier.fillMaxWidth().height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = L4Green),
                    ) { Text("Probe sampled servers") }
                }
                for (result in probes) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = result.target.label, style = MaterialTheme.typography.bodySmall, color = L4Text, modifier = Modifier.weight(1f, fill = false))
                        Text(text = if (result.reachable) "${result.rttMs} ms" else "unreachable", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = L4Text)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}
