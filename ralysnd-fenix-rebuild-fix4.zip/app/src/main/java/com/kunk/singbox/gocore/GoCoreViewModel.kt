// New code written for the Ralysnd FENIX rebuild (Go-core integration).
// Package: com.kunk.singbox.gocore (new; the old FENIX
// package is deleted). The old FENIX ViewModel surface (signIn, connect,
// disconnect, ping all, fastest, select, refresh, signOut, remove, switch)
// is re-implemented here against the dashboard API with NEW names
// (GoCoreUiState / GoCoreViewModel) so a stale reference is a compile
// error, not a silent old-code path.
//
// No tokens, passwords, or codes are stored here. The password is passed
// straight to the sign-in machine's start call and dropped. Account
// emails are display data only (see GoCoreAccountStore); they are never
// logged.

package com.kunk.singbox.gocore

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kunk.singbox.ipc.VpnStateStore
import com.kunk.singbox.manager.VpnServiceManager
import com.kunk.singbox.repository.LogRepository
import com.kunk.singbox.service.manager.VpnStopInitiator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Connection state shown on the FENIX tab. */
enum class GoConnectionState {
    DISCONNECTED, CONNECTING, CONNECTED, RECONNECTING, ERROR,
}

/** Full UI state for the new FENIX tab. */
data class GoCoreUiState(
    val accounts: List<GoAccount> = emptyList(),
    val activeAccountId: String? = null,
    val activeAccountEmail: String = "",
    val locations: List<GoLocation> = emptyList(),
    val selectedCountry: String = "",
    val connectionState: GoConnectionState = GoConnectionState.DISCONNECTED,
    val exitCountry: String? = null,
    val speedDownBps: Long = 0L,
    val speedUpBps: Long = 0L,
    val signIn: GoSignInUiState = GoSignInUiState.Idle,
    val errorMessage: String? = null,
    val coreError: String? = null,
    val isRefreshing: Boolean = false,
    val isPinging: Boolean = false,
)

class GoCoreViewModel(application: Application) : AndroidViewModel(application) {

    private val app: Application = application
    private val endpoint = GoCoreEndpoint(goCoreDataDir(app))
    private val api = DashboardApiClient(endpoint)
    private val accountStore = GoCoreAccountStore.getInstance(app)

    val eventStore = FenixEventStore(app)

    private val _uiState = MutableStateFlow(GoCoreUiState())
    val uiState: StateFlow<GoCoreUiState> = _uiState.asStateFlow()

    /** Transport state from the service (authoritative for tunnel up/down). */
    val transportState: StateFlow<GoCoreTransportState> = GoCoreVpnService.transportState

    private val signInMachine = SignInStateMachine(
        api = api,
        scope = viewModelScope,
        onEvent = { signInState ->
            _uiState.value = _uiState.value.copy(signIn = signInState)
            if (signInState is GoSignInUiState.Done) {
                refreshAll()
            }
        },
        onLog = { level, message ->
            eventStore.append(level, message)
            LogRepository.getInstance().addAlwaysLog("$level [FENIX] $message")
        },
    )

    /** Sign-in state, for the sheet. */
    val signInState: StateFlow<GoSignInUiState> = signInMachine.state

    private var coreEnsured = false
    private var ensureJob: Job? = null
    private var statusPollJob: Job? = null

    init {
        eventStore.load()
        viewModelScope.launch {
            // Reflect the service's tunnel state in the tab state.
            transportState.collect { transport ->
                val current = _uiState.value
                val derived = when {
                    transport.connected -> GoConnectionState.CONNECTED
                    transport.error != null -> GoConnectionState.ERROR
                    current.connectionState == GoConnectionState.CONNECTING -> {
                        GoConnectionState.CONNECTING
                    }
                    else -> GoConnectionState.DISCONNECTED
                }
                _uiState.value = current.copy(
                    connectionState = derived,
                    exitCountry = transport.exitCountry ?: current.exitCountry,
                )
                if (transport.connected) startStatusPolling() else stopStatusPolling()
            }
        }
        ensureCore()
    }

    private fun logEvent(level: String, message: String) {
        eventStore.append(level, message)
        LogRepository.getInstance().addAlwaysLog("$level [FENIX] $message")
    }

    /**
     * Start the daemon (proxy off) so the dashboard API answers. Idempotent.
     *
     * C2: the [coreEnsured] flag alone is NOT authoritative — the service
     * stops the daemon on every disconnect, so a stale flag would leave
     * the API dead (connection refused) until the app process is
     * recreated. The fast path requires the daemon to actually be up;
     * otherwise the daemon is restarted and the token re-awaited.
     */
    fun ensureCore() {
        if (coreEnsured && GoCoreBinding.running()) return
        if (ensureJob?.isActive == true) return
        coreEnsured = true
        ensureJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                ensureCoreNow()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        coreError = "FENIX core could not start",
                    )
                }
                logEvent("ERROR", "core start failed")
            }
        }
    }

    /**
     * Synchronous ensure, for callers that must not proceed until the
     * daemon + token are ready (see [startSignIn], M3). If a background
     * ensure is already in flight (e.g. from init), wait for it instead
     * of starting a second daemon. Throws on failure; callers surface it.
     */
    private suspend fun ensureCoreNow() {
        // Never join our own job: ensureCore() itself runs this function
        // inside ensureJob, and joining self would suspend forever.
        val currentJob = currentCoroutineContext()[Job]
        ensureJob?.let { job ->
            if (job.isActive && job !== currentJob) {
                runCatching { job.join() }
            }
        }
        if (!GoCoreBinding.running()) {
            GoCoreBinding.start(goCoreDataDir(app).absolutePath, false)
                .getOrThrow()
        }
        // Start removes the old token file and writes a fresh one
        // once bound; wait briefly for it before the first call.
        endpoint.awaitToken(10_000L)
            ?: throw IllegalStateException("Dashboard local token unavailable")
        coreEnsured = true
        refreshAll()
    }

    /** Refresh accounts, locations, and status from the daemon. */
    fun refreshAll() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val accountsResp = api.getAccounts()
                val accounts = accountsResp.accounts.sortedBy { it.position }
                val active = accounts.firstOrNull { it.active }
                if (active != null) {
                    accountStore.saveActive(active.email, active.id)
                } else if (accounts.isEmpty()) {
                    accountStore.clear()
                }
                val locationsResp = runCatching { api.getLocations() }.getOrNull()
                val statusResp = runCatching { api.getStatus() }.getOrNull()
                withContext(Dispatchers.Main) {
                    val current = _uiState.value
                    val mergedLocations = mergePings(
                        locationsResp?.locations ?: current.locations,
                        current.locations,
                    )
                    _uiState.value = current.copy(
                        accounts = accounts,
                        activeAccountId = active?.id,
                        activeAccountEmail = active?.email.orEmpty(),
                        locations = mergedLocations,
                        selectedCountry = statusResp?.proxy?.countryCode
                            ?.takeIf { it.isNotBlank() }
                            ?: current.selectedCountry,
                        exitCountry = statusResp?.exit?.countryCode
                            ?.takeIf { it.isNotBlank() }
                            ?: statusResp?.proxy?.countryCode
                                ?.takeIf { it.isNotBlank() }
                            ?: current.exitCountry,
                        speedDownBps = statusResp?.traffic?.downRate ?: 0L,
                        speedUpBps = statusResp?.traffic?.upRate ?: 0L,
                        isRefreshing = false,
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                logEvent("ERROR", "refresh failed")
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(isRefreshing = false)
                }
            }
        }
    }

    /** Keep old ping measurements when a locations refresh has none. */
    private fun mergePings(
        fresh: List<GoLocation>,
        previous: List<GoLocation>,
    ): List<GoLocation> {
        if (fresh.isEmpty()) return previous
        val oldByCode = previous.associateBy { it.code }
        return fresh.map { loc ->
            val old = oldByCode[loc.code]
            if (loc.pingMs == null && old?.pingMs != null) loc.copy(pingMs = old.pingMs) else loc
        }
    }

    private fun startStatusPolling() {
        if (statusPollJob?.isActive == true) return
        statusPollJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(3_000L)
                runCatching {
                    val status = api.getStatus()
                    val active = status.activeAccount
                    withContext(Dispatchers.Main) {
                        val current = _uiState.value
                        _uiState.value = current.copy(
                            exitCountry = status.exit?.countryCode
                                ?.takeIf { it.isNotBlank() }
                                ?: status.proxy?.countryCode
                                    ?.takeIf { it.isNotBlank() }
                                ?: current.exitCountry,
                            speedDownBps = status.traffic?.downRate ?: 0L,
                            speedUpBps = status.traffic?.upRate ?: 0L,
                            activeAccountEmail = active?.email ?: current.activeAccountEmail,
                        )
                    }
                }
            }
        }
    }

    private fun stopStatusPolling() {
        statusPollJob?.cancel()
        statusPollJob = null
    }

    // ---- Sign-in (sheet) ----

    /**
     * M3: await daemon start + token BEFORE starting the state machine,
     * so the first sign-in cannot fail spuriously on a not-yet-written
     * token file. On core failure the dialog gets a clean failure instead
     * of a generic UNKNOWN from a dead loopback port.
     */
    fun startSignIn(email: String, password: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                ensureCoreNow()
            } catch (e: Exception) {
                logEvent("ERROR", "signin failed: core not ready")
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        coreError = "FENIX core could not start",
                    )
                }
                signInMachine.failNow(SignInFailureCategory.NETWORK)
                return@launch
            }
            signInMachine.start(email, password)
        }
    }

    fun answerSignInStep(value: String) {
        signInMachine.answer(value)
    }

    fun cancelSignIn() {
        signInMachine.cancel()
    }

    // ---- Accounts ----

    fun switchAccount(accountId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { api.activateAccount(accountId) }
            refreshAll()
        }
    }

    fun refreshAccount() {
        val id = _uiState.value.activeAccountId ?: return
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { api.refreshAccount(id) }
            refreshAll()
        }
    }

    fun removeAccount(accountId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val isActive = accountId == _uiState.value.activeAccountId
            if (isActive && _uiState.value.connectionState == GoConnectionState.CONNECTED) {
                disconnectFenix()
            }
            runCatching { api.deleteAccount(accountId) }
            refreshAll()
        }
    }

    /** Sign out of the active account: stop the tunnel first, then remove it. */
    fun signOut() {
        val id = _uiState.value.activeAccountId ?: return
        removeAccount(id)
    }

    // ---- Locations ----

    fun selectCountry(countryCode: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { api.setLocation(countryCode) }
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(selectedCountry = countryCode)
            }
            refreshAll()
        }
    }

    /** User-visible notice line (connect errors, ping hints, permission). */
    fun showNotice(message: String) {
        _uiState.value = _uiState.value.copy(errorMessage = message)
    }

    /**
     * M2/M9: ping requires the proxy running (the daemon answers 409
     * otherwise), so gate on connected state with a visible message
     * instead of a silent log-only failure.
     */
    fun pingAllCountries() {
        if (_uiState.value.connectionState != GoConnectionState.CONNECTED) {
            showNotice("Connect FENIX first, then ping countries.")
            logEvent("ERROR", "ping all blocked: not connected")
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(isPinging = true, errorMessage = null)
            }
            try {
                val codes = _uiState.value.locations.map { it.code }
                val resp = api.pingLocations(codes)
                val pingByCode = resp.locations.associateBy { it.code }
                withContext(Dispatchers.Main) {
                    val current = _uiState.value
                    _uiState.value = current.copy(
                        locations = current.locations.map { loc ->
                            val ping = pingByCode[loc.code]
                            if (ping?.pingMs != null) loc.copy(pingMs = ping.pingMs) else loc
                        },
                        isPinging = false,
                    )
                }
            } catch (e: Exception) {
                logEvent("ERROR", "ping all failed")
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        isPinging = false,
                        errorMessage = "Ping failed. Try again.",
                    )
                }
            }
        }
    }

    /** Lowest measured ping; ties broken by list order (documented). */
    fun fastestCountry(): GoLocation? {
        return _uiState.value.locations
            .filter { it.pingMs != null && it.pingMs > 0 }
            .minByOrNull { it.pingMs ?: Long.MAX_VALUE }
    }

    // ---- Connect / disconnect (mutual exclusion, both directions) ----

    /**
     * Connect FENIX. The caller (screen) must have obtained VPN permission
     * via VpnService.prepare first. Stops sing-box first (bounded 10 s),
     * then starts the Go-core service. Never starts over a live sing-box.
     */
    fun connectSelected() {
        viewModelScope.launch(Dispatchers.IO) {
            withContext(Dispatchers.Main) {
                _uiState.value = _uiState.value.copy(
                    connectionState = GoConnectionState.CONNECTING,
                    errorMessage = null,
                )
            }
            try {
                ensureCore()
                if (VpnStateStore.getMode() == VpnStateStore.CoreMode.VPN) {
                    VpnServiceManager.stopVpn(app, VpnStopInitiator.MODE_SWITCH)
                    val stopped = VpnServiceManager.awaitModeStopped(
                        VpnStateStore.CoreMode.VPN,
                        10_000L,
                    )
                    if (!stopped) {
                        throw IllegalStateException("sing-box did not stop in time")
                    }
                }
                VpnStateStore.setMode(VpnStateStore.CoreMode.GO_CORE)
                VpnStateStore.setPending("starting")
                app.startForegroundService(
                    Intent(app, GoCoreVpnService::class.java).apply {
                        action = GoCoreServiceActions.ACTION_START
                    },
                )
                logEvent("INFO", "connect requested")
            } catch (e: Exception) {
                VpnStateStore.setMode(VpnStateStore.CoreMode.NONE)
                VpnStateStore.setPending("")
                logEvent("ERROR", "connect failed")
                withContext(Dispatchers.Main) {
                    _uiState.value = _uiState.value.copy(
                        connectionState = GoConnectionState.ERROR,
                        errorMessage = "Could not connect. Try again.",
                    )
                }
            }
        }
    }

    /** Disconnect FENIX (prompt stop; the service clears the owner record). */
    fun disconnectFenix() {
        viewModelScope.launch(Dispatchers.IO) {
            app.startService(
                Intent(app, GoCoreVpnService::class.java).apply {
                    action = GoCoreServiceActions.ACTION_STOP
                },
            )
            logEvent("INFO", "disconnect requested")
        }
    }

    override fun onCleared() {
        signInMachine.cancel()
        stopStatusPolling()
        // M8: the service owns the daemon while a tunnel runs, so a live
        // tunnel is never killed from here — but when the FENIX
        // destination is destroyed with NO tunnel active, stop a
        // ViewModel-started daemon instead of leaving it listening on
        // loopback until the app process dies. (If the app's tab
        // navigation retains this ViewModel across tab switches, the
        // daemon stays up for an instant return to the tab; that path
        // is the navigation's retention behavior, not a leak here.)
        if (VpnStateStore.getMode() != VpnStateStore.CoreMode.GO_CORE &&
            !GoCoreVpnService.isRunning &&
            GoCoreBinding.running()
        ) {
            runCatching { GoCoreBinding.stop() }
        }
        super.onCleared()
    }
}
