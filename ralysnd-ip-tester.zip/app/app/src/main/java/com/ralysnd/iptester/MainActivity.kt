package com.ralysnd.iptester

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.ralysnd.iptester.ui.theme.IpTesterColors
import com.ralysnd.iptester.ui.theme.IpTesterTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            IpTesterTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    TesterScreen()
                }
            }
        }
    }
}

@Composable
fun TesterScreen(vm: TesterViewModel = viewModel()) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current

    fun copyText(text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("vless", text))
        Toast.makeText(context, "کپی شد", Toast.LENGTH_SHORT).show()
    }

    fun pasteClipboard(): String {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        return clipboard.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("IP Tester", fontSize = 24.sp, color = IpTesterColors.Yellow)
            Text(
                "کانفیگ رو بده، آیپی‌ها رو با همون کانفیگ روی خط خودت تست می‌کنه — فقط کانفیگی که واقعاً کار کنه سالمه",
                fontSize = 14.sp,
                color = IpTesterColors.TextSecondary,
            )
        }

        item {
            OutlinedTextField(
                value = state.configText,
                onValueChange = { vm.setConfigText(it) },
                label = { Text("لینک کانفیگ VLESS") },
                placeholder = { Text("vless://...") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 5,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    val text = pasteClipboard()
                    if (text.isNotBlank()) vm.setConfigText(text)
                }) { Text("چسباندن") }
                OutlinedButton(onClick = { vm.setConfigText("") }) { Text("پاک کردن") }
            }
            val config = state.config
            if (config != null) {
                Text(
                    "SNI: ${config.sni} | Path: ${config.path} | Port: ${config.port} | ${config.security}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                )
            }
            state.configError?.let {
                Text(it, color = Color(0xFFEF4444), fontSize = 12.sp)
            }
        }

        item {
            Text("لیست آیپی", fontSize = 16.sp)
            Text(
                "فقط لیست داخلی اپ تست می‌شه: ${state.candidates.size} آیپی:پورت",
                fontSize = 12.sp,
                color = IpTesterColors.TextSecondary,
            )
        }

        item {
            Text("نوع تست", fontSize = 16.sp)
            Text(
                "پورت همیشه از لیست می‌آد: هر آیپی با پورت خودش تو کانفیگ جایگذاری می‌شه",
                fontSize = 12.sp,
                color = IpTesterColors.TextSecondary,
            )
            Row {
                RadioButton(
                    selected = state.testMode == TestMode.FULL,
                    onClick = { vm.setTestMode(TestMode.FULL) },
                )
                Text(
                    "تست واقعی کانفیگ",
                    modifier = Modifier.padding(top = 12.dp),
                )
            }
            Row {
                RadioButton(
                    selected = state.testMode == TestMode.TCP_ONLY,
                    onClick = { vm.setTestMode(TestMode.TCP_ONLY) },
                )
                Text(
                    "فقط وصل‌شدن (پینگ)",
                    modifier = Modifier.padding(top = 12.dp),
                )
            }
            Text(
                if (state.testMode == TestMode.FULL) {
                    "وصل‌شدن + TLS + وب‌سوکت + VLESS روی پورت هر آیپی — فقط اگه داده رد شد سالمه"
                } else {
                    "فقط وصل‌شدن TCP روی پورت هر آیپی"
                },
                fontSize = 12.sp,
                color = IpTesterColors.TextSecondary,
            )
        }

        item {
            if (state.running) {
                Button(
                    onClick = { vm.stopTest() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                ) { Text("توقف") }
                LinearProgressIndicator(
                    progress = {
                        if (state.total > 0) state.tested.toFloat() / state.total else 0f
                    },
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "تست‌شده ${state.tested} از ${state.total} — سالم: ${state.okCount}",
                    fontSize = 12.sp,
                )
            } else {
                Button(
                    onClick = { vm.startTest() },
                    enabled = state.config != null && state.candidates.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = IpTesterColors.Yellow,
                        contentColor = Color.Black,
                    ),
                ) { Text("شروع تست") }
            }
            state.message?.let {
                Text(it, fontSize = 12.sp, color = IpTesterColors.TextSecondary)
            }
        }

        if (state.results.isNotEmpty()) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("سالم‌ها (${state.results.size})", fontSize = 16.sp)
                    Spacer(modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = {
                        val config = state.config ?: return@OutlinedButton
                        val all = state.results.sortedBy { it.tcpMs }.joinToString("\n") { result ->
                            config.buildLink(result.candidate.ip, result.candidate.port)
                        }
                        copyText(all)
                    }) { Text("کپی همه لینک‌ها") }
                }
            }
            items(
                items = state.results.sortedBy { it.tcpMs },
                key = { "${it.candidate.ip}:${it.candidate.port}" },
            ) { result ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1E1E)),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "${result.candidate.ip}:${result.candidate.port}",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 14.sp,
                            )
                            val location = listOf(result.candidate.country, result.candidate.city)
                                .filter { it.isNotBlank() }
                                .joinToString("، ")
                            if (location.isNotBlank()) {
                                Text(location, fontSize = 11.sp, color = IpTesterColors.TextSecondary)
                            }
                            val status = "${result.tcpMs}ms" +
                                if (result.httpStatus > 0) " • HTTP ${result.httpStatus}" else ""
                            Text(status, fontSize = 12.sp)
                        }
                        OutlinedButton(onClick = {
                            val config = state.config ?: return@OutlinedButton
                            copyText(config.buildLink(result.candidate.ip, result.candidate.port))
                        }) { Text("کپی لینک") }
                    }
                }
            }
        }
    }
}
