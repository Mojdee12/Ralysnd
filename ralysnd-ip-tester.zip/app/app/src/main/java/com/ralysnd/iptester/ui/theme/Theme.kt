package com.ralysnd.iptester.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp

// Ralysnd yellow-black: dark background, yellow accent.
object IpTesterColors {
    val Background = Color(0xFF121212)
    val Surface = Color(0xFF1E1E1E)
    val Yellow = Color(0xFFFFD60A)
    val Green = Color(0xFF4CAF50)
    val Red = Color(0xFFEF4444)
    val TextPrimary = Color(0xFFF5F5F5)
    val TextSecondary = Color(0xFF9E9E9E)
}

private val IpTesterTypography = Typography(
    headlineMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 24.sp),
    headlineSmall = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 20.sp),
    bodyLarge = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 16.sp),
    bodyMedium = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 14.sp),
    bodySmall = TextStyle(fontFamily = FontFamily.SansSerif, fontSize = 12.sp),
    labelMedium = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
    labelSmall = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 10.sp)
)

@Composable
fun IpTesterTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = IpTesterColors.Background,
            surface = IpTesterColors.Surface,
            surfaceVariant = IpTesterColors.Surface,
            primary = IpTesterColors.Yellow,
            secondary = IpTesterColors.Green,
            error = IpTesterColors.Red,
            onBackground = IpTesterColors.TextPrimary,
            onSurface = IpTesterColors.TextPrimary,
            onPrimary = Color.Black
        ),
        typography = IpTesterTypography,
        content = content
    )
}
