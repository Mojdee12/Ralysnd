package com.ralysnd.iptester

import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Base64
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.random.Random

// Generous timeouts: the user's line in Iran is slow and lossy.
const val TCP_TIMEOUT_MS = 5000
const val TLS_TIMEOUT_MS = 10000

data class Candidate(
    val ip: String,
    val port: Int,
    val country: String = "",
    val city: String = "",
)

data class TestResult(
    val candidate: Candidate,
    /** TCP connect time in ms, or -1 when the TCP connect itself failed. */
    val tcpMs: Long,
    /** True only when the WebSocket upgrade answered 101. */
    val wsOk: Boolean,
    /** HTTP status of the WebSocket upgrade response, 0 when no response was read. */
    val httpStatus: Int,
    val error: String?,
)

fun isIpv4(s: String): Boolean {
    val parts = s.split(".")
    if (parts.size != 4) return false
    return parts.all { part ->
        val n = part.toIntOrNull() ?: return@all false
        n in 0..255
    }
}

/**
 * Parses an IP list. Each line is ip:port with optional :Region:Country:City
 * columns (the LML central-nodes file format). Lines without a valid IPv4
 * address or port are skipped. Duplicate ip:port pairs are kept once, in
 * first-seen order.
 */
fun parseIpList(text: String): List<Candidate> {
    val out = LinkedHashMap<String, Candidate>()
    for (raw in text.lines()) {
        val line = raw.trim()
        if (line.isEmpty()) continue
        val parts = line.split(":")
        if (parts.size < 2) continue
        val ip = parts[0].trim()
        if (!isIpv4(ip)) continue
        val port = parts[1].trim().toIntOrNull() ?: continue
        if (port !in 1..65535) continue
        val country = if (parts.size > 3) parts[3].trim() else ""
        val city = if (parts.size > 4) parts[4].trim() else ""
        val key = "$ip:$port"
        if (!out.containsKey(key)) {
            out[key] = Candidate(ip, port, country, city)
        }
    }
    return out.values.toList()
}

/**
 * Tests one candidate from this device (i.e. on the user's own line).
 * Always measures the TCP connect time. When [fullCheck] is true and a
 * [config] is given, it then does a TLS handshake with the config's SNI
 * (or a plain socket when security is not tls) and a WebSocket upgrade to
 * the config's path; only a 101 response counts as a working config.
 */
fun testCandidate(c: Candidate, config: VlessConfig?, fullCheck: Boolean): TestResult {
    val start = System.nanoTime()
    var active: Socket? = null
    try {
        val plain = Socket()
        active = plain
        plain.connect(InetSocketAddress(c.ip, c.port), TCP_TIMEOUT_MS)
        val tcpMs = (System.nanoTime() - start) / 1_000_000
        if (!fullCheck || config == null) {
            return TestResult(c, tcpMs, false, 0, null)
        }
        if (config.security == "tls") {
            val factory = SSLSocketFactory.getDefault()
            val ssl = factory.createSocket(plain, c.ip, c.port, true) as SSLSocket
            active = ssl
            val params: SSLParameters = ssl.sslParameters
            params.serverNames = listOf(SNIHostName(config.sni))
            ssl.sslParameters = params
            ssl.soTimeout = TLS_TIMEOUT_MS
            ssl.startHandshake()
            val verified = HttpsURLConnection.getDefaultHostnameVerifier()
                .verify(config.sni, ssl.session)
            if (!verified) {
                return TestResult(c, tcpMs, false, 0, "cert")
            }
            val status = wsUpgrade(ssl, config)
            return TestResult(c, tcpMs, status == 101, status, null)
        } else {
            plain.soTimeout = TLS_TIMEOUT_MS
            val status = wsUpgrade(plain, config)
            return TestResult(c, tcpMs, status == 101, status, null)
        }
    } catch (e: Exception) {
        return TestResult(c, -1, false, 0, e.javaClass.simpleName)
    } finally {
        try {
            active?.close()
        } catch (_: Exception) {
        }
    }
}

/** Sends a WebSocket upgrade for the config's path and returns the HTTP status. */
fun wsUpgrade(socket: Socket, config: VlessConfig): Int {
    val keyBytes = ByteArray(16)
    Random.Default.nextBytes(keyBytes)
    val key = Base64.getEncoder().encodeToString(keyBytes)
    val request = "GET ${config.path} HTTP/1.1\r\n" +
        "Host: ${config.host}\r\n" +
        "Upgrade: websocket\r\n" +
        "Connection: Upgrade\r\n" +
        "Sec-WebSocket-Key: $key\r\n" +
        "Sec-WebSocket-Version: 13\r\n\r\n"
    socket.getOutputStream().write(request.toByteArray(Charsets.UTF_8))
    socket.getOutputStream().flush()
    val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
    val statusLine = reader.readLine() ?: return 0
    val parts = statusLine.split(" ")
    return if (parts.size >= 2) parts[1].toIntOrNull() ?: 0 else 0
}
