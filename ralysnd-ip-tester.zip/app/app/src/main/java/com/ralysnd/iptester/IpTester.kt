package com.ralysnd.iptester

import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Base64
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.random.Random

// Generous timeouts: the user's line in Iran is slow and lossy.
const val TCP_TIMEOUT_MS = 5000
const val TLS_TIMEOUT_MS = 10000

data class Candidate(
    val ip: String,
    val port: Int,
    val country: String = "",
    val city: String = "",
)

data class TestResult(
    val candidate: Candidate,
    /** TCP connect time in ms, or -1 when the TCP connect itself failed. */
    val tcpMs: Long,
    /** True only when the full config actually carries traffic (VLESS + HTTP). */
    val works: Boolean,
    /** HTTP status of the WebSocket upgrade response, 0 when no response was read. */
    val httpStatus: Int,
    val error: String?,
)

fun isIpv4(s: String): Boolean {
    val parts = s.split(".")
    if (parts.size != 4) return false
    return parts.all { part ->
        val n = part.toIntOrNull() ?: return@all false
        n in 0..255
    }
}

/**
 * Parses an IP list. Each line is ip:port with optional :Region:Country:City
 * columns (the LML central-nodes file format). Lines without a valid IPv4
 * address or port are skipped. Duplicate ip:port pairs are kept once, in
 * first-seen order.
 */
fun parseIpList(text: String): List<Candidate> {
    val out = LinkedHashMap<String, Candidate>()
    for (raw in text.lines()) {
        val line = raw.trim()
        if (line.isEmpty()) continue
        val parts = line.split(":")
        if (parts.size < 2) continue
        val ip = parts[0].trim()
        if (!isIpv4(ip)) continue
        val port = parts[1].trim().toIntOrNull() ?: continue
        if (port !in 1..65535) continue
        val country = if (parts.size > 3) parts[3].trim() else ""
        val city = if (parts.size > 4) parts[4].trim() else ""
        val key = "$ip:$port"
        if (!out.containsKey(key)) {
            out[key] = Candidate(ip, port, country, city)
        }
    }
    return out.values.toList()
}

/**
 * Tests one candidate from this device (i.e. on the user's own line).
 * Always measures the TCP connect time. When [fullCheck] is true and a
 * [config] is given, it then does a TLS handshake with the config's SNI
 * (or a plain socket when security is not tls) and a WebSocket upgrade to
 * the config's path; only a 101 response counts as a working config.
 */
fun testCandidate(c: Candidate, config: VlessConfig?, fullCheck: Boolean): TestResult {
    val start = System.nanoTime()
    var active: Socket? = null
    try {
        if (!fullCheck || config == null) {
            val plain = Socket()
            active = plain
            plain.connect(InetSocketAddress(c.ip, c.port), TCP_TIMEOUT_MS)
            val tcpMs = (System.nanoTime() - start) / 1_000_000
            return TestResult(c, tcpMs, false, 0, null)
        }
        if (config.security == "tls") {
            val factory = SSLSocketFactory.getDefault()
            val ssl = factory.createSocket() as SSLSocket
            active = ssl
            ssl.soTimeout = TLS_TIMEOUT_MS
            ssl.connect(InetSocketAddress(c.ip, c.port), TCP_TIMEOUT_MS)
            val tcpMs = (System.nanoTime() - start) / 1_000_000
            val params: SSLParameters = ssl.sslParameters
            params.serverNames = listOf(SNIHostName(config.sni))
            ssl.sslParameters = params
            ssl.startHandshake()
            val verified = HttpsURLConnection.getDefaultHostnameVerifier()
                .verify(config.sni, ssl.session)
            if (!verified) {
                return TestResult(c, tcpMs, false, 0, "cert")
            }
            val status = wsUpgrade(ssl, config)
            if (status != 101) return TestResult(c, tcpMs, false, status, null)
            val ok = vlessWorks(ssl, config)
            return TestResult(c, tcpMs, ok, status, null)
        } else {
            val plain = Socket()
            active = plain
            plain.connect(InetSocketAddress(c.ip, c.port), TCP_TIMEOUT_MS)
            val tcpMs = (System.nanoTime() - start) / 1_000_000
            plain.soTimeout = TLS_TIMEOUT_MS
            val status = wsUpgrade(plain, config)
            if (status != 101) return TestResult(c, tcpMs, false, status, null)
            val ok = vlessWorks(plain, config)
            return TestResult(c, tcpMs, ok, status, null)
        }
    } catch (e: Exception) {
        return TestResult(c, -1, false, 0, e.javaClass.simpleName)
    } finally {
        try {
            active?.close()
        } catch (_: Exception) {
        }
    }
}

/** Sends a WebSocket upgrade for the config's path and returns the HTTP status. */
fun wsUpgrade(socket: Socket, config: VlessConfig): Int {
    val keyBytes = ByteArray(16)
    Random.Default.nextBytes(keyBytes)
    val key = Base64.getEncoder().encodeToString(keyBytes)
    val request = "GET ${config.path} HTTP/1.1\r\n" +
        "Host: ${config.host}\r\n" +
        "Upgrade: websocket\r\n" +
        "Connection: Upgrade\r\n" +
        "Sec-WebSocket-Key: $key\r\n" +
        "Sec-WebSocket-Version: 13\r\n\r\n"
    socket.getOutputStream().write(request.toByteArray(Charsets.UTF_8))
    socket.getOutputStream().flush()
    val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.UTF_8))
    val statusLine = reader.readLine() ?: return 0
    val parts = statusLine.split(" ")
    return if (parts.size >= 2) parts[1].toIntOrNull() ?: 0 else 0
}

/** Parses a UUID string (with or without dashes) into 16 bytes. Null on failure. */
fun parseUuid(uuid: String): ByteArray? {
    val hex = uuid.replace("-", "")
    if (hex.length != 32) return null
    return try {
        ByteArray(16) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    } catch (_: Exception) {
        null
    }
}

/** Sends one masked WebSocket binary frame (client frames must be masked). */
fun wsSendBinary(socket: Socket, payload: ByteArray) {
    val out = socket.getOutputStream()
    val mask = ByteArray(4)
    Random.Default.nextBytes(mask)
    val header = ByteArrayOutputStream()
    header.write(0x82) // FIN + binary opcode
    val len = payload.size
    when {
        len < 126 -> header.write(0x80 or len)
        len < 65536 -> {
            header.write(0x80 or 126)
            header.write(len shr 8)
            header.write(len and 0xFF)
        }
        else -> {
            header.write(0x80 or 127)
            val l = len.toLong()
            for (shift in 56 downTo 0 step 8) header.write(((l shr shift) and 0xFF).toInt())
        }
    }
    header.write(mask)
    out.write(header.toByteArray())
    val masked = ByteArray(len) { i -> (payload[i].toInt() xor mask[i % 4].toInt()).toByte() }
    out.write(masked)
    out.flush()
}

/**
 * Reads WebSocket frames until [test] matches the accumulated payload, the
 * server closes, or [timeoutMs] passes. Returns true only on a match.
 */
fun wsReadUntil(socket: Socket, timeoutMs: Int, test: (ByteArray) -> Boolean): Boolean {
    val input = socket.getInputStream()
    val acc = ByteArrayOutputStream()
    val deadline = System.currentTimeMillis() + timeoutMs
    while (System.currentTimeMillis() < deadline) {
        val b0 = input.read()
        if (b0 == -1) return false
        val b1 = input.read()
        if (b1 == -1) return false
        val opcode = b0 and 0x0F
        if (opcode == 0x8) return false // close frame
        var len = b1 and 0x7F
        if (len == 126) {
            val hi = input.read()
            val lo = input.read()
            if (hi == -1 || lo == -1) return false
            len = (hi shl 8) or lo
        } else if (len == 127) {
            var l = 0L
            for (i in 0 until 8) {
                val b = input.read()
                if (b == -1) return false
                l = (l shl 8) or b.toLong()
            }
            if (l > Int.MAX_VALUE) return false
            len = l.toInt()
        }
        // Server frames are unmasked; skip a mask if one is ever present.
        if (b1 and 0x80 != 0) {
            input.skip(4)
        }
        val payload = ByteArray(len)
        var read = 0
        while (read < len) {
            val n = input.read(payload, read, len - read)
            if (n == -1) return false
            read += n
        }
        if (opcode == 0x2 || opcode == 0x0) {
            acc.write(payload)
            if (test(acc.toByteArray())) return true
        }
        // Ping frames (0x9) are ignored; the socket timeout bounds the wait.
    }
    return false
}

/**
 * Real VLESS test: after the WS upgrade, sends a VLESS TCP request for
 * 1.1.1.1:80 plus an HTTP GET, and only counts the config as working when
 * an HTTP response actually comes back through the tunnel. A bare TCP
 * connect or a WS 101 is NOT enough — the config must carry real traffic.
 */
fun vlessWorks(socket: Socket, config: VlessConfig): Boolean {
    val uuid = parseUuid(config.uuid) ?: return false
    val req = ByteArrayOutputStream()
    req.write(0x00) // version
    req.write(uuid)
    req.write(0x00) // addon length
    req.write(0x01) // command: TCP
    req.write(0x00)
    req.write(0x50) // port 80
    req.write(0x01) // address type: IPv4
    req.write(byteArrayOf(1, 1, 1, 1))
    wsSendBinary(socket, req.toByteArray())
    val http = "GET / HTTP/1.0\r\nHost: one.one.one.one\r\n\r\n".toByteArray(Charsets.UTF_8)
    wsSendBinary(socket, http)
    return wsReadUntil(socket, TLS_TIMEOUT_MS) { data ->
        String(data, Charsets.UTF_8).contains("HTTP/")
    }
}
