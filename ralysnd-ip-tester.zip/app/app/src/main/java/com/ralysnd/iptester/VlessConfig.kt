package com.ralysnd.iptester

import java.net.URLDecoder
import java.net.URLEncoder

/**
 * A parsed VLESS link. The original link text is kept so [buildLink] can
 * rebuild it byte-for-byte except for the substituted address/port/remark.
 */
data class VlessConfig(
    val uuid: String,
    val address: String,
    val port: Int,
    val params: Map<String, String>,
    val rawQuery: String,
    val remark: String,
    val originalLink: String,
) {
    val security: String get() = params["security"] ?: "tls"
    val host: String get() = params["host"] ?: params["sni"] ?: address
    val sni: String get() = params["sni"] ?: params["host"] ?: address
    val path: String get() = params["path"] ?: "/"
    val type: String get() = params["type"] ?: "ws"

    /** Rebuild the link with [ip]:[port] as the server, everything else unchanged. */
    fun buildLink(ip: String, port: Int): String {
        val base = when {
            remark.contains(address) -> remark.replace(address, ip)
            remark.isBlank() -> ip
            else -> "$remark $ip"
        }
        val encoded = URLEncoder.encode(base, "UTF-8").replace("+", "%20")
        val query = if (rawQuery.isEmpty()) "" else "?$rawQuery"
        return "vless://$uuid@$ip:$port$query#$encoded"
    }
}

/** Parses a vless:// link. Returns null when the link is not a valid VLESS link. */
fun parseVless(link: String): VlessConfig? {
    val trimmed = link.trim()
    if (!trimmed.startsWith("vless://")) return null
    return try {
        val withoutScheme = trimmed.removePrefix("vless://")
        val hashIdx = withoutScheme.indexOf('#')
        val remark = if (hashIdx >= 0) {
            URLDecoder.decode(withoutScheme.substring(hashIdx + 1), "UTF-8")
        } else {
            ""
        }
        val beforeFrag = if (hashIdx >= 0) withoutScheme.substring(0, hashIdx) else withoutScheme
        val atIdx = beforeFrag.indexOf('@')
        if (atIdx < 0) return null
        val uuid = beforeFrag.substring(0, atIdx)
        if (uuid.isBlank()) return null
        val afterAt = beforeFrag.substring(atIdx + 1)
        val qIdx = afterAt.indexOf('?')
        val hostPort = if (qIdx >= 0) afterAt.substring(0, qIdx) else afterAt
        val rawQuery = if (qIdx >= 0) afterAt.substring(qIdx + 1) else ""
        val colonIdx = hostPort.lastIndexOf(':')
        if (colonIdx < 0) return null
        val address = hostPort.substring(0, colonIdx)
        val port = hostPort.substring(colonIdx + 1).toIntOrNull() ?: return null
        val params = linkedMapOf<String, String>()
        if (rawQuery.isNotEmpty()) {
            for (pair in rawQuery.split("&")) {
                val eq = pair.indexOf('=')
                if (eq > 0) {
                    params[URLDecoder.decode(pair.substring(0, eq), "UTF-8")] =
                        URLDecoder.decode(pair.substring(eq + 1), "UTF-8")
                }
            }
        }
        VlessConfig(uuid, address, port, params, rawQuery, remark, trimmed)
    } catch (_: Exception) {
        null
    }
}
