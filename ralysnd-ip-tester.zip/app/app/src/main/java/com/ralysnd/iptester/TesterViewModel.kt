package com.ralysnd.iptester

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore

/** Test depth. The port ALWAYS comes from the bundled list: each
 * candidate is tested on its own ip:port, substituted into the sample
 * config — never on the sample config's port. */
enum class TestMode { FULL, TCP_ONLY }

data class TesterState(
    val configText: String = "",
    val config: VlessConfig? = null,
    val configError: String? = null,
    val candidates: List<Candidate> = emptyList(),
    val testMode: TestMode = TestMode.FULL,
    val running: Boolean = false,
    val tested: Int = 0,
    val total: Int = 0,
    val okCount: Int = 0,
    val results: List<TestResult> = emptyList(),
    val message: String? = null,
)

class TesterViewModel(application: Application) : AndroidViewModel(application) {
    private val _state = MutableStateFlow(TesterState())
    val state: StateFlow<TesterState> = _state.asStateFlow()
    private var testJob: Job? = null

    init {
        // The IP list is bundled with the app: only this list is ever tested.
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val text = application.resources.openRawResource(R.raw.ip_list)
                    .bufferedReader().use { it.readText() }
                val candidates = parseIpList(text)
                _state.update { it.copy(candidates = candidates) }
            } catch (_: Exception) {
                _state.update { it.copy(message = "خواندن لیست داخلی نشد") }
            }
        }
    }

    fun setConfigText(text: String) {
        val parsed = if (text.isBlank()) null else parseVless(text)
        _state.update {
            it.copy(
                configText = text,
                config = parsed,
                configError = if (text.isNotBlank() && parsed == null) {
                    "لینک کانفیگ معتبر نیست"
                } else {
                    null
                },
            )
        }
    }

    fun setTestMode(mode: TestMode) {
        _state.update { it.copy(testMode = mode) }
    }

    fun startTest() {
        val current = _state.value
        val config = current.config ?: return
        if (current.candidates.isEmpty() || current.running) return
        val fullCheck = current.testMode == TestMode.FULL
        // Every candidate keeps its OWN port from the bundled list: the
        // ip:port pair is substituted into the sample config as-is.
        // (The old code overwrote every port with the config's port, so
        // only the ~962 entries already on that port were tested fairly.)
        val targets: List<Candidate> = current.candidates
        _state.update {
            it.copy(
                running = true,
                tested = 0,
                total = targets.size,
                okCount = 0,
                results = emptyList(),
                message = null,
            )
        }
        testJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                // Modest parallelism: the user's line is slow, flooding it
                // would only make every test time out.
                val semaphore = Semaphore(10)
                val jobs = targets.map { candidate ->
                    launch {
                        semaphore.acquire()
                        try {
                            val result = testCandidate(candidate, config, fullCheck)
                            val ok = if (fullCheck) result.works else result.tcpMs >= 0
                            _state.update { state ->
                                state.copy(
                                    tested = state.tested + 1,
                                    okCount = state.okCount + if (ok) 1 else 0,
                                    results = if (ok) state.results + result else state.results,
                                )
                            }
                        } finally {
                            semaphore.release()
                        }
                    }
                }
                jobs.joinAll()
                _state.update { it.copy(message = "تمام شد") }
            } finally {
                _state.update { it.copy(running = false) }
            }
        }
    }

    fun stopTest() {
        testJob?.cancel()
        _state.update { it.copy(running = false) }
    }
}
