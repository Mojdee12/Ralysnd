package com.kunk.singbox.ui.screens

import android.text.format.Formatter
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavController
import com.kunk.singbox.ipc.SingBoxRemote
import com.kunk.singbox.model.ConnectionState
import com.kunk.singbox.model.PingDisplayText
import com.kunk.singbox.model.RoutingMode
import com.kunk.singbox.ui.navigation.Screen as AppScreen
import com.kunk.singbox.viewmodel.DashboardViewModel
import com.kunk.singbox.viewmodel.SettingsViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kunk.singbox.ui.components.ConfirmDialog
import com.kunk.singbox.ui.components.InfoCard
import com.kunk.singbox.ui.components.StandardCard
import com.kunk.singbox.ui.components.ModeChip
import com.kunk.singbox.ui.components.SingleSelectDialog
import com.kunk.singbox.ui.components.StatusChip
import com.kunk.singbox.ui.components.AppNotificationManager
import com.kunk.singbox.ui.components.rememberLocalNetworkPermissionRequest
import com.kunk.singbox.ui.theme.Neutral500
import com.kunk.singbox.ui.theme.L4Background
import com.kunk.singbox.ui.theme.L4CenterConnectButton
import com.kunk.singbox.ui.theme.L4GlassCard
import com.kunk.singbox.ui.theme.L4Green
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim
import com.kunk.singbox.R
import com.kunk.singbox.utils.LocalNetworkPermission
import com.kunk.singbox.viewmodel.NodesViewModel
import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.kunk.singbox.ui.theme.liquidGlassIconButtonPanel
import com.kunk.singbox.ui.theme.liquidGlassMutedContentColor
import com.kunk.singbox.ui.theme.liquidGlassStrongContentColor
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collectLatest

@Composable
@Suppress("LongMethod", "CyclomaticComplexMethod", "CognitiveComplexMethod", "FunctionNaming")
fun DashboardScreen(
    navController: NavController,
    viewModel: DashboardViewModel = viewModel(),
    settingsViewModel: SettingsViewModel = viewModel(),
    nodesViewModel: NodesViewModel = viewModel(),
    bottomContentPadding: Dp = 0.dp
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val connectionState by viewModel.connectionState.collectAsStateWithLifecycle()
    val dataPlaneReadiness by viewModel.dataPlaneReadiness.collectAsStateWithLifecycle()
    val stats by viewModel.stats.collectAsStateWithLifecycle()
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val activeProfileId by viewModel.activeProfileId.collectAsStateWithLifecycle()
    val activeNodeId by viewModel.activeNodeId.collectAsStateWithLifecycle()
    val isAutoSelectionEnabled by viewModel.isAutoSelectionEnabled.collectAsStateWithLifecycle()
    val activeNodeLatency by viewModel.activeNodeLatency.collectAsStateWithLifecycle()
    val isPingTesting by viewModel.isPingTesting.collectAsStateWithLifecycle()
    val nodes by viewModel.nodes.collectAsStateWithLifecycle()
    val settings by settingsViewModel.settings.collectAsStateWithLifecycle()
    val runtimeNodeLabel by SingBoxRemote.activeLabel.collectAsStateWithLifecycle()

    val nodesForSelector by nodesViewModel.nodes.collectAsStateWithLifecycle()
    val rawNodesForSelector by nodesViewModel.rawNodes.collectAsStateWithLifecycle()
    val testingNodeIds by nodesViewModel.testingNodeIds.collectAsStateWithLifecycle()

    val activeProfileName by remember {
        derivedStateOf {
            profiles.find { it.id == activeProfileId }?.name
        }
    }

    // 连接态优先显示运行态标签，避免自动切换后主页仍显示手选旧节点
    val activeNodeName by remember(activeNodeId, nodes, connectionState, runtimeNodeLabel) {
        derivedStateOf {
            viewModel.getActiveNodeName()
        }
    }
    val autoSelectionSubtitle = when {
        !isAutoSelectionEnabled -> stringResource(R.string.nodes_auto_selection_disabled)
        runtimeNodeLabel.isNotBlank() -> stringResource(R.string.nodes_auto_selection_current, runtimeNodeLabel)
        connectionState == ConnectionState.Connecting -> stringResource(R.string.nodes_auto_selection_selecting)
        else -> stringResource(R.string.nodes_auto_selection_unavailable)
    }
    val displayedNodeName = if (isAutoSelectionEnabled) {
        stringResource(
            R.string.nodes_auto_selection_label,
            activeNodeName ?: stringResource(R.string.nodes_auto_selection_selecting)
        )
    } else {
        activeNodeName
    }

    var showModeDialog by remember { mutableStateOf(false) }
    val currentMode = stringResource(settings.routingMode.displayNameRes)
    var showUpdateDialog by remember { mutableStateOf(false) }
    var showTestDialog by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showNodeDialog by remember { mutableStateOf(false) }
    var lastConnectionState by remember { mutableStateOf<ConnectionState?>(null) }

    val vpnPermissionNeeded by viewModel.vpnPermissionNeeded.collectAsStateWithLifecycle()
    val requestLocalNetworkPermission = rememberLocalNetworkPermissionRequest()

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        viewModel.onVpnPermissionResult(result.resultCode == Activity.RESULT_OK)
    }

    LaunchedEffect(vpnPermissionNeeded) {
        if (vpnPermissionNeeded) {
            val prepareIntent = VpnService.prepare(context)
            if (prepareIntent != null) {
                vpnPermissionLauncher.launch(prepareIntent)
            } else {
                viewModel.onVpnPermissionResult(true)
            }
        }
    }

    LaunchedEffect(connectionState) {
        lastConnectionState = connectionState
    }

    LaunchedEffect(viewModel) {
        viewModel.toastEvents.collectLatest { message ->
            AppNotificationManager.showMessage(context, message)
        }
    }

    if (showModeDialog) {
        val options = RoutingMode.entries.map { stringResource(it.displayNameRes) }
        SingleSelectDialog(
            title = stringResource(R.string.dashboard_routing_mode),
            options = options,
            selectedIndex = RoutingMode.entries.indexOf(settings.routingMode).coerceAtLeast(0),
            onSelect = { index ->
                val selectedMode = RoutingMode.entries[index]
                scope.launch {
                    settingsViewModel.setRoutingModeAndWait(
                        selectedMode,
                        notifyRestartRequired = false
                    )
                    if (connectionState == ConnectionState.Connected || connectionState == ConnectionState.Connecting) {
                        viewModel.restartVpn()
                    }
                }
                showModeDialog = false
            },
            onDismiss = { showModeDialog = false }
        )
    }

    if (showUpdateDialog) {
        ConfirmDialog(
            title = stringResource(R.string.dashboard_update_subscription),
            message = stringResource(R.string.dashboard_update_subscription_confirm),
            confirmText = stringResource(R.string.common_update),
            onConfirm = {
                viewModel.updateAllSubscriptions()
                showUpdateDialog = false
            },
            onDismiss = { showUpdateDialog = false }
        )
    }

    if (showTestDialog) {
        ConfirmDialog(
            title = stringResource(R.string.dashboard_latency_test),
            message = stringResource(R.string.dashboard_latency_test_confirm),
            confirmText = stringResource(R.string.dashboard_start_test),
            onConfirm = {
                viewModel.testAllNodesLatency()
                showTestDialog = false
            },
            onDismiss = { showTestDialog = false }
        )
    }

    if (showProfileDialog) {
        val options = profiles.map { it.name }
        SingleSelectDialog(
            title = stringResource(R.string.dashboard_select_profile),
            options = options,
            selectedIndex = profiles.indexOfFirst { it.id == activeProfileId }.let { idx ->
                when {
                    options.isEmpty() -> -1
                    idx >= 0 -> idx
                    else -> 0
                }
            },
            onSelect = { index ->
                profiles.getOrNull(index)?.id?.let { viewModel.setActiveProfile(it) }
                showProfileDialog = false
            },
            onDismiss = { showProfileDialog = false }
        )
    }

    if (showNodeDialog) {
        NodePickerPage(
            title = stringResource(R.string.dashboard_select_node),
            profiles = profiles,
            allNodes = rawNodesForSelector,
            displayedNodes = nodesForSelector,
            selectedNodeId = activeNodeId,
            isAutoSelectionEnabled = isAutoSelectionEnabled,
            autoSelectionSubtitle = autoSelectionSubtitle,
            testingNodeIds = testingNodeIds,
            onSelectAuto = viewModel::enableAutoSelection,
            onSelectNode = { node ->
                viewModel.setActiveNode(node.id)
            },
            onDismiss = { showNodeDialog = false }
        )
    }

    // Helper to format bytes
    fun formatBytes(bytes: Long): String = Formatter.formatFileSize(context, bytes)

    // Session duration (ms) as "Xh Ym" or "Mm Ss" — real stats value.
    fun formatDuration(ms: Long): String {
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) "${hours}h ${minutes}m" else "${minutes}m ${seconds}s"
    }

    val statusBarPadding = WindowInsets.statusBars.asPaddingValues()

    // BENTO REWORK (approved mockup): the dashboard is the approved
    // bento mosaic — header, blue Connected tile, Data Usage +
    // Fastest Nodes row, Subscription + Account row. Every tile binds
    // real data; mockup sample texts/numbers are never copied.
    // Removed per the mockup (function preserved elsewhere, see notes):
    // - center circular button -> DISCONNECT/CONNECT pill in the blue
    //   tile (same toggle logic + local-network permission gate);
    // - status/mode chips -> routing mode via Settings > Routing;
    //   status shown in the blue tile;
    // - profile/node selector chips -> Profiles / Nodes tabs;
    // - engine grid -> WireGuard/FENIX are bottom tabs (the grid tiles
    //   were shortcuts to those tabs, no destination lost);
    // - InfoCard -> speeds/totals merged into the blue tile strip +
    //   Data Usage tile; ping retest via the Nodes tab;
    // - quick actions -> subscription refresh via the Subscription
    //   tile's Update pill; logs/diagnostics via Settings > Tools;
    // - My Configs list -> the Nodes tab is the config list.
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(L4Background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(top = statusBarPadding.calculateTopPadding())
                .padding(24.dp)
                .padding(bottom = bottomContentPadding),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header: big title + subtitle, as in the mockup.
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "DASHBOARD",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold
                    ),
                    color = L4Text
                )
                Text(
                    text = "RALYSND • VPN",
                    style = MaterialTheme.typography.labelLarge.copy(
                        letterSpacing = 1.sp
                    ),
                    color = L4TextDim
                )
            }

            val isConnected = connectionState == ConnectionState.Connected
            val isRunning = isConnected || connectionState == ConnectionState.Connecting
            val toggleConnection = { viewModel.toggleConnection() }
            val activeProfile = profiles.find { it.id == activeProfileId }

            // Blue Connected tile (mockup's wide blue tile).
            L4GlassCard(
                modifier = Modifier.fillMaxWidth(),
                tileColor = com.kunk.singbox.ui.theme.BentoBlue,
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(
                                        com.kunk.singbox.ui.theme.BentoSurface,
                                        androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = androidx.compose.material.icons.Icons.Rounded.Shield,
                                    contentDescription = null,
                                    tint = com.kunk.singbox.ui.theme.BentoBlue,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = when (connectionState) {
                                    ConnectionState.Connected -> "Connected"
                                    ConnectionState.Connecting -> "Connecting"
                                    ConnectionState.Error -> "Error"
                                    else -> "Disconnected"
                                },
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold
                                ),
                                color = com.kunk.singbox.ui.theme.BentoSurface
                            )
                        }
                        // CONNECT / DISCONNECT pill: the old center
                        // button's logic, moved into the tile.
                        androidx.compose.material3.Button(
                            onClick = {
                                if (!isRunning && LocalNetworkPermission.requiresLocalNetworkAccess(settings)) {
                                    requestLocalNetworkPermission(toggleConnection)
                                } else {
                                    toggleConnection()
                                }
                            },
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                containerColor = com.kunk.singbox.ui.theme.BentoSurface,
                                contentColor = com.kunk.singbox.ui.theme.BentoInk
                            ),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                horizontal = 16.dp,
                                vertical = 6.dp
                            )
                        ) {
                            Text(
                                text = if (isRunning) "DISCONNECT" else "CONNECT",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                )
                            )
                        }
                    }
                    // Active node line: real node name + real latency.
                    val nodeLine = buildString {
                        append(displayedNodeName ?: stringResource(R.string.dashboard_no_node_selected))
                        activeNodeLatency?.let { append(" • ${it}ms") }
                        if (isConnected) append(" • Protected")
                    }
                    Text(
                        text = nodeLine,
                        style = MaterialTheme.typography.bodyMedium,
                        color = com.kunk.singbox.ui.theme.BentoSurface
                    )
                    // Bottom strip: real session duration + totals.
                    if (isConnected) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(
                                    com.kunk.singbox.ui.theme.BentoSurface.copy(alpha = 0.25f)
                                )
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = "Connected time",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = com.kunk.singbox.ui.theme.BentoSurface.copy(alpha = 0.75f)
                                )
                                Text(
                                    text = formatDuration(stats.duration),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                    ),
                                    color = com.kunk.singbox.ui.theme.BentoSurface
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Down",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = com.kunk.singbox.ui.theme.BentoSurface.copy(alpha = 0.75f)
                                )
                                Text(
                                    text = formatBytes(stats.downloadTotal),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                    ),
                                    color = com.kunk.singbox.ui.theme.BentoSurface
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "Up",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = com.kunk.singbox.ui.theme.BentoSurface.copy(alpha = 0.75f)
                                )
                                Text(
                                    text = formatBytes(stats.uploadTotal),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                    ),
                                    color = com.kunk.singbox.ui.theme.BentoSurface
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "Tap CONNECT to protect your connection",
                            style = MaterialTheme.typography.bodySmall,
                            color = com.kunk.singbox.ui.theme.BentoSurface.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            // Protection warning (conditional state, kept from before).
            val browserExcluded = connectionState == ConnectionState.Connected &&
                dataPlaneReadiness.routingScope.contains("browser=excluded")
            val failedUnprotected =
                connectionState == ConnectionState.Error &&
                    dataPlaneReadiness.status == com.kunk.singbox.ipc.DataPlaneStatus.FAILED_UNPROTECTED
            val protectionWarning = when {
                browserExcluded ->
                    stringResource(R.string.vpn_browser_not_covered)
                failedUnprotected -> stringResource(R.string.vpn_status_failed_unprotected)
                else -> null
            }
            if (protectionWarning != null) {
                Text(
                    text = protectionWarning,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            runCatching { context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS)) }
                        }
                )
            }

            // Row: mint Data Usage tile + amber Fastest Nodes tile.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Mint Data Usage tile. The mockup's today/weekly/
                // monthly split has no counterpart (the app tracks
                // session totals + subscription totals only), so the
                // tile shows subscription usage when the active
                // profile reports a total, else session totals.
                L4GlassCard(
                    modifier = Modifier.weight(1f),
                    tileColor = com.kunk.singbox.ui.theme.BentoMint,
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = androidx.compose.material.icons.Icons.Rounded.BarChart,
                            contentDescription = null,
                            tint = L4Text,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "Data Usage",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                            ),
                            color = L4Text
                        )
                        val profileTotal = activeProfile?.totalTraffic ?: 0L
                        val profileUsed = activeProfile?.usedTraffic ?: 0L
                        if (profileTotal > 0) {
                            val profileRemaining = (profileTotal - profileUsed).coerceAtLeast(0L)
                            Text(
                                text = formatBytes(profileUsed),
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold
                                ),
                                color = L4Text
                            )
                            Text(
                                text = "used",
                                style = MaterialTheme.typography.bodySmall,
                                color = L4TextDim
                            )
                            androidx.compose.material3.LinearProgressIndicator(
                                progress = { (profileUsed.toFloat() / profileTotal.toFloat()).coerceIn(0f, 1f) },
                                modifier = Modifier.fillMaxWidth(),
                                color = L4Text,
                                trackColor = com.kunk.singbox.ui.theme.BentoSurface.copy(alpha = 0.6f)
                            )
                            Text(
                                text = "Limit: ${formatBytes(profileTotal)} • Left: ${formatBytes(profileRemaining)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = L4TextDim
                            )
                        } else {
                            Text(
                                text = formatBytes(stats.downloadTotal),
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold
                                ),
                                color = L4Text
                            )
                            Text(
                                text = "downloaded this session",
                                style = MaterialTheme.typography.bodySmall,
                                color = L4TextDim
                            )
                            Text(
                                text = "Up: ${formatBytes(stats.uploadTotal)} this session",
                                style = MaterialTheme.typography.bodySmall,
                                color = L4TextDim
                            )
                        }
                    }
                }

                // Amber Fastest Nodes tile (the old Scanner section,
                // restyled as the mockup's amber tile; top 3 by
                // measured latency, "—" when unmeasured).
                L4GlassCard(
                    modifier = Modifier.weight(1f),
                    tileColor = com.kunk.singbox.ui.theme.BentoAmber,
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = androidx.compose.material.icons.Icons.Rounded.Bolt,
                                    contentDescription = null,
                                    tint = L4Text,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Fastest Nodes",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                    ),
                                    color = L4Text
                                )
                            }
                            androidx.compose.material3.TextButton(
                                onClick = { viewModel.testAllNodesLatency() }
                            ) {
                                Text(
                                    text = "Ping all",
                                    color = com.kunk.singbox.ui.theme.BentoInk
                                )
                            }
                        }
                        val fastestNodes = remember(nodes) {
                            nodes.sortedWith(
                                compareBy<com.kunk.singbox.model.NodeUi> { it.latencyMs == null }
                                    .thenBy { it.latencyMs ?: Long.MAX_VALUE }
                            ).take(3)
                        }
                        if (fastestNodes.isEmpty()) {
                            Text(
                                text = "No nodes yet",
                                style = MaterialTheme.typography.bodySmall,
                                color = L4TextDim
                            )
                        } else {
                            for (node in fastestNodes) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.setActiveNode(node.id) },
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = node.displayName,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                                        ),
                                        color = L4Text,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = node.latencyMs?.let { "${it}ms" } ?: "—",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                        ),
                                        color = com.kunk.singbox.ui.theme.BentoInk
                                    )
                                }
                            }
                        }
                        Text(
                            text = "Tap to switch • Auto select " + if (isAutoSelectionEnabled) "ON" else "OFF",
                            style = MaterialTheme.typography.bodySmall,
                            color = L4TextDim
                        )
                    }
                }
            }

            // Row: violet Subscription tile + coral Account tile.
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Violet Subscription tile. The mockup's "Pro • Active
                // / Renews / Upgrade Plan" has no counterpart (no tier,
                // no renewal date, no upgrade flow), so the tile shows
                // the active profile's real subscription and its pill
                // refreshes subscriptions via the existing dialog.
                L4GlassCard(
                    modifier = Modifier.weight(1f),
                    tileColor = com.kunk.singbox.ui.theme.BentoViolet,
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = androidx.compose.material.icons.Icons.Rounded.Star,
                                contentDescription = null,
                                tint = com.kunk.singbox.ui.theme.BentoSurface,
                                modifier = Modifier.size(24.dp)
                            )
                            androidx.compose.material3.Button(
                                onClick = { showUpdateDialog = true },
                                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                    containerColor = com.kunk.singbox.ui.theme.BentoSurface,
                                    contentColor = com.kunk.singbox.ui.theme.BentoInk
                                ),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                    horizontal = 12.dp,
                                    vertical = 4.dp
                                )
                            ) {
                                Text(
                                    text = "Update",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                    )
                                )
                            }
                        }
                        Text(
                            text = "Subscription",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                            ),
                            color = com.kunk.singbox.ui.theme.BentoSurface
                        )
                        Text(
                            text = activeProfile?.name ?: stringResource(R.string.dashboard_no_profile_selected),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                            ),
                            color = com.kunk.singbox.ui.theme.BentoSurface
                        )
                        val subTotal = activeProfile?.totalTraffic ?: 0L
                        if (subTotal > 0) {
                            val subRemaining = (subTotal - (activeProfile?.usedTraffic ?: 0L)).coerceAtLeast(0L)
                            Text(
                                text = "Left: ${formatBytes(subRemaining)}",
                                style = MaterialTheme.typography.bodySmall,
                                color = com.kunk.singbox.ui.theme.BentoSurface.copy(alpha = 0.85f)
                            )
                        } else {
                            Text(
                                text = "No subscription data",
                                style = MaterialTheme.typography.bodySmall,
                                color = com.kunk.singbox.ui.theme.BentoSurface.copy(alpha = 0.85f)
                            )
                        }
                    }
                }

                // Coral Account tile. The mockup's "Firefox account /
                // user@example.com" belongs to the FENIX tab (this
                // screen has no Firefox-account state), so the tile
                // shows the real account concept here: the active
                // profile, with the app's own "Protected" marker while
                // connected.
                L4GlassCard(
                    modifier = Modifier.weight(1f),
                    tileColor = com.kunk.singbox.ui.theme.BentoCoral,
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = androidx.compose.material.icons.Icons.Rounded.Person,
                            contentDescription = null,
                            tint = L4Text,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = "Account",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                            ),
                            color = L4Text
                        )
                        Text(
                            text = activeProfile?.name ?: stringResource(R.string.dashboard_no_profile_selected),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
                            ),
                            color = L4Text
                        )
                        activeProfile?.let {
                            Text(
                                text = it.type.name,
                                style = MaterialTheme.typography.bodySmall,
                                color = L4TextDim
                            )
                        }
                        if (isConnected) {
                            Box(
                                modifier = Modifier
                                    .background(
                                        com.kunk.singbox.ui.theme.BentoSurface,
                                        androidx.compose.foundation.shape.RoundedCornerShape(999.dp)
                                    )
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "Protected",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                    ),
                                    color = com.kunk.singbox.ui.theme.BentoInk
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            modifier = Modifier.liquidGlassIconButtonPanel(),
            onClick = onClick
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = MaterialTheme.colorScheme.onBackground
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = liquidGlassStrongContentColor(MaterialTheme.colorScheme.onSurfaceVariant)
        )
    }
}
