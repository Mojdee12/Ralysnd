package com.kunk.singbox.ui.screens

import com.kunk.singbox.R
import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import com.kunk.singbox.utils.parser.NodeLinkParser
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import com.kunk.singbox.ui.theme.BentoAmber
import com.kunk.singbox.ui.theme.BentoBlue
import com.kunk.singbox.ui.theme.BentoCoral
import com.kunk.singbox.ui.theme.BentoInk
import com.kunk.singbox.ui.theme.BentoMint
import com.kunk.singbox.ui.theme.BentoViolet
import com.kunk.singbox.ui.theme.L4GlassCard
import com.kunk.singbox.ui.theme.L4Text
import com.kunk.singbox.ui.theme.L4TextDim
import com.kunk.singbox.ui.theme.PureWhite
import androidx.compose.ui.res.stringResource
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.derivedStateOf
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.kunk.singbox.model.NodeUi
import com.kunk.singbox.model.ProfileType
import com.kunk.singbox.model.UpdateStatus
import com.kunk.singbox.ui.scanner.QrScannerActivity
import com.kunk.singbox.ui.components.AppNotificationManager
import com.kunk.singbox.ui.components.ConfirmDialog
import com.kunk.singbox.ui.components.FloatingMainPageLayout
import com.kunk.singbox.ui.components.InputDialog
import com.kunk.singbox.ui.navigation.Screen
import com.kunk.singbox.ui.theme.liquidGlassIconButtonPanel
import com.kunk.singbox.ui.theme.liquidGlassScreenContainerColor
import com.kunk.singbox.utils.DeepLinkHandler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.Locale

private suspend fun readImportContentSafely(
    context: android.content.Context,
    uri: Uri,
    maxBytes: Int
): String = withContext(Dispatchers.IO) {
    context.contentResolver.openInputStream(uri)?.use { inputStream ->
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        val output = ByteArrayOutputStream()
        var totalBytes = 0

        while (true) {
            val read = inputStream.read(buffer)
            if (read <= 0) break
            totalBytes += read
            require(totalBytes <= maxBytes) {
                context.getString(R.string.profiles_import_content_too_large)
            }
            output.write(buffer, 0, read)
        }

        output.toString(Charsets.UTF_8.name())
    } ?: ""
}

@Composable
@Suppress("LongMethod", "CyclomaticComplexMethod", "CognitiveComplexMethod", "SwallowedException")
fun ProfilesScreen(
    navController: NavController,
    viewModel: com.kunk.singbox.viewmodel.ProfilesViewModel = androidx.lifecycle.viewmodel.compose.viewModel(),
    bottomContentPadding: Dp = 0.dp
) {
    val profiles by viewModel.profiles.collectAsStateWithLifecycle()
    val allNodes by viewModel.allNodes.collectAsStateWithLifecycle()
    val activeProfileId by viewModel.activeProfileId.collectAsStateWithLifecycle()
    val switchingProfileId by viewModel.switchingProfileId.collectAsStateWithLifecycle()
    val importState by viewModel.importState.collectAsStateWithLifecycle()
    val customDraftOutbounds by viewModel.customDraftOutbounds.collectAsStateWithLifecycle()
    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = currentBackStackEntry?.destination?.route

    var showSearchDialog by remember { mutableStateOf(false) }
    // M14: the search dialog used to discard its confirmed text.
    // The query is now real filter state (case-insensitive substring
    // on the profile name); blank = no filter.
    var profileSearchQuery by remember { mutableStateOf("") }
    val isProfileFiltering = profileSearchQuery.isNotBlank()
    var showImportSelection by remember { mutableStateOf(false) }
    var showSubscriptionInput by remember { mutableStateOf(false) }
    var showClipboardInput by remember { mutableStateOf(false) }
    var showCustomConfigPage by rememberSaveable { mutableStateOf(false) }
    var customProfileName by rememberSaveable { mutableStateOf("") }
    var customSelectedNodeIds by rememberSaveable { mutableStateOf(emptyList<String>()) }
    var editingProfile by remember { mutableStateOf<com.kunk.singbox.model.ProfileUi?>(null) }
    var profileToDelete by remember { mutableStateOf<com.kunk.singbox.model.ProfileUi?>(null) }

    val context = LocalContext.current
    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
    val commonLoadingMessage = stringResource(R.string.common_loading)
    val importContentTooLargeMessage = stringResource(R.string.profiles_import_content_too_large)
    val fileImportName = stringResource(R.string.profiles_file_import)
    val fileEmptyMessage = stringResource(R.string.profiles_file_empty)
    val readFileFailedFormat = stringResource(R.string.profiles_read_file_failed, "%s")
    val qrcodeImportName = stringResource(R.string.profiles_qrcode_import)
    val qrcodeSubscriptionName = stringResource(R.string.profiles_qrcode_subscription)
    val cameraPermissionRequiredMessage = stringResource(R.string.profiles_camera_permission_required)
    val clipboardEmptyMessage = stringResource(R.string.profiles_clipboard_empty)


    // M14: displayed list = filtered list while a query is active,
    // full list otherwise. derivedStateOf so it re-computes when the
    // profile list or the query changes (a plain remember() on the
    // list object would go stale). Profile order is the stored
    // order (no drag-reorder in the grid layout).
    val displayedProfiles by remember {
        derivedStateOf {
            if (profileSearchQuery.isBlank()) {
                profiles
            } else {
                profiles.filter { it.name.contains(profileSearchQuery, ignoreCase = true) }
            }
        }
    }


    androidx.compose.runtime.LaunchedEffect(Unit) {
        viewModel.toastEvents.collectLatest { message ->
            AppNotificationManager.showMessage(context, message)
        }
    }

    val pendingImport by DeepLinkHandler.pendingSubscriptionImport.collectAsStateWithLifecycle()

    val pendingProfileDelete = profileToDelete
    if (pendingProfileDelete != null) {
        ConfirmDialog(
            title = stringResource(R.string.common_delete),
            message = stringResource(R.string.common_delete_confirm, pendingProfileDelete.name),
            confirmText = stringResource(R.string.common_delete),
            isDestructive = true,
            onConfirm = {
                viewModel.deleteProfile(pendingProfileDelete.id)
                profileToDelete = null
            },
            onDismiss = { profileToDelete = null }
        )
    }

    pendingImport?.let { data ->
        // M33/M35: the deep-link import ALREADY required confirmation
        // (audit's open question, now verified); for cleartext URLs the
        // dialog additionally carries the cleartext warning, so the
        // confirmation is informed, never a blind tap.
        val deepLinkMessage = stringResource(
            R.string.profiles_deep_link_import_message,
            data.name,
            data.url
        ) + if (com.kunk.singbox.utils.CleartextUrl.isCleartext(data.url)) {
            "\n\n" + stringResource(R.string.profiles_cleartext_warning)
        } else {
            ""
        }
        ConfirmDialog(
            title = stringResource(R.string.profiles_deep_link_import_title),
            message = deepLinkMessage,
            confirmText = stringResource(R.string.common_import),
            onConfirm = {
                val started = viewModel.importSubscription(
                    name = data.name,
                    url = data.url,
                    autoUpdateInterval = data.autoUpdateInterval
                )
                if (started) {
                    DeepLinkHandler.clearPendingSubscriptionImport()
                } else {
                    AppNotificationManager.showMessage(context, commonLoadingMessage)
                }
            },
            onDismiss = { DeepLinkHandler.clearPendingSubscriptionImport() }
        )
    }

    // Handle update state feedback
    val importSuccessMessage = (importState as? com.kunk.singbox.viewmodel.ProfilesViewModel.ImportState.Success)
        ?.let { stringResource(R.string.profiles_import_success, it.profile.name) }
    val importFailedMessage = (importState as? com.kunk.singbox.viewmodel.ProfilesViewModel.ImportState.Error)
        ?.let { stringResource(R.string.profiles_import_failed, it.message) }

    // Handle import state feedback
    androidx.compose.runtime.LaunchedEffect(importState) {
        when (val state = importState) {
            is com.kunk.singbox.viewmodel.ProfilesViewModel.ImportState.Success -> {
                AppNotificationManager.showMessage(
                    context,
                    importSuccessMessage.orEmpty()
                )
                viewModel.resetImportState()
            }
            is com.kunk.singbox.viewmodel.ProfilesViewModel.ImportState.Error -> {
                AppNotificationManager.showMessage(
                    context = context,
                    message = importFailedMessage.orEmpty(),
                    duration = androidx.compose.material3.SnackbarDuration.Long
                )
                viewModel.resetImportState()
            }
            // Loading state is now handled by ImportLoadingDialog
            else -> {}
        }
    }

    if (importState is com.kunk.singbox.viewmodel.ProfilesViewModel.ImportState.Loading) {
        ImportLoadingDialog(
            message = (importState as com.kunk.singbox.viewmodel.ProfilesViewModel.ImportState.Loading).message,
            onCancel = { viewModel.cancelImport() }
        )
    }

    val scope = rememberCoroutineScope()

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                try {
                    val declaredLength = withContext(Dispatchers.IO) {
                        context.contentResolver.openAssetFileDescriptor(uri, "r")?.use { descriptor ->
                            descriptor.length
                        } ?: -1L
                    }
                    if (declaredLength > com.kunk.singbox.viewmodel.ProfilesViewModel.MAX_IMPORT_CONTENT_BYTES) {
                        AppNotificationManager.showMessage(
                            context,
                            importContentTooLargeMessage
                        )
                        return@launch
                    }

                    val content = readImportContentSafely(
                        context = context,
                        uri = uri,
                        maxBytes = com.kunk.singbox.viewmodel.ProfilesViewModel.MAX_IMPORT_CONTENT_BYTES
                    )

                    if (content.isNotBlank()) {

                        val fileName = uri.lastPathSegment?.let { segment ->

                            segment.substringAfterLast("/")
                                .substringAfterLast(":")
                                .substringBeforeLast(".")
                                .takeIf { it.isNotBlank() }
                        } ?: fileImportName

                        viewModel.importFromContent(fileName, content)
                    } else {
                        AppNotificationManager.showMessage(context, fileEmptyMessage)
                    }
                } catch (e: Exception) {
                    AppNotificationManager.showMessage(
                        context = context,
                        message = String.format(Locale.getDefault(), readFileFailedFormat, e.message),
                        duration = androidx.compose.material3.SnackbarDuration.Long
                    )
                }
            }
        }
    }

    val qrCodeLauncher = rememberLauncherForActivityResult(
        contract = ScanContract()
    ) { result ->
        if (result.contents != null) {
            val scannedContent = result.contents

            val isNodeLink = NodeLinkParser.isSupportedLink(scannedContent)

            val isSubscriptionUrl = scannedContent.startsWith("http://") ||
                scannedContent.startsWith("https://")

            when {
                isNodeLink -> {
                    viewModel.importFromContent(qrcodeImportName, scannedContent)
                }
                isSubscriptionUrl -> {
                    val urlParts = scannedContent.split("#")
                    val parsedName = if (urlParts.size > 1 && urlParts[1].isNotBlank()) {
                        try {
                            java.net.URLDecoder.decode(urlParts[1], "UTF-8")
                        } catch (e: Exception) {
                            urlParts[1]
                        }
                    } else {
                        null
                    }
                    val name = parsedName ?: qrcodeSubscriptionName
                    // M33: a QR-scanned http:// subscription used to fetch
                    // with no warning at all. Route cleartext scans through
                    // the same pending-confirmation dialog as deep links
                    // (which now carries the cleartext warning); https
                    // scans keep the direct import the user asked for by
                    // scanning.
                    if (com.kunk.singbox.utils.CleartextUrl.isCleartext(scannedContent)) {
                        DeepLinkHandler.setPendingSubscriptionImport(name, scannedContent, 0)
                    } else {
                        viewModel.importSubscription(name, scannedContent, 0)
                    }
                }
                scannedContent.trim().startsWith("{") || scannedContent.trim().startsWith("proxies:") -> {

                    viewModel.importFromContent(qrcodeImportName, scannedContent)
                }
                else -> {

                    viewModel.importFromContent(qrcodeImportName, scannedContent)
                }
            }
        }
    }

    fun createScanOptions(): ScanOptions {
        return ScanOptions().apply {
            setDesiredBarcodeFormats(ScanOptions.QR_CODE)
            setPrompt("")
            setCameraId(0)
            setBeepEnabled(true)
            setBarcodeImageEnabled(false)
            setOrientationLocked(false)
            setCaptureActivity(QrScannerActivity::class.java) // custom scanner activity with transparent status bar
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            qrCodeLauncher.launch(createScanOptions())
        } else {
            AppNotificationManager.showMessage(context, cameraPermissionRequiredMessage)
        }
    }

    if (showImportSelection) {
        ImportSelectionDialog(
            onDismiss = { showImportSelection = false },
            onTypeSelected = { type ->
                showImportSelection = false
                when (type) {
                    ProfileImportType.Subscription -> showSubscriptionInput = true
                    ProfileImportType.Clipboard -> showClipboardInput = true
                    ProfileImportType.Custom -> {
                        viewModel.clearCustomDraftNodes()
                        customProfileName = ""
                        customSelectedNodeIds = emptyList()
                        showCustomConfigPage = true
                    }
                    ProfileImportType.File -> {

                        filePickerLauncher.launch(arrayOf(
                            "application/json",
                            "text/plain",
                            "application/x-yaml",
                            "text/yaml",
                            "*/*"
                        ))
                    }
                    ProfileImportType.QRCode -> {

                        when {
                            ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.CAMERA
                            ) == PackageManager.PERMISSION_GRANTED -> {

                                qrCodeLauncher.launch(createScanOptions())
                            }
                            else -> {

                                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                        }
                    }
                }
            }
        )
    }

    if (showSubscriptionInput) {
        SubscriptionInputDialog(
            onDismiss = { showSubscriptionInput = false },
            onConfirm = { name, url, autoUpdateInterval, dnsPreResolve, dnsServer, dnsOverride ->
                viewModel.importSubscription(
                    name = name,
                    url = url,
                    autoUpdateInterval = autoUpdateInterval,
                    dnsPreResolve = dnsPreResolve,
                    dnsServer = dnsServer,
                    dnsOverride = dnsOverride
                )
                showSubscriptionInput = false
            }
        )
    }

    if (showClipboardInput) {
        val clipboardEmptyMsg = stringResource(R.string.profiles_clipboard_empty)
        val nameInvalidMsg = stringResource(R.string.profiles_name_invalid)
        val defaultClipboardName = stringResource(R.string.profiles_clipboard_import)

        InputDialog(
            title = stringResource(R.string.profiles_import_clipboard),
            placeholder = stringResource(R.string.profiles_import_clipboard_hint),
            initialValue = "",
            confirmText = stringResource(R.string.common_import),
            onConfirm = { name ->
                if (name.contains("://")) {
                    AppNotificationManager.showMessage(context, nameInvalidMsg)
                } else {
                    val content = clipboardManager.getText()?.text ?: ""
                    if (content.isNotBlank()) {
                        viewModel.importFromContent(if (name.isBlank()) defaultClipboardName else name, content)
                        showClipboardInput = false
                    } else {
                        AppNotificationManager.showMessage(context, clipboardEmptyMsg)
                    }
                }
            },
            onDismiss = { showClipboardInput = false }
        )
    }

    if (showCustomConfigPage && currentRoute == Screen.Profiles.route) {
        DisposableEffect(Unit) {
            viewModel.setAllNodesUiActive(true)
            onDispose {
                viewModel.setAllNodesUiActive(false)
            }
        }

        val subscriptionProfileNames = remember(profiles) {
            profiles
                .filter { it.type == ProfileType.Subscription }
                .associate { it.id to it.name }
        }
        val selectableNodes = remember(allNodes, subscriptionProfileNames) {
            allNodes
                .filter { subscriptionProfileNames.containsKey(it.sourceProfileId) }
                .sortedWith(compareBy<NodeUi>({ subscriptionProfileNames[it.sourceProfileId] ?: "" }, { it.name }))
        }

        CustomConfigPage(
            nodes = selectableNodes,
            profileNames = subscriptionProfileNames,
            addedNodes = customDraftOutbounds,
            name = customProfileName,
            selectedNodeIds = customSelectedNodeIds,
            onNameChange = { customProfileName = it },
            onSelectedNodeIdsChange = { customSelectedNodeIds = it },
            onPasteNodeLink = {
                val content = clipboardManager.getText()?.text.orEmpty()
                if (content.isBlank()) {
                    AppNotificationManager.showMessage(context, clipboardEmptyMessage)
                } else {
                    viewModel.addCustomDraftNodeLink(content)
                }
            },
            onManualAddNode = {
                navController.navigate(Screen.CustomProfileNodeProtocolSelect.route)
            },
            onRemoveAddedNode = viewModel::removeCustomDraftOutbound,
            onDismiss = {
                viewModel.clearCustomDraftNodes()
                customProfileName = ""
                customSelectedNodeIds = emptyList()
                showCustomConfigPage = false
            },
            onConfirm = { name, selectedNodeIds ->
                viewModel.createCustomConfig(name, selectedNodeIds) { success ->
                    if (success) {
                        customProfileName = ""
                        customSelectedNodeIds = emptyList()
                        showCustomConfigPage = false
                    }
                }
            }
        )
    }

    if (showSearchDialog) {
        InputDialog(
            title = stringResource(R.string.profiles_search),
            initialValue = profileSearchQuery,
            placeholder = stringResource(R.string.profiles_search_hint),
            confirmText = stringResource(R.string.common_search),
            // M14: the confirmed text is now stored and filters the
            // list below (was: dialog closed and the text discarded).
            onConfirm = { query ->
                profileSearchQuery = query.trim()
                showSearchDialog = false
            },
            onDismiss = { showSearchDialog = false }
        )
    }

    if (editingProfile != null) {
        val profile = checkNotNull(editingProfile)
        SubscriptionInputDialog(
            initialName = profile.name,
            initialUrl = profile.url ?: "",
            initialAutoUpdateInterval = profile.autoUpdateInterval,
            initialDnsPreResolve = profile.dnsPreResolve,
            initialDnsServer = profile.dnsServer,
            initialDnsOverride = profile.dnsOverride,
            title = stringResource(R.string.profiles_edit_profile),
            onDismiss = { editingProfile = null },
            onConfirm = { name, url, autoUpdateInterval, dnsPreResolve, dnsServer, dnsOverride ->
                viewModel.updateProfileMetadata(
                    profileId = profile.id,
                    newName = name,
                    newUrl = url,
                    autoUpdateInterval = autoUpdateInterval,
                    dnsPreResolve = dnsPreResolve,
                    dnsServer = dnsServer,
                    dnsOverride = dnsOverride
                )
                editingProfile = null
            }
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            containerColor = liquidGlassScreenContainerColor(MaterialTheme.colorScheme.background),
            contentWindowInsets = WindowInsets(0, 0, 0, 0)
        ) { padding ->
            FloatingMainPageLayout(
                title = stringResource(R.string.profiles_title),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = padding.calculateBottomPadding()),
                actions = {
                    // M14: clear-search affordance, shown only while a
                    // filter is active; tapping it restores the full list.
                    if (isProfileFiltering) {
                        IconButton(
                            modifier = Modifier.liquidGlassIconButtonPanel(),
                            onClick = { profileSearchQuery = "" }
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search", tint = MaterialTheme.colorScheme.onBackground)
                        }
                    }
                    IconButton(
                        modifier = Modifier.liquidGlassIconButtonPanel(),
                        onClick = { showSearchDialog = true }
                    ) {
                        Icon(Icons.Rounded.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.onBackground)
                    }
                }
            ) { contentTopPadding ->
                // BENTO REWORK (approved mockup): 2-column profile
                // tile grid + blue Active Profile tile + amber dashed
                // Add tile + white Tip tile. Long-press drag-reorder
                // is removed: it has no home in the grid mockup, and
                // the stored profile order is kept as-is. The mockup's
                // "Protocol / Server" lines have no counterpart
                // (profiles are multi-node containers with mixed
                // protocols, no single protocol/server field), so tiles
                // show type + node count + remaining volume instead.
                // The mockup's "Connected • 28ms" pill has no
                // Profiles-side data (no connection/latency state in
                // this screen's scope), so the Active tile shows an
                // "Active" pill. The mockup's Tip sentence about sync
                // is NOT a real feature (profiles are local), so the
                // Tip tile carries honest guidance instead.
                val profileTileColors = remember {
                    listOf(
                        BentoCoral to BentoInk,
                        BentoMint to BentoInk,
                        BentoViolet to PureWhite
                    )
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        top = contentTopPadding + 16.dp,
                        end = 16.dp,
                        bottom = 16.dp + bottomContentPadding
                    ),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // M14: honest empty state when a search matches
                    // nothing (instead of a blank list).
                    if (isProfileFiltering && displayedProfiles.isEmpty()) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Text(
                                text = "No profiles match \"$profileSearchQuery\"",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.fillMaxWidth().padding(16.dp)
                            )
                        }
                    }
                    // Blue Active Profile tile (full span).
                    val activeProfile = displayedProfiles.find { it.id == activeProfileId }
                    if (activeProfile != null) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            L4GlassCard(
                                modifier = Modifier.fillMaxWidth(),
                                tileColor = BentoBlue,
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .background(
                                                    PureWhite,
                                                    RoundedCornerShape(12.dp)
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = null,
                                                tint = BentoBlue,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = "Active Profile",
                                            style = MaterialTheme.typography.titleLarge.copy(
                                                fontWeight = FontWeight.ExtraBold
                                            ),
                                            color = PureWhite
                                        )
                                    }
                                    Text(
                                        text = "${activeProfile.name} is currently active",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = PureWhite
                                    )
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                PureWhite,
                                                RoundedCornerShape(999.dp)
                                            )
                                            .padding(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = if (switchingProfileId == activeProfile.id) "Switching…" else "Active",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Bold
                                            ),
                                            color = BentoInk
                                        )
                                    }
                                }
                            }
                        }
                    }
                    // Profile tiles (2-column grid).
                    itemsIndexed(
                        items = displayedProfiles,
                        key = { _, profile -> profile.id }
                    ) { index, profile ->
                        val (tileColor, tileContent) = profileTileColors[index % profileTileColors.size]
                        ProfileBentoTile(
                            profile = profile,
                            tileColor = tileColor,
                            tileContent = tileContent,
                            nodeCount = allNodes.count { it.sourceProfileId == profile.id },
                            isActive = profile.id == activeProfileId,
                            isSwitching = switchingProfileId == profile.id,
                            onSelect = { viewModel.setActiveProfile(profile.id) },
                            onUpdate = { viewModel.updateProfile(profile.id) },
                            onToggle = { viewModel.toggleProfileEnabled(profile.id) },
                            onEdit = {
                                if (profile.type == ProfileType.Subscription ||
                                    profile.type == ProfileType.Imported) {
                                    editingProfile = profile
                                } else {
                                    navController.navigate(Screen.ProfileEditor.createRoute(profile.id))
                                }
                            },
                            onDelete = { profileToDelete = profile }
                        )
                    }
                    // Amber dashed Add tile (grid cell; replaces the FAB).
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .drawBehind {
                                    val strokeWidth = 2.dp.toPx()
                                    val dash = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                                    drawRoundRect(
                                        color = BentoAmber,
                                        topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
                                        size = Size(size.width - strokeWidth, size.height - strokeWidth),
                                        cornerRadius = CornerRadius(24.dp.toPx(), 24.dp.toPx()),
                                        style = Stroke(width = strokeWidth, pathEffect = dash)
                                    )
                                }
                                .clickable { showImportSelection = true }
                                .padding(14.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    imageVector = Icons.Rounded.Add,
                                    contentDescription = null,
                                    tint = L4Text,
                                    modifier = Modifier.size(28.dp)
                                )
                                Text(
                                    text = "Add New Profile",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = L4Text
                                )
                                Text(
                                    text = "Create a new VPN profile",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = L4TextDim
                                )
                            }
                        }
                    }
                    // White Tip tile (full span; honest text only).
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        L4GlassCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Info,
                                    contentDescription = null,
                                    tint = BentoBlue,
                                    modifier = Modifier.size(24.dp)
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "Tip",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = L4Text
                                    )
                                    Text(
                                        text = "Tap a profile to make it active. Use the … menu on a tile to edit, update, enable or delete it.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = L4TextDim
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Bento profile tile (approved mockup): icon by type, name, type,
 * node count, remaining volume when the profile reports a total,
 * status pill, and a "…" menu with the same actions the old
 * ProfileCard offered (edit / update / enable-disable / delete).
 * The mockup's per-profile "Protocol / Server" lines have no
 * counterpart (profiles hold many nodes with mixed protocols).
 */
@Composable
private fun ProfileBentoTile(
    profile: com.kunk.singbox.model.ProfileUi,
    tileColor: androidx.compose.ui.graphics.Color,
    tileContent: androidx.compose.ui.graphics.Color,
    nodeCount: Int,
    isActive: Boolean,
    isSwitching: Boolean,
    onSelect: () -> Unit,
    onUpdate: () -> Unit,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }
    val context = LocalContext.current
    fun formatBytes(bytes: Long): String =
        android.text.format.Formatter.formatFileSize(context, bytes)
    val typeIcon = when (profile.type) {
        ProfileType.Subscription -> Icons.Rounded.CloudDownload
        ProfileType.LocalFile -> Icons.Rounded.Description
        ProfileType.Imported -> Icons.Rounded.Download
        ProfileType.Custom -> Icons.Rounded.Build
    }
    val pillText = when {
        isSwitching -> "Switching…"
        profile.updateStatus == UpdateStatus.Updating -> "Updating…"
        !profile.enabled -> "Disabled"
        isActive -> "Active"
        else -> "Idle"
    }
    L4GlassCard(
        modifier = modifier,
        tileColor = tileColor,
        onClick = onSelect
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = typeIcon,
                    contentDescription = null,
                    tint = tileContent,
                    modifier = Modifier.size(28.dp)
                )
                Box(modifier = Modifier.wrapContentSize(Alignment.TopStart)) {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.MoreVert,
                            contentDescription = "More",
                            tint = tileContent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Edit") },
                            onClick = { showMenu = false; onEdit() }
                        )
                        DropdownMenuItem(
                            text = { Text("Update") },
                            onClick = { showMenu = false; onUpdate() }
                        )
                        DropdownMenuItem(
                            text = { Text(if (profile.enabled) "Disable" else "Enable") },
                            onClick = { showMenu = false; onToggle() }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete") },
                            onClick = { showMenu = false; onDelete() }
                        )
                    }
                }
            }
            Text(
                text = profile.name,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold
                ),
                color = tileContent,
                maxLines = 2
            )
            Text(
                text = profile.type.name,
                style = MaterialTheme.typography.bodySmall,
                color = tileContent.copy(alpha = 0.85f)
            )
            Text(
                text = "$nodeCount nodes",
                style = MaterialTheme.typography.bodySmall,
                color = tileContent.copy(alpha = 0.85f)
            )
            if (profile.totalTraffic > 0) {
                val remaining = (profile.totalTraffic - profile.usedTraffic).coerceAtLeast(0L)
                Text(
                    text = "Left: ${formatBytes(remaining)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = tileContent.copy(alpha = 0.85f)
                )
            }
            Box(
                modifier = Modifier
                    .background(
                        tileContent.copy(alpha = 0.2f),
                        RoundedCornerShape(999.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = pillText,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = tileContent
                )
            }
        }
    }
}
