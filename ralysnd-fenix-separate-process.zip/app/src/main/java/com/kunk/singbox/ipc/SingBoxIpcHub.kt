package com.kunk.singbox.ipc

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.RemoteCallbackList
import android.os.SystemClock
import android.util.Log
import com.kunk.singbox.aidl.ISingBoxServiceCallback
import com.kunk.singbox.repository.*
import com.kunk.singbox.repository.LogRepository
import com.kunk.singbox.service.ProxyOnlyService
import com.kunk.singbox.service.SingBoxService
import com.kunk.singbox.service.root.RootTransparentForegroundService
import com.kunk.singbox.service.ServiceState
import com.kunk.singbox.service.manager.BackgroundPowerManager
import com.kunk.singbox.service.manager.ServiceStateHolder
import com.kunk.singbox.service.manager.UrlTestTagMatcher
import com.kunk.singbox.utils.perf.PerfTracer
import java.lang.ref.WeakReference
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.locks.ReentrantLock
import java.util.concurrent.ScheduledThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.withLock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

internal fun Bundle.toRuntimeStateSnapshot(): VpnStateStore.RuntimeStateSnapshot {
    val readinessBundle = getBundle(SingBoxIpcHub.SNAPSHOT_READINESS)
    val generation = getLong(SingBoxIpcHub.SNAPSHOT_GENERATION, 0L)
    return VpnStateStore.normalizeRuntimeStateSnapshot(
        VpnStateStore.RuntimeStateSnapshot(
            generation = generation,
            stateOrdinal = getInt(SingBoxIpcHub.SNAPSHOT_STATE, ServiceState.STOPPED.ordinal),
            activeLabel = getString(SingBoxIpcHub.SNAPSHOT_ACTIVE_LABEL).orEmpty(),
            lastError = getString(SingBoxIpcHub.SNAPSHOT_LAST_ERROR).orEmpty(),
            manuallyStopped = getBoolean(SingBoxIpcHub.SNAPSHOT_MANUALLY_STOPPED, false),
            readiness = readinessBundle?.toReadinessSnapshot(generation)
                ?: DataPlaneReadinessSnapshot.stopped()
        )
    )
}

private fun Bundle.toReadinessSnapshot(generation: Long): DataPlaneReadinessSnapshot {
    return DataPlaneReadinessSnapshot(
        schemaVersion = getInt(SingBoxIpcHub.READINESS_SCHEMA_VERSION, 0),
        status = enumValueOrDefault(getString(SingBoxIpcHub.READINESS_STATUS), DataPlaneStatus.STOPPED),
        tunEstablished = getBoolean(SingBoxIpcHub.READINESS_TUN_ESTABLISHED, false),
        systemVpnTransport = getBoolean(SingBoxIpcHub.READINESS_SYSTEM_VPN, false),
        systemVpnOwnerStatus = enumValueOrDefault(
            getString(SingBoxIpcHub.READINESS_OWNER_STATUS),
            VpnOwnerStatus.UNKNOWN
        ),
        coreReady = getBoolean(SingBoxIpcHub.READINESS_CORE_READY, false),
        selectorReady = getBoolean(SingBoxIpcHub.READINESS_SELECTOR_READY, false),
        recoveryActive = getBoolean(SingBoxIpcHub.READINESS_RECOVERY_ACTIVE, false),
        routingScope = getString(SingBoxIpcHub.READINESS_ROUTING_SCOPE).orEmpty(),
        lockdownStatus = enumValueOrDefault(
            getString(SingBoxIpcHub.READINESS_LOCKDOWN_STATUS),
            VpnLockdownStatus.UNKNOWN
        ),
        foreignVpnDetected = getBoolean(SingBoxIpcHub.READINESS_FOREIGN_VPN, false),
        ownedVpnNetworkLost = getBoolean(SingBoxIpcHub.READINESS_OWNED_VPN_LOST, false),
        ownedVpnNetworkHandle = getLong(SingBoxIpcHub.READINESS_OWNED_NETWORK, 0L),
        observedVpnNetworkHandle = getLong(SingBoxIpcHub.READINESS_OBSERVED_NETWORK, 0L),
        rootPid = getInt(SingBoxIpcHub.READINESS_ROOT_PID, 0),
        rootFdCount = getInt(SingBoxIpcHub.READINESS_ROOT_FD_COUNT, 0),
        rootRuntimeSessionId = getString(SingBoxIpcHub.READINESS_ROOT_SESSION).orEmpty(),
        rootRuleRevision = getLong(SingBoxIpcHub.READINESS_ROOT_RULE_REVISION, 0L),
        rootRoutingGeneration = getLong(SingBoxIpcHub.READINESS_ROOT_ROUTING_GENERATION, 0L),
        rootConfigSha256 = getString(SingBoxIpcHub.READINESS_ROOT_CONFIG_SHA256).orEmpty(),
        rootSidecarSha256 = getString(SingBoxIpcHub.READINESS_ROOT_SIDECAR_SHA256).orEmpty(),
        rootStaticPlanSha256 = getString(SingBoxIpcHub.READINESS_ROOT_STATIC_SHA256).orEmpty(),
        rootAppRoutingSha256 = getString(SingBoxIpcHub.READINESS_ROOT_APP_SHA256).orEmpty(),
        rootResolvedPlanSha256 = getString(SingBoxIpcHub.READINESS_ROOT_RESOLVED_SHA256).orEmpty(),
        rootWatchdogReady = getBoolean(SingBoxIpcHub.READINESS_ROOT_WATCHDOG, false),
        rootRulesInstalled = getBoolean(SingBoxIpcHub.READINESS_ROOT_RULES, false),
        lastReadinessReason = getString(SingBoxIpcHub.READINESS_REASON).orEmpty(),
        updatedAtElapsedMs = getLong(SingBoxIpcHub.READINESS_UPDATED_AT, 0L),
        serviceInstanceId = getString(SingBoxIpcHub.READINESS_SERVICE_INSTANCE).orEmpty(),
        generation = generation,
        vpnSessionId = getLong(SingBoxIpcHub.READINESS_VPN_SESSION, 0L)
    ).normalized()
}

private inline fun <reified T : Enum<T>> enumValueOrDefault(value: String?, fallback: T): T {
    return value?.let { enumValue -> enumValues<T>().firstOrNull { it.name == enumValue } } ?: fallback
}

internal fun resolveUpdatedRuntimeLastError(
    state: ServiceState?,
    explicitError: String?,
    previousError: String
): String = explicitError ?: if (state == ServiceState.STARTING) "" else previousError

internal fun VpnStateStore.RuntimeStateSnapshot.persistenceKey(): String =
    "$stateOrdinal:${readiness.status}:$lastError:$manuallyStopped:$activeLabel"

@Suppress("TooManyFunctions")
object SingBoxIpcHub {
    private const val TAG = "SingBoxIpcHub"

    internal const val SNAPSHOT_GENERATION = "generation"
    internal const val SNAPSHOT_STATE = "state"
    internal const val SNAPSHOT_ACTIVE_LABEL = "active_label"
    internal const val SNAPSHOT_LAST_ERROR = "last_error"
    internal const val SNAPSHOT_MANUALLY_STOPPED = "manually_stopped"
    internal const val SNAPSHOT_READINESS = "readiness"
    internal const val READINESS_SCHEMA_VERSION = "schema_version"
    internal const val READINESS_STATUS = "status"
    internal const val READINESS_TUN_ESTABLISHED = "tun_established"
    internal const val READINESS_SYSTEM_VPN = "system_vpn_transport"
    internal const val READINESS_OWNER_STATUS = "owner_status"
    internal const val READINESS_CORE_READY = "core_ready"
    internal const val READINESS_SELECTOR_READY = "selector_ready"
    internal const val READINESS_RECOVERY_ACTIVE = "recovery_active"
    internal const val READINESS_ROUTING_SCOPE = "routing_scope"
    internal const val READINESS_LOCKDOWN_STATUS = "lockdown_status"
    internal const val READINESS_FOREIGN_VPN = "foreign_vpn_detected"
    internal const val READINESS_OWNED_VPN_LOST = "owned_vpn_lost"
    internal const val READINESS_OWNED_NETWORK = "owned_vpn_network"
    internal const val READINESS_OBSERVED_NETWORK = "observed_vpn_network"
    internal const val READINESS_ROOT_PID = "root_pid"
    internal const val READINESS_ROOT_FD_COUNT = "root_fd_count"
    internal const val READINESS_ROOT_SESSION = "root_runtime_session"
    internal const val READINESS_ROOT_RULE_REVISION = "root_rule_revision"
    internal const val READINESS_ROOT_ROUTING_GENERATION = "root_routing_generation"
    internal const val READINESS_ROOT_CONFIG_SHA256 = "root_config_sha256"
    internal const val READINESS_ROOT_SIDECAR_SHA256 = "root_sidecar_sha256"
    internal const val READINESS_ROOT_STATIC_SHA256 = "root_static_plan_sha256"
    internal const val READINESS_ROOT_APP_SHA256 = "root_app_routing_sha256"
    internal const val READINESS_ROOT_RESOLVED_SHA256 = "root_resolved_plan_sha256"
    internal const val READINESS_ROOT_WATCHDOG = "root_watchdog_ready"
    internal const val READINESS_ROOT_RULES = "root_rules_installed"
    internal const val READINESS_REASON = "reason"
    internal const val READINESS_UPDATED_AT = "updated_at_elapsed_ms"
    internal const val READINESS_SERVICE_INSTANCE = "service_instance_id"
    internal const val READINESS_VPN_SESSION = "vpn_session_id"

    private const val MIN_BROADCAST_INTERVAL_MS = 50L

    private val mainHandler = Handler(Looper.getMainLooper())

    private val broadcastScheduler = ScheduledThreadPoolExecutor(1).apply {
        removeOnCancelPolicy = true
    }

    private val logRepo by lazy { LogRepository.getInstance() }
    private val ipcScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val pendingUrlTestJobs = ConcurrentHashMap<Long, kotlinx.coroutines.Job>()

    private fun log(msg: String) {
        Log.i(TAG, msg)
        logRepo.addLog("INFO [IPC] $msg")
    }

    private val stateLock = Any()

    private val serviceInstanceId = UUID.randomUUID().toString()

    @Volatile
    private var stateSnapshot = VpnStateStore.RuntimeStateSnapshot(
        readiness = DataPlaneReadinessSnapshot.stopped(serviceInstanceId)
    )

    private val callbacks = RemoteCallbackList<ISingBoxServiceCallback>()

    private val stateNames = ServiceState.entries.map { it.name }.toTypedArray()

    private val lastBroadcastAtMs = AtomicLong(0L)
    private val broadcastPending = AtomicBoolean(false)
    private val broadcasting = AtomicBoolean(false)
    private val heartbeatStarted = AtomicBoolean(false)
    private val lastPersistedAtMs = AtomicLong(0L)
    @Volatile private var lastPersistedSafetyKey: String = ""
    private val broadcastLock = ReentrantLock()
    private val callbackBroadcastLock = ReentrantLock()

    @Volatile
    private var powerManager: BackgroundPowerManager? = null

    @Volatile
    private var serviceRef: WeakReference<SingBoxIpcService>? = null

    private val lastStateUpdateAtMs = AtomicLong(0L)
    private val lastBackgroundAtMs = AtomicLong(0L)
    private val appForeground = AtomicBoolean(false)

    fun setPowerManager(manager: BackgroundPowerManager?) {
        powerManager = manager
        Log.d(TAG, "PowerManager ${if (manager != null) "set" else "cleared"}")
    }

    fun registerService(service: SingBoxIpcService) {
        synchronized(this) {
            serviceRef?.clear()
            serviceRef = WeakReference(service)
        }
        synchronized(stateLock) {
            val persisted = VpnStateStore.getRuntimeStateSnapshot()
            stateSnapshot = restoreSnapshotOnServiceRegistration(
                current = stateSnapshot,
                persisted = persisted,
                liveCoreState = currentLiveCoreState(),
                serviceInstanceId = serviceInstanceId,
                nowElapsedMs = SystemClock.elapsedRealtime()
            )
            if (currentLiveCoreState() == null && stateSnapshot.stateOrdinal == ServiceState.STOPPED.ordinal) {
                VpnStateStore.setActive(false)
                VpnStateStore.setPending("")
                VpnStateStore.persistRuntimeStateSnapshotBestEffort(stateSnapshot)
            }
        }
        log("SingBoxIpcService registered")
        startReadinessHeartbeat()
        if (currentLiveCoreState() != null) updateReadiness { it }
    }

    internal fun restoreSnapshotOnServiceRegistration(
        current: VpnStateStore.RuntimeStateSnapshot,
        persisted: VpnStateStore.RuntimeStateSnapshot,
        liveCoreState: ServiceState?,
        serviceInstanceId: String,
        nowElapsedMs: Long
    ): VpnStateStore.RuntimeStateSnapshot {
        val restored = if (persisted.generation >= current.generation) persisted else current
        val visibleStateOrdinal = resolveVisibleStateOrdinal(restored.stateOrdinal, liveCoreState)
        val readiness = if (liveCoreState == null) {
            DataPlaneReadinessSnapshot.stopped(serviceInstanceId).copy(generation = restored.generation)
        } else {
            val source = current.readiness.takeIf { current.generation > 0L } ?: restored.readiness
            source.copy(
                serviceInstanceId = serviceInstanceId,
                updatedAtElapsedMs = nowElapsedMs,
                generation = restored.generation
            )
        }
        return restored.copy(stateOrdinal = visibleStateOrdinal, readiness = readiness)
    }

    fun serviceInstanceId(): String = serviceInstanceId

    private fun startReadinessHeartbeat() {
        if (!heartbeatStarted.compareAndSet(false, true)) return
        broadcastScheduler.scheduleWithFixedDelay(
            {
                if (currentLiveCoreState() != null) {
                    updateReadiness { it }
                }
            },
            DataPlaneReadinessSnapshot.HEARTBEAT_INTERVAL_MS,
            DataPlaneReadinessSnapshot.HEARTBEAT_INTERVAL_MS,
            TimeUnit.MILLISECONDS
        )
    }

    fun unregisterService(service: SingBoxIpcService) {
        synchronized(this) {
            if (serviceRef?.get() !== service) return
            serviceRef?.clear()
            serviceRef = null
        }
        log("SingBoxIpcService unregistered")
    }

    fun onServiceBinderDied() {
        synchronized(this) {
            serviceRef?.clear()
            serviceRef = null
        }
        synchronized(stateLock) {
            val current = stateSnapshot
            stateSnapshot = VpnStateStore.buildNextRuntimeStateSnapshot(current) { snapshot ->
                snapshot.copy(
                    stateOrdinal = ServiceState.STOPPED.ordinal,
                    activeLabel = "",
                    lastError = snapshot.lastError.takeIf {
                        shouldPreserveLastErrorOnBinderDied(it, snapshot.manuallyStopped)
                    }.orEmpty(),
                    readiness = DataPlaneReadinessSnapshot.stopped(serviceInstanceId).copy(
                        status = DataPlaneStatus.FAILED_UNPROTECTED,
                        lastReadinessReason = "ipc_service_died",
                        updatedAtElapsedMs = SystemClock.elapsedRealtime()
                    )
                )
            }
        }
        persistAndBroadcast(stateSnapshot)
        Log.w(TAG, "SingBoxIpcService binder died")
        runCatching {
            logRepo.addLog("WARN [IPC] SingBoxIpcService binder died")
        }
    }

    internal fun shouldPreserveLastErrorOnBinderDied(
        lastError: String,
        manuallyStopped: Boolean
    ): Boolean {
        return manuallyStopped && lastError.isNotBlank()
    }

    internal fun resolveRealtimeUrlTestNodeDelay(
        nodeTag: String,
        progressResults: List<Map<String, Int>>
    ): Int {
        var resolvedDelay = -1
        progressResults.forEach { results ->
            val matched = UrlTestTagMatcher.resolveDelayDetail(results, nodeTag)
            val candidate = matched?.delay ?: -1
            if (candidate > 0) {
                resolvedDelay = candidate
            }
        }
        return resolvedDelay
    }

    private fun currentLiveCoreState(): ServiceState? {
        val vpnService = ServiceStateHolder.instance
        val vpnState = vpnService?.currentServiceState()
        val owner = VpnStateStore.getStopOwnerMode() ?: VpnStateStore.getMode()
        return when (owner) {
            VpnStateStore.CoreMode.VPN -> vpnState?.takeIf { it != ServiceState.STOPPED }
                ?: when {
                    vpnState == ServiceState.STOPPING -> ServiceState.STOPPING
                    SingBoxService.isStarting -> ServiceState.STARTING
                    SingBoxService.isRunning -> ServiceState.RUNNING
                    else -> null
                }
            VpnStateStore.CoreMode.ROOT -> when {
                RootTransparentForegroundService.isStopping -> ServiceState.STOPPING
                RootTransparentForegroundService.isStarting -> ServiceState.STARTING
                RootTransparentForegroundService.isRunning -> ServiceState.RUNNING
                else -> null
            }
            VpnStateStore.CoreMode.PROXY -> when {
                ProxyOnlyService.isStarting -> ServiceState.STARTING
                ProxyOnlyService.isRunning -> ServiceState.RUNNING
                else -> null
            }
            VpnStateStore.CoreMode.GO_CORE -> when {
                // SEPARATE PROCESS: GoCoreVpnService runs in :gocore, so
                // its statics are invisible here (this hub runs in :bg).
                // Read the cross-process store the service maintains:
                // pending "starting" → STARTING, active → RUNNING,
                // otherwise STARTING (requested, not yet up — a failed
                // start clears the mode to NONE, so it never lands here
                // as a stale RUNNING).
                VpnStateStore.getPending() == "starting" -> ServiceState.STARTING
                VpnStateStore.getActive() -> ServiceState.RUNNING
                else -> ServiceState.STARTING
            }
            VpnStateStore.CoreMode.NONE -> null
        }
    }

    internal fun resolveVisibleStateOrdinal(
        cachedStateOrdinal: Int,
        liveCoreState: ServiceState?
    ): Int {
        if (ServiceState.values().getOrNull(cachedStateOrdinal) == null) return ServiceState.STOPPED.ordinal
        return liveCoreState?.ordinal ?: ServiceState.STOPPED.ordinal
    }

    fun onAppLifecycle(isForeground: Boolean) {
        appForeground.set(isForeground)
        val vpnState = stateNames.getOrNull(stateSnapshot.stateOrdinal) ?: "UNKNOWN"
        log("onAppLifecycle: isForeground=$isForeground, vpnState=$vpnState")

        if (isForeground) {
            powerManager?.onAppForeground()
        } else {
            lastBackgroundAtMs.set(SystemClock.elapsedRealtime())
            powerManager?.onAppBackground()
        }
    }

    fun getStateSnapshotBundle(): Bundle {
        return currentStateSnapshot().toBundle()
    }

    fun currentReadiness(): DataPlaneReadinessSnapshot = synchronized(stateLock) {
        stateSnapshot.readiness
    }

    fun currentStateGeneration(): Long = synchronized(stateLock) {
        stateSnapshot.generation
    }

    fun getLastStateUpdateTime(): Long = lastStateUpdateAtMs.get()

    private fun currentStateSnapshot(): VpnStateStore.RuntimeStateSnapshot {
        return synchronized(stateLock) {
            val snapshot = stateSnapshot
            val liveCoreState = currentLiveCoreState()
            val visibleStateOrdinal = resolveVisibleStateOrdinal(
                cachedStateOrdinal = snapshot.stateOrdinal,
                liveCoreState = liveCoreState
            )
            val visibleReadiness = if (visibleStateOrdinal == ServiceState.STOPPED.ordinal) {
                DataPlaneReadinessSnapshot.stopped(serviceInstanceId).copy(
                    lastReadinessReason = "live_core_missing",
                    generation = snapshot.generation
                )
            } else {
                snapshot.readiness
            }
            val reconciled = if (
                visibleStateOrdinal == snapshot.stateOrdinal && visibleReadiness == snapshot.readiness
            ) {
                snapshot
            } else {
                snapshot.copy(
                    stateOrdinal = visibleStateOrdinal,
                    readiness = visibleReadiness
                )
            }
            reconciled
        }
    }

    fun isAppForeground(): Boolean = appForeground.get()

    private fun VpnStateStore.RuntimeStateSnapshot.toBundle(): Bundle {
        return Bundle().apply {
            putLong(SNAPSHOT_GENERATION, generation)
            putInt(SNAPSHOT_STATE, stateOrdinal)
            putString(SNAPSHOT_ACTIVE_LABEL, activeLabel)
            putString(SNAPSHOT_LAST_ERROR, lastError)
            putBoolean(SNAPSHOT_MANUALLY_STOPPED, manuallyStopped)
            putBundle(SNAPSHOT_READINESS, readiness.toBundle())
        }
    }

    private fun DataPlaneReadinessSnapshot.toBundle(): Bundle = Bundle().apply {
        putInt(READINESS_SCHEMA_VERSION, schemaVersion)
        putString(READINESS_STATUS, status.name)
        putBoolean(READINESS_TUN_ESTABLISHED, tunEstablished)
        putBoolean(READINESS_SYSTEM_VPN, systemVpnTransport)
        putString(READINESS_OWNER_STATUS, systemVpnOwnerStatus.name)
        putBoolean(READINESS_CORE_READY, coreReady)
        putBoolean(READINESS_SELECTOR_READY, selectorReady)
        putBoolean(READINESS_RECOVERY_ACTIVE, recoveryActive)
        putString(READINESS_ROUTING_SCOPE, routingScope)
        putString(READINESS_LOCKDOWN_STATUS, lockdownStatus.name)
        putBoolean(READINESS_FOREIGN_VPN, foreignVpnDetected)
        putBoolean(READINESS_OWNED_VPN_LOST, ownedVpnNetworkLost)
        putLong(READINESS_OWNED_NETWORK, ownedVpnNetworkHandle)
        putLong(READINESS_OBSERVED_NETWORK, observedVpnNetworkHandle)
        putInt(READINESS_ROOT_PID, rootPid)
        putInt(READINESS_ROOT_FD_COUNT, rootFdCount)
        putString(READINESS_ROOT_SESSION, rootRuntimeSessionId)
        putLong(READINESS_ROOT_RULE_REVISION, rootRuleRevision)
        putLong(READINESS_ROOT_ROUTING_GENERATION, rootRoutingGeneration)
        putString(READINESS_ROOT_CONFIG_SHA256, rootConfigSha256)
        putString(READINESS_ROOT_SIDECAR_SHA256, rootSidecarSha256)
        putString(READINESS_ROOT_STATIC_SHA256, rootStaticPlanSha256)
        putString(READINESS_ROOT_APP_SHA256, rootAppRoutingSha256)
        putString(READINESS_ROOT_RESOLVED_SHA256, rootResolvedPlanSha256)
        putBoolean(READINESS_ROOT_WATCHDOG, rootWatchdogReady)
        putBoolean(READINESS_ROOT_RULES, rootRulesInstalled)
        putString(READINESS_REASON, lastReadinessReason)
        putLong(READINESS_UPDATED_AT, updatedAtElapsedMs)
        putString(READINESS_SERVICE_INSTANCE, serviceInstanceId)
        putLong(READINESS_VPN_SESSION, vpnSessionId)
    }

    fun update(
        state: ServiceState? = null,
        activeLabel: String? = null,
        lastError: String? = null,
        manuallyStopped: Boolean? = null,
        readiness: DataPlaneReadinessSnapshot? = null
    ) {
        val updateStart = SystemClock.elapsedRealtime()
        val updatedSnapshot = synchronized(stateLock) {
            val current = stateSnapshot
            state?.let {
                val oldState = stateNames.getOrNull(current.stateOrdinal) ?: "UNKNOWN"
                log("state update: $oldState -> ${it.name}")
            }
            VpnStateStore.buildNextRuntimeStateSnapshot(current) { snapshot ->
                snapshot.copy(
                    stateOrdinal = state?.ordinal ?: snapshot.stateOrdinal,
                    activeLabel = activeLabel ?: snapshot.activeLabel,
                    lastError = resolveUpdatedRuntimeLastError(state, lastError, snapshot.lastError),
                    manuallyStopped = manuallyStopped ?: snapshot.manuallyStopped,
                    readiness = readiness?.copy(
                        serviceInstanceId = serviceInstanceId,
                        updatedAtElapsedMs = readiness.updatedAtElapsedMs.takeIf { it > 0L }
                            ?: SystemClock.elapsedRealtime()
                    ) ?: snapshot.readiness
                )
            }.also { stateSnapshot = it }
        }
        persistAndBroadcast(updatedSnapshot)

        Log.d(
            TAG,
            "[IPC] update generation=${updatedSnapshot.generation} " +
                "completed in ${SystemClock.elapsedRealtime() - updateStart}ms"
        )
    }

    fun updateReadiness(transform: (DataPlaneReadinessSnapshot) -> DataPlaneReadinessSnapshot) {
        val updatedSnapshot = synchronized(stateLock) {
            val current = stateSnapshot
            val readiness = transform(current.readiness)
            val controlChanged = readiness.coreReady != current.readiness.coreReady ||
                readiness.selectorReady != current.readiness.selectorReady
            if (controlChanged || readiness.status != current.readiness.status ||
                readiness.lastReadinessReason != current.readiness.lastReadinessReason) {
                LogRepository.getInstance().addAlwaysLog(
                    "INFO [Startup] readiness=${readiness.status} reason=${readiness.lastReadinessReason} " +
                        "core=${readiness.coreReady} selector=${readiness.selectorReady} " +
                        "tun=${readiness.tunEstablished} owner=${readiness.systemVpnOwnerStatus} " +
                        "recovery=${readiness.recoveryActive}"
                )
            }
            VpnStateStore.buildNextRuntimeStateSnapshot(current) { snapshot ->
                snapshot.copy(
                    readiness = readiness.copy(
                        serviceInstanceId = serviceInstanceId,
                        updatedAtElapsedMs = SystemClock.elapsedRealtime()
                    )
                )
            }.also { stateSnapshot = it }
        }
        persistAndBroadcast(updatedSnapshot)
    }

    private fun persistAndBroadcast(snapshot: VpnStateStore.RuntimeStateSnapshot) {
        lastStateUpdateAtMs.set(SystemClock.elapsedRealtime())
        broadcastLock.withLock {
            broadcastPending.set(true)
            scheduleBroadcastIfNeededLocked()
        }
        val now = SystemClock.elapsedRealtime()
        // 节点确认也依赖持久快照，不能等到下一次 30 秒心跳才写入。
        val safetyKey = snapshot.persistenceKey()
        if (safetyKey != lastPersistedSafetyKey ||
            now - lastPersistedAtMs.get() >= DataPlaneReadinessSnapshot.PERSIST_HEARTBEAT_INTERVAL_MS
        ) {
            lastPersistedSafetyKey = safetyKey
            lastPersistedAtMs.set(now)
            ipcScope.launch {
                VpnStateStore.persistRuntimeStateSnapshotBestEffort(snapshot)
            }
        }
    }

    fun registerCallback(callback: ISingBoxServiceCallback) {
        callbacks.register(callback)
        mainHandler.post {
            runCatching {
                val snapshot = currentStateSnapshot()
                callback.onStateChanged(
                    snapshot.stateOrdinal,
                    snapshot.activeLabel,
                    snapshot.lastError,
                    snapshot.manuallyStopped,
                    snapshot.generation
                )
            }
        }
    }

    fun unregisterCallback(callback: ISingBoxServiceCallback) {
        callbacks.unregister(callback)
    }

    private inline fun broadcastCallbacks(crossinline action: (ISingBoxServiceCallback) -> Unit) {
        callbackBroadcastLock.withLock {
            val n = callbacks.beginBroadcast()
            try {
                for (i in 0 until n) {
                    runCatching {
                        action(callbacks.getBroadcastItem(i))
                    }
                }
            } finally {
                callbacks.finishBroadcast()
            }
        }
    }

    private fun scheduleBroadcastIfNeededLocked() {
        if (broadcasting.compareAndSet(false, true)) {
            broadcastScheduler.execute { drainOrReschedule() }
        }
    }

    private fun drainOrReschedule() {
        try {
            val remaining = broadcastLock.withLock {
                val now = SystemClock.elapsedRealtime()
                val elapsed = now - lastBroadcastAtMs.get()
                val delayMs = MIN_BROADCAST_INTERVAL_MS - elapsed

                if (delayMs <= 0L) {
                    broadcastPending.set(false)
                }

                delayMs
            }

            if (remaining > 0) {
                broadcastScheduler.schedule(
                    { drainOrReschedule() },
                    remaining,
                    TimeUnit.MILLISECONDS
                )
                return
            }

            val snapshot = currentStateSnapshot()

            broadcastCallbacks { callback ->
                callback.onStateChanged(
                    snapshot.stateOrdinal,
                    snapshot.activeLabel,
                    snapshot.lastError,
                    snapshot.manuallyStopped,
                    snapshot.generation
                )
            }

            broadcastLock.withLock {
                lastBroadcastAtMs.set(SystemClock.elapsedRealtime())
                broadcasting.set(false)
                if (broadcastPending.get()) {
                    scheduleBroadcastIfNeededLocked()
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "drainOrReschedule failed", t)
            broadcastLock.withLock {
                broadcasting.set(false)
                if (broadcastPending.get()) {
                    scheduleBroadcastIfNeededLocked()
                }
            }
        }
    }

    object HotReloadResult {
        const val SUCCESS = 0
        const val VPN_NOT_RUNNING = 1
        const val KERNEL_ERROR = 2
        const val UNKNOWN_ERROR = 3
    }

    @Suppress("UNUSED_PARAMETER")
    fun requestUrlTestNodeDelay(requestId: Long, groupTag: String, nodeTag: String, timeoutMs: Int) {
        val context = serviceRef?.get()
        if (context == null) {
            requestUrlTestNodeDelayResult(requestId, -1)
            return
        }
        pendingUrlTestJobs.remove(requestId)?.cancel()
        val job = ipcScope.launch {
            val delay = runCatching {
                val repo = ConfigRepository.getInstance(context)
                val node = repo.getNodeByName(nodeTag) ?: return@runCatching -1
                repo.testNodeLatency(node.id).takeIf { it > 0L && it <= Int.MAX_VALUE }?.toInt() ?: -1
            }.getOrElse {
                Log.w(TAG, "requestUrlTestNodeDelay failed: requestId=$requestId", it)
                -1
            }
            requestUrlTestNodeDelayResult(requestId, delay)
        }
        pendingUrlTestJobs[requestId] = job
        job.invokeOnCompletion { pendingUrlTestJobs.remove(requestId) }
    }

    fun requestUrlTestNodeDelayResult(requestId: Long, delay: Int) {
        broadcastCallbacks { callback ->
            callback.onUrlTestNodeDelayResult(requestId, delay)
        }
    }

    fun hotReloadConfig(configContent: String): Int {
        log("[HotReload] IPC request received")

        if (stateSnapshot.stateOrdinal != ServiceState.RUNNING.ordinal) {
            Log.w(TAG, "[HotReload] VPN not running, state=${stateSnapshot.stateOrdinal}")
            PerfTracer.recordEvent(PerfTracer.Phases.HOT_RELOAD, "vpn_not_running")
            return HotReloadResult.VPN_NOT_RUNNING
        }

        val service = ServiceStateHolder.instance
        if (service == null) {
            Log.e(TAG, "[HotReload] SingBoxService instance is null")
            PerfTracer.recordEvent(PerfTracer.Phases.HOT_RELOAD, "service_missing")
            return HotReloadResult.VPN_NOT_RUNNING
        }

        val startedAtMs = SystemClock.elapsedRealtime()
        return try {
            val result = service.performHotReloadSync(configContent)
            if (result) {
                log("[HotReload] Success")
                PerfTracer.recordDuration(
                    PerfTracer.Phases.HOT_RELOAD,
                    SystemClock.elapsedRealtime() - startedAtMs,
                    "success"
                )
                HotReloadResult.SUCCESS
            } else {
                Log.e(TAG, "[HotReload] Kernel returned false")
                PerfTracer.recordDuration(
                    PerfTracer.Phases.HOT_RELOAD,
                    SystemClock.elapsedRealtime() - startedAtMs,
                    "kernel_error"
                )
                HotReloadResult.KERNEL_ERROR
            }
        } catch (e: Exception) {
            Log.e(TAG, "[HotReload] Exception: ${e.message}", e)
            PerfTracer.recordDuration(
                PerfTracer.Phases.HOT_RELOAD,
                SystemClock.elapsedRealtime() - startedAtMs,
                "exception"
            )
            HotReloadResult.UNKNOWN_ERROR
        }
    }
}
