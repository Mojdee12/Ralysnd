// New code for the FENIX separate-process redesign (Go-core integration).
//
// PURPOSE: host the Go daemon in the :gocore process WITHOUT a tunnel, so
// the FENIX tab can list accounts and sign in without loading libgojni.so
// into the main process (which already runs sing-box's Go runtime — two Go
// runtimes in one process kill the process silently on the second init).
//
// LIFECYCLE:
// - ACTION_ENSURE_DAEMON: start the daemon with on=false (dashboard API
//   only, proxy off) if it is not already running. No-op when running.
//   The service stays alive afterwards: the daemon lives in this process,
//   and stopping the service would let the system reclaim the process
//   (and the daemon with it). While a tunnel is up, the foreground
//   GoCoreVpnService (same :gocore process) keeps the process alive.
// - ACTION_STOP_DAEMON: stop the daemon, but ONLY when no tunnel is
//   active (VpnStateStore mode != GO_CORE — the cross-process store).
//   When a tunnel is active, the VpnService owns the daemon and this is
//   a no-op; the VpnService's own stop tears the daemon down.
// - A null intent (system restart) is a no-op: daemon startup is always
//   driven explicitly by the main process (ensureCore), never sticky.
//
// This service NEVER touches GoCoreAccountStore or FenixEventStore (both
// are main-process display state) and never touches sing-box. It talks to
// the main process only through the cross-process VpnStateStore (MMKV
// multi-process) and the daemon's own loopback dashboard files (the token
// file lives in the shared app files dir, visible to every process).

package com.kunk.singbox.gocore

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.kunk.singbox.ipc.VpnStateStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Actions this daemon host understands. */
object GoCoreDaemonActions {
    const val ACTION_ENSURE_DAEMON = "com.kunk.singbox.gocore.ACTION_ENSURE_DAEMON"
    const val ACTION_STOP_DAEMON = "com.kunk.singbox.gocore.ACTION_STOP_DAEMON"
}

/**
 * Plain (non-VpnService) daemon host in :gocore. All GoCoreBinding calls
 * here run in :gocore, never in the main process.
 */
class GoCoreDaemonService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            GoCoreDaemonActions.ACTION_ENSURE_DAEMON -> {
                scope.launch {
                    runCatching {
                        if (!GoCoreBinding.running()) {
                            GoCoreBinding.start(
                                goCoreDataDir(applicationContext).absolutePath,
                                false,
                            ).getOrThrow()
                        }
                    }
                }
            }
            GoCoreDaemonActions.ACTION_STOP_DAEMON -> {
                // Only when no tunnel is active; otherwise the VpnService
                // owns the daemon and stops it with the tunnel.
                if (VpnStateStore.getMode() != VpnStateStore.CoreMode.GO_CORE) {
                    runCatching { GoCoreBinding.stop() }
                    stopSelf()
                }
            }
            else -> {
                // Null or unknown intent (e.g. system restart): no-op.
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
