package com.kunk.singbox.foxy.data

import android.content.Context
import com.tencent.mmkv.MMKV

/**
 * Registry of Foxy/FENIX Firefox accounts (multi-account support).
 *
 * One MMKV store ("foxyvpn_accounts") holds ONLY identifiers — never
 * tokens (those live in per-account [TokenStore] keys):
 * - "account_list": account ids joined by "\n" (an id is a normalised
 *   email, or [LEGACY_ACCOUNT_ID] for the pre-multi-account sign-in
 *   whose email was never recorded — see migration note below).
 * - "active_account": the id whose tokens the Foxy tunnel must use.
 *
 * Migration: on first use after the update, if the registry is empty
 * but the legacy TokenStore holds a session, the legacy account is
 * registered as the first account (id "legacy", email recorded only if
 * the legacy store actually has one). It is NEVER deleted by migration,
 * and the user can keep using it or add a fresh account with its real
 * email. New sign-ins always record their email, so every account added
 * after this change is identified by email text.
 */
class FoxyAccountRegistry(context: Context) {

    private val mmkv: MMKV by lazy {
        MMKV.mmkvWithID("foxyvpn_accounts", MMKV.MULTI_PROCESS_MODE)
    }

    fun loadAccounts(): List<String> {
        val raw = mmkv.decodeString(KEY_ACCOUNT_LIST, null)?.takeIf { it.isNotBlank() } ?: return emptyList()
        return raw.split("\n").map { it.trim() }.filter { it.isNotBlank() }.distinct()
    }

    fun addAccount(accountId: String) {
        val id = accountId.trim().lowercase()
        if (id.isBlank()) return
        val updated = (loadAccounts() + id).distinct()
        mmkv.encode(KEY_ACCOUNT_LIST, updated.joinToString("\n"))
        if (loadActive().isBlank()) setActive(id)
    }

    fun removeAccount(accountId: String) {
        val id = accountId.trim().lowercase()
        val updated = loadAccounts().filter { it != id }
        mmkv.encode(KEY_ACCOUNT_LIST, updated.joinToString("\n"))
        if (loadActive() == id) {
            setActive(updated.firstOrNull() ?: "")
        }
    }

    fun loadActive(): String = mmkv.decodeString(KEY_ACTIVE_ACCOUNT, null)?.trim().orEmpty()

    fun setActive(accountId: String) {
        mmkv.encode(KEY_ACTIVE_ACCOUNT, accountId.trim().lowercase())
    }

    /** Registers the pre-multi-account sign-in as the first account, if present. Returns true if migrated. */
    fun migrateLegacyIfNeeded(legacyEmail: String?): Boolean {
        if (loadAccounts().isNotEmpty()) return false
        val id = legacyEmail?.trim()?.lowercase()?.takeIf { it.isNotBlank() } ?: LEGACY_ACCOUNT_ID
        addAccount(id)
        setActive(id)
        return true
    }

    companion object {
        const val LEGACY_ACCOUNT_ID = "legacy"
        private const val KEY_ACCOUNT_LIST = "account_list"
        private const val KEY_ACTIVE_ACCOUNT = "active_account"
    }
}
