package com.kunk.singbox.ui.theme

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.min

/**
 * RALYSND v2 DESIGN SYSTEM — approved second mockup.
 *
 * Deep navy-black background (#070B12), cyan primary + amber secondary.
 * Deliberately NOT the old system: no emerald->violet gradient ring, no
 * centered connect button, no vertical server list as the main pattern.
 * Layout vocabulary: big bold RALYSND headline, a large circular usage
 * ring, a HORIZONTAL carousel of country cards, an accounts strip, a
 * floating pill bottom bar, and a small floating power button at the
 * bottom-right corner (never centered).
 *
 * Presentation only: no navigation, ViewModel, protocol, database, or
 * permission logic lives here, and no sample data is produced here.
 * Every card renders only the real values its caller passes in; the
 * usage ring shows an explicit empty state when there is no data.
 * NO photos, NO profile pictures, NO avatar images anywhere in this
 * file: countries are identified by flag emoji text + country-code
 * text badge, accounts by email text only.
 */

/** v2 palette. */
val V2Background = Color(0xFF070B12)
val V2Surface = Color(0xFF0E1626)
val V2SurfaceAlt = Color(0xFF13203A)
val V2Outline = Color(0xFF22314F)
val V2Cyan = Color(0xFF22D3EE)
val V2CyanDim = Color(0xFF0E7490)
val V2Amber = Color(0xFFF59E0B)
val V2Text = Color(0xFFFFFFFF)
val V2TextDim = Color(0xFF94A3B8)

/** v2 glass card: navy surface, thin outline, 20dp corners, cyan when selected. */
@Composable
fun V2GlassCard(
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(20.dp)
    val borderColor = if (selected) V2Cyan else V2Outline
    val borderWidth = if (selected) 1.5.dp else 1.dp
    val clickModifier = if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
    Box(
        modifier = modifier
            .clip(shape)
            .background(V2Surface, shape)
            .border(borderWidth, borderColor, shape)
            .then(clickModifier)
            .animateContentSize(),
    ) {
        Column(modifier = Modifier.fillMaxWidth(), content = content)
    }
}

/** Small text badge showing a country code (e.g. DE) — text only, never an image. */
@Composable
fun V2CodeBadge(code: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(V2SurfaceAlt)
            .border(1.dp, V2Outline, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = code.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
            color = V2Cyan,
        )
    }
}

/**
 * Large circular usage ring. [progress] is 0f..1f (used / total).
 * When [hasData] is false, the ring is empty and the center shows the
 * empty-state text instead of any invented percentage.
 */
@Composable
fun V2UsageRing(
    progress: Float,
    centerTop: String,
    centerBottom: String,
    modifier: Modifier = Modifier,
) {
    val clamped = progress.coerceIn(0f, 1f)
    Box(modifier = modifier.size(180.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(180.dp)) {
            val stroke = 14.dp.toPx()
            val diameter = min(size.width, size.height) - stroke
            val topLeft = Offset(stroke / 2f, stroke / 2f)
            drawArc(
                color = V2Outline,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = Size(diameter, diameter),
                style = Stroke(width = stroke, cap = StrokeCap.Round),
            )
            if (clamped > 0f) {
                drawArc(
                    color = V2Cyan,
                    startAngle = -90f,
                    sweepAngle = 360f * clamped,
                    useCenter = false,
                    topLeft = topLeft,
                    size = Size(diameter, diameter),
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = centerTop,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                color = V2Text,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = centerBottom,
                style = MaterialTheme.typography.bodySmall,
                color = V2TextDim,
            )
        }
    }
}

/**
 * One country card for the horizontal carousel.
 * Layout (exact, per the approved design + user correction): flag
 * (emoji text) + country-code text badge on the top row, country name
 * below, and the PING BELOW the country name in large, clearly visible
 * text, live-updating as results arrive. No corner-only ping badge.
 * [pingText] is the caller-supplied live value ("123 ms", "pinging…",
 * or "—" when unmeasured) — never invented here.
 */
@Composable
fun V2CountryCard(
    flag: String,
    countryCode: String,
    countryName: String,
    pingText: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "v2CountryCardScale",
    )
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = modifier
            .width(168.dp)
            .scale(scale)
            .clip(shape)
            .background(V2Surface, shape)
            .border(if (selected) 1.5.dp else 1.dp, if (selected) V2Cyan else V2Outline, shape)
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .animateContentSize(),
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = flag, fontSize = 26.sp)
                Spacer(modifier = Modifier.width(8.dp))
                V2CodeBadge(code = countryCode)
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = countryName,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = V2Text,
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = pingText,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = if (selected) V2Cyan else V2Amber,
            )
            Text(
                text = "ping",
                style = MaterialTheme.typography.labelSmall,
                color = V2TextDim,
            )
        }
    }
}

/**
 * Small floating power button for the bottom-right corner (v2 layout).
 * 64dp circle, cyan border when running, amber when idle; min 48dp tap
 * target is exceeded. Label text sits under the button, not inside a
 * centered hero control.
 */
@Composable
fun V2FloatingPowerButton(
    isRunning: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "v2PowerScale",
    )
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .scale(scale)
                .clip(CircleShape)
                .background(V2Surface, CircleShape)
                .border(1.5.dp, if (isRunning) V2Cyan else V2Amber, CircleShape)
                .clickable(interactionSource = interactionSource, indication = null, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Filled.PowerSettingsNew,
                contentDescription = if (isRunning) "Disconnect" else "Connect",
                tint = if (isRunning) V2Cyan else V2Text,
                modifier = Modifier.size(28.dp),
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = if (isRunning) "DISCONNECT" else "CONNECT",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
            color = if (isRunning) V2Cyan else V2TextDim,
        )
    }
}
