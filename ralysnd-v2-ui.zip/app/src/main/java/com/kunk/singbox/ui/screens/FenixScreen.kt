package com.kunk.singbox.ui.screens

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.kunk.singbox.foxy.FoxyViewModel
import com.kunk.singbox.foxy.data.formatBytes
import com.kunk.singbox.foxy.data.model.ConnectionState as FoxyConnectionState
import com.kunk.singbox.foxy.data.model.emojiFlag
import com.kunk.singbox.model.ConnectionState
import com.kunk.singbox.ui.theme.V2Amber
import com.kunk.singbox.ui.theme.V2Background
import com.kunk.singbox.ui.theme.V2CountryCard
import com.kunk.singbox.ui.theme.V2Cyan
import com.kunk.singbox.ui.theme.V2FloatingPowerButton
import com.kunk.singbox.ui.theme.V2GlassCard
import com.kunk.singbox.ui.theme.V2Surface
import com.kunk.singbox.ui.theme.V2Text
import com.kunk.singbox.ui.theme.V2TextDim
import com.kunk.singbox.ui.theme.V2UsageRing
import com.kunk.singbox.viewmodel.DashboardViewModel

/**
 * FENIX bottom-tab screen — v2 approved style, FoxyVPN's flow (MIT, Vauth).
 *
 * v2 layout, exactly: big bold RALYSND headline at top (the app wordmark,
 * with this tab titled FENIX beneath it), a large circular usage ring
 * showing the AGGREGATE volume across all added Firefox accounts
 * (real Guardian data only; "Quota unavailable" when no account reports
 * one), a FENIX Accounts strip (EMAIL TEXT ONLY — never a profile
 * photo/avatar — with a + button to add another account, tap an account
 * to switch, remove only when not connected), and a HORIZONTAL carousel
 * of country cards. Each country card shows its flag (emoji text) +
 * country-code text badge, the country name, and its PING BELOW the
 * country name in large text, live-updating as ping results arrive
 * (not only as a small corner badge). Ping all is a prominent primary
 * action; Fastest picks the lowest measured ping.
 *
 * Connect is the small floating power button at the bottom-right corner
 * (never a centered hero control). The tunnel itself is untouched:
 * FoxyVpnService (Netty H2 CONNECT with Bearer proxy pass to the Fastly
 * edge, local SOCKS5 proxy, hev-socks5-tunnel) using the ACTIVE
 * account's tokens. No credential is stored in source or logs.
 *
 * Footer credit (FoxyVPN MIT attribution): "FENIX engine based on
 * FoxyVPN (MIT) by Vauth".
 */
@Composable
fun FenixScreen(
    navController: NavController,
    viewModel: FoxyViewModel = viewModel(),
    dashboardViewModel: DashboardViewModel = viewModel(),
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val connectionState by dashboardViewModel.connectionState.collectAsStateWithLifecycle()
    val foxyState by viewModel.foxyState.collectAsStateWithLifecycle()
    var pendingFenixConnect by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && pendingFenixConnect) {
            pendingFenixConnect = false
            viewModel.connectSelected(context, dashboardViewModel)
        } else {
            pendingFenixConnect = false
        }
    }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var twoFactorCode by remember { mutableStateOf("") }
    val foxyRunning = foxyState == FoxyConnectionState.CONNECTED ||
        foxyState == FoxyConnectionState.CONNECTING
    val isRunning = foxyRunning ||
        connectionState == ConnectionState.Connected ||
        connectionState == ConnectionState.Connecting

    val onPowerClick: () -> Unit = {
        if (isRunning) {
            if (foxyRunning) {
                viewModel.disconnectFenix(context)
            } else {
                dashboardViewModel.toggleConnection()
            }
        } else {
            val prepareIntent = VpnService.prepare(context)
            if (prepareIntent != null) {
                pendingFenixConnect = true
                vpnPermissionLauncher.launch(prepareIntent)
            } else {
                viewModel.connectSelected(context, dashboardViewModel)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(V2Background),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
                .padding(bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // Headline: big bold wordmark + tab title (text only).
            Text(
                text = "RALYSND",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp,
                ),
                color = V2Text,
            )
            Text(
                text = "FENIX — Firefox VPN on your own Firefox accounts",
                style = MaterialTheme.typography.bodyMedium,
                color = V2TextDim,
            )

            // Aggregate usage ring: total volume across all accounts.
            val totalRemaining = state.totalQuotaRemaining
            val totalMax = state.totalMaxBytes
            val ringProgress = if (totalRemaining != null && totalMax != null && totalMax > 0) {
                1f - (totalRemaining.toFloat() / totalMax.toFloat())
            } else {
                0f
            }
            val ringTop = when {
                totalRemaining != null && totalMax != null ->
                    "${formatBytes(totalRemaining)} left"
                totalMax != null -> "of ${formatBytes(totalMax)}"
                else -> "Quota unavailable"
            }
            val ringBottom = when {
                state.accounts.isEmpty() -> "Add a Firefox account to see volume"
                state.accountsWithoutQuota > 0 -> "${state.accounts.size} accounts · some quotas unavailable"
                else -> "${state.accounts.size} accounts · total volume"
            }
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                V2UsageRing(
                    progress = ringProgress,
                    centerTop = ringTop,
                    centerBottom = ringBottom,
                )
            }

            // Accounts strip: email text only, + to add, tap to switch.
            if (state.signedIn) {
                Text(text = "FENIX Accounts", fontWeight = FontWeight.Bold, color = V2Text)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (account in state.accounts) {
                        val accountLabel = account.displayEmail.ifBlank { "Firefox account" }
                        V2GlassCard(
                            selected = account.isActive,
                            onClick = { viewModel.switchAccount(account.id) },
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = accountLabel, fontWeight = FontWeight.SemiBold, color = V2Text)
                                    val accountRemaining = account.entitlement?.quotaRemaining
                                    val accountMax = account.entitlement?.maxBytes
                                    Text(
                                        text = when {
                                            accountRemaining != null ->
                                                "Quota remaining: ${formatBytes(accountRemaining)}"
                                            accountMax != null ->
                                                "Allowance: ${formatBytes(accountMax)}"
                                            else -> "Quota unavailable"
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = V2TextDim,
                                    )
                                    if (account.isActive) {
                                        Text(text = "Active account", style = MaterialTheme.typography.labelSmall, color = V2Cyan)
                                    }
                                }
                                if (!foxyRunning) {
                                    TextButton(onClick = { viewModel.removeAccount(account.id) }) {
                                        Text(text = "Remove", color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                    Button(
                        onClick = { viewModel.startAddingAccount() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = V2Cyan, contentColor = V2Background),
                    ) { Text(text = "+ Add another Firefox account", fontWeight = FontWeight.Bold) }
                }
            }

            // Login card: first sign-in, or adding another account.
            AnimatedVisibility(visible = !state.signedIn || state.addingAccount) {
                V2GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            text = if (state.addingAccount) "Add another Firefox account" else "Sign in with your Firefox account",
                            fontWeight = FontWeight.Bold,
                            color = V2Text,
                        )
                        OutlinedTextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Firefox account email") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                        )
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                        )
                        if (state.needsTwoFactor) {
                            OutlinedTextField(
                                value = twoFactorCode,
                                onValueChange = { twoFactorCode = it },
                                label = { Text("Confirmation code sent to your email") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                            )
                            Button(
                                onClick = { viewModel.submitTwoFactorCode(twoFactorCode) },
                                enabled = !state.isLoading && twoFactorCode.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = V2Cyan, contentColor = V2Background),
                            ) { Text("Verify code") }
                        } else {
                            Button(
                                onClick = { viewModel.signIn(email, password) },
                                enabled = !state.isLoading && email.isNotBlank() && password.isNotBlank(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = V2Cyan, contentColor = V2Background),
                            ) { Text(if (state.addingAccount) "Add account" else "Sign in") }
                        }
                        Row {
                            TextButton(
                                onClick = {
                                    context.startActivity(
                                        Intent(Intent.ACTION_VIEW, Uri.parse("https://accounts.firefox.com/signup")),
                                    )
                                },
                            ) { Text("Create a Firefox account", color = V2Cyan) }
                            if (state.addingAccount) {
                                TextButton(onClick = { viewModel.cancelAddingAccount() }) {
                                    Text("Cancel", color = V2TextDim)
                                }
                            }
                        }
                    }
                }
            }

            // Country panel: horizontal carousel, ping BELOW each country name.
            if (state.signedIn) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(text = "Countries", fontWeight = FontWeight.Bold, color = V2Text)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.pingAllCountries() },
                            enabled = !state.isPinging,
                            modifier = Modifier.height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = V2Cyan, contentColor = V2Background),
                        ) { Text(if (state.isPinging) "Pinging…" else "Ping all", fontWeight = FontWeight.Bold) }
                        Button(
                            onClick = {
                                val fastest = viewModel.fastestCountry()
                                if (fastest != null) viewModel.selectCountry(fastest.code)
                            },
                            modifier = Modifier.height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = V2Surface, contentColor = V2Amber),
                        ) { Text("Fastest") }
                    }
                }
                if (state.isLoading || state.isPinging || state.isConnecting) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = V2Cyan)
                }
                state.selected?.let { selected ->
                    Text(
                        text = "Selected: ${selected.countryName} (${selected.host}:${selected.port})",
                        style = MaterialTheme.typography.bodyMedium,
                        color = V2TextDim,
                    )
                }
                val sorted = state.countries.sortedBy { country ->
                    state.pingMs[country.code] ?: Int.MAX_VALUE
                }
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .animateContentSize(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(sorted, key = { it.code }) { country ->
                        val ping = state.pingMs[country.code]
                        val isSelected = state.selected?.countryCode.equals(country.code, ignoreCase = true)
                        V2CountryCard(
                            flag = country.emojiFlag,
                            countryCode = country.code,
                            countryName = country.name,
                            pingText = when {
                                ping != null -> "$ping ms"
                                state.isPinging -> "pinging…"
                                else -> "—"
                            },
                            selected = isSelected,
                            onClick = { viewModel.selectCountry(country.code) },
                        )
                    }
                }
                Button(
                    onClick = { viewModel.refreshAccountAndCountries() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = V2Surface, contentColor = V2Text),
                ) { Text("Refresh accounts & countries") }
            }

            state.message?.let {
                Text(text = it, color = MaterialTheme.colorScheme.error)
            }
            Text(
                text = "FENIX engine based on FoxyVPN (MIT) by Vauth",
                style = MaterialTheme.typography.bodySmall,
                color = V2TextDim,
            )
            Spacer(modifier = Modifier.height(72.dp))
        }

        // Floating power button, bottom-right corner (never centered).
        if (state.signedIn) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 20.dp, bottom = 108.dp),
            ) {
                V2FloatingPowerButton(isRunning = isRunning, onClick = onPowerClick)
            }
        }
    }
}

