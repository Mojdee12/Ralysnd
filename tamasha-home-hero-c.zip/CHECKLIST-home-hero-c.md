# CHECKLIST — Home hero C + Settings (build v2, 2.1.0)

Approved look: sample C (hero with side info panel), picked by the user 2026-11-16 02:16.
Palette: bg #0B0D10 / surface #16191D, single green accent #00C853, Vazirmatn.
Version: versionCode 6, versionName "2.1.0" (v1 was 5 / 2.0.0).

## Top bar — activity_main.xml (kept, + settings button)
- [ ] Logo R mark (logo_mark drawable, unchanged) + RALYSND brand text — existing
- [ ] Live clock (TextClock, existing)
- [ ] Search button btn_search → SearchActivity — existing
- [ ] NEW settings button btn_settings (gear, search_btn_bg) → SettingsActivity
- [ ] Top-bar buttons nextFocusDown → hero_watch

## Hero preview — MainActivity.java + activity_main.xml (NEW)
- [ ] PlayerView hero_preview, left ~2/3 of hero row, RESIZE_MODE_ZOOM, setUseController(false)
- [ ] Second ExoPlayer, muted (volume 0), built like PlayerActivity: DefaultLoadControl
      15s/50s, per-source headers + agent, HLS vs Progressive by URL, source failover
      on error (500ms retry, next source; all exhausted → fallback logo shown)
- [ ] Hero switches when a rail card gains focus, debounced ~300ms (Handler + Runnable)
- [ ] Fallback logo overlay (hero_fallback: logo thumb + letter tile) visible until the
      first frame renders (onRenderedFirstFrame) and when all sources fail
- [ ] Lifecycle: onPause pauses preview, onResume resumes, onDestroy releases player
- [ ] Preview keeps playing while the user browses rails (no pause on focus change)
- [ ] Initial hero channel = repo.all first item (most popular); empty repo → Toast only

## Info panel — activity_main.xml (NEW, right ~1/3 of hero row)
- [ ] Channel logo (Logos.load, letter-tile fallback) 56dp thumb
- [ ] BIG channel name (22sp bold Vazirmatn, firstStrong) — real selected channel
- [ ] Category CHIP (chip_bg.xml) — the ONLY place a category shows on home now
- [ ] Green LIVE pill (live_pill.xml, accent bg + dark text, "● LIVE")
- [ ] Watch Now button (watch_btn_selector.xml, green solid, focus = green ring)
      → opens PlayerActivity for the selected channel
- [ ] Fav star hero_fav: ☆ visible when off, ★ green when on (same as player)
- [ ] Channel count line: real repo.all.size() formatted ("1,130 channels") — never hard-coded
- [ ] Panel updates on every hero switch (logo, name, chip, fav, count stays)

## Rails — activity_main.xml + RailAdapter.java (NEW) + ChannelAdapter/item_card (EDITED)
- [ ] Vertical RecyclerView (id rails) below hero; one rail per group:
      ALL first, FAVORITES second (only when non-empty), then each real category
- [ ] Rail = title (real category name, allCaps) + horizontal RecyclerView
- [ ] Rail cards = reworked item_card: fixed 200dp x 112dp (16:9), logo thumb + name
      ONLY — NO category text inside any card (card_cat + card_tag removed from
      layout; shortCat() removed from ChannelAdapter)
- [ ] Focused card = thin green ring via card_selector (existing, no white flash)
- [ ] Card click → PlayerActivity; card focus → hero switch (debounced)
- [ ] Old tab row (R.id.tabs) + 5-column grid (R.id.grid) + grid_empty REMOVED
      from activity_main.xml; buildTabs()/focusGridSoon() removed from MainActivity
- [ ] onResume rebuilds rails (favorites may have changed in the player) + refreshes
      hero fav star; hero channel selection is preserved
- [ ] Initial focus = first card of the ALL rail (retry once, as before)

## Focus flow (D-pad)
- [ ] Top bar → hero Watch Now / fav → rails, via default FocusFinder +
      nextFocusDown (top bar → hero_watch) / nextFocusUp (hero_watch → btn_search)
- [ ] No invisible-focus trap: hero preview itself is not focusable

## Settings — SettingsActivity.java + activity_settings.xml (NEW) + manifest
- [ ] Manifest entry: .SettingsActivity, exported=false, landscape, AppTheme
- [ ] Opened from top-bar settings button; BACK key / back button closes
- [ ] Row 1 Clear favorites: subtitle shows real count (FavStore.count());
      first tap → "Tap again to clear", second tap → FavStore.clear() + Toast
- [ ] Row 2 Clear logo cache: Glide clearMemory (main thread) + clearDiskCache
      (background thread) + Toast
- [ ] Row 3 About: app name + version from PackageManager (never hard-coded) +
      real channel count (repo.all.size())
- [ ] Rows focusable with source_item_selector (dark + green ring, no white flash)
- [ ] NO fake toggles, NO invented settings

## Deletions (dead after tab/grid removal)
- [ ] TabAdapter.java deleted (only MainActivity referenced it)
- [ ] item_tab.xml deleted (only TabAdapter inflated it)
- [ ] tab_selector.xml deleted (only item_tab referenced it)

## Version bump — app/build.gradle
- [ ] versionCode 5 → 6, versionName "2.0.0" → "2.1.0"

## Untouched (verify after editing)
- [ ] channels.json checksum still 40d9e503bd5fd8bb5473c7278da450c378a79de952ec2c48e5327b57842fe268
- [ ] PlayerActivity.java + activity_player.xml byte-identical (player split layout,
      ExoPlayer path, D-pad model)
- [ ] SearchActivity.java, SourceAdapter.java, Repo.java, Channel.java, Fonts.java,
      Logos.java, PlayerChannelAdapter.java byte-identical
- [ ] No new dependencies; minSdk 21; Java only

## Verification results (appended after implementation)
- All resource references resolve (script check over java+xml: R.id/string/drawable/
  layout/color + @string/@drawable/@color/@layout — zero missing).
- channels.json checksum unchanged:
  40d9e503bd5fd8bb5473c7278da450c378a79de952ec2c48e5327b57842fe268
- PlayerActivity.java + activity_player.xml + SearchActivity.java + SourceAdapter.java
  + Repo.java + Channel.java + Fonts.java + Logos.java + PlayerChannelAdapter.java
  untouched (mtimes still 2026-11-15 22:19–22:21, from the v1 reskin).
- No dangling references: grep for TabAdapter / item_tab / tab_selector /
  R.id.tabs / R.id.grid / card_cat / shortCat / card_tag returns nothing.
- Manifest contains .SettingsActivity (exported=false, landscape, AppTheme).
- versionCode 6 / versionName "2.1.0" in app/build.gradle.
- Every changed file re-read after editing (MainActivity, ChannelAdapter,
  RailAdapter, SettingsActivity, FavStore, activity_main, activity_settings,
  item_card, strings).
- No new dependencies; minSdk 21; Java only. No local compile possible in the
  sandbox — server build is the compile proof.

## Deletions — 3 files (NOT in the zip; must be removed on the build server too)
- app/src/main/java/com/tamasha/tv/TabAdapter.java
- app/src/main/res/layout/item_tab.xml
- app/src/main/res/drawable/tab_selector.xml

## Gate-check (parent agent, 2026-11-16 02:24, BEFORE server build)
- Zip SHA verified against subagent report (54bca59d... before fix); channels.json checksum unchanged 40d9e503...
- Re-read in full: MainActivity.java, ChannelAdapter.java, RailAdapter.java, SettingsActivity.java, FavStore.java, activity_main.xml, item_rail.xml, strings.xml. All resource refs (R.id/string/drawable/color/layout) resolve against the zip + v1 tree; versionCode 6 / 2.1.0 confirmed; manifest has SettingsActivity; zero tab/grid references.
- ONE FIX APPLIED BY PARENT: RailAdapter.bind() used to scrollToPosition(0) on every rebind, and MainActivity calls buildRails() on every onResume and every fav toggle — returning from the player would reset every rail's horizontal scroll. Fixed: ChannelAdapter.sameAs() (reference equality — Repo reuses the same Channel instances) + RailAdapter only resets scroll when the list actually changed. New zip SHA below.
