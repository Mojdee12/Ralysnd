package com.tamasha.tv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/**
 * Home rails: one vertical row per group (ALL, FAVORITES, each category).
 * Each rail is a title + a horizontal RecyclerView of 16:9 cards.
 */
public final class RailAdapter extends RecyclerView.Adapter<RailAdapter.RailVH> {

    public static final class Rail {
        public final String title;
        public final List<Channel> channels;
        public Rail(String title, List<Channel> channels) {
            this.title = title;
            this.channels = channels == null ? new ArrayList<>() : channels;
        }
    }

    public interface Callbacks {
        void onPick(Channel c);
        void onFocus(Channel c);
    }

    private final List<Rail> rails = new ArrayList<>();
    private final Callbacks callbacks;

    public RailAdapter(Callbacks callbacks) {
        this.callbacks = callbacks;
    }

    public void setRails(List<Rail> next) {
        rails.clear();
        if (next != null) rails.addAll(next);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public RailVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_rail, parent, false);
        return new RailVH(v, callbacks);
    }

    @Override
    public void onBindViewHolder(@NonNull RailVH h, int position) {
        h.bind(rails.get(position));
    }

    @Override
    public int getItemCount() { return rails.size(); }

    static final class RailVH extends RecyclerView.ViewHolder {
        final TextView title;
        final RecyclerView list;
        final ChannelAdapter adapter;

        RailVH(@NonNull View v, Callbacks callbacks) {
            super(v);
            title = v.findViewById(R.id.rail_title);
            list = v.findViewById(R.id.rail_list);
            Fonts.setBold(title);
            list.setLayoutManager(new LinearLayoutManager(v.getContext(),
                    RecyclerView.HORIZONTAL, false));
            list.setItemAnimator(null);
            list.setHasFixedSize(true);
            adapter = new ChannelAdapter(null, callbacks::onPick);
            adapter.setOnFocusListener(callbacks::onFocus);
            list.setAdapter(adapter);
        }

        void bind(Rail rail) {
            title.setText(rail.title);
            boolean same = adapter.sameAs(rail.channels);
            adapter.setItems(rail.channels);
            // Keep the user's horizontal scroll position on rebind (e.g. returning
            // from the player or toggling a favorite); only reset for a new list.
            if (!same) list.scrollToPosition(0);
        }
    }
}
