package com.tamasha.tv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.VH> {

    public interface OnPick { void onPick(Channel c); }
    public interface OnFocus { void onFocus(Channel c); }

    private final List<Channel> items = new ArrayList<>();
    private final OnPick listener;
    private OnFocus focusListener;

    public ChannelAdapter(List<Channel> items, OnPick listener) {
        if (items != null) this.items.addAll(items);
        this.listener = listener;
    }

    /** Optional: fired when a card gains D-pad focus (drives the home hero). */
    public void setOnFocusListener(OnFocus l) { focusListener = l; }

    public void setItems(List<Channel> next) {
        items.clear();
        if (next != null) items.addAll(next);
        notifyDataSetChanged();
    }

    /** True when the adapter already holds exactly these channel objects in this order
     * (Repo reuses the same Channel instances, so reference equality is enough). */
    public boolean sameAs(List<Channel> next) {
        return items.equals(next);
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_card, parent, false);
        return new VH(v, listener, items, () -> focusListener);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        h.bind(items.get(position));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static String displayName(Channel c) {
        return c.nameEn.isEmpty() ? c.name : c.nameEn;
    }

    static String initial(Channel c) {
        String n = displayName(c);
        return n.isEmpty() ? "T" : n.substring(0, 1).toUpperCase(Locale.US);
    }

    /** Supplies the current focus listener without holding a stale adapter reference. */
    interface FocusSupplier { OnFocus get(); }

    static final class VH extends RecyclerView.ViewHolder {
        final ImageView logo;
        final TextView initial, name, badgeVpn;
        final List<Channel> items;
        final OnPick listener;
        final FocusSupplier focusSupplier;

        VH(@NonNull View v, OnPick listener, List<Channel> items, FocusSupplier focusSupplier) {
            super(v);
            this.listener = listener;
            this.items = items;
            this.focusSupplier = focusSupplier;

            logo     = v.findViewById(R.id.card_logo);
            initial  = v.findViewById(R.id.card_initial);
            name     = v.findViewById(R.id.card_name);
            badgeVpn = v.findViewById(R.id.badge_vpn);

            Fonts.setBold(name);
            Fonts.set(initial);

            v.setOnClickListener(view -> {
                int pos = getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) listener.onPick(items.get(pos));
            });

            // Focus keeps the dark tile; only a thin green ring (card_selector) + slight scale.
            v.setOnFocusChangeListener((view, hasFocus) -> {
                view.animate().scaleX(hasFocus ? 1.05f : 1f)
                        .scaleY(hasFocus ? 1.05f : 1f)
                        .setDuration(120).start();
                if (hasFocus) {
                    OnFocus l = focusSupplier.get();
                    int pos = getAdapterPosition();
                    if (l != null && pos != RecyclerView.NO_POSITION) l.onFocus(items.get(pos));
                }
            });
        }

        void bind(Channel c) {
            initial.setText(initial(c));
            name.setText(displayName(c));
            badgeVpn.setVisibility(c.needVpn ? View.VISIBLE : View.GONE);
            Logos.load(logo, initial, c.logoUrl);
        }
    }
}
