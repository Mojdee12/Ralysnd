package com.tamasha.tv;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;

/**
 * Settings — only real options, each wired to real code:
 * clear favorites (two-tap confirm), clear Glide logo cache, About (real version + count).
 */
public class SettingsActivity extends Activity {

    private TextView favSub;
    private boolean favConfirmArmed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Fonts.setBold((TextView) findViewById(R.id.settings_title));
        favSub = findViewById(R.id.set_fav_sub);
        Fonts.set(favSub);
        Fonts.setBold((TextView) findViewById(R.id.set_fav_title));
        Fonts.setBold((TextView) findViewById(R.id.set_cache_title));
        Fonts.set((TextView) findViewById(R.id.set_cache_sub));
        Fonts.setBold((TextView) findViewById(R.id.set_about_title));
        Fonts.set((TextView) findViewById(R.id.set_about_sub));

        // Back button
        findViewById(R.id.btn_back).setOnClickListener(v -> finish());

        // About: real version (PackageManager) + real channel count.
        TextView aboutSub = findViewById(R.id.set_about_sub);
        String version = appVersion();
        int count = Repo.get(this).all.size();
        aboutSub.setText(getString(R.string.set_about_sub, version, count));

        refreshFavRow();

        // Clear favorites — two taps to confirm.
        findViewById(R.id.row_clear_fav).setOnClickListener(v -> {
            if (!favConfirmArmed) {
                favConfirmArmed = true;
                favSub.setText(R.string.set_clear_fav_confirm);
                return;
            }
            favConfirmArmed = false;
            FavStore.get(this).clear();
            refreshFavRow();
            Toast.makeText(this, R.string.set_clear_fav_done, Toast.LENGTH_SHORT).show();
        });

        // Clear Glide logo cache — memory on the main thread, disk on a background thread.
        findViewById(R.id.row_clear_cache).setOnClickListener(v -> {
            Glide.get(this).clearMemory();
            new Thread(() -> Glide.get(this).clearDiskCache()).start();
            Toast.makeText(this, R.string.set_clear_cache_done, Toast.LENGTH_SHORT).show();
        });
    }

    private void refreshFavRow() {
        favConfirmArmed = false;
        int n = FavStore.get(this).count();
        favSub.setText(n == 0
                ? getString(R.string.set_clear_fav_none)
                : getString(R.string.set_clear_fav_count, n));
    }

    /** App version name from the package — never hard-coded. */
    private String appVersion() {
        try {
            PackageInfo info = getPackageManager().getPackageInfo(getPackageName(), 0);
            return info.versionName == null ? "" : info.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "";
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
