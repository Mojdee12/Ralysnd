package com.tamasha.tv;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Home (sample C): top bar + hero (live muted preview + info panel) + category rails.
 * The hero preview is a second, muted ExoPlayer with the same loading rules as the
 * player (per-source headers + agent, HLS vs Progressive, source failover).
 */
public class MainActivity extends android.app.Activity implements Player.Listener {

    // How long to wait after a rail card gains focus before switching the hero.
    private static final long HERO_SWITCH_DELAY = 300L;
    // Delay before trying next hero source after error.
    private static final long HERO_RETRY_DELAY = 500L;

    // ---- hero preview player ----
    private ExoPlayer heroPlayer;
    private Channel heroChannel;
    private Channel pendingHeroChannel;
    private int heroSourceIndex = 0;
    private int heroFailCount = 0;

    // ---- data ----
    private Repo repo;
    private RailAdapter railAdapter;
    private RecyclerView railsView;

    // ---- views ----
    private PlayerView heroPreview;
    private View heroFallback;
    private ImageView heroLogo, heroFallbackLogo;
    private TextView heroLetter, heroFallbackLetter, heroName, heroCat, heroFav, heroCount;

    // ---- UI thread ----
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable rSwitchHero = () -> {
        if (pendingHeroChannel != null) switchHero(pendingHeroChannel);
    };
    private final Runnable rNextHeroSource = this::nextHeroSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        repo = Repo.get(this);
        if (repo.all.isEmpty()) {
            Toast.makeText(this, getString(R.string.lbl_load_error), Toast.LENGTH_LONG).show();
        }

        Fonts.setBold((TextView) findViewById(R.id.brand_text));
        Fonts.set((TextView) findViewById(R.id.clock));

        // ---- bind hero views ----
        heroPreview       = findViewById(R.id.hero_preview);
        heroFallback      = findViewById(R.id.hero_fallback);
        heroFallbackLogo  = findViewById(R.id.hero_fallback_logo);
        heroFallbackLetter = findViewById(R.id.hero_fallback_letter);
        heroLogo          = findViewById(R.id.hero_logo);
        heroLetter        = findViewById(R.id.hero_letter);
        heroName          = findViewById(R.id.hero_name);
        heroCat           = findViewById(R.id.hero_cat);
        heroFav           = findViewById(R.id.hero_fav);
        heroCount         = findViewById(R.id.hero_count);

        Fonts.setBold(heroName);
        Fonts.set(heroCat);
        Fonts.setBold((TextView) findViewById(R.id.hero_live));
        Fonts.setBold((TextView) findViewById(R.id.hero_watch));
        Fonts.set(heroCount);

        heroPreview.setUseController(false);
        heroPreview.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);

        // ---- hero buttons ----
        findViewById(R.id.hero_watch).setOnClickListener(v -> {
            if (heroChannel != null) open(heroChannel);
        });
        heroFav.setOnClickListener(v -> {
            if (heroChannel == null) return;
            FavStore.get(this).toggle(this, heroChannel);
            updateHeroFav();
            buildRails();
        });

        // ---- search + settings ----
        findViewById(R.id.btn_search).setOnClickListener(v ->
                startActivity(new Intent(this, SearchActivity.class)));
        findViewById(R.id.btn_settings).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));

        // ---- rails ----
        railsView = findViewById(R.id.rails);
        railsView.setLayoutManager(new LinearLayoutManager(this));
        railsView.setItemAnimator(null);
        railAdapter = new RailAdapter(new RailAdapter.Callbacks() {
            @Override public void onPick(Channel c) { open(c); }
            @Override public void onFocus(Channel c) { onRailCardFocused(c); }
        });
        railsView.setAdapter(railAdapter);
        buildRails();

        // ---- build hero player (once; never rebuilt) ----
        DefaultLoadControl lc = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(15_000, 50_000, 1500, 2500)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build();
        heroPlayer = new ExoPlayer.Builder(this).setLoadControl(lc).build();
        heroPlayer.addListener(this);
        heroPlayer.setVolume(0f);
        heroPreview.setPlayer(heroPlayer);

        // ---- initial hero channel: most popular (repo.all is sorted by popular) ----
        if (!repo.all.isEmpty()) {
            heroChannel = repo.all.get(0);
            refreshHeroPanel();
            loadHeroSource();
        }

        // Set initial focus to the first card of the ALL rail.
        focusFirstCardSoon();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Favorites may have changed while in the player — rebuild rails, refresh fav star.
        buildRails();
        updateHeroFav();
        if (heroPlayer != null) heroPlayer.setPlayWhenReady(true);
        // If focus was lost (e.g. after returning from the player), restore it.
        railsView.post(() -> {
            if (getCurrentFocus() == null) focusFirstCardSoon();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (heroPlayer != null) heroPlayer.setPlayWhenReady(false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        if (heroPlayer != null) {
            heroPlayer.removeListener(this);
            heroPlayer.release();
            heroPlayer = null;
        }
    }

    // ============================================================
    //  Rails
    // ============================================================

    /** Rails: ALL first, FAVORITES second (when non-empty), then each real category. */
    private void buildRails() {
        List<RailAdapter.Rail> rails = new ArrayList<>();
        rails.add(new RailAdapter.Rail(getString(R.string.tab_live), repo.all));

        List<Channel> favs = new ArrayList<>();
        for (Channel c : repo.all) if (FavStore.get(this).isFav(c)) favs.add(c);
        if (!favs.isEmpty()) {
            rails.add(new RailAdapter.Rail(getString(R.string.tab_fav), favs));
        }

        for (Repo.Category cat : repo.categories) {
            if (!cat.channels.isEmpty()) {
                String name = cat.nameEn.isEmpty() ? cat.name : cat.nameEn;
                rails.add(new RailAdapter.Rail(name, cat.channels));
            }
        }

        railAdapter.setRails(rails);
    }

    private void focusFirstCardSoon() {
        railsView.post(() -> {
            if (focusFirstCard()) return;
            railsView.postDelayed(this::focusFirstCard, 200);
        });
    }

    /** Focus the first card of the ALL rail. Returns true if focus was set. */
    private boolean focusFirstCard() {
        RecyclerView.ViewHolder railH =
                railsView.findViewHolderForAdapterPosition(0);
        if (railH == null) return false;
        RecyclerView inner = railH.itemView.findViewById(R.id.rail_list);
        if (inner == null) return false;
        RecyclerView.ViewHolder h = inner.findViewHolderForAdapterPosition(0);
        if (h == null) return false;
        h.itemView.requestFocus();
        return true;
    }

    // ============================================================
    //  Hero preview
    // ============================================================

    /** A rail card gained focus — switch the hero after a short debounce. */
    private void onRailCardFocused(Channel c) {
        if (c == null || c == heroChannel) return;
        pendingHeroChannel = c;
        ui.removeCallbacks(rSwitchHero);
        ui.postDelayed(rSwitchHero, HERO_SWITCH_DELAY);
    }

    private void switchHero(Channel c) {
        heroChannel = c;
        heroSourceIndex = 0;
        heroFailCount = 0;
        refreshHeroPanel();
        loadHeroSource();
    }

    /** Update the info panel for the current hero channel. */
    private void refreshHeroPanel() {
        if (heroChannel == null) return;
        String n = displayName(heroChannel);
        String cat = heroChannel.categoryEn.isEmpty() ? heroChannel.category : heroChannel.categoryEn;

        heroLetter.setText(initial(heroChannel));
        heroName.setText(n);
        heroCat.setText(cat);
        heroCount.setText(getString(R.string.channels_count, repo.all.size()));
        Logos.load(heroLogo, heroLetter, heroChannel.logoUrl);
        updateHeroFav();
    }

    private void updateHeroFav() {
        if (heroChannel == null || heroFav == null) return;
        boolean fav = FavStore.get(this).isFav(heroChannel);
        heroFav.setText(fav ? "★" : "☆");
        heroFav.setTextColor(ContextCompat.getColor(this,
                fav ? R.color.accent : R.color.text_dim));
    }

    /** Load the current hero source into the preview player. */
    private void loadHeroSource() {
        if (heroChannel == null || heroPlayer == null) return;
        if (heroChannel.sources.isEmpty()) {
            showHeroFallback();
            return;
        }
        ui.removeCallbacks(rNextHeroSource);
        if (heroSourceIndex >= heroChannel.sources.size()) heroSourceIndex = 0;

        Channel.Source s = heroChannel.sources.get(heroSourceIndex);
        showHeroFallback();

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(8000)
                .setReadTimeoutMs(8000)
                .setDefaultRequestProperties(s.headers);
        if (!s.agent.isEmpty()) http.setUserAgent(s.agent);

        String url = s.url.trim();
        if (url.isEmpty()) { nextHeroSource(); return; }

        MediaItem item = MediaItem.fromUri(url);
        boolean isHls = url.contains(".m3u8") || url.contains(".m3u");
        MediaSource ms = isHls
                ? new HlsMediaSource.Factory(http).createMediaSource(item)
                : new ProgressiveMediaSource.Factory(http).createMediaSource(item);

        heroPlayer.stop();
        heroPlayer.setMediaSource(ms);
        heroPlayer.prepare();
        heroPlayer.setPlayWhenReady(true);
    }

    /** Move to the next hero source; if all exhausted, keep the fallback logo. */
    private void nextHeroSource() {
        if (heroChannel == null) return;
        heroFailCount++;
        if (heroFailCount >= heroChannel.sources.size()) {
            showHeroFallback();
            return;
        }
        heroSourceIndex = (heroSourceIndex + 1) % heroChannel.sources.size();
        loadHeroSource();
    }

    private void showHeroFallback() {
        if (heroChannel != null) {
            heroFallbackLetter.setText(initial(heroChannel));
            Logos.load(heroFallbackLogo, heroFallbackLetter, heroChannel.logoUrl);
        }
        if (heroFallback != null) heroFallback.setVisibility(View.VISIBLE);
    }

    private void hideHeroFallback() {
        if (heroFallback != null) heroFallback.setVisibility(View.GONE);
    }

    // ============================================================
    //  Hero player callbacks (Player.Listener)
    // ============================================================

    @Override
    public void onPlaybackStateChanged(int state) {
        if (state == Player.STATE_READY) {
            heroFailCount = 0;
            hideHeroFallback();
        }
    }

    @Override
    public void onRenderedFirstFrame() {
        hideHeroFallback();
    }

    @Override
    public void onPlayerError(@NonNull PlaybackException error) {
        ui.removeCallbacks(rNextHeroSource);
        ui.postDelayed(rNextHeroSource, HERO_RETRY_DELAY);
    }

    // ============================================================
    //  Keys / navigation
    // ============================================================

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void open(Channel c) {
        Intent it = new Intent(this, PlayerActivity.class);
        it.putExtra("channel_id", c.id);
        startActivity(it);
    }

    // ============================================================
    //  Helpers
    // ============================================================

    private static String displayName(Channel c) {
        return c.nameEn.isEmpty() ? c.name : c.nameEn;
    }

    private static String initial(Channel c) {
        String n = displayName(c);
        return n.isEmpty() ? "T" : n.substring(0, 1).toUpperCase(Locale.US);
    }
}
