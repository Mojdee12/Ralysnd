package com.tamasha.tv;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.LinkedHashSet;
import java.util.Set;

public final class FavStore {
    private static final String PREF = "tamasha_fav";
    private static FavStore instance;
    private final SharedPreferences prefs;
    private final Set<String> ids = new LinkedHashSet<>();

    private FavStore(Context ctx) {
        prefs = ctx.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
        ids.addAll(prefs.getStringSet("ids", new LinkedHashSet<String>()));
    }

    public static synchronized FavStore get(Context ctx) {
        if (instance == null) instance = new FavStore(ctx);
        return instance;
    }

    public boolean isFav(Channel c) { return ids.contains(String.valueOf(c.id)); }

    public int count() { return ids.size(); }

    public void clear() {
        ids.clear();
        prefs.edit().remove("ids").apply();
    }

    public void toggle(Context ctx, Channel c) {
        String k = String.valueOf(c.id);
        if (ids.contains(k)) ids.remove(k); else ids.add(k);
        prefs.edit().putStringSet("ids", new LinkedHashSet<>(ids)).apply();
    }
}
