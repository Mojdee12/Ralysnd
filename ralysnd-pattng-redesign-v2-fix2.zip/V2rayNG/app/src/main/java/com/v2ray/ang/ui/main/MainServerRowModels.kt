package com.v2ray.ang.ui.main

import com.v2ray.ang.core.AetherCore
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.dto.entities.ServersCache
import com.v2ray.ang.enums.AetherProtocol
import com.v2ray.ang.enums.EConfigType
import com.v2ray.ang.extension.isComplexType
import com.v2ray.ang.extension.nullIfBlank
import com.v2ray.ang.handler.AngConfigManager

internal data class ServerRowUiModel(
    val guid: String,
    val profile: ProfileItem,
    val remarks: String,
    val statistics: String,
    val typeDescription: String,
    val testDelayMillis: Long,
    val subscriptionBadge: String,
)

internal data class ServerGroupUiState(
    val servers: List<ServersCache> = emptyList(),
    val rows: List<ServerRowUiModel> = emptyList(),
)

internal fun buildServerRowUiModel(
    server: ServersCache,
    subscriptionRemarks: String,
    aetherProtocolLabel: (AetherProtocol) -> String = AetherProtocol::name,
): ServerRowUiModel {
    val profile = server.profile
    return ServerRowUiModel(
        guid = server.guid,
        profile = profile,
        remarks = profile.remarks,
        statistics = profile.description.nullIfBlank()
            ?: AngConfigManager.generateDescription(profile),
        typeDescription = serverProtocolDescription(profile, aetherProtocolLabel),
        testDelayMillis = server.testDelayMillis,
        subscriptionBadge = subscriptionRemarks.firstOrNull()?.toString().orEmpty(),
    )
}

/**
 * The type of [profile] as its row names it; an Aether profile's WARP protocol is named by [aetherProtocolLabel], as
 * the editor names it, see [aetherProtocolLabels].
 */
internal fun serverProtocolDescription(
    profile: ProfileItem,
    aetherProtocolLabel: (AetherProtocol) -> String = AetherProtocol::name,
): String {
    if (profile.configType.isComplexType()) return profile.configType.name
    val parts = mutableListOf(profile.configType.name)
    if (profile.configType == EConfigType.AETHER) {
        // The tunnel from the outside in, so a profile that runs Psiphon or Tor alone is not named after a WARP protocol it never opens.
        parts.add(AetherCore.of(profile).path(aetherProtocolLabel).joinToString(" → "))
    }
    profile.network?.let { network ->
        if (network.isNotBlank() && !network.equals("tcp", ignoreCase = true)) {
            parts.add(network)
        }
    }
    profile.security?.let { security ->
        if (security.isNotBlank()) {
            parts.add(
                if (profile.insecure == true && security.equals("tls", ignoreCase = true)) {
                    "$security insecure"
                } else {
                    security
                }
            )
        }
    }
    return parts.joinToString(" / ")
}

/**
 * The names the editor's protocol list gives the WARP protocols, [labels] beside the [values] a profile stores, as a
 * lookup for [serverProtocolDescription]; a protocol the list lacks keeps its own name.
 */
internal fun aetherProtocolLabels(labels: List<String>, values: List<String>): (AetherProtocol) -> String =
    { protocol -> labels.getOrNull(values.indexOf(protocol.type)) ?: protocol.name }

/**
 * Flag emoji for a server's remarks, matched on the country name in it
 * (e.g. "Germany Berlin", "JP Tokyo", "DE-01"). Returns null when no
 * country is found; the caller falls back to the subscription-badge letter.
 *
 * Matching order: a flag emoji already in the remarks first, then
 * multi-word country names, then single-word names,
 * then a two-letter ISO code at the start that reads like a server code:
 * followed by a separator or digit ("DE-01") or by a capitalized word
 * ("JP Tokyo"). A bare two-letter word at the start is not enough: "in",
 * "is", "no", "my" are all country codes and common English words, so
 * "my server" must not become a Malaysian flag.
 */
fun flagEmojiForRemarks(remarks: String): String? {
    // A flag emoji already in the remarks (e.g. "Ralysnd | 🇺🇸 2606:...") wins:
    // return it as-is instead of guessing from names.
    extractFlagEmoji(remarks)?.let { return it }
    val normalized = remarks.lowercase()
    for ((name, code) in COUNTRY_PHRASES) {
        if (Regex("(?<![a-z])${Regex.escape(name)}(?![a-z])").containsMatchIn(normalized)) {
            return flagEmoji(code)
        }
    }
    val tokens = normalized.split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
    for (token in tokens) {
        COUNTRY_NAMES[token]?.let { return flagEmoji(it) }
    }
    val code = Regex("""^[^A-Za-z]*([A-Za-z]{2})(?=[-_.0-9]|\s+[A-Z])""")
        .find(remarks)?.groupValues?.get(1)?.uppercase()
    if (code != null && code in COUNTRY_CODES) {
        return flagEmoji(code)
    }
    return null
}

/** Regional-indicator flag emoji for a two-letter ISO country code. */
fun flagEmoji(countryCode: String): String {
    val code = countryCode.uppercase()
    require(code.length == 2 && code.all { it in 'A'..'Z' }) { "not an ISO country code: $countryCode" }
    return code.map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")
}

/**
 * First flag emoji (a pair of regional-indicator symbols) found in [text],
 * or null. Regional indicators are supplementary-plane code points, so the
 * scan walks code points, not UTF-16 units.
 */
fun extractFlagEmoji(text: String): String? {
    var i = 0
    while (i < text.length) {
        val cp = text.codePointAt(i)
        if (cp in 0x1F1E6..0x1F1FF) {
            val next = i + Character.charCount(cp)
            if (next < text.length) {
                val cp2 = text.codePointAt(next)
                if (cp2 in 0x1F1E6..0x1F1FF) {
                    return text.substring(i, next + Character.charCount(cp2))
                }
            }
        }
        i += Character.charCount(cp)
    }
    return null
}

private val COUNTRY_PHRASES = listOf(
    "united states" to "US",
    "united kingdom" to "GB",
    "south korea" to "KR",
    "hong kong" to "HK",
    "south africa" to "ZA",
    "new zealand" to "NZ",
    "saudi arabia" to "SA",
    "costa rica" to "CR",
    "dominican republic" to "DO",
    "czech republic" to "CZ",
    "united arab emirates" to "AE",
)

private val COUNTRY_NAMES = mapOf(
    "usa" to "US",
    "america" to "US",
    "uk" to "GB",
    "england" to "GB",
    "britain" to "GB",
    "germany" to "DE",
    "deutschland" to "DE",
    "netherlands" to "NL",
    "holland" to "NL",
    "france" to "FR",
    "japan" to "JP",
    "singapore" to "SG",
    "canada" to "CA",
    "australia" to "AU",
    "india" to "IN",
    "iran" to "IR",
    "persia" to "IR",
    "turkey" to "TR",
    "turkiye" to "TR",
    "russia" to "RU",
    "ukraine" to "UA",
    "poland" to "PL",
    "sweden" to "SE",
    "norway" to "NO",
    "denmark" to "DK",
    "finland" to "FI",
    "spain" to "ES",
    "italy" to "IT",
    "portugal" to "PT",
    "greece" to "GR",
    "switzerland" to "CH",
    "austria" to "AT",
    "belgium" to "BE",
    "ireland" to "IE",
    "czech" to "CZ",
    "czechia" to "CZ",
    "hungary" to "HU",
    "romania" to "RO",
    "bulgaria" to "BG",
    "croatia" to "HR",
    "serbia" to "RS",
    "lithuania" to "LT",
    "latvia" to "LV",
    "estonia" to "EE",
    "iceland" to "IS",
    "luxembourg" to "LU",
    "korea" to "KR",
    "china" to "CN",
    "taiwan" to "TW",
    "thailand" to "TH",
    "vietnam" to "VN",
    "indonesia" to "ID",
    "malaysia" to "MY",
    "philippines" to "PH",
    "pakistan" to "PK",
    "bangladesh" to "BD",
    "israel" to "IL",
    "uae" to "AE",
    "emirates" to "AE",
    "dubai" to "AE",
    "saudi" to "SA",
    "qatar" to "QA",
    "kuwait" to "KW",
    "bahrain" to "BH",
    "egypt" to "EG",
    "nigeria" to "NG",
    "kenya" to "KE",
    "brazil" to "BR",
    "mexico" to "MX",
    "argentina" to "AR",
    "chile" to "CL",
    "colombia" to "CO",
    "peru" to "PE",
    "kazakhstan" to "KZ",
    "uzbekistan" to "UZ",
    "georgia" to "GE",
    "armenia" to "AM",
    "azerbaijan" to "AZ",
    "moldova" to "MD",
    "slovakia" to "SK",
    "slovenia" to "SI",
    "malta" to "MT",
    "cyprus" to "CY",
    "albania" to "AL",
    "montenegro" to "ME",
    "belarus" to "BY",
    "morocco" to "MA",
    "algeria" to "DZ",
    "tunisia" to "TN",
    "ghana" to "GH",
    "ethiopia" to "ET",
    "nepal" to "NP",
    "srilanka" to "LK",
    "cambodia" to "KH",
    "myanmar" to "MM",
    "mongolia" to "MN",
    "iraq" to "IQ",
    "jordan" to "JO",
    "lebanon" to "LB",
    "oman" to "OM",
    "yemen" to "YE",
    "venezuela" to "VE",
    "ecuador" to "EC",
    "bolivia" to "BO",
    "uruguay" to "UY",
    "paraguay" to "PY",
    "cuba" to "CU",
    "panama" to "PA",
    "jamaica" to "JM",
    "puerto" to "PR",
)

private val COUNTRY_CODES = setOf(
    "US", "GB", "DE", "FR", "NL", "JP", "SG", "CA", "AU", "IN", "IR", "TR", "RU",
    "UA", "PL", "SE", "NO", "DK", "FI", "ES", "IT", "PT", "GR", "CH", "AT", "BE",
    "IE", "CZ", "HU", "RO", "BG", "HR", "RS", "LT", "LV", "EE", "IS", "LU", "KR",
    "CN", "HK", "TW", "TH", "VN", "ID", "MY", "PH", "PK", "BD", "IL", "AE", "SA",
    "QA", "KW", "BH", "EG", "NG", "KE", "ZA", "BR", "MX", "AR", "CL", "CO", "PE",
    "NZ", "KZ", "UZ", "GE", "AM", "AZ", "MD", "SK", "SI", "MT", "CY", "MK", "AL",
    "BA", "ME", "BY", "MA", "DZ", "TN", "GH", "ET", "NP", "LK", "KH", "MM", "MN",
    "IQ", "JO", "LB", "OM", "YE", "VE", "EC", "BO", "UY", "PY", "CU", "PA", "JM",
    "PR", "CR", "DO",
)
