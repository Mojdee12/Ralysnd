package com.v2ray.ang.ui.main

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Test

class FlagEmojiTest {

    @Test
    fun fullCountryNamesGiveTheirFlag() {
        assertEquals("\uD83C\uDDE9\uD83C\uDDEA", flagEmojiForRemarks("Germany Berlin"))
        assertEquals("\uD83C\uDDEF\uD83C\uDDF5", flagEmojiForRemarks("Japan Tokyo 112ms"))
        assertEquals("\uD83C\uDDFA\uD83C\uDDF8", flagEmojiForRemarks("United States - New York"))
        assertEquals("\uD83C\uDDEC\uD83C\uDDE7", flagEmojiForRemarks("United Kingdom London"))
        assertEquals("\uD83C\uDDEE\uD83C\uDDF7", flagEmojiForRemarks("Iran Tehran"))
    }

    @Test
    fun flagEmojiAlreadyInRemarksIsReturnedAsIs() {
        assertEquals("\uD83C\uDDFA\uD83C\uDDF8", flagEmojiForRemarks("Ralysnd | \uD83C\uDDFA\uD83C\uDDF8 2606:4700:d0::639f"))
        assertEquals("\uD83C\uDDE9\uD83C\uDDEA", flagEmojiForRemarks("DE-01 \uD83C\uDDE9\uD83C\uDDEA Berlin"))
        assertNull(flagEmojiForRemarks("Ralysnd 2606:4700:d0::639f"))
    }

    @Test
    fun firstTokenTwoLetterCodesGiveTheirFlag() {
        assertEquals("\uD83C\uDDE9\uD83C\uDDEA", flagEmojiForRemarks("DE-01"))
        assertEquals("\uD83C\uDDEF\uD83C\uDDF5", flagEmojiForRemarks("JP Tokyo"))
        assertEquals("\uD83C\uDDF8\uD83C\uDDEC", flagEmojiForRemarks("SG-01 Singapore"))
        assertEquals("\uD83C\uDDFA\uD83C\uDDF8", flagEmojiForRemarks("US New York"))
    }

    @Test
    fun ambiguousWordsDoNotGiveAFlag() {
        // "in", "is", "no", "my" are country codes and common words; a bare
        // two-letter word at the start, followed by a lowercase word, is not
        // a server code.
        assertNull(flagEmojiForRemarks("VLESS in the morning"))
        assertNull(flagEmojiForRemarks("my server"))
        assertNull(flagEmojiForRemarks("no name here"))
        assertNull(flagEmojiForRemarks("in the morning"))
        assertNull(flagEmojiForRemarks("Premium 01"))
    }

    @Test
    fun flagEmojiBuildsRegionalIndicators() {
        assertEquals("\uD83C\uDDE9\uD83C\uDDEA", flagEmoji("DE"))
        assertEquals("\uD83C\uDDEC\uD83C\uDDE7", flagEmoji("gb"))
    }
}
