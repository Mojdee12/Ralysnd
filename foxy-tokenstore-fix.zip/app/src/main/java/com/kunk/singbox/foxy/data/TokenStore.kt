package com.kunk.singbox.foxy.data

import android.content.Context
import com.kunk.singbox.foxy.data.model.RuntimeAuth
import com.tencent.mmkv.MMKV

/**
 * FoxyVPN TokenStore, adapted for Ralysnd, with MULTI-ACCOUNT support.
 *
 * Original FoxyVPN used EncryptedSharedPreferences (androidx.security:security-crypto),
 * which KunBox does not depend on. This version uses the app's existing MMKV store
 * (already initialised in SingBoxApplication, same store family as the rest of the app)
 * with the same public API Foxy's FxaAuthRepository expects.
 *
 * MULTI-ACCOUNT KEYS: a TokenStore is now bound to one account id:
 * - accountId == null or "legacy" -> the ORIGINAL single-account keys, byte for
 *   byte ("access_token", "refresh_token", ...). This is the backward-compatible
 *   path: the account a user already signed in with keeps working untouched.
 * - any other accountId -> keys are prefixed "acct_<sanitised-id>_<key>", so
 *   each Firefox account's tokens live under its own keys in the same MMKV
 *   store and never overwrite each other. Sanitising lowercases the id and
 *   replaces every non [a-z0-9] character with '_', so an email maps to
 *   exactly one deterministic prefix.
 *
 * clear() removes ONLY this account's keys — it must never wipe the whole
 * MMKV store now that several accounts share it (the old implementation
 * called mmkv.clear(), which would have deleted every other account).
 *
 * CAVEAT: MMKV here is not encrypted. Before a public release, move this store to
 * an encrypted store (androidx.security:security-crypto) — tokens must not ship
 * in plaintext storage in a production build.
 */
class TokenStore(context: Context, accountId: String? = null) {

    private val mmkv: MMKV by lazy {
        MMKV.mmkvWithID("foxyvpn_tokens", MMKV.MULTI_PROCESS_MODE)
    }

    private val prefix: String = when {
        accountId.isNullOrBlank() || accountId == LEGACY_ACCOUNT_ID -> ""
        else -> "acct_${sanitizeAccountId(accountId)}_"
    }

    private fun key(name: String): String = prefix + name

    fun saveAuth(auth: RuntimeAuth) {
        mmkv.encode(key(KEY_ACCESS_TOKEN), auth.accessToken)
        if (auth.refreshToken != null) {
            mmkv.encode(key(KEY_REFRESH_TOKEN), auth.refreshToken)
        } else {
            mmkv.remove(key(KEY_REFRESH_TOKEN))
        }
        mmkv.encode(key(KEY_EXPIRES_AT), auth.expiresAtEpochSeconds)
    }

    fun loadAuth(): RuntimeAuth? = runCatching {
        val access = mmkv.decodeString(key(KEY_ACCESS_TOKEN), null)?.takeIf { it.isNotBlank() }
            ?: return@runCatching null
        val refresh = mmkv.decodeString(key(KEY_REFRESH_TOKEN), null)?.takeIf { it.isNotBlank() }
        val expiresAt = mmkv.decodeLong(key(KEY_EXPIRES_AT), 0L)
        RuntimeAuth(access, refresh, expiresAt)
    }.getOrNull()

    fun hasValidAccessToken(): Boolean {
        val auth = loadAuth() ?: return false
        if (auth.expiresAtEpochSeconds <= 0L) return false
        val nowSeconds = System.currentTimeMillis() / 1000
        return auth.expiresAtEpochSeconds - nowSeconds > CLOCK_SKEW_TOLERANCE_SECONDS
    }

    fun hasStoredSession(): Boolean = loadAuth() != null

    fun hasRefreshToken(): Boolean = loadAuth()?.refreshToken != null

    /** The email this account signed in with (saved at sign-in; absent for the migrated legacy account). */
    fun saveEmail(email: String) {
        mmkv.encode(key(KEY_EMAIL), email)
    }

    fun loadEmail(): String? =
        mmkv.decodeString(key(KEY_EMAIL), null)?.takeIf { it.isNotBlank() }

    var pendingSessionToken: String?
        get() = mmkv.decodeString(key(KEY_PENDING_SESSION_TOKEN), null)?.takeIf { it.isNotBlank() }
        set(value) {
            if (value != null) {
                mmkv.encode(key(KEY_PENDING_SESSION_TOKEN), value)
            } else {
                mmkv.remove(key(KEY_PENDING_SESSION_TOKEN))
            }
        }

    /** Removes ONLY this account's keys, never other accounts' tokens. */
    fun clear() {
        mmkv.remove(key(KEY_ACCESS_TOKEN))
        mmkv.remove(key(KEY_REFRESH_TOKEN))
        mmkv.remove(key(KEY_EXPIRES_AT))
        mmkv.remove(key(KEY_PENDING_SESSION_TOKEN))
        mmkv.remove(key(KEY_EMAIL))
    }

    companion object {
        const val LEGACY_ACCOUNT_ID = "legacy"
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_EXPIRES_AT = "expires_at"
        private const val KEY_PENDING_SESSION_TOKEN = "pending_session_token"
        private const val KEY_EMAIL = "email"
        private const val CLOCK_SKEW_TOLERANCE_SECONDS = 60L

        fun sanitizeAccountId(accountId: String): String =
            accountId.lowercase().map { if (it in 'a'..'z' || it in '0'..'9') it else '_' }.joinToString("")
    }
}
