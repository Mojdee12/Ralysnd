package com.mlmvpn.scanner.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.absoluteOffset
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.AbsoluteAlignment
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.mlmvpn.scanner.R
import com.mlmvpn.scanner.ui.theme.EmberGlyphSeat
import com.mlmvpn.scanner.ui.theme.EmberRowChevron
import com.mlmvpn.scanner.ui.theme.EngineGlyphs
import com.mlmvpn.scanner.ui.theme.GlyphIcon
import com.mlmvpn.scanner.ui.theme.emberGlass
import com.mlmvpn.scanner.ui.LocalSystemBottomPadding
import com.mlmvpn.scanner.ui.LocalSystemTopPadding
import com.mlmvpn.scanner.ui.settings.IosAlert
import com.mlmvpn.scanner.ui.settings.IosAlertAction
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** How icons slide aside and back: quick, and settling without a wobble, as on iOS. */
private val SlotSpring = spring<Offset>(dampingRatio = 0.82f, stiffness = 420f)

/** A folder opening out of its tile, and closing back into it. */
private val FolderOpenSpring = spring<Float>(dampingRatio = 0.86f, stiffness = 340f)
private val FolderCloseSpring = spring<Float>(dampingRatio = 1f, stiffness = 520f)

/** The search coming down over the board, and going. */
private val SearchOpenSpring = spring<Float>(dampingRatio = 1f, stiffness = 520f)
private val SearchCloseSpring = spring<Float>(dampingRatio = 1f, stiffness = 760f)

/**
 * The app's front door: a wallpaper, a grid of icons, and a dock.
 *
 * This replaces both halves of the old navigation at once -- the five-icon floating bar and the
 * hamburger drawer that hid twelve more features behind it. Everything the drawer held is an
 * icon here, so nothing in the app is more than two taps away and nothing is invisible until you
 * go looking for it.
 *
 * Icons gather into folders the way they do on iOS: hold one over another and a folder grows
 * behind it; let go and the two are a folder, opened at once with a name taken from what they are.
 * Hold one over a folder and it springs open to take it wherever it is wanted inside; drag one out
 * of an open folder and it closes behind it, leaving the icon to land anywhere on the board. See
 * [HomeDrag] for how one drag crosses all of that.
 *
 * The backdrop is NOT drawn here. It is painted at the activity root, behind the system bars, so
 * it runs edge to edge with no cut line under the status icons; this screen is transparent and
 * sits on top of it.
 */
@Composable
fun HomeScreen(
    isRunning: Boolean,
    showTraffic: Boolean,
    onOpen: (HomeApp) -> Unit,
    /** Settings > Software update. Only reachable while [updateReady] is true. */
    onOpenUpdate: () -> Unit = {},
    /** Settings, on the page of a row the search found (the route); the row is armed already. */
    onOpenSetting: (String) -> Unit = {},
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var order by remember { mutableStateOf(HomeLayoutStore.load(context)) }
    var editMode by remember { mutableStateOf(false) }

    // THE HERO is the home face (HeroHome, the Ember-Pro composition); the board below is the
    // secondary surface it opens onto. Not persisted: the app launches onto the hero, and the
    // board is a visit, not a mode the app stays in.
    var hero by remember { mutableStateOf(true) }

    // The folder open over the board: [openKey] while it is open, [shownKey] for as long as it is
    // on screen at all, the closing animation included. What it shows is read back out of `order`,
    // so a change made inside it -- a new name, a member moved -- is the board's own state and the
    // two can never disagree.
    var openKey by remember { mutableStateOf<String?>(null) }
    var shownKey by remember { mutableStateOf<String?>(null) }
    val folderProgress = remember { Animatable(0f) }
    var removing by remember { mutableStateOf<BoardItem.Folder?>(null) }
    var removingWidget by remember { mutableStateOf(false) }

    val drag = remember { HomeDrag(scope) }

    fun commit(items: List<BoardItem>) {
        order = items
        HomeLayoutStore.save(context, items)
    }
    fun commitLayout(layout: BoardLayout?) {
        if (layout != null) commit(HomeLayoutStore.toItems(layout))
    }

    // Where each folder's row is on screen (the board root's coordinates), for the folder
    // panel to grow out of its row the way it grew out of its tile. Filled by BoardList's
    // folder rows as they are laid out; an entry goes away with its row.
    val rowRects = remember { mutableStateMapOf<String, Rect>() }

    /** Edit mode's reorder in list form: a swap with the neighbour, saved by the same commit a drag used. */
    fun moveItem(item: BoardItem, dir: Int) {
        val i = order.indexOfFirst { it.id == item.id }
        val j = i + dir
        if (i < 0 || j !in order.indices) return
        commit(order.toMutableList().also { val t = it[i]; it[i] = it[j]; it[j] = t })
    }
    fun openFolder(key: String) {
        openKey = key
        shownKey = key
        scope.launch { folderProgress.animateTo(1f, FolderOpenSpring) }
    }
    fun closeFolder() {
        if (openKey == null) return
        openKey = null
        scope.launch {
            folderProgress.animateTo(0f, FolderCloseSpring)
            if (openKey == null) shownKey = null
        }
    }

    // The search over the board (HomeSearch), kept the way the folder is: [searchOpen] while it
    // takes input, [searchShown] for as long as it is on screen at all, the fade included.
    var searchOpen by remember { mutableStateOf(false) }
    var searchShown by remember { mutableStateOf(false) }
    val searchProgress = remember { Animatable(0f) }
    fun openSearch() {
        // Not over a rearrangement, an open folder or an icon in the air: each of those has the board.
        if (editMode || openKey != null || drag.session != null) return
        searchOpen = true
        searchShown = true
        scope.launch { searchProgress.animateTo(1f, SearchOpenSpring) }
    }
    fun closeSearch() {
        if (!searchOpen) return
        searchOpen = false
        scope.launch {
            searchProgress.animateTo(0f, SearchCloseSpring)
            if (!searchOpen) searchShown = false
        }
    }
    /** Leaving for what the search found: gone at once -- that screen covers this one anyway. */
    fun dropSearch() {
        searchOpen = false
        searchShown = false
        scope.launch { searchProgress.snapTo(0f) }
    }

    // Wired on every composition, so the drag always acts on the board as it is now.
    drag.committed = { HomeLayoutStore.toLayout(order) }
    drag.commit = { commitLayout(it) }
    drag.openFolderKey = { openKey }
    drag.springOpen = { openFolder(it) }
    drag.closeFolder = { closeFolder() }
    drag.onFolderMade = { openFolder(it) }
    drag.haptics = LocalHapticFeedback.current
    drag.stillSlopPx = with(LocalDensity.current) { 4.dp.toPx() }

    // On the board, back returns to the hero before it would ever offer to exit the app: the
    // board is a surface opened FROM the hero, so back is its way home.
    BackHandler(enabled = !hero && !editMode && openKey == null && !searchShown) { hero = true }
    // Leaving edit mode is what back does first, before it would ever offer to exit the app. An
    // open folder answers back itself (it closes, or leaves its own renaming first).
    BackHandler(enabled = editMode && openKey == null) { editMode = false }
    GerehTileMenuDialog(onEditHome = { editMode = true }, onRemoved = { order = HomeLayoutStore.load(context) })

    val liveEngines = ActiveEngines.ids()
    val progress: State<Float> = folderProgress.asState()
    val searchState: State<Float> = searchProgress.asState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .onGloballyPositioned { drag.root = it }
            .homeDragTracker(drag),
    ) {
        if (hero) {
            // The hero face. Every destination the board holds stays reachable from here: the
            // chips and tiles open their pages through the same onOpen a board tile takes, the
            // pills open Locations and Subscriptions, and "+N Engines" opens the board itself.
            HeroHome(
                onOpen = onOpen,
                onShowBoard = { hero = false },
                modifier = Modifier.fillMaxSize(),
            )
        } else {
        // EMBER-PRO (s02): the board's ground is the kit ground — BgDeep with the dotted map
        // at the sample's board alpha — not the user's photo wallpaper. The wallpaper
        // machinery itself is untouched (the hero, modals and the wallpaper picker still use
        // it, and the user's choice is still stored); the board face paints its own ground
        // over it, the way the hero paints its own.
        com.mlmvpn.scanner.ui.theme.EmberMapBackground(
            modifier = Modifier.fillMaxSize(),
            mapAlpha = 0.10f,
            showPins = false,
        )
        // While a folder is open the ground behind everything veils to deep slate, so the
        // icons still show through, dimmed. (Was a frosted slice of the photo wallpaper —
        // the board has no photo behind it any more.)
        if (shownKey != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = progress.value }
                    .background(com.mlmvpn.scanner.ui.theme.Ember.BgDeep.copy(alpha = 0.78f)),
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                // The board softens behind an open folder. Read in the layer, so the opening costs a
                // redraw a frame and no recomposition; below Android 12 the scrim alone does it.
                .graphicsLayer {
                    // Behind the search as well, while it fades in over the board.
                    val p = maxOf(progress.value, searchState.value)
                    renderEffect = if (p > 0.01f) BlurEffect(p * 16f, p * 16f, TileMode.Decal) else null
                }
                .padding(
                    top = LocalSystemTopPadding.current,
                    bottom = LocalSystemBottomPadding.current,
                )
                // The sides matter only in landscape, and there they matter a lot: the display cutout
                // sits on one edge and the navigation bar on the other, so padding top and bottom
                // alone left the board pushed towards one side -- the icons were centred in the
                // window and visibly off-centre on the screen. `displayCutout` and `navigationBars`
                // rather than `systemBars`, because the status bar is a top inset already applied
                // above and taking it twice would add a margin nothing is behind.
                .windowInsetsPadding(
                    WindowInsets.displayCutout
                        .union(WindowInsets.navigationBars)
                        .only(WindowInsetsSides.Horizontal)
                )
        ) {
            // A newer release is announced the iOS way: a red badge on the Settings icon (see
            // AppIconCell) and a row at the top of Settings -- not a glyph in this strip.
            HomeStatusStrip(
                isRunning = isRunning,
                showTraffic = showTraffic,
                editMode = editMode,
                onDone = { editMode = false },
                // On the board, the brand panel is the way back to the hero face.
                onBrandTap = { hero = true },
            )

            // EMBER-PRO (s02 `.searchrow`): the search as a glass field under the strip,
            // opening the same search the pill under the board opens (which stays, dots and
            // all — it is also the page indicator). Hidden while rearranging, like the pill.
            if (!editMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .height(48.dp)
                        .emberGlass(RoundedCornerShape(14.dp))
                        .pointerInput(Unit) { detectTapGestures { openSearch() } }
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        androidx.compose.material.icons.Icons.Default.Search,
                        contentDescription = null,
                        tint = com.mlmvpn.scanner.ui.theme.Ember.TextFaint,
                        modifier = Modifier.size(16.dp),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        com.mlmvpn.scanner.store.tr("جستجو", "Search"),
                        color = com.mlmvpn.scanner.ui.theme.Ember.TextFaint,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                    )
                }
            }

            BoardList(
                // The board as a list (owner's order, 2026-11-06): one kit row per destination,
                // in the saved order — the arrangement itself is data and is untouched.
                items = order,
                editMode = editMode,
                liveEngines = liveEngines,
                shownFolder = shownKey,
                folderProgress = progress,
                rowRects = rowRects,
                rootCoords = { drag.root },
                onEnterEditMode = { editMode = true },
                onExitEditMode = { editMode = false },
                onOpen = { item ->
                    when (item) {
                        // A folder opens in edit mode too -- that is where it is renamed and rearranged.
                        is BoardItem.Folder -> openFolder(item.key)
                        is BoardItem.App -> if (!editMode) onOpen(item.app)
                    }
                },
                onLongPress = { item ->
                    // A hold on a board cell used to pick the icon up (and so enter edit mode);
                    // in list form the hold only enters edit mode — see BoardList's note. The
                    // Gereh tile keeps its own menu on a hold, exactly as it did on the grid.
                    if (!editMode) {
                        if (item is BoardItem.App && item.app.id == com.mlmvpn.scanner.chat.MlmChat.TILE_ID) {
                            GerehTileMenu.open.value = true
                        } else {
                            editMode = true
                        }
                    }
                },
                onMove = { item, dir -> moveItem(item, dir) },
                onRemoveFolder = { removing = it },
                // While the search covers the board, a remote's focus stays in the search.
                tvFocus = !searchShown,
                widget = Appearance.homeWidget,
                onOpenApp = { if (!editMode) onOpen(it) },
                onRemoveWidget = { removingWidget = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
            )

            // Centred, because the dock no longer fills the width it is given -- see GlassDock. On a
            // phone this changes nothing (the bar is wider than the screen); on anything larger it is
            // what keeps the dock under the middle of the board instead of pinned to one edge.
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                GlassDock(
                    apps = HomeDestinations.DOCK,
                    tileSize = 56.dp,
                    onOpen = { if (!editMode) onOpen(it) },
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
                    focusable = !searchShown,
                )
            }
        }

        val key = shownKey
        val folder = order.firstOrNull { it is BoardItem.Folder && it.key == key } as BoardItem.Folder?
        if (key != null && folder == null && !drag.active) {
            // The folder is gone from under its own panel -- its last app left it. Nothing to show.
            LaunchedEffect(key) { closeFolder(); shownKey = null }
        }
        if (folder != null) {
            val factoryTitle = stringResource(HomeDestinations.folderTitleRes(folder.key))
            FolderOverlay(
                folder = folder,
                apps = drag.folderApps(folder.key) ?: folder.apps,
                gap = if (drag.active) drag.folderGap else null,
                open = openKey == folder.key,
                progress = progress,
                origin = { rowRects[BoardLayoutRules.folderRef(folder.key)] },
                editMode = editMode,
                drag = drag,
                liveEngines = liveEngines,
                onEnterEditMode = { editMode = true },
                onExitEditMode = { editMode = false },
                onOpenApp = { app ->
                    closeFolder()
                    onOpen(app)
                },
                onClose = { closeFolder() },
                onRename = { title ->
                    commitLayout(
                        BoardLayoutRules.rename(HomeLayoutStore.toLayout(order), folder.key, title, factoryTitle)
                    )
                },
            )
        }

        DragLayer(drag) { item, tilePx ->
            val size = with(LocalDensity.current) { tilePx.toDp() }
            when (item) {
                is BoardItem.App -> AppIconTile(app = item.app, size = size, connected = item.id in liveEngines)
                is BoardItem.Folder -> FolderTile(folder = item, tileSize = size, connected = item.apps.any { it.id in liveEngines })
            }
        }

        // The search, over everything: board, dock, an open folder (it cannot be opened over one).
        if (searchShown) {
            HomeSearch(
                open = searchOpen,
                progress = searchState,
                board = order,
                liveEngines = liveEngines,
                onOpenApp = { app ->
                    dropSearch()
                    onOpen(app)
                },
                onOpenSetting = { route ->
                    dropSearch()
                    onOpenSetting(route)
                },
                onClose = { closeSearch() },
            )
        }
        } // hero / board
    }

    if (removingWidget) {
        IosAlert(
            title = com.mlmvpn.scanner.store.tr("برداشتن ویجت اتصال؟", "Remove the connection widget?"),
            message = com.mlmvpn.scanner.store.tr(
                "ویجت از صفحهٔ اصلی برداشته می‌شود و کاشی‌ها جای آن را می‌گیرند. هر وقت خواستید از تنظیمات › صفحه نمایش یا ویجت استدیو دوباره روشنش کنید.",
                "The widget leaves the home screen and the icons take its place. Turn it back on any time in Settings › Display or in Widget Studio.",
            ),
            actions = listOf(
                IosAlertAction(stringResource(R.string.common_cancel), onClick = { removingWidget = false }),
                IosAlertAction(
                    com.mlmvpn.scanner.store.tr("برداشتن", "Remove"),
                    onClick = {
                        removingWidget = false
                        Appearance.setHomeWidget(context, false)
                    },
                    destructive = true,
                ),
            ),
            onDismiss = { removingWidget = false },
        )
    }

    removing?.let { f ->
        val title = folderTitle(f)
        IosAlert(
            title = stringResource(R.string.home_folder_remove_title, title),
            message = stringResource(R.string.home_folder_remove_body),
            actions = listOf(
                IosAlertAction(stringResource(R.string.common_cancel), onClick = { removing = null }),
                IosAlertAction(
                    stringResource(R.string.home_folder_remove),
                    onClick = {
                        removing = null
                        commitLayout(BoardLayoutRules.ungroup(HomeLayoutStore.toLayout(order), f.key))
                    },
                    destructive = true,
                ),
            ),
            onDismiss = { removing = null },
        )
    }
}


/**
 * The strip where a phone would put its clock and battery. Ours carries the one thing a VPN app
 * has to answer at a glance -- am I protected -- plus the session counters when they are on.
 */
@Composable
private fun HomeStatusStrip(
    isRunning: Boolean,
    showTraffic: Boolean,
    editMode: Boolean,
    onDone: () -> Unit,
    /** Tapping the brand panel (the board's way back to the hero face); null leaves it inert. */
    onBrandTap: (() -> Unit)? = null,
) {
    // The live meter is read HERE, in this strip, and nowhere higher -- the same leaf rule as
    // the hero bar and the chrome bar (FeatureTopBar). HomeScreen used to take the two rates
    // as parameters, so every traffic tick recomposed the whole home grid for two figures only
    // this strip's traffic panel shows; the tick now invalidates only this strip. The gating
    // is unchanged: 0.0 unless a session is up and the readout is on.
    val totals by com.mlmvpn.scanner.data.SessionTraffic.totals.collectAsStateWithLifecycle()
    val trafficDown = if (isRunning && showTraffic) totals.rx / 1048576f else 0f
    val trafficUp = if (isRunning && showTraffic) totals.tx / 1048576f else 0f
    // EMBER-PRO (s02 `.strip`): three glass panels in a row — the brand panel at the sample's
    // fixed 170dp, the session traffic as its own glass panel between them, and Support as a
    // small square glass chip (chat glyph over its word), where the old strip put a pink
    // heart pill beside the brand and bare figures at the trailing edge.
    val ember = com.mlmvpn.scanner.ui.theme.Ember
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(68.dp)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            modifier = Modifier
                .width(160.dp)
                .height(56.dp)
                .emberGlass(ember.ShapeBrand)
                .then(
                    if (onBrandTap != null) Modifier.pointerInput(Unit) {
                        detectTapGestures { onBrandTap() }
                    } else Modifier
                )
                .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            com.mlmvpn.scanner.ui.theme.EmberFlame(Modifier.size(26.dp))
            Spacer(Modifier.width(8.dp))
            Column {
                Text(
                    "Ralysnd",
                    color = ember.TextHi,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.2.sp,
                    maxLines = 1,
                )
                Text(
                    "v" + com.mlmvpn.scanner.BuildConfig.VERSION_NAME,
                    color = ember.TextFaint,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.8.sp,
                    maxLines = 1,
                )
            }
        }

        if (editMode) {
            Spacer(Modifier.weight(1f))
            Text(
                text = stringResource(R.string.home_edit_done),
                color = ember.TextHi,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .emberGlass(RoundedCornerShape(16.dp))
                    .pointerInput(Unit) { detectTapGestures { onDone() } }
                    .padding(horizontal = 16.dp, vertical = 8.dp),
            )
        } else {
            if (showTraffic) {
                // The traffic panel: the same two live rates the strip always showed, in the
                // sample's form — ember arrows, tabular figures, the unit small beside them,
                // and a tracked micro caption under. No session-usage figure: the strip has
                // never had one (that number lives in the connection widget), so none is
                // invented for the panel's second line.
                val valueColor = if (isRunning) ember.TextValue else ember.TextFaint
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                        .emberGlass(ember.ShapeBrand)
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.Center,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "↓",
                            color = if (isRunning) ember.EmberText else ember.TextFaint,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            String.format("%.1f", trafficDown),
                            color = valueColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            style = com.mlmvpn.scanner.ui.theme.EmberTabular,
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "↑",
                            color = if (isRunning) ember.EmberText else ember.TextFaint,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            String.format("%.1f", trafficUp),
                            color = valueColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            style = com.mlmvpn.scanner.ui.theme.EmberTabular,
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            "MB/s",
                            color = ember.TextFaint,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Medium,
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    com.mlmvpn.scanner.ui.theme.EmberMicroLabel("Live traffic")
                }
            } else {
                Spacer(Modifier.weight(1f))
            }
            // Supporting the app: one tap, the donation page in the browser — now the
            // sample's square glass chip instead of the pink pill.
            val context = LocalContext.current
            Column(
                modifier = Modifier
                    .size(56.dp)
                    .emberGlass(ember.ShapeBrand)
                    .pointerInput(Unit) { detectTapGestures { com.mlmvpn.scanner.utils.Donate.open(context) } },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                com.mlmvpn.scanner.ui.theme.GlyphIcon(
                    id = "support",
                    size = 17.dp,
                    color = ember.EmberText,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    com.mlmvpn.scanner.store.tr("حمایت", "Support"),
                    color = ember.TextLabel,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                )
            }
        }
    }
}


/** Where an icon is, slid there from wherever it last was. */
@Composable
internal fun rememberSlotPosition(target: Offset): State<Offset> {
    val anim = remember { Animatable(target, Offset.VectorConverter) }
    LaunchedEffect(target) {
        if (anim.value != target) anim.animateTo(target, SlotSpring)
    }
    return anim.asState()
}

internal fun Offset.toIntOffset(): IntOffset = IntOffset(x.roundToInt(), y.roundToInt())

/**
 * One cell of the board or of an open folder: its tile and caption, and everything a cell does
 * -- open on a tap, start a drag, jiggle while rearranging, show the plate a folder grows from.
 */
@Composable
internal fun BoardCell(
    item: BoardItem,
    drag: HomeDrag,
    fromFolder: String?,
    tileSize: Dp,
    tilePx: Float,
    editMode: Boolean,
    liveEditMode: () -> Boolean,
    jiggle: State<Float>,
    jigglePhase: Float,
    connected: Boolean,
    /** For the folder whose panel is open: its tile fades as the panel grows out of it. */
    hiddenBy: State<Float>?,
    contentHeight: androidx.compose.runtime.MutableFloatState,
    onTap: () -> Unit,
    onEnterEditMode: () -> Unit,
    /** Folders only: the edit-mode badge that takes the folder apart. */
    onRemove: (() -> Unit)?,
    modifier: Modifier = Modifier,
    /** Off while something covers the board (the search), so a remote cannot move behind it. */
    tvFocus: Boolean = true,
) {
    var coords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    // The gestures live as long as the cell; these keep what they act on current.
    val currentItem by rememberUpdatedState(item)
    val currentTilePx by rememberUpdatedState(tilePx)
    val currentOnTap by rememberUpdatedState(onTap)
    val currentOnEnterEditMode by rememberUpdatedState(onEnterEditMode)
    val landing = drag.landingId == item.id
    val target = drag.onto == item.id
    // The plate a new folder grows from, behind an app held over; a folder held over swells.
    val plate by animateFloatAsState(if (target) 1f else 0f, spring(dampingRatio = 0.8f, stiffness = 520f), label = "plate")

    Box(
        modifier = modifier
            .zIndex(if (target) 1f else 0f)
            .onGloballyPositioned { coords = it }
            .homeItemGestures(
                key = item.id,
                drag = drag,
                item = { currentItem },
                fromFolder = fromFolder,
                tilePx = { currentTilePx },
                editMode = liveEditMode,
                coordinates = { coords },
                tileTopLeftInRoot = {
                    val root = drag.root
                    val own = coords
                    if (root == null || own == null || !own.isAttached) null else {
                        val cell = root.localBoundingBoxOf(own, clipBounds = false)
                        val top = ((cell.height - contentHeight.floatValue) / 2f).coerceAtLeast(0f)
                        Offset(cell.left + (cell.width - currentTilePx) / 2f, cell.top + top)
                    }
                },
                onTap = { currentOnTap() },
                onEnterEditMode = { currentOnEnterEditMode() },
            )
            .tvFocusable(enabled = tvFocus, onPress = onTap)
            .graphicsLayer {
                alpha = when {
                    landing -> 0f
                    hiddenBy != null -> 1f - hiddenBy.value
                    else -> 1f
                }
                rotationZ = jiggle.value * jigglePhase
            },
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier.onSizeChanged { contentHeight.floatValue = it.height.toFloat() },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Box(modifier = Modifier.size(tileSize)) {
                when (item) {
                    is BoardItem.App -> {
                        if (plate > 0.01f) {
                            Box(
                                modifier = Modifier
                                    .size(tileSize)
                                    .graphicsLayer {
                                        val s = 1f + 0.26f * plate
                                        scaleX = s
                                        scaleY = s
                                        alpha = plate
                                    }
                                    .emberGlass(com.mlmvpn.scanner.ui.theme.Ember.ShapeTile, soft = true),
                            )
                        }
                        AppIconTile(app = item.app, size = tileSize, connected = connected)
                    }
                    is BoardItem.Folder -> FolderTile(
                        folder = item,
                        tileSize = tileSize,
                        connected = connected,
                        modifier = Modifier.graphicsLayer {
                            val s = 1f + 0.12f * plate
                            scaleX = s
                            scaleY = s
                        },
                    )
                }
                if (editMode && onRemove != null) {
                    RemoveBadge(size = tileSize, onClick = onRemove)
                }
            }
            Spacer(Modifier.height(8.dp))
            TileCaption(
                when (item) {
                    is BoardItem.App -> stringResource(item.app.labelRes)
                    is BoardItem.Folder -> folderTitle(item)
                }
            )
        }
    }
}

/**
 * iOS's minus badge, top-left of an icon while the board is being rearranged. Only folders wear
 * it here -- the destinations are the app itself and cannot be removed -- and on a folder it takes
 * the folder apart, its apps going back onto the board.
 */
@Composable
private fun RemoveBadge(size: Dp, onClick: () -> Unit) {
    val d = (size * 0.34f).coerceIn(18.dp, 24.dp)
    val description = stringResource(R.string.home_folder_remove)
    // Physical top-left in both directions, like iOS.
    val corner = if (LocalLayoutDirection.current == LayoutDirection.Rtl) Alignment.TopEnd else Alignment.TopStart
    Box(modifier = Modifier.size(size)) {
        Box(
            modifier = Modifier
                .align(corner)
                .absoluteOffset(x = -(d * 0.32f), y = -(d * 0.32f))
                .size(d)
                .shadow(elevation = 2.dp, shape = CircleShape, clip = false)
                .clip(CircleShape)
                .background(Color(0xFF8E8E93).copy(alpha = 0.96f))
                .semantics { contentDescription = description }
                .pointerInput(Unit) { detectTapGestures { onClick() } },
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Default.Remove, contentDescription = null, tint = Color.White, modifier = Modifier.size(d * 0.72f))
        }
    }
}

/**
 * The row of dots under a board that has more than one page.
 *
 * Drawn only when there IS more than one page. A single dot under a board that cannot be swiped
 * is an invitation to try, and the thing it invites does nothing.
 */
@Composable
internal fun PageDots(count: Int, current: Int, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier.fillMaxWidth().padding(top = 4.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        repeat(count) { i ->
            Box(
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .size(8.dp)
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (i == current) com.mlmvpn.scanner.ui.theme.Ember.TextLabel
                        else com.mlmvpn.scanner.ui.theme.Ember.TextMicro
                    )
            )
        }
    }
}

/**
 * The board as a list (the owner's composition, 2026-11-06): the connection widget on top,
 * then one kit row per destination, top to bottom, in the board's saved order. It replaces
 * the paged tile grid on this surface; the arrangement it reads — the order itself and the
 * folders — is the same saved data the grid read, and nothing here writes it except edit
 * mode's moves, which go through the same commit (and so the same store) a drag used.
 *
 * What the grid's drag machinery did that a list does not translate, kept honest:
 *  - Drag-reorder and making a folder by dropping one icon on another were geometry: slots,
 *    pages, a gap that follows the finger. A list has no slots to drop into, so reorder in
 *    edit mode is the two move keys on each row (a swap with the neighbour, saved at once),
 *    and folders are neither made nor filled by dragging here. The folder panel itself is
 *    unchanged — its own inside rearrange still drags, on its own geometry; carrying one of
 *    its apps out onto the board has nowhere to land and settles back into the folder.
 *  - The jiggle was the drag's edit-mode face and goes with it; edit mode here is told by
 *    the strip's Done chip and the keys on the rows.
 *  - The page dots and their pill belonged to the pager; the search they also opened is
 *    still one tap away, in the field under the strip.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BoardList(
    items: List<BoardItem>,
    editMode: Boolean,
    liveEngines: Set<String>,
    shownFolder: String?,
    folderProgress: State<Float>,
    rowRects: MutableMap<String, Rect>,
    rootCoords: () -> LayoutCoordinates?,
    onEnterEditMode: () -> Unit,
    onExitEditMode: () -> Unit,
    onOpen: (BoardItem) -> Unit,
    onLongPress: (BoardItem) -> Unit,
    onMove: (BoardItem, Int) -> Unit,
    onRemoveFolder: (BoardItem.Folder) -> Unit,
    tvFocus: Boolean,
    /** The connection widget is on (Settings > Display); in a scrolling list it always has room. */
    widget: Boolean = false,
    onOpenApp: (HomeApp) -> Unit = {},
    onRemoveWidget: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val liveEditMode by rememberUpdatedState(editMode)
    val liveOnExitEditMode by rememberUpdatedState(onExitEditMode)
    Box(
        modifier = modifier
            // A tap anywhere the rows are not finishes rearranging, as on the grid. Only the
            // empty space reaches this: a row's own gestures take its press.
            .pointerInput(Unit) {
                detectTapGestures { if (liveEditMode) liveOnExitEditMode() }
            }
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (widget) {
                item(key = "connection-widget") {
                    HomeConnectionWidget(
                        editMode = editMode,
                        onOpenApp = onOpenApp,
                        onEnterEditMode = onEnterEditMode,
                        onRemove = onRemoveWidget,
                        // The grid gave the widget two of its rows; at a phone's pitch that
                        // is this tall. The widget lays itself out by the space it is given.
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(228.dp),
                    )
                }
            }
            itemsIndexed(items, key = { _, item -> item.id }) { index, item ->
                BoardListRow(
                    item = item,
                    index = index,
                    count = items.size,
                    editMode = editMode,
                    connected = when (item) {
                        is BoardItem.App -> item.id in liveEngines
                        is BoardItem.Folder -> item.apps.any { it.id in liveEngines }
                    },
                    hiddenBy = if (item is BoardItem.Folder && item.key == shownFolder) folderProgress else null,
                    tvFocus = tvFocus,
                    onOpen = onOpen,
                    onLongPress = onLongPress,
                    onMove = onMove,
                    onRemoveFolder = onRemoveFolder,
                    rootCoords = rootCoords,
                    onRect = { rect -> rowRects[item.id] = rect },
                    onRectGone = { rowRects.remove(item.id) },
                )
            }
        }
    }
}

/**
 * One destination's row: the glyph seat (the kit's, with the glyph centred in it), the name,
 * the live mark where there is one, and the kit's chevron — in edit mode, the move keys and,
 * on a folder, the key that takes it apart. A row opens exactly what its tile opened.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BoardListRow(
    item: BoardItem,
    index: Int,
    count: Int,
    editMode: Boolean,
    connected: Boolean,
    /** For the folder whose panel is open: its row fades as the panel grows out of it. */
    hiddenBy: State<Float>?,
    tvFocus: Boolean,
    onOpen: (BoardItem) -> Unit,
    onLongPress: (BoardItem) -> Unit,
    onMove: (BoardItem, Int) -> Unit,
    onRemoveFolder: (BoardItem.Folder) -> Unit,
    rootCoords: () -> LayoutCoordinates?,
    onRect: (Rect) -> Unit,
    onRectGone: () -> Unit,
) {
    DisposableEffect(item.id) {
        onDispose { if (item is BoardItem.Folder) onRectGone() }
    }
    // Settings wears the update badge, as its tile did (see AppIconCell).
    val update by com.mlmvpn.scanner.update.UpdateChecker.updateAvailableFlow.collectAsState()
    val showBadge = item is BoardItem.App && item.app.id == "settings" && update != null
    val ember = com.mlmvpn.scanner.ui.theme.Ember
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(
                if (item is BoardItem.Folder) {
                    Modifier.onGloballyPositioned { coords ->
                        val root = rootCoords()?.takeIf { it.isAttached } ?: return@onGloballyPositioned
                        if (coords.isAttached) onRect(root.localBoundingBoxOf(coords, clipBounds = false))
                    }
                } else {
                    Modifier
                }
            )
            .graphicsLayer {
                alpha = if (hiddenBy != null) 1f - hiddenBy.value else 1f
            }
            .tvFocusable(enabled = tvFocus, cornerRadius = 16, onPress = { onOpen(item) })
            .emberGlass(ember.ShapeRow, selected = connected)
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = { onOpen(item) },
                onLongClick = { onLongPress(item) },
            )
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        when (item) {
            is BoardItem.App -> BoardRowSeat(item.app)
            is BoardItem.Folder -> BoardFolderSeat(item)
        }
        Spacer(Modifier.width(12.dp))
        Text(
            text = when (item) {
                is BoardItem.App -> stringResource(item.app.labelRes)
                is BoardItem.Folder -> folderTitle(item)
            },
            color = ember.TextValue,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (showBadge) {
            Box(
                modifier = Modifier
                    .height(18.dp)
                    .widthIn(min = 18.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFFFF3B30))
                    .padding(horizontal = 4.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "1",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                )
            }
            Spacer(Modifier.width(8.dp))
        }
        if (editMode) {
            BoardEditKey(icon = Icons.Default.KeyboardArrowUp, enabled = index > 0) { onMove(item, -1) }
            Spacer(Modifier.width(8.dp))
            BoardEditKey(icon = Icons.Default.KeyboardArrowDown, enabled = index < count - 1) { onMove(item, 1) }
            if (item is BoardItem.Folder) {
                Spacer(Modifier.width(8.dp))
                BoardEditKey(icon = Icons.Default.Remove, enabled = true) { onRemoveFolder(item) }
            }
        } else {
            if (item is BoardItem.Folder) {
                // How many are inside — the row's only fact about a folder, and a real one.
                Text(
                    text = item.apps.size.toString(),
                    color = ember.TextDim,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    style = com.mlmvpn.scanner.ui.theme.EmberTabular,
                    maxLines = 1,
                )
                Spacer(Modifier.width(8.dp))
            }
            if (connected) {
                // The running lamp, in row form: the ember dot the connected tile wore.
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Brush.verticalGradient(listOf(ember.EmberHi, ember.EmberDeep))),
                )
                Spacer(Modifier.width(8.dp))
            }
            EmberRowChevron()
        }
    }
}

/**
 * A destination's seat in a row: the kit's glyph seat exactly as [EmberGlyphSeat] builds it,
 * with the destination's older vector as the mark for any id the glyph set does not cover
 * (none of the board's current destinations are uncovered).
 */
@Composable
private fun BoardRowSeat(app: HomeApp, size: Dp = 40.dp) {
    if (EngineGlyphs.has(app.id)) {
        EmberGlyphSeat(
            glyphId = app.id,
            slate = !EngineGlyphs.seatEmber(app.id),
            size = size,
        )
        return
    }
    val emberSeat = EngineGlyphs.seatEmber(app.id)
    val ember = com.mlmvpn.scanner.ui.theme.Ember
    Box(
        modifier = Modifier
            .size(size)
            .clip(ember.ShapeIconBox)
            .background(
                if (emberSeat) Brush.linearGradient(
                    listOf(ember.Ember.copy(alpha = 0.17f), ember.Ember.copy(alpha = 0.05f)),
                ) else Brush.linearGradient(
                    listOf(Color(0xFF7EA4CD).copy(alpha = 0.12f), Color(0xFF7EA4CD).copy(alpha = 0.04f)),
                ),
            )
            .border(
                1.dp,
                if (emberSeat) ember.Ember.copy(alpha = 0.22f) else Color(0xFF7EA4CD).copy(alpha = 0.16f),
                ember.ShapeIconBox,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = app.icon,
            contentDescription = null,
            tint = EngineGlyphs.glyphColor(app.id),
            modifier = Modifier.size(size * 0.56f),
        )
    }
}

/**
 * A folder's seat in a row: slate glass holding the first members' own glyphs as miniatures,
 * the way the folder's tile held their tiles — so a folder is found by what is inside it.
 */
@Composable
private fun BoardFolderSeat(folder: BoardItem.Folder, size: Dp = 40.dp) {
    val ember = com.mlmvpn.scanner.ui.theme.Ember
    Box(
        modifier = Modifier
            .size(size)
            .clip(ember.ShapeIconBox)
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF7EA4CD).copy(alpha = 0.12f), Color(0xFF7EA4CD).copy(alpha = 0.04f)),
                ),
            )
            .border(1.dp, Color(0xFF7EA4CD).copy(alpha = 0.16f), ember.ShapeIconBox),
        contentAlignment = Alignment.Center,
    ) {
        val minis = folder.apps.filter { EngineGlyphs.has(it.id) }.take(4)
        if (minis.isEmpty()) {
            GlyphIcon("widgetstudio", size * 0.56f, Color(0xFF9DB2C9))
        } else {
            val mini = size * 0.34f
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                for (r in 0 until 2) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (c in 0 until 2) {
                            val app = minis.getOrNull(r * 2 + c)
                            if (app != null) {
                                GlyphIcon(app.id, mini, EngineGlyphs.glyphColor(app.id))
                            } else {
                                Spacer(Modifier.size(mini))
                            }
                        }
                    }
                }
            }
        }
    }
}

/** A small glass key on a row in edit mode: move up, move down, take a folder apart. */
@Composable
private fun BoardEditKey(icon: ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .emberGlass(RoundedCornerShape(12.dp))
            .then(
                if (enabled) {
                    Modifier.pointerInput(Unit) { detectTapGestures { onClick() } }
                } else {
                    Modifier
                }
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            contentDescription = null,
            tint = com.mlmvpn.scanner.ui.theme.Ember.TextLabel.copy(alpha = if (enabled) 1f else 0.3f),
            modifier = Modifier.size(18.dp),
        )
    }
}
