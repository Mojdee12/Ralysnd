package com.mlmvpn.scanner.ui.home

import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.mlmvpn.scanner.BuildConfig
import com.mlmvpn.scanner.data.SubscriptionManager
import com.mlmvpn.scanner.store.tr
import com.mlmvpn.scanner.ui.LocalSystemBottomPadding
import com.mlmvpn.scanner.ui.LocalSystemTopPadding
import com.mlmvpn.scanner.ui.configstudio.TimeLeftUnit
import com.mlmvpn.scanner.ui.configstudio.timeLeftParts
import com.mlmvpn.scanner.ui.theme.Ember
import com.mlmvpn.scanner.ui.theme.EmberCapsule
import com.mlmvpn.scanner.ui.theme.EmberFlame
import com.mlmvpn.scanner.ui.theme.EmberIconBox
import com.mlmvpn.scanner.ui.theme.EmberMapBadge
import com.mlmvpn.scanner.ui.theme.EmberMapBackground
import com.mlmvpn.scanner.ui.theme.EmberMapData
import com.mlmvpn.scanner.ui.theme.EmberTabular
import com.mlmvpn.scanner.ui.theme.EmberTag
import com.mlmvpn.scanner.ui.theme.EmberTagKind
import com.mlmvpn.scanner.ui.theme.EmberTelemetryCell
import com.mlmvpn.scanner.ui.theme.emberExitFrame
import com.mlmvpn.scanner.ui.theme.emberGlass
import com.mlmvpn.scanner.widget.WidgetConnect
import com.mlmvpn.scanner.widget.WidgetConnectService
import com.mlmvpn.scanner.widget.WidgetFormat
import com.mlmvpn.scanner.widget.WidgetLive
import com.mlmvpn.scanner.widget.WidgetMethods
import com.mlmvpn.scanner.widget.WidgetPainter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * THE HERO: the Ember-Pro home face, composed exactly as the owner-approved samples
 * (design-v10 hero, design-v11 p01) lay it out -- the dotted world map full-screen, the glass
 * brand panel and the Locations / Subscription pills at the top left, the engine chips at the
 * top right, four shortcut tiles and the wide floating control bar at the bottom.
 *
 * This is the board's replacement as the home FACE, not as the home's contents: every
 * destination the launcher board holds stays reachable from here. The chips open their
 * methods' own pages (the same [onOpen] a board tile tap takes), the tiles open theirs, the
 * pills open Quick Connect's locations and the V2Ray subscriptions, and the "+N Engines" chip
 * opens the board itself ([onShowBoard]) -- the board, its wallpaper, folders, drag editing,
 * search and dock all live there unchanged.
 *
 * State and behaviour are the connection widget's own, read for a second surface: the same
 * [WidgetLive] flows, the same last-method record ([lastMethod]), the same consent flow and
 * the same connect/disconnect calls (see HomeConnectionWidget, whose board surface keeps the
 * live chart this composition has no place for). Nothing here invents a figure: the map's exit
 * pin and arc come from the reported exit country, the telemetry is the widget's set (exit
 * country, session, rates -- this surface is not given an exit IP or a ping, so neither is
 * shown), and the subscription pill's days-left is the nearest real subscription expiry.
 */
@Composable
internal fun HeroHome(
    onOpen: (HomeApp) -> Unit,
    onShowBoard: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val conn by WidgetLive.conn.collectAsState()
    DisposableEffect(Unit) {
        WidgetLive.wantCountry("hero", true)
        onDispose { WidgetLive.wantCountry("hero", false) }
    }
    val method = conn.method?.takeIf { WidgetMethods.isMethod(it) }
    // Off the main thread, for the widget's documented reason (slow records froze the board).
    var last by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(conn.method) {
        last = withContext(Dispatchers.IO) { lastMethod(context) }
    }
    val shown = method ?: last
    val shownApp = WidgetMethods.app(shown)

    val consent = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val m = last
        if (res.resultCode == Activity.RESULT_OK && m != null) WidgetConnectService.start(context, m, null)
    }
    val scope = rememberCoroutineScope()
    fun connectLast() {
        val m = last ?: return
        if (com.mlmvpn.scanner.data.ScanGuard.isScanBusy()) {
            android.widget.Toast.makeText(context, tr("یک اسکن در حال اجراست؛ اول آن را متوقف کنید", "A scan is running; stop it first"), android.widget.Toast.LENGTH_LONG).show()
            return
        }
        // VpnService.prepare off the main thread, as in the widget (it froze the home screen).
        scope.launch {
            val prep = withContext(Dispatchers.IO) { runCatching { VpnService.prepare(context) }.getOrNull() }
            if (prep != null) runCatching { consent.launch(prep) } else WidgetConnectService.start(context, m, null)
        }
    }

    val exitFrame = emberExitFrame(conn.country)
    val exitName = conn.country?.let { WidgetFormat.countryName(it) }.orEmpty()

    Box(modifier = modifier) {
        EmberMapBackground(
            modifier = Modifier.fillMaxSize(),
            mapAlpha = when {
                conn.up -> 1f
                conn.busy -> 0.9f
                else -> 0.75f
            },
            exitFrame = exitFrame,
            connected = conn.up,
            connecting = conn.busy,
        ) {
            // The samples' pin badges: home below its pin, the exit above its own; slate while
            // the tunnel is down, ember-lit while it is up.
            EmberMapBadge("HOME • IRAN", EmberMapData.HOME_X, EmberMapData.HOME_Y + 36f, dim = !conn.up)
            if (exitFrame != null && exitName.isNotBlank()) {
                EmberMapBadge(exitName, exitFrame.x, exitFrame.y - 64f, dim = !conn.up)
            }
        }

        // Top left: the brand panel, then the two pills under it (the samples' stack).
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 16.dp, top = LocalSystemTopPadding.current + 12.dp),
        ) {
            HeroBrandPanel()
            Spacer(Modifier.height(8.dp))
            HeroPill(onClick = {
                HomeDestinations.gridById("quick")?.let(onOpen)
            }) {
                Icon(
                    Icons.Filled.LocationOn,
                    contentDescription = null,
                    tint = Color(0xFFFF8A3D),
                    modifier = Modifier.size(12.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text("Locations", color = Color(0xFFE8EEF5), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(8.dp))
            HeroSubscriptionPill(onClick = {
                WidgetMethods.app("nodes")?.let(onOpen)
            })
        }

        // Top right: the engine stack.
        HeroChips(
            shownId = shown,
            conn = conn,
            onOpen = onOpen,
            onShowBoard = onShowBoard,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 16.dp, top = LocalSystemTopPadding.current + 12.dp),
        )

        // Bottom: shortcut tiles, the control bar, the footline.
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, bottom = LocalSystemBottomPadding.current + 8.dp),
        ) {
            HeroTiles(onOpen = onOpen)
            Spacer(Modifier.height(16.dp))
            HeroLiveBar(
                conn = conn,
                exitName = exitName,
                shownLabel = shownApp?.let { WidgetPainter.labelOf(it) },
                capsuleEnabled = conn.busy || last != null,
                onCapsule = {
                    if (conn.busy) WidgetConnect.disconnect(context) else connectLast()
                },
            )
        }
    }
}

/**
 * PERFORMANCE (upg5, 2026-11-12; clock fixed upg6, 2026-11-13): the control bar and the
 * footline are the only hero elements that tick once a second while connected (live rates +
 * session clock), so the live-traffic flow is collected HERE, in this leaf, and nowhere
 * higher. Before, HeroHome itself collected it: every traffic tick (the flow's `seq` moves
 * each tick, so its value is never equal) recomposed the whole hero, and the map background's
 * content lambda is recreated on every recomposition, so the ~3,000-dot Canvas redrew once a
 * second for the sake of two rate figures. Now the tick invalidates only this leaf; the map,
 * brand panel, pills and chips sit still until the connection state itself changes.
 *
 * The session clock is read HERE too, where it is displayed -- not passed in as a string
 * from HeroHome. Its tick is scoped inside [useSessionClock]: a caller that only passes the
 * returned string on never sees it move, because the state read lives in the clock function
 * and only that function recomposes. UPG5 left the clock call in HeroHome while the traffic
 * collection moved here, so the hero's Session clock froze at the value from the last HeroHome
 * recomposition (the connect moment); the traffic tick that used to refresh it no longer
 * reaches the parent. This leaf recomposes once a second on the traffic tick anyway, so
 * reading the clock here advances it once a second, exactly as before UPG5. Pixels identical;
 * the sampler's lifecycle is unchanged (still collected exactly while the hero is on screen).
 */
@Composable
private fun HeroLiveBar(
    conn: WidgetLive.Conn,
    exitName: String,
    shownLabel: String?,
    capsuleEnabled: Boolean,
    onCapsule: () -> Unit,
) {
    // Collected only while the hero is on screen: collecting is what keeps the sampler going.
    val traffic by WidgetLive.traffic.collectAsStateWithLifecycle()
    val clock = useSessionClock(conn.up, conn.since)
    HeroBar(
        conn = conn,
        clock = clock,
        exitName = exitName,
        shownLabel = shownLabel,
        rxRate = traffic.rxRate,
        txRate = traffic.txRate,
        capsuleEnabled = capsuleEnabled,
        onCapsule = onCapsule,
    )
    Spacer(Modifier.height(8.dp))
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Text(
            text = when {
                conn.up -> (shownLabel ?: "RALYSND").uppercase() +
                    " • SESSION " + clock
                conn.busy -> "CONNECTING" +
                    (shownLabel?.let { " • " + it.uppercase() } ?: "")
                else -> "DISCONNECTED"
            },
            color = Ember.TextFoot,
            fontSize = 8.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.9.sp,
            maxLines = 1,
        )
    }
}

/** The hero's floating brand panel: flame, wordmark, version (the samples' `.brand`). */
@Composable
private fun HeroBrandPanel() {
    Row(
        modifier = Modifier
            .height(56.dp)
            .emberGlass(Ember.ShapeBrand)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        EmberFlame(Modifier.size(26.dp))
        Spacer(Modifier.width(8.dp))
        Column {
            Text(
                "Ralysnd",
                color = Ember.TextHi,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.2.sp,
                maxLines = 1,
            )
            Text(
                "v" + BuildConfig.VERSION_NAME,
                color = Ember.TextFaint,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 0.8.sp,
                maxLines = 1,
            )
        }
    }
}

/** A hero pill (the samples' `.pill`): 30dp glass, an icon and a label, opening its surface. */
@Composable
private fun HeroPill(
    onClick: () -> Unit,
    content: @Composable () -> Unit,
) {
    Row(
        modifier = Modifier
            .height(30.dp)
            .emberGlass(Ember.ShapePill)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) { onClick() }
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

/**
 * The subscription pill: the nearest real expiry among the user's subscriptions, in the
 * samples' wording ("24 days left"), from the same manager the V2Ray tab reads. No expiry
 * anywhere -- a plain list of links, an unlimited plan -- and the pill carries no figure.
 */
@Composable
private fun HeroSubscriptionPill(onClick: () -> Unit) {
    val context = LocalContext.current
    val manager = remember { SubscriptionManager(context) }
    val subs by manager.subscriptionsFlow.collectAsState()
    val expireAt = subs.mapNotNull { it.usage?.expireAt }.minOrNull()
    val parts = expireAt?.let { timeLeftParts(it) }
    val daysText = when {
        expireAt == null -> null
        parts == null -> "Expired"
        else -> when (parts.second) {
            TimeLeftUnit.DAYS -> "${parts.first} days left"
            TimeLeftUnit.HOURS -> "${parts.first} hours left"
            TimeLeftUnit.MINUTES -> "${parts.first} min left"
        }
    }
    HeroPill(onClick = onClick) {
        DiamondGlyph(Modifier.size(12.dp))
        Spacer(Modifier.width(8.dp))
        Text("Subscription", color = Color(0xFFE8EEF5), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        if (daysText != null) {
            Spacer(Modifier.width(8.dp))
            Text(
                daysText,
                color = if (parts == null && expireAt != null) Ember.ErrText else Ember.EmberText,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                style = EmberTabular,
                maxLines = 1,
            )
        }
    }
}

/** The samples' faceted-diamond mark on the subscription pill, as a small canvas drawing. */
@Composable
private fun DiamondGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val stroke = Stroke(width = 1.6.dp.toPx())
        val outline = Path().apply {
            moveTo(w * 0.5f, h * 0.06f)
            lineTo(w * 0.94f, h * 0.5f)
            lineTo(w * 0.5f, h * 0.94f)
            lineTo(w * 0.06f, h * 0.5f)
            close()
        }
        drawPath(outline, Ember.EmberText, style = stroke)
        val facet = Ember.EmberText.copy(alpha = 0.55f)
        drawLine(facet, Offset(w * 0.06f, h * 0.5f), Offset(w * 0.94f, h * 0.5f), strokeWidth = 1.1.dp.toPx())
        drawLine(facet, Offset(w * 0.5f, h * 0.06f), Offset(w * 0.30f, h * 0.5f), strokeWidth = 1.1.dp.toPx())
        drawLine(facet, Offset(w * 0.30f, h * 0.5f), Offset(w * 0.5f, h * 0.94f), strokeWidth = 1.1.dp.toPx())
        drawLine(facet, Offset(w * 0.5f, h * 0.06f), Offset(w * 0.70f, h * 0.5f), strokeWidth = 1.1.dp.toPx())
        drawLine(facet, Offset(w * 0.70f, h * 0.5f), Offset(w * 0.5f, h * 0.94f), strokeWidth = 1.1.dp.toPx())
    }
}

/**
 * The engine stack (the samples' `.chips`): the method in use lit ember with an ACTIVE badge,
 * the last method READY, the other leads IDLE, and the "+N Engines" chip that opens the board.
 * The four leads are the samples' own -- V2Ray, WireGuard, WARP, Psiphon -- with the current
 * method added at the head when it is a different one, so the stack never hides what is running.
 */
@Composable
private fun HeroChips(
    shownId: String?,
    conn: WidgetLive.Conn,
    onOpen: (HomeApp) -> Unit,
    onShowBoard: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val allMethods = remember { WidgetMethods.all() }
    val chipApps = remember(shownId) {
        val leads = listOf("nodes", "wireguard", "warp", "psiphon")
        val ids = buildList {
            if (shownId != null && shownId !in leads) add(shownId)
            addAll(leads)
        }
        ids.mapNotNull { WidgetMethods.app(it) }
    }
    val moreCount = (allMethods.size - chipApps.size).coerceAtLeast(0)

    Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        chipApps.forEach { app ->
            val (badge, kind, lit) = when {
                conn.up && conn.method == app.id -> Triple("ACTIVE", EmberTagKind.Ember, true)
                conn.busy && conn.method == app.id -> Triple("CONNECTING", EmberTagKind.Line, true)
                shownId == app.id -> Triple("READY", EmberTagKind.Line, false)
                else -> Triple("IDLE", EmberTagKind.Plain, false)
            }
            HeroChip(app = app, badge = badge, kind = kind, lit = lit, onClick = { onOpen(app) })
        }
        // The way to everything else: the board, with its full registry of destinations.
        Row(
            modifier = Modifier
                .width(130.dp)
                .height(32.dp)
                .emberGlass(Ember.ShapeChip, soft = true)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                ) { onShowBoard() }
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Text("Engines", color = Color(0xFF9DB2C9), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.width(8.dp))
            Text(
                "+$moreCount",
                color = Ember.EmberText,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                style = EmberTabular,
            )
            Icon(
                Icons.Filled.ExpandMore,
                contentDescription = null,
                tint = Ember.TextDim,
                modifier = Modifier.size(12.dp),
            )
        }
    }
}

/** One engine chip (the samples' `.chip`): status dot, the method's own name, its badge. */
@Composable
private fun HeroChip(
    app: HomeApp,
    badge: String,
    kind: EmberTagKind,
    lit: Boolean,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .width(130.dp)
            .height(32.dp)
            .then(
                if (lit) Modifier.shadow(
                    elevation = 9.dp,
                    shape = Ember.ShapeChip,
                    clip = false,
                    ambientColor = Ember.Ember.copy(alpha = 0.30f),
                    spotColor = Ember.Ember.copy(alpha = 0.30f),
                ) else Modifier
            )
            .clip(Ember.ShapeChip)
            .background(if (lit) Ember.ChipOnBrush else Ember.SoftBrush)
            .border(
                1.dp,
                if (lit) Color(0xFFFF8533).copy(alpha = 0.8f) else Ember.SoftBorder,
                Ember.ShapeChip,
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
            ) { onClick() }
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(5.dp)
                .clip(CircleShape)
                .background(if (lit) Ember.EmberHi else Ember.DotSlate),
        )
        Spacer(Modifier.width(8.dp))
        Text(
            stringResource(app.labelRes),
            color = if (lit) Ember.TextHi else Ember.TextMuted,
            fontSize = 11.sp,
            fontWeight = if (lit) FontWeight.Bold else FontWeight.SemiBold,
            letterSpacing = 0.2.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        EmberTag(badge, kind)
    }
}

/**
 * The four shortcut tiles over the bar (the samples' `.tiles`): Quick Connect, Free Config,
 * Cloud and Game Boost -- real destinations all, wearing the samples' glyphs and the app's
 * own names.
 */
@Composable
private fun HeroTiles(onOpen: (HomeApp) -> Unit) {
    val tiles: List<Pair<HomeApp, ImageVector>> = remember {
        listOfNotNull(
            HomeDestinations.gridById("quick")?.let { it to Icons.Filled.FlashOn },
            HomeDestinations.gridById("freeconfig")?.let { it to Icons.Filled.Layers },
            HomeDestinations.DOCK.firstOrNull { it.id == "cloud" }?.let { it to Icons.Filled.Cloud },
            HomeDestinations.gridById("game")?.let { it to Icons.Filled.SportsEsports },
        )
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        tiles.forEach { (app, glyph) ->
            Column(
                modifier = Modifier
                    .weight(1f)
                    .height(68.dp)
                    .emberGlass(Ember.ShapeTile)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { onOpen(app) }
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically),
            ) {
                EmberIconBox(glyph, size = 30.dp)
                Text(
                    stringResource(app.labelRes),
                    color = Ember.TextLabel,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

/**
 * The wide floating control bar (the samples' `.bar`): the connect capsule, a hairline, and
 * the telemetry grid -- Location / Session over Up / Down while the tunnel is up, the same
 * grid dimmed with Method / Status while it is down.
 */
@Composable
private fun HeroBar(
    conn: WidgetLive.Conn,
    clock: String,
    exitName: String,
    shownLabel: String?,
    rxRate: Long,
    txRate: Long,
    capsuleEnabled: Boolean,
    onCapsule: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(88.dp)
            .emberGlass(Ember.ShapeBar)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        EmberCapsule(
            state = when {
                conn.up -> 2
                conn.busy -> 1
                else -> 0
            },
            label = when {
                conn.up -> tr("قطع", "Disconnect")
                conn.busy -> tr("لغو", "Cancel")
                else -> tr("اتصال سریع", "Quick Connect")
            },
            enabled = capsuleEnabled,
            onClick = onCapsule,
        )
        Spacer(Modifier.width(12.dp))
        Box(
            Modifier
                .width(1.dp)
                .height(48.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color(0xFF27405C), Color.Transparent),
                    ),
                ),
        )
        Spacer(Modifier.width(12.dp))
        when {
            conn.up -> Column(modifier = Modifier.weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    EmberTelemetryCell("Location", exitName.ifBlank { "—" }, modifier = Modifier.weight(1.3f))
                    EmberTelemetryCell("Session", clock, modifier = Modifier.weight(0.7f))
                }
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    EmberTelemetryCell("↑ Up", WidgetFormat.rate(txRate), modifier = Modifier.weight(1.3f))
                    EmberTelemetryCell("↓ Down", WidgetFormat.rate(rxRate), modifier = Modifier.weight(0.7f))
                }
            }
            conn.busy -> Text(
                tr("در حال برقراری اتصال…", "Connecting…"),
                color = Ember.EmberText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f),
            )
            else -> Column(modifier = Modifier.weight(1f)) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    EmberTelemetryCell("Method", shownLabel ?: "—", modifier = Modifier.weight(1.3f), dim = true)
                    EmberTelemetryCell("Status", "Disconnected", modifier = Modifier.weight(0.7f), dim = true)
                }
                Spacer(Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    EmberTelemetryCell("↑ Up", WidgetFormat.rate(txRate), modifier = Modifier.weight(1.3f), dim = true)
                    EmberTelemetryCell("↓ Down", WidgetFormat.rate(rxRate), modifier = Modifier.weight(0.7f), dim = true)
                }
            }
        }
    }
}
