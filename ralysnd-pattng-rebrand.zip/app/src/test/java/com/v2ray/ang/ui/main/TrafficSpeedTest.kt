package com.v2ray.ang.ui.main

import com.v2ray.ang.AppConfig
import com.v2ray.ang.dto.OutboundTrafficStat
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class TrafficSpeedTest {

    private fun stat(tag: String, direction: String, value: Long) =
        OutboundTrafficStat(tag = tag, direction = direction, value = value)

    @Test
    fun proxyTrafficIsSummedAndDividedByTheInterval() {
        val stats = listOf(
            stat("proxy", AppConfig.UPLINK, 3000L),
            stat("proxy", AppConfig.DOWNLINK, 9000L),
            stat("proxy-2", AppConfig.UPLINK, 3000L),
        )
        val speed = computeProxySpeed(stats, intervalSeconds = 3.0)
        assertEquals(2000.0, speed.upBps, 0.001)
        assertEquals(3000.0, speed.downBps, 0.001)
    }

    @Test
    fun directBlockedAndExitNodeTrafficIsExcluded() {
        val stats = listOf(
            stat(AppConfig.TAG_DIRECT, AppConfig.UPLINK, 6000L),
            stat(AppConfig.TAG_BLOCKED, AppConfig.DOWNLINK, 6000L),
            stat(AppConfig.TAG_EXIT_NODE, AppConfig.UPLINK, 6000L),
            stat(AppConfig.TAG_EXIT_NODE, AppConfig.DOWNLINK, 6000L),
            stat("proxy", AppConfig.UPLINK, 3000L),
        )
        val speed = computeProxySpeed(stats, intervalSeconds = 3.0)
        assertEquals(1000.0, speed.upBps, 0.001)
        assertEquals(0.0, speed.downBps, 0.001)
    }

    @Test
    fun emptyStatsGiveZeroSpeed() {
        assertEquals(TrafficSpeed(), computeProxySpeed(emptyList(), intervalSeconds = 3.0))
    }

    @Test
    fun zeroOrNegativeIntervalGivesZeroSpeed() {
        val stats = listOf(stat("proxy", AppConfig.UPLINK, 3000L))
        assertEquals(TrafficSpeed(), computeProxySpeed(stats, intervalSeconds = 0.0))
        assertEquals(TrafficSpeed(), computeProxySpeed(stats, intervalSeconds = -1.0))
    }

    @Test
    fun unknownDirectionIsIgnored() {
        val stats = listOf(
            stat("proxy", "sideways", 9000L),
            stat("proxy", AppConfig.DOWNLINK, 3000L),
        )
        val speed = computeProxySpeed(stats, intervalSeconds = 3.0)
        assertEquals(0.0, speed.upBps, 0.001)
        assertEquals(1000.0, speed.downBps, 0.001)
    }
}
