package com.tamasha.tv;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class Channel {
    public final long id;
    public final int categoryId;
    public final String name;
    public final String nameEn;
    public final String category;
    public final String categoryEn;
    public final boolean needVpn;
    public final long popular;
    public final List<Source> sources = new ArrayList<>();
    public final Source main;
    public final String logoUrl;

    public Channel(long id, int categoryId, String name, String nameEn, String category,
                   String categoryEn, boolean needVpn, long popular, Source main, String logoUrl) {
        this.id = id;
        this.categoryId = categoryId;
        this.name = name == null ? "" : name;
        this.nameEn = nameEn == null ? "" : nameEn;
        this.category = category == null ? "" : category;
        this.categoryEn = categoryEn == null ? "" : categoryEn;
        this.needVpn = needVpn;
        this.popular = popular;
        this.main = main;
        this.logoUrl = logoUrl == null ? "" : logoUrl;
    }

    public static final class Source {
        public final String title;
        public final String url;
        public final String referer;
        public final String origin;
        public final String agent;
        public final Map<String, String> headers = new HashMap<>();
        public final String country;

        public Source(String title, String url, String referer, String origin, String agent,
                      Map<String, String> headers, String country) {
            this.title = title == null || title.trim().isEmpty() ? "Source" : title;
            this.url = url == null ? "" : url;
            this.referer = referer == null ? "" : referer;
            this.origin = origin == null ? "" : origin;
            this.agent = agent == null ? "" : agent;
            this.country = country == null ? "" : country;
            if (headers != null) this.headers.putAll(headers);
        }
    }

    private static Map<String, String> parseHeaders(Object raw, String referer, String origin, String agent) {
        Map<String, String> map = new HashMap<>();
        if (referer != null && !referer.isEmpty()) map.put("Referer", referer);
        if (origin != null && !origin.isEmpty()) map.put("Origin", origin);
        if (agent != null && !agent.isEmpty()) map.put("User-Agent", agent);
        if (raw instanceof JSONObject) {
            JSONObject o = (JSONObject) raw;
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String k = it.next();
                String v = o.optString(k, "");
                if (!k.isEmpty() && !v.isEmpty()) map.put(k, v);
            }
        }
        return map;
    }

    public static List<Channel> loadAll(Context ctx) {
        List<Channel> out = new ArrayList<>();
        try {
            InputStream is = ctx.getAssets().open("channels.json");
            StringBuilder sb = new StringBuilder();
            BufferedReader r = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            JSONObject root = new JSONObject(sb.toString());
            JSONArray posts = root.getJSONArray("posts");
            for (int i = 0; i < posts.length(); i++) {
                JSONObject p = posts.getJSONObject(i);
                Source main = new Source("Main", p.optString("channel_url", ""),
                        p.optString("channel_referer", ""), p.optString("channel_origin", ""),
                        p.optString("channel_agent", ""),
                        parseHeaders(p.opt("channel_headers"), p.optString("channel_referer", ""),
                                p.optString("channel_origin", ""), p.optString("channel_agent", "")),
                        "iran");
                Channel ch = new Channel(p.optLong("channel_id"), p.optInt("category_id"),
                        p.optString("channel_name", null), p.optString("channel_name_en", null),
                        p.optString("category_name", null), p.optString("category_name_en", null),
                        p.optInt("need_vpn", 0) == 1, optLong(p.optString("popular", "0")), main,
                        p.optString("channel_image", ""));
                ch.sources.add(main);
                JSONArray ss = p.optJSONArray("sourses");
                if (ss != null) {
                    for (int j = 0; j < ss.length(); j++) {
                        JSONObject s = ss.getJSONObject(j);
                        if (s.optString("channel_url", "").isEmpty()) continue;
                        ch.sources.add(new Source(s.optString("title", "Source"),
                                s.optString("channel_url", ""), s.optString("channel_referer", ""),
                                s.optString("channel_origin", ""), "",
                                parseHeaders(s.opt("channel_headers"), s.optString("channel_referer", ""),
                                        s.optString("channel_origin", ""), ""),
                                s.optString("country", "")));
                    }
                }
                out.add(ch);
            }
        } catch (Exception ignored) {
        }
        Collections.sort(out, new Comparator<Channel>() {
            @Override public int compare(Channel a, Channel b) { return Long.compare(b.popular, a.popular); }
        });
        return out;
    }

    private static long optLong(String s) {
        try { return Long.parseLong(s.trim()); } catch (Exception e) { return 0; }
    }
}
