package com.tamasha.tv;

import android.content.Context;
import android.graphics.Typeface;
import android.widget.TextView;

/**
 * Vazirmatn (bundled in assets/fonts) applied to TextViews.
 * Falls back to the system font if a bundled font is missing.
 */
public final class Fonts {
    private Fonts() {}

    private static Typeface regular;
    private static Typeface bold;

    public static Typeface regular(Context ctx) {
        if (regular == null) {
            try { regular = Typeface.createFromAsset(ctx.getAssets(), "fonts/vazirmatn_regular.ttf"); }
            catch (Exception e) { regular = Typeface.DEFAULT; }
        }
        return regular;
    }

    public static Typeface bold(Context ctx) {
        if (bold == null) {
            try { bold = Typeface.createFromAsset(ctx.getAssets(), "fonts/vazirmatn_bold.ttf"); }
            catch (Exception e) { bold = Typeface.DEFAULT_BOLD; }
        }
        return bold;
    }

    /** Regular weight. */
    public static void set(TextView tv) {
        if (tv != null) tv.setTypeface(regular(tv.getContext()));
    }

    /** Bold weight. */
    public static void setBold(TextView tv) {
        if (tv != null) tv.setTypeface(bold(tv.getContext()));
    }
}
