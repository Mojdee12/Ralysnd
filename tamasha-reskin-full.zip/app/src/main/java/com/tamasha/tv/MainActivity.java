package com.tamasha.tv;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends android.app.Activity {

    private ChannelAdapter gridAdapter;
    private TabAdapter tabAdapter;
    private RecyclerView grid, tabs;
    private List<List<Channel>> groups;
    private List<String> labels;
    private TextView gridEmpty;
    private int selectedTab = 0;
    private Repo repo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        repo = Repo.get(this);
        if (repo.all.isEmpty()) {
            Toast.makeText(this, getString(R.string.lbl_load_error), Toast.LENGTH_LONG).show();
        }

        gridEmpty = findViewById(R.id.grid_empty);
        Fonts.setBold((TextView) findViewById(R.id.brand_text));
        Fonts.set((TextView) findViewById(R.id.clock));

        // Grid — 5 columns on typical 1080p TV
        grid = findViewById(R.id.grid);
        GridLayoutManager glm = new GridLayoutManager(this, 5);
        grid.setLayoutManager(glm);
        grid.setItemAnimator(null);
        grid.setHasFixedSize(true);
        gridAdapter = new ChannelAdapter(repo.all, c -> open(c));
        grid.setAdapter(gridAdapter);

        // Tabs
        tabs = findViewById(R.id.tabs);
        tabs.setLayoutManager(new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false));
        tabs.setItemAnimator(null);
        tabAdapter = new TabAdapter(null, (name, index) -> {
            selectedTab = index;
            tabAdapter.setSelected(index);
            gridAdapter.setItems(groups.get(index));
            grid.scrollToPosition(0);
            tabs.scrollToPosition(index);
            updateEmpty();
        });
        tabs.setAdapter(tabAdapter);

        buildTabs();

        // Search button
        findViewById(R.id.btn_search).setOnClickListener(v ->
                startActivity(new Intent(this, SearchActivity.class)));

        // Set initial focus to the grid (retry once if the first item is not laid out yet)
        focusGridSoon();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Favorites may have changed while in the player — rebuild the tab list.
        buildTabs();
    }

    /** Build tab list: ALL + FAVORITES (if any) + each category. Preserves the selected tab. */
    private void buildTabs() {
        labels = new ArrayList<>();
        groups = new ArrayList<>();

        labels.add(getString(R.string.tab_live));
        groups.add(repo.all);

        List<Channel> favs = new ArrayList<>();
        for (Channel c : repo.all) if (FavStore.get(this).isFav(c)) favs.add(c);
        if (!favs.isEmpty()) {
            labels.add(getString(R.string.tab_fav));
            groups.add(favs);
        }

        for (Repo.Category cat : repo.categories) {
            if (!cat.channels.isEmpty()) {
                String lbl = TabAdapter.shortLabel(cat.nameEn.isEmpty() ? cat.name : cat.nameEn);
                if (lbl.isEmpty()) lbl = "CAT";
                labels.add(lbl);
                groups.add(cat.channels);
            }
        }

        if (selectedTab >= labels.size()) selectedTab = 0;
        tabAdapter.setLabels(labels);
        tabAdapter.setSelected(selectedTab);
        gridAdapter.setItems(groups.get(selectedTab));
        tabs.scrollToPosition(selectedTab);
        updateEmpty();
    }

    private void updateEmpty() {
        if (groups == null || groups.isEmpty() || gridEmpty == null) return;
        List<Channel> cur = groups.get(selectedTab);
        if (cur == null || cur.isEmpty()) {
            boolean favTab = getString(R.string.tab_fav).equals(labels.get(selectedTab));
            gridEmpty.setText(favTab ? R.string.empty_fav : R.string.empty_none);
            gridEmpty.setVisibility(View.VISIBLE);
        } else {
            gridEmpty.setVisibility(View.GONE);
        }
    }

    private void focusGridSoon() {
        grid.post(() -> {
            RecyclerView.ViewHolder vh = grid.findViewHolderForAdapterPosition(0);
            if (vh != null) { vh.itemView.requestFocus(); return; }
            grid.postDelayed(() -> {
                RecyclerView.ViewHolder h2 = grid.findViewHolderForAdapterPosition(0);
                if (h2 != null) h2.itemView.requestFocus();
            }, 150);
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void open(Channel c) {
        Intent it = new Intent(this, PlayerActivity.class);
        it.putExtra("channel_id", c.id);
        startActivity(it);
    }
}
