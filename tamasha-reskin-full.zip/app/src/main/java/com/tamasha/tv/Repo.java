package com.tamasha.tv;

import android.content.Context;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Repo {
    private static Repo instance;
    public final List<Channel> all;
    public final List<Category> categories;

    public static final class Category {
        public final int id;
        public final String name;
        public final String nameEn;
        public final List<Channel> channels = new ArrayList<>();
        public Category(int id, String name, String nameEn) { this.id = id; this.name = name; this.nameEn = nameEn; }
    }

    private Repo(Context ctx) {
        all = Channel.loadAll(ctx.getApplicationContext());
        Map<Integer, Category> byId = new LinkedHashMap<>();
        for (Channel c : all) {
            Category cat = byId.get(c.categoryId);
            if (cat == null) { cat = new Category(c.categoryId, c.category, c.categoryEn); byId.put(c.categoryId, cat); }
            cat.channels.add(c);
        }
        categories = new ArrayList<>(byId.values());
    }

    public static synchronized Repo get(Context ctx) {
        if (instance == null) instance = new Repo(ctx);
        return instance;
    }

    public int indexOf(Channel c) { return all.indexOf(c); }

    public Channel byId(long id) {
        for (Channel c : all) if (c.id == id) return c;
        return null;
    }
}
