package com.tamasha.tv;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SearchActivity extends android.app.Activity {

    private ResultAdapter adapter;
    private TextView emptyView;
    private Repo repo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        repo = Repo.get(this);

        RecyclerView rv = findViewById(R.id.search_results);
        emptyView = findViewById(R.id.search_empty);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ResultAdapter(c -> open(c));
        rv.setAdapter(adapter);

        EditText input = findViewById(R.id.search_input);
        Fonts.set(input);
        Fonts.set(emptyView);
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int i, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int i, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { filter(s.toString()); }
        });
        input.requestFocus();
    }

    private void filter(String q) {
        String query = q.trim().toLowerCase(Locale.US);
        List<Channel> results = new ArrayList<>();
        if (query.isEmpty()) {
            adapter.setItems(results);
            emptyView.setText(R.string.search_hint_empty);
            emptyView.setVisibility(View.VISIBLE);
            return;
        }
        for (Channel c : repo.all) {
            String n  = c.name.toLowerCase(Locale.US);
            String ne = c.nameEn.toLowerCase(Locale.US);
            if (n.contains(query) || ne.contains(query)) results.add(c);
        }
        adapter.setItems(results);
        if (results.isEmpty()) {
            emptyView.setText(R.string.no_results);
            emptyView.setVisibility(View.VISIBLE);
        } else {
            emptyView.setVisibility(View.GONE);
        }
    }

    private void open(Channel c) {
        Intent it = new Intent(this, PlayerActivity.class);
        it.putExtra("channel_id", c.id);
        startActivity(it);
    }

    // ---- inner adapter ----
    private static final class ResultAdapter extends RecyclerView.Adapter<ResultAdapter.VH> {
        interface OnPick { void onPick(Channel c); }
        private final List<Channel> items = new ArrayList<>();
        private final OnPick listener;

        ResultAdapter(OnPick l) { listener = l; }

        void setItems(List<Channel> next) {
            items.clear();
            if (next != null) items.addAll(next);
            notifyDataSetChanged();
        }

        @NonNull @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_result, parent, false);
            return new VH(v, listener, items);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int pos) { h.bind(items.get(pos)); }

        @Override public int getItemCount() { return items.size(); }

        static final class VH extends RecyclerView.ViewHolder {
            final ImageView logo;
            final TextView ini, name, cat, vpn;
            final List<Channel> items;
            final OnPick listener;

            VH(@NonNull View v, OnPick l, List<Channel> items) {
                super(v);
                this.listener = l;
                this.items    = items;
                logo  = v.findViewById(R.id.res_logo);
                ini   = v.findViewById(R.id.res_initial);
                name  = v.findViewById(R.id.res_name);
                cat   = v.findViewById(R.id.res_cat);
                vpn   = v.findViewById(R.id.res_vpn);
                Fonts.setBold(name);
                Fonts.set(ini);
                Fonts.set(cat);

                v.setOnClickListener(view -> {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) listener.onPick(items.get(pos));
                });
            }

            void bind(Channel c) {
                String n = ChannelAdapter.displayName(c);
                ini.setText(ChannelAdapter.initial(c));
                name.setText(n);
                String catStr = c.categoryEn.isEmpty() ? c.category : c.categoryEn;
                cat.setText(catStr.toUpperCase(Locale.US));
                vpn.setVisibility(c.needVpn ? View.VISIBLE : View.GONE);
                Logos.load(logo, ini, c.logoUrl);
            }
        }
    }
}
