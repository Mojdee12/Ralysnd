package com.tamasha.tv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public final class SourceAdapter extends RecyclerView.Adapter<SourceAdapter.VH> {

    public interface OnSource { void onSource(int index); }

    private final List<Channel.Source> items = new ArrayList<>();
    private final OnSource listener;
    private int active = 0;

    public SourceAdapter(List<Channel.Source> items, OnSource listener) {
        if (items != null) this.items.addAll(items);
        this.listener = listener;
    }

    public void setItems(List<Channel.Source> next) {
        items.clear();
        if (next != null) items.addAll(next);
        notifyDataSetChanged();
    }

    public void setSelected(int index) {
        int old = active;
        active = index;
        notifyItemChanged(old);
        notifyItemChanged(index);
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_source, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        h.bind(items.get(position), position == active, position, listener);
    }

    @Override
    public int getItemCount() { return items.size(); }

    static final class VH extends RecyclerView.ViewHolder {
        final TextView title, activeTag;

        VH(@NonNull View v) {
            super(v);
            title     = v.findViewById(R.id.src_title);
            activeTag = v.findViewById(R.id.src_active);
            Fonts.set(title);
        }

        void bind(Channel.Source s, boolean isActive, int pos, OnSource listener) {
            String label = "Source " + (pos + 1);
            if (s.title != null && !s.title.isEmpty() && !s.title.equals("Source")) {
                label = s.title;
            }
            if (!s.country.isEmpty()) label += "  [" + s.country.toUpperCase() + "]";
            title.setText(label);
            activeTag.setVisibility(isActive ? View.VISIBLE : View.GONE);
            itemView.setOnClickListener(v -> listener.onSource(pos));
        }
    }
}
