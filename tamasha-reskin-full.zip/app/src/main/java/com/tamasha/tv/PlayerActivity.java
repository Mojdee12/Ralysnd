package com.tamasha.tv;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale;

public class PlayerActivity extends Activity implements Player.Listener {

    // How long the overlay stays visible after last interaction
    private static final long OVERLAY_TIMEOUT = 3500L;
    // How long the channel-switch banner stays
    private static final long BANNER_TIMEOUT = 1800L;
    // Delay before trying next source after error
    private static final long SOURCE_RETRY_DELAY = 500L;

    // ---- player ----
    private ExoPlayer player;

    // ---- data ----
    private Repo repo;
    private List<Channel> navList;
    private int navIndex;
    private Channel current;
    private int sourceIndex = 0;
    private int failCount   = 0;        // consecutive source failures this channel

    // ---- views ----
    private PlayerView playerView;
    private View bufferSpinner, overlay, banner, sourcesSheet;
    private TextView pName, pStatus, pCount, pFav, pSource;
    private TextView pBannerLetter, pBannerName, pBannerMeta;
    private ImageView pBannerLogo;
    private TextView pChannelLabel;
    private RecyclerView sourcesList;
    private SourceAdapter sourceAdapter;
    private RecyclerView pList;
    private PlayerChannelAdapter pListAdapter;
    private TextView pPlay, pRew, pFwd, pVolDown, pVolUp, pSourcesBtn;
    private AudioManager audio;

    // ---- UI thread ----
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable rHideOverlay = this::hideOverlay;
    private final Runnable rHideBanner  = this::hideBanner;
    private final Runnable rNextSource  = this::nextSource;

    // ============================================================
    //  Lifecycle
    // ============================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);

        repo = Repo.get(this);
        long id = getIntent().getLongExtra("channel_id", -1);
        current = repo.byId(id);
        if (current == null) { finish(); return; }

        navList  = findNavList(current);
        navIndex = navList.indexOf(current);
        if (navIndex < 0) navIndex = 0;

        // ---- bind views ----
        playerView     = findViewById(R.id.player_view);
        bufferSpinner  = findViewById(R.id.p_buffer);
        overlay        = findViewById(R.id.overlay);
        banner         = findViewById(R.id.p_banner);
        sourcesSheet   = findViewById(R.id.sources_sheet);
        pName          = findViewById(R.id.p_name);
        pStatus        = findViewById(R.id.p_status);
        pCount         = findViewById(R.id.p_count);
        pFav           = findViewById(R.id.p_fav);
        pSource        = findViewById(R.id.p_source);
        pBannerLetter  = findViewById(R.id.p_banner_letter);
        pBannerName    = findViewById(R.id.p_banner_name);
        pBannerMeta    = findViewById(R.id.p_banner_meta);
        pChannelLabel  = findViewById(R.id.p_channel_label);
        sourcesList    = findViewById(R.id.sources_list);
        pList          = findViewById(R.id.p_list);
        pBannerLogo    = findViewById(R.id.p_banner_logo);
        pPlay          = findViewById(R.id.p_play);
        pRew           = findViewById(R.id.p_rew);
        pFwd           = findViewById(R.id.p_fwd);
        pVolDown       = findViewById(R.id.p_vol_down);
        pVolUp         = findViewById(R.id.p_vol_up);
        pSourcesBtn    = findViewById(R.id.p_sources_btn);
        audio          = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        Fonts.setBold(pName);
        Fonts.set(pStatus);
        Fonts.set(pCount);
        Fonts.set(pSource);
        Fonts.setBold(pBannerName);
        Fonts.set(pBannerMeta);
        Fonts.set(pChannelLabel);

        playerView.setUseController(false);
        // Fill the screen for 4:3 streams instead of letterboxing.
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_ZOOM);

        // ---- source adapter ----
        sourceAdapter = new SourceAdapter(null, idx -> {
            sourceIndex = idx;
            failCount   = 0;
            closeSheet();
            loadSource();
        });
        sourcesList.setLayoutManager(new LinearLayoutManager(this));
        sourcesList.setAdapter(sourceAdapter);

        // ---- channel list (right side of the split layout) ----
        pListAdapter = new PlayerChannelAdapter(navList, pos -> switchTo(pos));
        pList.setLayoutManager(new LinearLayoutManager(this));
        pList.setAdapter(pListAdapter);

        // ---- back button ----
        findViewById(R.id.p_back).setOnClickListener(v -> finish());

        // ---- fav button ----
        pFav.setOnClickListener(v -> {
            FavStore.get(this).toggle(this, current);
            updateFav();
            showOverlay();
        });

        // ---- bottom control bar ----
        pPlay.setOnClickListener(v -> { togglePlayPause(); showOverlay(); });
        pRew.setOnClickListener(v -> { seekBy(-10_000); showOverlay(); });
        pFwd.setOnClickListener(v -> { seekBy(10_000); showOverlay(); });
        pVolDown.setOnClickListener(v -> { adjustVolume(-1); showOverlay(); });
        pVolUp.setOnClickListener(v -> { adjustVolume(1); showOverlay(); });
        pSourcesBtn.setOnClickListener(v -> openSheet());

        // ---- close sheet button ----
        View sheetClose = findViewById(R.id.p_sheet_close);
        if (sheetClose != null) sheetClose.setOnClickListener(v -> closeSheet());

        // ---- build player (once; never rebuilt) ----
        DefaultLoadControl lc = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(15_000, 50_000, 1500, 2500)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build();
        player = new ExoPlayer.Builder(this).setLoadControl(lc).build();
        player.addListener(this);
        playerView.setPlayer(player);

        // ---- initial load ----
        refreshUI();
        loadSource();
        showOverlay();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (player != null) player.setPlayWhenReady(true);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) player.setPlayWhenReady(false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
        if (player != null) {
            player.removeListener(this);
            player.release();
            player = null;
        }
    }

    // ============================================================
    //  Channel / source loading
    // ============================================================

    /** Update all overlay text for the current channel + source index. */
    private void refreshUI() {
        String n   = displayName(current);
        String cat = (current.categoryEn.isEmpty() ? current.category : current.categoryEn)
                .toUpperCase(Locale.US);
        String ch  = "CH " + (navIndex + 1) + "/" + navList.size();

        pName.setText(n);
        pCount.setText(ch);
        pSource.setText("SOURCE " + (sourceIndex + 1) + "/" + current.sources.size()
                + (current.needVpn ? "  ·  VPN" : ""));
        pChannelLabel.setText(n + "  ·  " + cat);

        pBannerLetter.setText(initial(current));
        pBannerName.setText(n);
        pBannerMeta.setText(ch + (current.needVpn ? "  ·  VPN" : ""));
        Logos.load(pBannerLogo, pBannerLetter, current.logoUrl);

        updateFav();
        updatePlayBtn();
        sourceAdapter.setItems(current.sources);
        sourceAdapter.setSelected(sourceIndex);
        if (pListAdapter != null) {
            pListAdapter.setSelected(navIndex);
            pList.scrollToPosition(navIndex);
        }
    }

    private void updateFav() {
        boolean fav = FavStore.get(this).isFav(current);
        pFav.setText(fav ? "★" : "☆");
        pFav.setTextColor(ContextCompat.getColor(this,
                fav ? R.color.accent : R.color.text_dim));
    }

    /** Switch to the channel at navList position pos (used by the player list). */
    private void switchTo(int pos) {
        if (navList.isEmpty() || pos < 0 || pos >= navList.size()) return;
        navIndex    = pos;
        current     = navList.get(navIndex);
        sourceIndex = 0;
        failCount   = 0;
        refreshUI();
        showBanner();
        loadSource();
    }

    private void togglePlayPause() {
        if (player == null) return;
        boolean playing = player.getPlayWhenReady();
        player.setPlayWhenReady(!playing);
        setStatus(getString(playing ? R.string.st_paused : R.string.st_live));
        bufferSpinner.setVisibility(View.GONE);
        updatePlayBtn();
    }

    private void seekBy(long ms) {
        if (player == null) return;
        long pos = Math.max(0, player.getCurrentPosition() + ms);
        player.seekTo(pos);
    }

    private void adjustVolume(int direction) {
        if (audio == null) return;
        audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                direction > 0 ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI);
    }

    private void updatePlayBtn() {
        if (pPlay == null) return;
        boolean playing = player != null && player.getPlayWhenReady();
        pPlay.setText(playing ? "⏸" : "▶");
    }

    /** Move D-pad focus into the channel list at the current row. */
    private void focusPlayerList() {
        if (pList == null) return;
        pList.scrollToPosition(navIndex);
        pList.post(() -> {
            RecyclerView.ViewHolder h = pList.findViewHolderForAdapterPosition(navIndex);
            if (h != null) h.itemView.requestFocus();
            else pList.requestFocus();
        });
    }

    /** Load current source into ExoPlayer. */
    private void loadSource() {
        if (current.sources.isEmpty()) {
            setStatus(getString(R.string.st_none));
            return;
        }
        ui.removeCallbacks(rNextSource);
        if (sourceIndex >= current.sources.size()) sourceIndex = 0;

        Channel.Source s = current.sources.get(sourceIndex);
        setStatus(getString(R.string.st_connecting));
        bufferSpinner.setVisibility(View.VISIBLE);

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(8000)
                .setReadTimeoutMs(8000)
                .setDefaultRequestProperties(s.headers);
        if (!s.agent.isEmpty()) http.setUserAgent(s.agent);

        String url = s.url.trim();
        if (url.isEmpty()) { nextSource(); return; }

        MediaItem item = MediaItem.fromUri(url);
        boolean isHls  = url.contains(".m3u8") || url.contains(".m3u");
        MediaSource ms = isHls
                ? new HlsMediaSource.Factory(http).createMediaSource(item)
                : new ProgressiveMediaSource.Factory(http).createMediaSource(item);

        player.stop();
        player.setMediaSource(ms);
        player.prepare();
        player.setPlayWhenReady(true);

        refreshUI();
    }

    /** Move to next source; if all exhausted, show error. */
    private void nextSource() {
        failCount++;
        if (failCount >= current.sources.size()) {
            setStatus(getString(R.string.st_none));
            showBanner();
            return;
        }
        sourceIndex = (sourceIndex + 1) % current.sources.size();
        setStatus(getString(R.string.st_switching));
        loadSource();
    }

    /** Navigate channels: delta = -1 (up) or +1 (down). */
    private void switchChannel(int delta) {
        if (navList.isEmpty()) return;
        navIndex    = (navIndex + delta + navList.size()) % navList.size();
        current     = navList.get(navIndex);
        sourceIndex = 0;
        failCount   = 0;
        refreshUI();
        showBanner();
        loadSource();
    }

    // ============================================================
    //  Overlay / banner animations
    // ============================================================

    private void showOverlay() {
        overlay.animate().cancel();
        overlay.animate().alpha(1f).setDuration(180).start();
        ui.removeCallbacks(rHideOverlay);
        ui.postDelayed(rHideOverlay, OVERLAY_TIMEOUT);
    }

    private void hideOverlay() {
        overlay.animate().cancel();
        overlay.animate().alpha(0f).setDuration(300).start();
        // No invisible focus: drop focus out of the channel list when the overlay hides.
        if (pList != null && pList.hasFocus()) pList.clearFocus();
    }

    private void showBanner() {
        banner.animate().cancel();
        banner.setAlpha(1f);
        ui.removeCallbacks(rHideBanner);
        ui.postDelayed(rHideBanner, BANNER_TIMEOUT);
    }

    private void hideBanner() {
        banner.animate().cancel();
        banner.animate().alpha(0f).setDuration(250).start();
    }

    private void setStatus(String s) { pStatus.setText(s); }

    // ============================================================
    //  Sources sheet
    // ============================================================

    private void openSheet() {
        ui.removeCallbacks(rHideOverlay);
        overlay.animate().alpha(1f).setDuration(100).start();
        sourcesSheet.setVisibility(View.VISIBLE);
        sourceAdapter.setSelected(sourceIndex);
        // move focus into the list
        sourcesList.post(() -> {
            RecyclerView.ViewHolder h = sourcesList.findViewHolderForAdapterPosition(sourceIndex);
            if (h != null) h.itemView.requestFocus();
            else sourcesList.requestFocus();
        });
    }

    private void closeSheet() {
        sourcesSheet.setVisibility(View.GONE);
        showOverlay();
    }

    // ============================================================
    //  Key handling
    // ============================================================

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // If sheet is open, let RecyclerView handle navigation; only capture Back
        if (sourcesSheet.getVisibility() == View.VISIBLE) {
            if (keyCode == KeyEvent.KEYCODE_BACK) { closeSheet(); return true; }
            return super.onKeyDown(keyCode, event);
        }

        switch (keyCode) {
            // D-pad up/down: zap when the overlay is hidden; when it is visible,
            // the first press moves focus into the channel list and the list
            // itself consumes further presses (focus moves between rows).
            case KeyEvent.KEYCODE_DPAD_UP:
                if (overlay.getAlpha() > 0.5f) {
                    showOverlay();
                    if (pList != null && pList.hasFocus()) return super.onKeyDown(keyCode, event);
                    focusPlayerList();
                    return true;
                }
                showOverlay(); switchChannel(-1); return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                if (overlay.getAlpha() > 0.5f) {
                    showOverlay();
                    if (pList != null && pList.hasFocus()) return super.onKeyDown(keyCode, event);
                    focusPlayerList();
                    return true;
                }
                showOverlay(); switchChannel(1);  return true;

            // Hardware channel keys always zap.
            case KeyEvent.KEYCODE_CHANNEL_UP:
                showOverlay(); switchChannel(-1); return true;
            case KeyEvent.KEYCODE_CHANNEL_DOWN:
                showOverlay(); switchChannel(1);  return true;

            // Source left/right
            case KeyEvent.KEYCODE_DPAD_LEFT:
                showOverlay();
                failCount = 0;
                sourceIndex = (sourceIndex - 1 + current.sources.size()) % current.sources.size();
                loadSource();
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                showOverlay();
                failCount = 0;
                sourceIndex = (sourceIndex + 1) % current.sources.size();
                loadSource();
                return true;

            // Media keys
            case KeyEvent.KEYCODE_MEDIA_NEXT:
                showOverlay(); switchChannel(1);  return true;
            case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                showOverlay(); switchChannel(-1); return true;

            // Play / pause — with the list focused, CENTER clicks the row instead.
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                if (pList != null && pList.hasFocus()) return super.onKeyDown(keyCode, event);
                togglePlayPause();
                showOverlay();
                return true;

            // Open sources sheet
            case KeyEvent.KEYCODE_MENU:
            case KeyEvent.KEYCODE_INFO:
                openSheet();
                return true;

            // Back: first press shows overlay; second exits
            case KeyEvent.KEYCODE_BACK:
                if (overlay.getAlpha() < 0.5f) { showOverlay(); return true; }
                finish();
                return true;
        }
        showOverlay();
        return super.onKeyDown(keyCode, event);
    }

    // ============================================================
    //  ExoPlayer callbacks
    // ============================================================

    @Override
    public void onPlaybackStateChanged(int state) {
        switch (state) {
            case Player.STATE_READY:
                bufferSpinner.setVisibility(View.GONE);
                setStatus(getString(R.string.st_live));
                failCount = 0;
                break;
            case Player.STATE_BUFFERING:
                bufferSpinner.setVisibility(View.VISIBLE);
                setStatus(getString(R.string.st_buffering));
                break;
            case Player.STATE_ENDED:
                bufferSpinner.setVisibility(View.GONE);
                break;
            case Player.STATE_IDLE:
                bufferSpinner.setVisibility(View.GONE);
                break;
        }
        updatePlayBtn();
    }

    @Override
    public void onPlayerError(@NonNull PlaybackException error) {
        bufferSpinner.setVisibility(View.GONE);
        setStatus(getString(R.string.st_switching));
        ui.removeCallbacks(rNextSource);
        ui.postDelayed(rNextSource, SOURCE_RETRY_DELAY);
    }

    // ============================================================
    //  Helpers
    // ============================================================

    private List<Channel> findNavList(Channel c) {
        for (Repo.Category cat : repo.categories) {
            if (cat.channels.contains(c)) return cat.channels;
        }
        return repo.all;
    }

    private static String displayName(Channel c) {
        return c.nameEn.isEmpty() ? c.name : c.nameEn;
    }

    private static String initial(Channel c) {
        String n = displayName(c);
        return n.isEmpty() ? "T" : n.substring(0, 1).toUpperCase(Locale.US);
    }
}
