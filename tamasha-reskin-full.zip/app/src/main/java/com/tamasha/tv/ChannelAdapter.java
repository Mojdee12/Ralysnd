package com.tamasha.tv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.VH> {

    public interface OnPick { void onPick(Channel c); }

    private final List<Channel> items = new ArrayList<>();
    private final OnPick listener;

    public ChannelAdapter(List<Channel> items, OnPick listener) {
        if (items != null) this.items.addAll(items);
        this.listener = listener;
    }

    public void setItems(List<Channel> next) {
        items.clear();
        if (next != null) items.addAll(next);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_card, parent, false);
        return new VH(v, listener, items);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        h.bind(items.get(position));
    }

    @Override
    public int getItemCount() { return items.size(); }

    static String displayName(Channel c) {
        return c.nameEn.isEmpty() ? c.name : c.nameEn;
    }

    static String initial(Channel c) {
        String n = displayName(c);
        return n.isEmpty() ? "T" : n.substring(0, 1).toUpperCase(Locale.US);
    }

    static String shortCat(Channel c) {
        String cat = c.categoryEn.isEmpty() ? c.category : c.categoryEn;
        return cat.length() > 10 ? cat.substring(0, 9).trim() + "…" : cat;
    }

    static final class VH extends RecyclerView.ViewHolder {
        final ImageView logo;
        final TextView initial, name, cat, badgeVpn, tagHidden;
        final List<Channel> items;
        final OnPick listener;

        VH(@NonNull View v, OnPick listener, List<Channel> items) {
            super(v);
            this.listener = listener;
            this.items = items;

            logo     = v.findViewById(R.id.card_logo);
            initial  = v.findViewById(R.id.card_initial);
            name     = v.findViewById(R.id.card_name);
            cat      = v.findViewById(R.id.card_cat);
            badgeVpn = v.findViewById(R.id.badge_vpn);
            tagHidden = v.findViewById(R.id.card_tag);

            Fonts.setBold(name);
            Fonts.set(initial);
            Fonts.set(cat);

            v.setOnClickListener(view -> {
                int pos = getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) listener.onPick(items.get(pos));
            });

            // Focus keeps the dark tile; only a thin green ring (card_selector) + slight scale.
            v.setOnFocusChangeListener((view, hasFocus) ->
                    view.animate().scaleX(hasFocus ? 1.05f : 1f)
                            .scaleY(hasFocus ? 1.05f : 1f)
                            .setDuration(120).start());
        }

        void bind(Channel c) {
            initial.setText(initial(c));
            name.setText(displayName(c));
            String catStr = shortCat(c);
            if (catStr.isEmpty()) {
                cat.setVisibility(View.GONE);
            } else {
                cat.setVisibility(View.VISIBLE);
                cat.setText(catStr.toUpperCase(Locale.US));
            }
            badgeVpn.setVisibility(c.needVpn ? View.VISIBLE : View.GONE);
            Logos.load(logo, initial, c.logoUrl);
        }
    }
}
