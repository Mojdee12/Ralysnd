package com.tamasha.tv;

import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

/**
 * Loads a channel logo URL into an ImageView, with a letter tile as the fallback.
 * Only full http(s) URLs are loaded; bare filenames (no http scheme) are never
 * given an invented base URL — the letter tile stays.
 */
public final class Logos {
    private Logos() {}

    public static void load(ImageView logo, TextView fallback, @Nullable String url) {
        if (logo == null) return;
        if (url == null || !url.startsWith("http")) {
            logo.setVisibility(View.GONE);
            if (fallback != null) fallback.setVisibility(View.VISIBLE);
            return;
        }
        if (fallback != null) fallback.setVisibility(View.VISIBLE);
        logo.setVisibility(View.VISIBLE);
        float radiusPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 10,
                logo.getResources().getDisplayMetrics());
        Glide.with(logo)
                .load(url)
                .transform(new CenterCrop(), new RoundedCorners(Math.round(radiusPx)))
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model,
                                                Target<Drawable> target, boolean isFirstResource) {
                        logo.setVisibility(View.GONE);
                        if (fallback != null) fallback.setVisibility(View.VISIBLE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model,
                                                   Target<Drawable> target, DataSource dataSource,
                                                   boolean isFirstResource) {
                        if (fallback != null) fallback.setVisibility(View.GONE);
                        return false;
                    }
                })
                .into(logo);
    }
}
