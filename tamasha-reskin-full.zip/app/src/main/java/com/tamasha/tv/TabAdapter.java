package com.tamasha.tv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class TabAdapter extends RecyclerView.Adapter<TabAdapter.VH> {

    public interface OnTab { void onTab(String name, int index); }

    private final List<String> labels = new ArrayList<>();
    private final OnTab listener;
    private int selected = 0;

    public TabAdapter(List<String> labels, OnTab listener) {
        if (labels != null) this.labels.addAll(labels);
        this.listener = listener;
    }

    public void setSelected(int index) {
        int old = selected;
        selected = index;
        notifyItemChanged(old);
        notifyItemChanged(index);
    }

    public void setLabels(List<String> next) {
        labels.clear();
        if (next != null) labels.addAll(next);
        if (selected >= labels.size()) selected = 0;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_tab, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        h.bind(labels.get(position), position == selected, position, listener);
    }

    @Override
    public int getItemCount() { return labels.size(); }

    /** Returns a short uppercase label for a category name. */
    public static String shortLabel(String cat) {
        if (cat == null || cat.isEmpty()) return "";
        // Known mappings
        switch (cat.toLowerCase(Locale.US)) {
            case "international": return "INTL";
            case "entertainment": return "ENTERTAIN";
            case "sports":        return "SPORTS";
            case "movies & series": return "MOVIES";
            case "documentary":   return "DOCU";
            case "documentary films": return "DOCU-FILM";
            case "music":         return "MUSIC";
            case "kids":          return "KIDS";
            case "kids & family": return "KIDS";
            case "kids & teens":  return "KIDS";
            case "gem tv networks": return "GEM";
            case "telewebion":    return "TELEWEBION";
            case "arabic":        return "ARABIC";
            case "turkish":       return "TURKISH";
            case "kurdish":       return "KURDISH";
            case "gems":          return "GEMS";
            case "general":       return "GENERAL";
            default:
                String up = cat.toUpperCase(Locale.US);
                return up.length() > 9 ? up.substring(0, 8) : up;
        }
    }

    static final class VH extends RecyclerView.ViewHolder {
        final TextView label;
        int colorSelected, colorNormal;

        VH(@NonNull View v) {
            super(v);
            label = (TextView) v;
            colorSelected = ContextCompat.getColor(v.getContext(), R.color.white);
            colorNormal   = ContextCompat.getColor(v.getContext(), R.color.text_dim);
            Fonts.setBold(label);
        }

        void bind(String text, boolean isSelected, int pos, OnTab listener) {
            label.setText(text);
            label.setSelected(isSelected);
            label.setTextColor(isSelected ? colorSelected : colorNormal);
            label.setOnClickListener(v -> listener.onTab(text, pos));
        }
    }
}
