package com.tamasha.tv;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

/** Channel list shown on the right side of the player (split layout). */
public final class PlayerChannelAdapter extends RecyclerView.Adapter<PlayerChannelAdapter.VH> {

    public interface OnPick { void onPick(int position); }

    private final List<Channel> items = new ArrayList<>();
    private final OnPick listener;
    private int selected = -1;

    public PlayerChannelAdapter(List<Channel> items, OnPick listener) {
        if (items != null) this.items.addAll(items);
        this.listener = listener;
    }

    public void setSelected(int index) {
        int old = selected;
        selected = index;
        if (old >= 0) notifyItemChanged(old);
        if (index >= 0) notifyItemChanged(index);
    }

    public int getSelected() { return selected; }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_player_channel, parent, false);
        return new VH(v, listener, items);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        h.bind(items.get(position), position == selected);
    }

    @Override
    public int getItemCount() { return items.size(); }

    static final class VH extends RecyclerView.ViewHolder {
        final ImageView logo;
        final TextView initial, name, live, vpn;

        VH(@NonNull View v, OnPick listener, List<Channel> items) {
            super(v);
            logo    = v.findViewById(R.id.pl_logo);
            initial = v.findViewById(R.id.pl_initial);
            name    = v.findViewById(R.id.pl_name);
            live    = v.findViewById(R.id.pl_live);
            vpn     = v.findViewById(R.id.pl_vpn);
            Fonts.setBold(name);
            Fonts.set(initial);
            v.setOnClickListener(view -> {
                int pos = getAdapterPosition();
                if (pos != RecyclerView.NO_POSITION) listener.onPick(pos);
            });
        }

        void bind(Channel c, boolean isSelected) {
            initial.setText(ChannelAdapter.initial(c));
            name.setText(ChannelAdapter.displayName(c));
            live.setVisibility(isSelected ? View.VISIBLE : View.GONE);
            vpn.setVisibility(c.needVpn ? View.VISIBLE : View.GONE);
            itemView.setSelected(isSelected);
            Logos.load(logo, initial, c.logoUrl);
        }
    }
}
