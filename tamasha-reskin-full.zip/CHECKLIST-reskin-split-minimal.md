# Reskin checklist — Tamasha TV source, minimal split look (visual-only)

Project: `~/workspace/tamasha-src/` (TamashaTV, `com.tamasha.tv`, v2.0.0/5, Java/Views, Media3 ExoPlayer 1.5.1).
User order: HER OWN latest build. ALL 1,130 channels kept. ONLY appearance fixed. PLAYER MUST work.
Palette: bg `#0B0D10`, surface `#16191D`, surface2 `#1E2226`, line `#23282D`, text `#E8E8F0`,
text_dim `#9AA0A6`, text_faint `#5A6068`, ONE accent green `#00C853` (LIVE dot, focus ring, selected tab
underline, fav star when active). VPN badge = dark pill + green text (NOT orange). No white focus flash.
No new features, no `channels.json` change, no package/version change, no new deps except Glide 4.x (logos only).

Baseline checksums (before any edit, `/tmp/tamasha-baseline.sha256`):
- channels.json `40d9e503bd5fd8bb5473c7278da450c378a79de952ec2c48e5327b57842fe268` — MUST be identical after.
- Repo.java `b0295e3c…` / Channel.java `1d546690…` — Channel.java gets ONLY the `logoUrl` field;
  Repo.java loses ONLY the unused `hot` list. Everything else in both files untouched.
- PlayerActivity.java `ecd7e192…` — WILL change (list wiring + bottom controls only); ExoPlayer
  setup, headers, retry/failover logic must be byte-identical in the final diff review.

## 0. Palette & theme
- [ ] `values/colors.xml`: bg #0B0D10, surface #16191D, surface2 #1E2226, line #23282D,
      text_dim #9AA0A6, text_faint #5A6068, accent #00C853, live_green #00C853, tile #16191D,
      vpn_amber #F59E0B (kept ONLY as the VPN semantic value — badge itself restyled, see §5).
      DELETE unused: accent2, av0–av7, tile_hi, focused_bg, focused_text, gold (fav star → accent).
      KEEP defs ink/ink_dim (harmless, referenced by nothing after the reskin).
- [ ] `values/themes.xml`: no edit needed (references @color/accent and @color/bg symbolically).
- [ ] `values/strings.xml`: hint_nav → plain words (no ▲▼◀▶ glyphs);
      ADD `empty_fav` ("No favorites yet"), `empty_none` ("No channels"),
      `search_hint_empty` ("Type to search 1,130 channels").

## 1. Focus model (no white flash) — grid, search rows, source rows, buttons
- [ ] `drawable/card_focused_bg.xml`: rewrite → solid surface2 + 2dp stroke @color/accent, 10dp radius.
      (card_selector already points focused/selected here; default stays card_bg.)
- [ ] `drawable/search_btn_bg.xml`: focused → surface2 + 2dp accent stroke (was solid white).
- [ ] `drawable/source_item_selector.xml`: focused → surface2 + 2dp accent stroke (was solid white);
      selected wash #33FFFFFF kept.
- [ ] `drawable/tab_selector.xml`: selected underline #FFFFFF → @color/accent; focused wash kept.
- [ ] `ChannelAdapter.VH`: REMOVE ink text-color flip on focus (text stays light); keep 1.05x scale.
- [ ] `SearchActivity.ResultAdapter.VH`: REMOVE ink text-color flip on focus.
- [ ] `SourceAdapter.VH`: REMOVE ink text-color flip on focus (ACTIVE tag stays green = readable).
- [ ] `TabAdapter.VH`: selected white / normal dim — unchanged (already correct).

## 2. Logos (audit §1) + font (audit §2) + branding (audit §3)
- [ ] `Channel.java`: ADD `logoUrl` field, read from `channel_image` in loadAll (847 full URLs;
      283 bare filenames kept as-is — NO invented base URL; empty never occurs).
- [ ] `app/build.gradle`: ADD Glide 4.x (`com.github.bumptech.glide:glide:4.16.0`) — the ONE allowed dep.
- [ ] New `Fonts.java`: loads Vazirmatn regular+bold from `assets/fonts/` (copied from
      `~/workspace/ralysnd-tv/app/src/main/res/font/`), `set(TextView)` / `setBold(TextView)`,
      cached Typefaces. Applied in adapters' bind + activities' static TextViews.
- [ ] `assets/fonts/vazirmatn_regular.ttf` + `vazirmatn_bold.ttf` copied in.
- [ ] Logos shown (Glide, logo only): main grid card thumb, player-list row thumb, player banner thumb,
      search result tile. Fallback: letter tile (dark tile + initial, never a white box).
      Glide failure → initial stays visible.
- [ ] `drawable/tv_banner.png` REBUILT with Python/PIL (320×180): dark #0B0D10 bg, green rounded
      square with white R, "RALYSND" white bold text. (Old one said «تماشا» with a blank red square.)
- [ ] `drawable/logo_mark.xml`: solid → @color/accent; main top-bar "R" textColor ink → white.

## 3. Main screen (activity_main.xml + item_card.xml + item_tab.xml)
- [ ] Top bar: logo mark (green square + white R), "RALYSND", NEW `TextClock` (HH:mm, text_dim,
      no Java — `android:format24Hour`/`format12Hour`), search button (restyled bg).
- [ ] Tabs: minimal row (tab_selector underline now green when selected); shortLabel fixes in
      `TabAdapter`: "Movies & Series"→MOVIES, "Kids & Teens"→KIDS, "GEM TV Networks"→GEM,
      "Telewebion"→TELEWEBION, "Documentary Films"→DOCU-FILM (no live collisions in the 15
      categories, but the old truncations "MOVIES &" / "KIDS & T" / "GEM TV N" / "TELEWE" were ugly).
- [ ] Divider 1dp @color/line — kept.
- [ ] Grid: 5 columns kept; `item_card.xml` redesigned — logo thumb (48dp, Glide logo or initial)
      top-left as the visual anchor, VPN badge top-right (dark pill + green text), name bottom-left
      with marginEnd so it NEVER runs under the category tag (audit §7), category bottom-right.
      Card 110dp kept; focus = dark + green ring via card_selector (no white).
- [ ] Empty state (audit §8): `grid_empty` TextView centered in a FrameLayout wrapping the grid;
      "No favorites yet" on the FAVORITES tab, "No channels" otherwise. Load-failure Toast kept.
- [ ] Favorites tab (audit §8): extract tab-building in MainActivity into `buildTabs()`, called from
      onCreate AND onResume; `TabAdapter.setLabels()` added (preserve selected index, clamp);
      grid shows the selected group after rebuild. No restart needed for fav changes.
- [ ] Initial grid focus (audit §12): retry once (150ms) if the first holder is not laid out yet.
- [ ] RTL (audit §13): `android:textDirection="firstStrong"` on name TextViews (card, player, search,
      banner) — Persian renders correctly without flipping the LTR TV layout.

## 4. Player screen (activity_player.xml + PlayerActivity.java) — THE SPLIT LAYOUT
- [ ] Layout: root FrameLayout kept; PlayerView match_parent behind everything (video fills screen).
      Overlay middle row = horizontal: transparent spacer weight 2 (video shows through) + right
      list panel weight 1 (surface bg, header "UP NEXT" + divider, RecyclerView `@id/p_list`).
      Overlay top bar (back / name+status / CH counter / fav) and bottom bar span full width.
      When overlay hides (alpha 0), the list hides with it → video is truly full-screen.
- [ ] Banner (audit §6): dark pill — banner_bg → solid surface + 1dp line stroke; letter 52sp →
      48dp logo thumb (ImageView `@id/p_banner_logo` + initial `@id/p_banner_letter` fallback) +
      name + meta; NEW green "●" dot before the meta text. Still centered, still 1.8s.
- [ ] Bottom control bar (slim, all REAL controls): play/pause `@id/p_play` (▶/⏸, follows state),
      −10s `@id/p_rew`, +10s `@id/p_fwd`, VOL− `@id/p_vol_down`, VOL+ `@id/p_vol_up`,
      SOURCES `@id/p_sources_btn` (opens sheet), plus existing source label + hint text.
      NO settings button (no settings screen exists — dead button forbidden), NO fullscreen button
      (already fullscreen), NO duplicate fav (already in top bar).
- [ ] NEW `layout/item_player_channel.xml`: 56dp row — logo thumb 36dp (Glide logo or initial),
      name (14sp bold, firstStrong), green "●" LIVE dot only on the current row, VPN badge.
      Background `@drawable/player_row_selector.xml` (NEW: focused → surface2 + green ring;
      selected → transparent + green ring; default transparent).
- [ ] NEW `PlayerChannelAdapter.java`: mirrors SourceAdapter; `setSelected(int)` + scroll;
      click → switch to that channel.
- [ ] PlayerActivity wiring ONLY: bind p_list + adapter (navList), bottom buttons, `switchTo(int)`
      (switchChannel delegates to it — same behavior), `togglePlayPause()` (DPAD_CENTER delegates),
      `seekBy(long)`, `updatePlayBtn()` (called from toggle + onPlaybackStateChanged),
      `focusPlayerList()` (scroll + request focus on current row), `AudioManager` for volume.
- [ ] Key handling: overlay HIDDEN → UP/DOWN/CH_UP/CH_DOWN zap (unchanged); overlay VISIBLE →
      first DPAD_UP/DOWN moves focus INTO the list at the current row (no zap), further presses
      move focus inside the list (framework); DPAD_CENTER with list focus → row click;
      CHANNEL_UP/DOWN always zap; LEFT/RIGHT always switch source; MENU/INFO opens sheet; BACK kept.
- [ ] hideOverlay(): clear focus from the list if it has it (no invisible-focus trap).
- [ ] refreshUI(): `pListAdapter.setSelected(navIndex)` + scroll to current.
- [ ] PlayerView: `setResizeMode(RESIZE_MODE_ZOOM)` (audit §10 — 4:3 streams stop letterboxing).
- [ ] Fav star (audit §10): not-fav = "☆" outline in text_dim (visible); fav = "★" in accent green.
      (updateFav: gold → accent; also sets the glyph.)
- [ ] LIVE dot (audit §10): green "●" TextView next to p_status in the top bar.
- [ ] UNTOUCHED in PlayerActivity: ExoPlayer Builder + DefaultLoadControl, DefaultHttpDataSource
      factory + headers + agent, Hls/Progressive source choice, nextSource() failover,
      onPlayerError() retry, onPlaybackStateChanged() status logic (except updatePlayBtn() calls),
      findNavList(), displayName()/initial() helpers. Verify by re-reading after edits.

## 5. Search screen (activity_search.xml + item_result.xml + SearchActivity.java)
- [ ] Palette only via colors (search_box → surface2 automatically). No layout restructure.
- [ ] Empty query (audit §11): show hint "Type to search 1,130 channels" (was blank);
      non-empty + no results → "No channels found" (existing string).
- [ ] Result rows: logo thumb (Glide logo or initial in card_bg tile — tile now surface, follows
      the dark focus state), name firstStrong, category, VPN badge (dark pill + green text).
- [ ] ResultAdapter: remove ink focus flip (see §1).

## 6. Sources sheet (activity_player.xml sheet + item_source.xml + SourceAdapter.java)
- [ ] `drawable/sources_sheet_bg.xml`: fill #F0141420 → @color/surface, stroke #33FFFFFF → @color/line.
- [ ] `item_source.xml`: title text kept; ACTIVE tag color live_green (= #00C853 now). Root bg =
      source_item_selector (restyled §1). Selected row = wash + green ACTIVE tag, readable on focus.
- [ ] SourceAdapter: remove ink focus flip (see §1). No logic change.

## 7. Deletions (audit §4)
- [ ] DELETE 11 unused drawables: badge_live, badge_dark, tab_bg, tab_indicator, tab_text_color,
      tool_bg, epg_item_bg, logo_chip, card_focus_ring, card_ring, card_tile.
      (Verified unreferenced by the @drawable usage count before editing.)
- [ ] DELETE unused colors av0–av7 (and accent2, tile_hi, focused_bg, focused_text, gold — see §0).
- [ ] DELETE unused `hot` list in Repo.java (field + the filling loop) — ONLY Repo.java change.

## 8. Verification (before zipping)
- [ ] Re-read every changed layout + Java file after editing.
- [ ] Grep: no orange/blue/violet accent hex remains in colors/themes/layouts/drawables
      (allowed survivors: vpn_amber #F59E0B value + badge_vpn #E6830A? — NO: badge_vpn repointed
      to @color/vpn_amber; report any remaining #4F7FFF/#7B5FFF/#E6830A/#F59E0B literals).
- [ ] Checksums: channels.json identical to baseline; Repo.java/Channel.java differ ONLY as listed.
- [ ] Confirm: package, versionCode/Name, manifest, launcher/banner, no new permissions,
      no new deps except Glide, minSdk-21-safe code only (TextClock API 17+, textDirection API 17+,
      AspectRatioFrameLayout is Media3 — fine).
- [ ] Zip: `~/workspace/tamasha-reskin-split-minimal.zip` — project-relative paths under
      tamasha-src/, ONLY changed/added files + a DELETIONS list (deleted files must be removed
      on the build server too — list them in the report). Report SHA-256 + file list.

## 9. Verification results (2026-11-16, after implementation)
- [x] Every changed layout + Java file re-read after editing (activity_main, activity_player,
      item_card, item_result, item_player_channel, colors.xml, strings.xml, build.gradle,
      Main/Player/Search/ChannelAdapter/TabAdapter/SourceAdapter, Channel, Repo, Fonts, Logos,
      PlayerChannelAdapter).
- [x] channels.json checksum UNCHANGED: 40d9e503bd5fd8bb5473c7278da450c378a79de952ec2c48e5327b57842fe268.
- [x] Channel.java: ONLY the `logoUrl` field + constructor param + `channel_image` read.
      Repo.java: ONLY the `hot` field + filling loop removed (no other refs to `hot`).
- [x] PlayerActivity: ExoPlayer build (DefaultLoadControl + ExoPlayer.Builder), loadSource
      (headers/agent/HLS-vs-Progressive), nextSource failover, onPlayerError retry,
      switchChannel, findNavList, displayName/initial — all re-read, byte-identical to baseline
      except the added `updatePlayBtn()` call at the end of onPlaybackStateChanged.
- [x] Grep: NO #4F7FFF / #7B5FFF / #E6830A anywhere in res. Only #F59E0B survivor is the
      `vpn_amber` color DEFINITION itself (intentionally kept, now unreferenced by any layout).
      NO solid #FFFFFF in any drawable (the one hit was source_item_bg.xml — see deletions).
      NO references to any deleted drawable/color anywhere in app/src/main.
- [x] All 18 new ids referenced from Java exist in the layouts (grep-checked).
- [x] Package com.tamasha.tv, versionCode 5, versionName 2.0.0, manifest untouched.
      Only new dependency: Glide 4.16.0 (logos only). minSdk-21-safe: TextClock (API 17+),
      textDirection firstStrong (API 17+), AudioManager/AspectRatioFrameLayout as used.
- [x] Tab labels: verified against the real 15 categories in channels.json — no collisions;
      ugly truncations fixed (MOVIES / KIDS / GEM / TELEWEBION / DOCU-FILM).
- [x] DELETED (12 files — the 11 ordered + source_item_bg, a 12th unreferenced drawable
      whose focused state had a white 2dp stroke): badge_live, badge_dark, tab_bg,
      tab_indicator, tab_text_color, tool_bg, epg_item_bg, logo_chip, card_focus_ring,
      card_ring, card_tile, source_item_bg. These must be REMOVED on the build server too
      (they are not in the zip).

## 10. Audit items 1–13 — status
1. Logos: DONE — Channel.logoUrl from channel_image; Glide 4.16.0; logos on cards,
   player list, player banner, search rows; letter-tile fallback for the 283 bare
   filenames and any failed load; NO invented base URL.
2. Persian font: DONE — Vazirmatn regular+bold in assets/fonts, Fonts helper applied
   in adapters + activities (glyph-only views left on the system font).
3. Branding: DONE — tv_banner.png rebuilt (dark bg, green rounded square + white R,
   "RALYSND"); top-bar logo mark is now green with a white R.
4. One brand color + deletions: DONE — single green #00C853; VPN badge dark pill +
   green text; 12 unused drawables deleted; av0–av7/accent2/tile_hi/focused_bg/
   focused_text/gold removed; Repo.hot removed.
5. Focus state: DONE — no white fill anywhere; dark tile + 2dp green ring + 1.05x
   scale; all ink text flips removed; ACTIVE tag stays green on the focused row.
6. Player banner: DONE — dark pill, 48dp logo thumb + name + green ● + CH x/y (+VPN).
7. Card layout: DONE — name has 64dp marginEnd (never under the category tag);
   48dp logo thumb is the visual anchor.
8. Favorites tab stale + empty states: DONE — buildTabs() runs in onResume (selection
   preserved); grid empty state ("No favorites yet" / "No channels"); Toast kept.
9. Tabs: DONE — see §9 (no live collisions; truncations fixed).
10. Player: DONE — PlayerView RESIZE_MODE_ZOOM; fav star ☆ in text_dim when off,
    ★ in green when on; green ● next to status; hint_nav in plain words.
11. Search: DONE — empty query shows "Type to search 1,130 channels"; rows follow
    the dark+ring focus (tile stays dark, consistent).
12. Focus robustness: DONE — initial grid focus retried once after 150ms.
13. RTL: DONE — textDirection="firstStrong" on card/player/search/banner name views.
