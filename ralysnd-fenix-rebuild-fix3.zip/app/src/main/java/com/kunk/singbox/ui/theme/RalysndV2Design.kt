package com.kunk.singbox.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * V2 palette vals ONLY — recovered verbatim from ralysnd-fenix-rebuild.zip
 * (2026-10-30), which still carried the pre-deletion file. Do NOT delete
 * this file again: fix2 deleted the original RalysndV2Design.kt believing
 * its "0 callers" note, but that note counted only the five composable
 * callers, not the val references — Theme.kt's OLEDColorScheme and
 * RalysndDesign.kt's glow use V2Cyan / V2Amber / V2Background / V2Surface /
 * V2SurfaceAlt / V2Outline, so deleting the vals broke the build
 * (build #3 :app:compileDebugKotlin). The five dormant composables
 * (V2GlassCard, V2CodeBadge, V2UsageRing, V2CountryCard,
 * V2CenterConnectButton) are intentionally NOT restored here: audit m5
 * confirmed they have zero callers. If this file is ever removed again,
 * first grep the whole tree for every V2* val below.
 *
 * Values below are byte-identical to the recovered file (dark v2 palette).
 * They feed only the OLED/dark scheme and the faint home glow; the live
 * light bento UI uses Bento* colors and is unaffected.
 */

/** v2 palette (recovered verbatim). */
val V2Background = Color(0xFF070B12)
val V2Surface = Color(0xFF0E1626)
val V2SurfaceAlt = Color(0xFF13203A)
val V2Outline = Color(0xFF22314F)
val V2Cyan = Color(0xFF22D3EE)
val V2CyanDim = Color(0xFF0E7490)
val V2Amber = Color(0xFFF59E0B)
val V2Text = Color(0xFFFFFFFF)
val V2TextDim = Color(0xFF94A3B8)
