ralysnd-fenix-rebuild-fix3 — fixes for build #3 (:app:compileDebugKotlin) failures.
Apply AFTER fix2, by unzipping over ~/kunbox. Contains ONLY the 4 files below.

Contents (app/-relative):
- app/src/main/java/com/kunk/singbox/ui/theme/RalysndV2Design.kt (RECREATED, vals only)
  Restores the V2* color vals deleted by fix2, recovered verbatim from
  ralysnd-fenix-rebuild.zip. The 5 dormant composables are NOT restored
  (audit m5: zero callers). Theme.kt OLEDColorScheme + RalysndDesign.kt
  glow need these vals, so this file must exist.
- app/src/main/java/com/kunk/singbox/ipc/SingBoxIpcHub.kt (edited)
  Adds the missing GO_CORE branch to currentLiveCoreState() + the
  GoCoreVpnService import.
- app/src/main/java/com/kunk/singbox/ui/screens/GoCoreScreen.kt (edited)
  TextButton(onClick { ... }) -> TextButton(onClick = { ... }) at line 276.
- app/src/main/java/com/kunk/singbox/SingBoxApplication.kt (full local copy, unchanged)
  Overwrites the server's divergent/stale copy that referenced
  GlobalPreferences. The local file has zero such references.

GUARDS — do NOT do these, or the build breaks again:
- Do NOT re-run fix2's DELETIONS. They deleted RalysndV2Design.kt; this
  fix3 recreates it. Re-running them would delete it again.
- Do NOT re-copy ~/armanlife-trial/core-trial.aar over app/libs/core.aar.
  The server's core.aar is already stripped (42,026,637 bytes); re-copying
  the trial .aar restores the duplicate go.* classes from build #2.
- Do NOT re-apply fix1 (GoCoreBinding.kt already imports mobile.Mobile).
- Verify BEFORE building: app/libs/core.aar is still the stripped copy,
  and RalysndV2Design.kt exists after unzipping. Then clean build.
