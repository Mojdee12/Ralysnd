# Ralysnd TV — no custom ProGuard rules yet. Minification is off for
# release (see app/build.gradle.kts); keep this file so the release
# build does not fail on a missing proguard file.
