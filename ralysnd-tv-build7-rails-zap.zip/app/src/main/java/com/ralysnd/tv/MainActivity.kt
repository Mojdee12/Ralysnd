package com.ralysnd.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.ralysnd.tv.ui.theme.RalysndTvTheme

/**
 * Single activity for the whole TV app (as in the original DarkTV).
 * All navigation lives in [RalysndTvApp]; there are no other activities.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RalysndTvTheme {
                RalysndTvApp()
            }
        }
    }
}
