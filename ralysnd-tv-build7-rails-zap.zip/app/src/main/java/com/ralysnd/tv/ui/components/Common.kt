package com.ralysnd.tv.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors

/**
 * Shared building blocks for the green-split style. Every screen uses these
 * so the look is identical everywhere: dark surface cards, emerald focus
 * border, red LIVE badge, logo + name channel rows.
 */

/**
 * One shared Coil loader for channel logos: disk cache (100 MB under the
 * app cache dir) + memory cache (25% of available memory), so a logo is
 * downloaded once and every later row/tile/rail reuses it instead of
 * re-fetching over a slow connection. Built lazily and cached per process.
 */
object LogoImageLoader {
    @Volatile
    private var instance: ImageLoader? = null

    fun get(context: android.content.Context): ImageLoader =
        instance ?: synchronized(this) {
            instance ?: ImageLoader.Builder(context)
                .memoryCache {
                    MemoryCache.Builder(context)
                        .maxSizePercent(0.25)
                        .build()
                }
                .diskCache {
                    DiskCache.Builder()
                        .directory(context.cacheDir.resolve("coil_logos"))
                        .maxSizeBytes(100L * 1024L * 1024L)
                        .build()
                }
                .respectCacheHeaders(false)
                .build()
                .also { instance = it }
        }
}

/** Red LIVE pill, as on the home preview and the focused channel row. */
@Composable
fun LiveBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(RalysndTvColors.LiveRed, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "● LIVE",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}

/** Small VPN pill: marks channels the source app flags as needing a VPN
 *  to play. Only the 11 explicitly flagged channels carry it — nothing
 *  is inferred. Shown on rows, tiles and in the player. */
@Composable
fun VpnBadge(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .border(
                width = 1.dp,
                color = RalysndTvColors.GreenPrimary,
                RoundedCornerShape(8.dp),
            )
            .background(RalysndTvColors.SurfaceElevated, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "VPN",
            color = RalysndTvColors.GreenPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}

/** Channel logo: remote image when present, initial letter on a green tile when not.
 * 209 of the 383 channels ship without a logo, so the fallback is part of the design.
 * Logos that fail to load (e.g. blocked hosts) fall back to the letter tile too —
 * never a blank white box. Logos go through the shared cached loader, requested
 * at 192px (covers the largest 84dp tile) so a logo is fetched once, downsampled
 * once, and reused from cache everywhere it appears. */
@Composable
fun ChannelLogo(channel: Channel, modifier: Modifier = Modifier) {
    var loadFailed by remember(channel.logo) { mutableStateOf(false) }
    if (channel.logo.isNotBlank() && !loadFailed) {
        val context = LocalContext.current
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(channel.logo)
                .size(192)
                .memoryCachePolicy(CachePolicy.ENABLED)
                .diskCachePolicy(CachePolicy.ENABLED)
                .build(),
            imageLoader = LogoImageLoader.get(context),
            contentDescription = channel.name,
            contentScale = ContentScale.Fit,
            onError = { loadFailed = true },
            modifier = modifier
                .clip(RoundedCornerShape(8.dp))
                .background(RalysndTvColors.SurfaceElevated),
        )
    } else {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(8.dp))
                .background(RalysndTvColors.GreenDark),
            contentAlignment = Alignment.Center,
        ) {
            Text(
                text = channel.name.firstOrNull()?.uppercase() ?: "•",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
        }
    }
}

/**
 * A D-pad focusable card. Focused state gets the emerald border + slight
 * surface lift used across all mockups; unfocused state is the plain dark card.
 */
@Composable
fun FocusableCard(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = modifier
            .border(
                BorderStroke(
                    width = if (focused) 3.dp else 1.dp,
                    color = if (focused) RalysndTvColors.GreenPrimary
                    else RalysndTvColors.SurfaceElevated,
                ),
                RoundedCornerShape(16.dp),
            )
            .background(
                if (focused) RalysndTvColors.SurfaceElevated
                else RalysndTvColors.Surface,
                RoundedCornerShape(16.dp),
            )
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

/** One channel row: logo + name (+ LIVE badge when it is the playing channel). */
@Composable
fun ChannelRow(
    channel: Channel,
    isPlaying: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FocusableCard(
        onClick = onClick,
        modifier = modifier,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        ) {
            ChannelLogo(channel, Modifier.size(48.dp))
            Spacer(Modifier.width(14.dp))
            Text(
                text = channel.name,
                color = RalysndTvColors.TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = RalysndFontFamily,
                modifier = Modifier.weight(1f),
            )
            if (channel.needsVpn) {
                VpnBadge()
                Spacer(Modifier.width(8.dp))
            }
            if (isPlaying) LiveBadge()
        }
    }
}

/** Bottom D-pad hint bar, as on the home mockup. */
@Composable
fun DpadHint(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = RalysndTvColors.TextMuted,
        fontSize = 16.sp,
        fontFamily = RalysndFontFamily,
        textAlign = TextAlign.Center,
        modifier = modifier,
    )
}
