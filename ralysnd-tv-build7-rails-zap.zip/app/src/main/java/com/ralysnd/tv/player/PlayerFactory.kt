package com.ralysnd.tv.player

import android.content.Context
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import com.ralysnd.tv.data.SettingsStore

/**
 * Media3 ExoPlayer factory — the player stays ExoPlayer (user order).
 * Tuned for live HLS: small live offset, short rebuffer, and buffer sizes
 * that follow the Settings screen (Small / Medium / Large).
 */
object PlayerFactory {

    /** One media item per stream URL, with a low-latency live configuration.
     *  The MIME type is set explicitly: most streams are HLS (.m3u8, some
     *  with a ?token= query), BBC Persian also carries DASH (.mpd)
     *  alternates, and ExoPlayer must not guess from the bare URI. */
    fun mediaItemFor(url: String): MediaItem {
        val mimeType = when {
            ".mpd" in url -> MimeTypes.APPLICATION_MPD
            ".m3u8" in url -> MimeTypes.APPLICATION_M3U8
            else -> null
        }
        return MediaItem.Builder()
            .setUri(url)
            .apply { mimeType?.let { setMimeType(it) } }
            .setLiveConfiguration(
                MediaItem.LiveConfiguration.Builder()
                    .setTargetOffsetMs(2_000)
                    .setMinPlaybackSpeed(0.98f)
                    .setMaxPlaybackSpeed(1.02f)
                    .build()
            )
            .build()
    }

    fun create(context: Context, settings: SettingsStore): ExoPlayer {
        val (minBufferMs, maxBufferMs) = when (settings.bufferSize) {
            SettingsStore.BufferSize.SMALL -> 8_000 to 16_000
            SettingsStore.BufferSize.MEDIUM -> 15_000 to 30_000
            SettingsStore.BufferSize.LARGE -> 30_000 to 60_000
        }
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                minBufferMs,
                maxBufferMs,
                /* bufferForPlaybackMs = */ 2_500,
                /* bufferForPlaybackAfterRebufferMs = */ 5_000,
            )
            .build()
        return ExoPlayer.Builder(context)
            .setLoadControl(loadControl)
            .setBandwidthMeter(DefaultBandwidthMeter.getSingletonInstance(context))
            .build()
            .apply {
                // Cap the picked rendition at the chosen video quality.
                trackSelectionParameters = trackSelectionParameters.buildUpon()
                    .setMaxVideoSize(Int.MAX_VALUE, settings.videoQuality.maxHeight)
                    .setPreferredAudioLanguage(
                        when (settings.audioLanguage) {
                            "en" -> "en"
                            "fa" -> "fa"
                            else -> null
                        }
                    )
                    .setPreferredTextLanguage(if (settings.subtitlesEnabled) "fa" else null)
                    .setTrackTypeDisabled(
                        C.TRACK_TYPE_TEXT,
                        !settings.subtitlesEnabled,
                    )
                    .build()
            }
    }

    /** Playback speeds offered by the player control bar (same as the original). */
    val SPEEDS: List<Float> = listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)

    fun nextSpeed(current: Float): Float {
        val index = SPEEDS.indexOfFirst { it == current }.takeIf { it >= 0 } ?: 3
        return SPEEDS[(index + 1) % SPEEDS.size]
    }

    fun formatSpeed(speed: Float): String =
        if (speed == 1f) "1x" else "${speed}x"
}
