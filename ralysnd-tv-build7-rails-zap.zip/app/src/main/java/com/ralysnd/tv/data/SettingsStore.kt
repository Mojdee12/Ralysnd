package com.ralysnd.tv.data

import android.content.Context

/**
 * Playback preferences shown on the Settings screen, persisted in
 * SharedPreferences. Defaults match the approved settings mockup:
 * Auto 1080p, Medium buffer, autoplay next channel on, subtitles off,
 * audio language Persian.
 */
class SettingsStore(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    enum class VideoQuality(val label: String, val maxHeight: Int) {
        AUTO("Auto 1080p", 1080),
        HD_1080("1080p", 1080),
        HD_720("720p", 720),
        SD_480("480p", 480),
    }

    enum class BufferSize(val label: String) {
        SMALL("Small"),
        MEDIUM("Medium"),
        LARGE("Large"),
    }

    var videoQuality: VideoQuality
        get() = runCatching {
            VideoQuality.valueOf(prefs.getString(KEY_QUALITY, VideoQuality.AUTO.name)!!)
        }.getOrDefault(VideoQuality.AUTO)
        set(value) = prefs.edit().putString(KEY_QUALITY, value.name).apply()

    var bufferSize: BufferSize
        get() = runCatching {
            BufferSize.valueOf(prefs.getString(KEY_BUFFER, BufferSize.MEDIUM.name)!!)
        }.getOrDefault(BufferSize.MEDIUM)
        set(value) = prefs.edit().putString(KEY_BUFFER, value.name).apply()

    var autoplayNextChannel: Boolean
        get() = prefs.getBoolean(KEY_AUTOPLAY, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTOPLAY, value).apply()

    var subtitlesEnabled: Boolean
        get() = prefs.getBoolean(KEY_SUBTITLES, false)
        set(value) = prefs.edit().putBoolean(KEY_SUBTITLES, value).apply()

    /** "fa", "en" or "auto". */
    var audioLanguage: String
        get() = prefs.getString(KEY_AUDIO_LANG, "fa") ?: "fa"
        set(value) = prefs.edit().putString(KEY_AUDIO_LANG, value).apply()

    companion object {
        private const val PREFS_NAME = "ralysnd_tv_settings"
        private const val KEY_QUALITY = "video_quality"
        private const val KEY_BUFFER = "buffer_size"
        private const val KEY_AUTOPLAY = "autoplay_next_channel"
        private const val KEY_SUBTITLES = "subtitles_enabled"
        private const val KEY_AUDIO_LANG = "audio_language"
    }
}
