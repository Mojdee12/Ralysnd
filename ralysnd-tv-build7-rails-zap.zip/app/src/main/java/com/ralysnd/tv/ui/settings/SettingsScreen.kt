package com.ralysnd.tv.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ralysnd.tv.BuildConfig
import com.ralysnd.tv.data.ChannelRepository
import com.ralysnd.tv.data.SettingsStore
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors

/**
 * Settings — the approved settings mockup: top bar (wordmark + Settings +
 * status), left nav (Playback, Video Quality, Subtitles, Audio, About) and
 * right rows (Video quality, Buffer size, Autoplay next channel, Subtitles,
 * Audio language, App version). Values persist in SettingsStore and apply
 * to the player on its next start.
 */
@Composable
fun SettingsScreen(
    settings: SettingsStore,
    channelCount: Int,
    modifier: Modifier = Modifier,
) {
    var section by remember { mutableStateOf(Section.PLAYBACK) }
    // Read once per composition; rows write through SettingsStore directly.
    var quality by remember { mutableStateOf(settings.videoQuality) }
    var buffer by remember { mutableStateOf(settings.bufferSize) }
    var autoplay by remember { mutableStateOf(settings.autoplayNextChannel) }
    var subtitles by remember { mutableStateOf(settings.subtitlesEnabled) }
    var audioLang by remember { mutableStateOf(settings.audioLanguage) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(RalysndTvColors.Background)
            .padding(horizontal = 32.dp, vertical = 20.dp),
    ) {
        // ---- Top bar ---------------------------------------------------------
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(RalysndTvColors.Surface)
                .padding(horizontal = 20.dp, vertical = 14.dp),
        ) {
            Text(
                text = "Ralysnd ",
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Text(
                text = "TV",
                color = RalysndTvColors.GreenPrimary,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Spacer(Modifier.width(48.dp))
            Text(
                text = "Settings",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = "$channelCount channels",
                color = RalysndTvColors.TextMuted,
                fontSize = 16.sp,
                fontFamily = RalysndFontFamily,
            )
        }

        Spacer(Modifier.height(20.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            // ---- Left nav ----------------------------------------------------
            Column(
                modifier = Modifier
                    .width(300.dp)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(20.dp))
                    .background(RalysndTvColors.Surface)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                for (item in Section.entries) {
                    NavRow(
                        label = item.label,
                        selected = section == item,
                        onClick = { section = item },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }

            // ---- Right panel ---------------------------------------------------
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(20.dp))
                    .background(RalysndTvColors.Surface)
                    .padding(24.dp),
            ) {
                Text(
                    text = section.title,
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = RalysndFontFamily,
                )
                Text(
                    text = section.subtitle,
                    color = RalysndTvColors.TextMuted,
                    fontSize = 16.sp,
                    fontFamily = RalysndFontFamily,
                )
                Spacer(Modifier.height(18.dp))
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    when (section) {
                        Section.PLAYBACK -> {
                            item {
                                CycleRow(
                                    title = "Video quality",
                                    value = quality.label,
                                    onClick = {
                                        quality = SettingsStore.VideoQuality.entries[
                                            (quality.ordinal + 1) % SettingsStore.VideoQuality.entries.size
                                        ]
                                        settings.videoQuality = quality
                                    },
                                )
                            }
                            item {
                                CycleRow(
                                    title = "Buffer size",
                                    value = buffer.label,
                                    onClick = {
                                        buffer = SettingsStore.BufferSize.entries[
                                            (buffer.ordinal + 1) % SettingsStore.BufferSize.entries.size
                                        ]
                                        settings.bufferSize = buffer
                                    },
                                )
                            }
                            item {
                                ToggleRow(
                                    title = "Autoplay next channel",
                                    value = if (autoplay) "On" else "Off",
                                    checked = autoplay,
                                    onToggle = {
                                        autoplay = it
                                        settings.autoplayNextChannel = it
                                    },
                                )
                            }
                            item {
                                ToggleRow(
                                    title = "Subtitles",
                                    value = if (subtitles) "On" else "Off",
                                    checked = subtitles,
                                    onToggle = {
                                        subtitles = it
                                        settings.subtitlesEnabled = it
                                    },
                                )
                            }
                            item {
                                CycleRow(
                                    title = "Audio language",
                                    value = audioLanguageLabel(audioLang),
                                    onClick = {
                                        audioLang = when (audioLang) {
                                            "fa" -> "en"
                                            "en" -> "auto"
                                            else -> "fa"
                                        }
                                        settings.audioLanguage = audioLang
                                    },
                                )
                            }
                            item {
                                InfoRow(
                                    title = "App version",
                                    value = "${BuildConfig.VERSION_NAME} • Ralysnd TV",
                                )
                            }
                        }
                        Section.VIDEO_QUALITY -> {
                            items(SettingsStore.VideoQuality.entries) { option ->
                                CycleRow(
                                    title = option.label,
                                    value = if (option == quality) "Selected" else "",
                                    onClick = {
                                        quality = option
                                        settings.videoQuality = option
                                    },
                                )
                            }
                        }
                        Section.SUBTITLES -> {
                            item {
                                ToggleRow(
                                    title = "Subtitles",
                                    value = if (subtitles) "On" else "Off",
                                    checked = subtitles,
                                    onToggle = {
                                        subtitles = it
                                        settings.subtitlesEnabled = it
                                    },
                                )
                            }
                        }
                        Section.AUDIO -> {
                            item {
                                CycleRow(
                                    title = "Audio language",
                                    value = audioLanguageLabel(audioLang),
                                    onClick = {
                                        audioLang = when (audioLang) {
                                            "fa" -> "en"
                                            "en" -> "auto"
                                            else -> "fa"
                                        }
                                        settings.audioLanguage = audioLang
                                    },
                                )
                            }
                        }
                        Section.ABOUT -> {
                            item {
                                InfoRow(
                                    title = "App version",
                                    value = "${BuildConfig.VERSION_NAME} • Ralysnd TV",
                                )
                            }
                            item {
                                InfoRow(
                                    title = "Channels",
                                    value = "$channelCount live channels",
                                )
                            }
                            item {
                                InfoRow(
                                    title = "Player",
                                    value = "Media3 ExoPlayer",
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private enum class Section(val label: String, val title: String, val subtitle: String) {
    PLAYBACK("Playback", "Playback Settings", "Configure playback and streaming preferences"),
    VIDEO_QUALITY("Video Quality", "Video Quality", "Maximum rendition the player may pick"),
    SUBTITLES("Subtitles", "Subtitles", "Subtitle display for live channels"),
    AUDIO("Audio", "Audio", "Preferred audio language"),
    ABOUT("About", "About", "Ralysnd TV"),
}

private fun audioLanguageLabel(code: String): String = when (code) {
    "fa" -> "Persian"
    "en" -> "English"
    else -> "Auto"
}

@Composable
private fun NavRow(label: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = modifier
            .border(
                width = if (focused) 3.dp else 0.dp,
                color = if (focused) Color.White else Color.Transparent,
                RoundedCornerShape(14.dp),
            )
            .background(
                if (selected) RalysndTvColors.GreenPrimary else Color.Transparent,
                RoundedCornerShape(14.dp),
            )
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 18.dp, vertical = 14.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        Text(
            text = label,
            color = if (selected) Color.Black else Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = RalysndFontFamily,
        )
    }
}

@Composable
private fun SettingRowShell(
    title: String,
    value: String,
    onClick: (() -> Unit)?,
    trailing: @Composable () -> Unit,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    val clickableModifier = if (onClick != null) {
        Modifier
            .focusable(interactionSource = interactionSource)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
    } else {
        Modifier
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (focused) 3.dp else 1.dp,
                color = if (focused) RalysndTvColors.GreenPrimary
                else RalysndTvColors.SurfaceElevated,
                RoundedCornerShape(14.dp),
            )
            .background(RalysndTvColors.SurfaceElevated, RoundedCornerShape(14.dp))
            .then(clickableModifier)
            .padding(horizontal = 18.dp, vertical = 14.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = RalysndFontFamily,
            )
            Text(
                text = value,
                color = RalysndTvColors.TextMuted,
                fontSize = 16.sp,
                fontFamily = RalysndFontFamily,
            )
        }
        trailing()
    }
}

@Composable
private fun CycleRow(title: String, value: String, onClick: () -> Unit) {
    SettingRowShell(title = title, value = value, onClick = onClick) {
        Text(
            text = "›",
            color = RalysndTvColors.GreenPrimary,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun ToggleRow(title: String, value: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    SettingRowShell(title = title, value = value, onClick = { onToggle(!checked) }) {
        Switch(
            checked = checked,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = RalysndTvColors.GreenPrimary,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = RalysndTvColors.PillGrey,
            ),
        )
    }
}

@Composable
private fun InfoRow(title: String, value: String) {
    SettingRowShell(title = title, value = value, onClick = null) {}
}
