package com.ralysnd.tv

import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.data.ChannelRepository
import com.ralysnd.tv.data.SettingsStore
import com.ralysnd.tv.ui.channels.ChannelsScreen
import com.ralysnd.tv.ui.home.HomeScreen
import com.ralysnd.tv.ui.player.PlayerScreen
import com.ralysnd.tv.ui.settings.SettingsScreen

/** Navigation destinations. One activity, four screens, D-pad throughout. */
sealed interface Screen {
    data object Home : Screen
    data object Channels : Screen
    data class Player(val channelId: String) : Screen
    data object Settings : Screen
}

@Composable
fun RalysndTvApp() {
    val context = LocalContext.current
    val repository = remember {
        runCatching { ChannelRepository.load(context) }
            .getOrElse { ChannelRepository(emptyList()) }
    }
    val settings = remember { SettingsStore(context) }
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

    // Back from anywhere returns to Home; back from Home exits (default).
    BackHandler(enabled = screen != Screen.Home) {
        screen = Screen.Home
    }

    when (val current = screen) {
        Screen.Home -> HomeScreen(
            repository = repository,
            settings = settings,
            onPlay = { channel -> screen = Screen.Player(channel.id) },
            onOpenChannels = { screen = Screen.Channels },
            onOpenSettings = { screen = Screen.Settings },
        )
        Screen.Channels -> ChannelsScreen(
            repository = repository,
            onPlay = { channel -> screen = Screen.Player(channel.id) },
        )
        is Screen.Player -> {
            val channel: Channel? = repository.channelById(current.channelId)
            if (channel == null) {
                screen = Screen.Home
            } else {
                PlayerScreen(
                    channel = channel,
                    repository = repository,
                    settings = settings,
                    onBack = { screen = Screen.Home },
                    onChannelSelected = { next -> screen = Screen.Player(next.id) },
                )
            }
        }
        Screen.Settings -> SettingsScreen(
            settings = settings,
            channelCount = repository.all.size,
        )
    }
}
