package com.ralysnd.tv.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.ralysnd.tv.data.Channel
import com.ralysnd.tv.data.ChannelRepository
import com.ralysnd.tv.data.SettingsStore
import com.ralysnd.tv.player.PlayerFactory
import com.ralysnd.tv.ui.components.ChannelLogo
import com.ralysnd.tv.ui.components.DpadHint
import com.ralysnd.tv.ui.components.FocusableCard
import com.ralysnd.tv.ui.components.LiveBadge
import com.ralysnd.tv.ui.theme.RalysndFontFamily
import com.ralysnd.tv.ui.theme.RalysndTvColors
import kotlinx.coroutines.delay

/**
 * Home — the approved rails look (build 7, mockup F):
 * slim left nav rail (wordmark, Home + categories with channel counts,
 * All Channels, Settings at the bottom), a top featured HERO = the live
 * muted preview of the selected channel (name + category + LIVE badge +
 * green Watch button), and below it horizontal rails per category.
 * OK on a rail card selects it into the hero; OK on the hero / Watch
 * plays it. D-pad moves between nav, hero and rails; the focused card
 * gets the emerald border.
 *
 * Deliberately NO lookup field anywhere on this screen: the original
 * app has none and it was not approved for the rebuild. NO invented
 * data either: no viewer counts, no program names or synopses, no EPG —
 * a rail card shows only the channel's logo and name, which is real.
 */
@Composable
fun HomeScreen(
    repository: ChannelRepository,
    settings: SettingsStore,
    onPlay: (Channel) -> Unit,
    onOpenChannels: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // Nav categories, computed once: the bundled data never changes.
    val navCategories = remember(repository) { navCategoryOrder(repository) }
    val navCounts = remember(repository) {
        navCategories.associateWith { repository.channelsFor(it).size }
    }
    var navCategory by remember { mutableStateOf(ChannelRepository.CATEGORY_ALL) }

    val channelsForNav = remember(navCategory) {
        repository.channelsFor(navCategory).filter { it.isPlayable }
    }
    var selectedChannel by remember(navCategory) {
        mutableStateOf(channelsForNav.firstOrNull())
    }

    // The hero text follows the selection at once, but the preview video
    // only switches after 300ms with no further movement — scrolling fast
    // through rails must not thrash the player on a slow connection.
    var previewChannel by remember { mutableStateOf(selectedChannel) }
    LaunchedEffect(selectedChannel) {
        if (previewChannel != selectedChannel) {
            previewChannel = null
            delay(300)
            previewChannel = selectedChannel
        }
    }

    // "All" shows the big categories in fixed order; a chosen category
    // shows just its own rail. Empty categories never get a rail.
    val rails = remember(navCategory) { railsFor(repository, navCategory) }

    Row(
        modifier = modifier
            .fillMaxSize()
            .background(RalysndTvColors.Background)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp),
    ) {
        // ---- Left: slim nav rail ------------------------------------------
        Column(
            modifier = Modifier
                .width(220.dp)
                .fillMaxSize()
                .clip(RoundedCornerShape(20.dp))
                .background(RalysndTvColors.Surface)
                .padding(16.dp),
        ) {
            Text(
                text = "Ralysnd ",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Text(
                text = "TV",
                color = RalysndTvColors.GreenPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = RalysndFontFamily,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = "${repository.all.size} channels",
                color = RalysndTvColors.TextMuted,
                fontSize = 14.sp,
                fontFamily = RalysndFontFamily,
            )
            Spacer(Modifier.height(16.dp))
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f),
            ) {
                items(navCategories, key = { it }) { category ->
                    NavRailRow(
                        label = categoryLabel(category),
                        count = navCounts[category] ?: 0,
                        selected = category == navCategory,
                        onClick = { navCategory = category },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                item {
                    NavRailRow(
                        label = "All Channels",
                        count = null,
                        selected = false,
                        onClick = onOpenChannels,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            NavRailRow(
                label = "⚙ Settings",
                count = null,
                selected = false,
                onClick = onOpenSettings,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(10.dp))
            DpadHint(
                text = "OK to play • ← → rails",
                modifier = Modifier.fillMaxWidth(),
            )
        }

        // ---- Right: hero + rails -------------------------------------------
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxSize(),
        ) {
            // Hero: live muted preview of the selected channel.
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.44f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black),
            ) {
                // The preview player stays composed even while the
                // selection is debouncing (previewChannel null): the
                // single player instance survives and only its media
                // item swaps, instead of being released and recreated
                // on every rail scroll.
                MutedPreviewPlayer(
                    channel = previewChannel,
                    settings = settings,
                    modifier = Modifier.fillMaxSize(),
                )
                // Bottom overlay: LIVE badge + name + category + Watch.
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .background(RalysndTvColors.Background.copy(alpha = 0.78f))
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                ) {
                    LiveBadge()
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = selectedChannel?.name ?: "",
                            color = Color.White,
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = RalysndFontFamily,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = categoryLabel(
                                selectedChannel?.categories?.firstOrNull()
                                    ?: ChannelRepository.CATEGORY_ALL,
                            ),
                            color = RalysndTvColors.TextMuted,
                            fontSize = 16.sp,
                            fontFamily = RalysndFontFamily,
                        )
                    }
                    Spacer(Modifier.width(16.dp))
                    OpenPlayerButton(
                        enabled = selectedChannel != null,
                        onClick = { selectedChannel?.let(onPlay) },
                    )
                }
            }

            Spacer(Modifier.height(18.dp))

            // Rails: one horizontal row of channel cards per category.
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(18.dp),
                modifier = Modifier.weight(0.56f),
            ) {
                items(rails, key = { it.key }) { rail ->
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = rail.label,
                                color = Color.White,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = RalysndFontFamily,
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = "• ${rail.channels.size}",
                                color = RalysndTvColors.TextMuted,
                                fontSize = 16.sp,
                                fontFamily = RalysndFontFamily,
                            )
                        }
                        Spacer(Modifier.height(10.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            items(rail.channels, key = { it.id }) { channel ->
                                RailCard(
                                    channel = channel,
                                    selected = channel.id == selectedChannel?.id,
                                    onClick = { selectedChannel = channel },
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/** One rail: a category key, its display label, and its playable channels. */
private data class Rail(
    val key: String,
    val label: String,
    val channels: List<Channel>,
)

/** Rails for the current nav selection. "All" = the big categories in
 *  fixed order; a chosen category = just its own rail. */
private fun railsFor(repository: ChannelRepository, navCategory: String): List<Rail> {
    val keys = if (navCategory == ChannelRepository.CATEGORY_ALL) {
        listOf("movies", "entertainment", "news", "sports", "music", "general")
    } else {
        listOf(navCategory)
    }
    return keys.mapNotNull { key ->
        val list = repository.channelsFor(key).filter { it.isPlayable }
        if (list.isEmpty()) null else Rail(key, categoryLabel(key), list)
    }
}

/** Nav order: the named categories first (only the ones that exist),
 *  then any other present categories in the repository's count order,
 *  so no channel is ever unreachable from Home. */
private fun navCategoryOrder(repository: ChannelRepository): List<String> {
    val preferred = listOf(
        "movies", "series", "entertainment", "news",
        "sports", "music", "kids", "documentary",
    )
    val present = repository.categories.filter { it != ChannelRepository.CATEGORY_ALL }
    val ordered = preferred.filter { it in present } +
        present.filter { it !in preferred }
    return listOf(ChannelRepository.CATEGORY_ALL) + ordered
}

@Composable
private fun NavRailRow(
    label: String,
    count: Int?,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FocusableCard(
        onClick = onClick,
        modifier = modifier,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (selected) RalysndTvColors.GreenPrimary
                    else RalysndTvColors.Surface,
                    RoundedCornerShape(16.dp),
                )
                .padding(horizontal = 16.dp, vertical = 11.dp),
        ) {
            Text(
                text = label,
                color = if (selected) RalysndTvColors.Background
                else RalysndTvColors.TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = RalysndFontFamily,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            if (count != null) {
                Text(
                    text = "$count",
                    color = if (selected) RalysndTvColors.Background
                    else RalysndTvColors.TextMuted,
                    fontSize = 14.sp,
                    fontFamily = RalysndFontFamily,
                )
            }
        }
    }
}

/** One rail card: logo + name; the hero's channel also shows LIVE. */
@Composable
private fun RailCard(
    channel: Channel,
    selected: Boolean,
    onClick: () -> Unit,
) {
    FocusableCard(
        onClick = onClick,
        modifier = Modifier.width(250.dp),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
        ) {
            ChannelLogo(channel, Modifier.size(56.dp))
            Spacer(Modifier.width(12.dp))
            Text(
                text = channel.name,
                color = RalysndTvColors.TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = RalysndFontFamily,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            if (selected) {
                Spacer(Modifier.width(8.dp))
                LiveBadge()
            }
        }
    }
}

@Composable
private fun OpenPlayerButton(enabled: Boolean, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val focused by interactionSource.collectIsFocusedAsState()
    Box(
        modifier = Modifier
            .border(
                width = if (focused) 3.dp else 0.dp,
                color = if (focused) Color.White else Color.Transparent,
                RoundedCornerShape(24.dp),
            )
            .background(RalysndTvColors.GreenPrimary, RoundedCornerShape(24.dp))
            .focusable(enabled, interactionSource)
            .clickable(enabled = enabled, interactionSource = interactionSource, indication = null) { onClick() }
            .padding(horizontal = 24.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = "▶ Watch",
            color = Color.Black,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = RalysndFontFamily,
        )
    }
}

/**
 * Muted live preview of the selected channel. A SINGLE player instance
 * for the whole Home screen: switching the channel only swaps its media
 * item, the player is never recreated per selection. Released when the
 * home screen leaves. The hero is a wide banner, so the video zooms to
 * fill it instead of letterboxing.
 */
@Composable
private fun MutedPreviewPlayer(
    channel: Channel?,
    settings: SettingsStore,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val player = remember {
        PlayerFactory.create(context, settings).apply { volume = 0f }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    LaunchedEffect(channel) {
        val url = channel?.primaryUrl ?: return@LaunchedEffect
        player.setMediaItem(PlayerFactory.mediaItemFor(url))
        player.prepare()
        player.play()
    }
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                useController = false
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            }
        },
        modifier = modifier,
    )
}

/** Display label for a category key ("all" -> "All", "general" -> "General", ...). */
fun categoryLabel(category: String): String =
    category.replaceFirstChar { it.uppercase() }
