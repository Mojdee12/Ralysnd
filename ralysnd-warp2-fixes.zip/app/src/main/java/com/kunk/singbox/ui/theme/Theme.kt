﻿package com.kunk.singbox.ui.theme

import android.app.Activity
import androidx.compose.ui.graphics.Color
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RippleConfiguration
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.kunk.singbox.model.AppThemeMode
import com.kunk.singbox.model.AppThemeStyle

// RALYSND v2 Dark Theme — deep navy-black, cyan primary, amber secondary.
// Approved second mockup: this palette now drives every screen (Dashboard,
// Nodes, Profiles, FENIX, Settings) through MaterialTheme, so the whole
// app shares one visual system without touching any screen's logic.
private val OLEDColorScheme = darkColorScheme(
    primary = V2Cyan,
    onPrimary = V2Background,
    secondary = V2Amber,
    onSecondary = V2Background,
    tertiary = V2Cyan,
    background = V2Background,
    onBackground = PureWhite,
    surface = V2Surface,
    onSurface = PureWhite,
    surfaceVariant = V2SurfaceAlt,
    onSurfaceVariant = Neutral400,
    outline = V2Outline,
    error = Destructive
)

// Light Theme
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF16A34A),
    onPrimary = LightSurface,
    secondary = LightTextSecondary,
    onSecondary = LightTextPrimary,
    tertiary = LightTextSecondary,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightTextSecondary,
    outline = LightDivider,
    error = Destructive
)

@Suppress("FunctionNaming")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SingBoxTheme(
    appTheme: AppThemeMode = AppThemeMode.SYSTEM,
    appThemeStyle: AppThemeStyle = AppThemeStyle.DEFAULT,
    content: @Composable () -> Unit
) {
    // RALYSND sample-4 (approved clean light theme): the whole app
    // renders light regardless of the system setting, so the panel
    // looks exactly like the approved sample on every device. The
    // theme setting is intentionally overridden by this decision.
    @Suppress("UNUSED_VARIABLE")
    val isSystemDark = isSystemInDarkTheme()
    val useDarkTheme = false

    val colorScheme = if (useDarkTheme) OLEDColorScheme else LightColorScheme
    val rippleConfiguration = if (appThemeStyle == AppThemeStyle.LIQUID_GLASS) {
        null
    } else {
        RippleConfiguration()
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window

            window.statusBarColor = android.graphics.Color.TRANSPARENT
            window.navigationBarColor = android.graphics.Color.TRANSPARENT

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                window.isNavigationBarContrastEnforced = false
            }
            // 启用沉浸式布局，内容延伸到系统栏区域。
            WindowCompat.setDecorFitsSystemWindows(window, false)

            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = !useDarkTheme
            insetsController.isAppearanceLightNavigationBars = !useDarkTheme
        }
    }

    CompositionLocalProvider(
        LocalAppThemeStyle provides appThemeStyle,
        LocalRippleConfiguration provides rippleConfiguration
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
